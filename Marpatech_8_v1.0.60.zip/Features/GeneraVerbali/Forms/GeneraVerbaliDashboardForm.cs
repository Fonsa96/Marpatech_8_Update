﻿using Inventor;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.Mail;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public class GeneraVerbaliDashboardForm : Form
    {
        private readonly Inventor.Application
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        public GeneraVerbaliDashboardForm(
            Inventor.Application inventorApp,
            FeatureOpenContext openContext)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliDashboard",
                    620,
                    330);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);
        }


        private void InitializeComponent()
        {
            System.Drawing.Color backgroundColor =
                _isDarkTheme
                    ? System.Drawing.Color.FromArgb(18, 18, 22)
                    : System.Drawing.Color.FromArgb(245, 247, 250);

            System.Drawing.Color panelColor =
                _isDarkTheme
                    ? System.Drawing.Color.FromArgb(32, 34, 40)
                    : System.Drawing.Color.White;

            System.Drawing.Color titleColor =
                _isDarkTheme
                    ? System.Drawing.Color.White
                    : System.Drawing.Color.FromArgb(30, 41, 59);

            Text =
                "Genera Verbali";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new System.Drawing.Size(
                    620,
                    330);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliDashboardForm_FormClosing;


            /*
             * ==========================================
             * TITOLO
             * ==========================================
             */
            Label titleLabel =
                new Label
                {
                    Text =
                        "Genera Verbali",

                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            24F,
                            System.Drawing.FontStyle.Bold),

                    ForeColor =
                        titleColor,

                    AutoSize =
                        true,

                    Location =
                        new System.Drawing.Point(
                            35,
                            28)
                };


            /*
             * ==========================================
             * IMPOSTAZIONI
             * ==========================================
             */
            Button settingsButton =
                new Button
                {
                    Text =
                        "⚙",

                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            18F,
                            System.Drawing.FontStyle.Regular),

                    Size =
                        new System.Drawing.Size(
                            42,
                            42),

                    Location =
                        new System.Drawing.Point(
                            ClientSize.Width - 70,
                            28),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        titleColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            settingsButton.FlatAppearance.BorderSize =
                0;

            settingsButton.Click +=
                SettingsButton_Click;


            /*
             * ==========================================
             * CONTENITORE MODALITÀ
             * ==========================================
             */
            Panel modesPanel =
                new Panel
                {
                    Location =
                        new System.Drawing.Point(
                            35,
                            95),

                    Size =
                        new System.Drawing.Size(
                            ClientSize.Width - 70,
                            ClientSize.Height - 130),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        panelColor,

                    Padding =
                        new Padding(
                            16)
                };


            /*
             * ==========================================
             * MODALITÀ L
             * ==========================================
             */
            Button modalitaLButton =
                new Button
                {
                    Text =
                        "Modalità L",

                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            18F,
                            System.Drawing.FontStyle.Bold),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        System.Drawing.Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        System.Drawing.Color.White,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            modalitaLButton.FlatAppearance.BorderSize =
                0;

            modalitaLButton.Click +=
                ModalitaLButton_Click;


            /*
             * ==========================================
             * MODALITÀ STL
             * ==========================================
             */
            Button modalitaStlButton =
                new Button
                {
                    Text =
                        "Modalità STL",

                    Font =
                        new System.Drawing.Font(
                            "Segoe UI",
                            18F,
                            System.Drawing.FontStyle.Bold),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        System.Drawing.Color.FromArgb(
                            16,
                            185,
                            129),

                    ForeColor =
                        System.Drawing.Color.White,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            modalitaStlButton.FlatAppearance.BorderSize =
                0;

            modalitaStlButton.Click +=
                ModalitaStlButton_Click;


            /*
             * ==========================================
             * LAYOUT 50 / 50
             * ==========================================
             */
            TableLayoutPanel modesLayout =
                new TableLayoutPanel
                {
                    Dock =
                        DockStyle.Fill,

                    ColumnCount =
                        2,

                    RowCount =
                        1,

                    Padding =
                        new Padding(
                            0),

                    Margin =
                        new Padding(
                            0)
                };

            modesLayout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    50F));

            modesLayout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    50F));

            modalitaLButton.Dock =
                DockStyle.Fill;

            modalitaStlButton.Dock =
                DockStyle.Fill;

            modalitaLButton.Margin =
                new Padding(
                    0,
                    0,
                    8,
                    0);

            modalitaStlButton.Margin =
                new Padding(
                    8,
                    0,
                    0,
                    0);

            modesLayout.Controls.Add(
                modalitaLButton,
                0,
                0);

            modesLayout.Controls.Add(
                modalitaStlButton,
                1,
                0);

            modesPanel.Controls.Add(
                modesLayout);


            Controls.Add(
                titleLabel);

            Controls.Add(
                settingsButton);

            Controls.Add(
                modesPanel);
        }

        private void ModalitaLButton_Click(
            object? sender,
            EventArgs e)
        {
            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);

            Hide();


            GeneraVerbaliModalitaLForm form =
                new GeneraVerbaliModalitaLForm(
                    _inventorApp,
                    _openContext);


            form.FormClosed +=
                (_, _) =>
                {
                    if (!IsDisposed)
                    {
                        Close();
                    }
                };


            form.Show(
                owner);
        }


        private void ModalitaStlButton_Click(
            object? sender,
            EventArgs e)
        {
        }


        private void SettingsButton_Click(
            object? sender,
            EventArgs e)
        {
            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);

            SingleFormService.ShowSingle(
                "GeneraVerbaliSettings",
                () => new GeneraVerbaliSettingsForm(
                    _inventorApp,
                    _openContext),
                owner);
        }


        private void GeneraVerbaliDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "GeneraVerbaliDashboard");
        }
    }
}