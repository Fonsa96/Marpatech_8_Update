﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public static class FeatureWindowService
    {
        public static void Open(
            Form featureForm,
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                dashboard.Hide();
            }

            featureForm.FormClosed +=
                (_, _) =>
                {
                    RestoreDashboard(
                        context);
                };

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                /*
                 * Apertura dalla Main Dashboard.
                 */
                featureForm.Show(
                    dashboard);
            }
            else if (context.WindowOwner != null)
            {
                /*
                 * Apertura diretta dalla Ribbon Inventor.
                 *
                 * Inventor diventa il vero owner Win32
                 * della finestra modeless.
                 *
                 * Questo è fondamentale anche per la
                 * corretta gestione dell'input tastiera.
                 */
                featureForm.Show(
                    context.WindowOwner);
            }
            else
            {
                /*
                 * Fallback di compatibilità.
                 */
                featureForm.Show();
            }

            featureForm.BringToFront();

            featureForm.Activate();

            featureForm.Focus();
        }

        private static void RestoreDashboard(
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard == null ||
                dashboard.IsDisposed)
            {
                return;
            }

            dashboard.Show();

            if (dashboard.WindowState ==
                FormWindowState.Minimized)
            {
                dashboard.WindowState =
                    FormWindowState.Normal;
            }

            dashboard.BringToFront();

            dashboard.Activate();
        }
    }
}
