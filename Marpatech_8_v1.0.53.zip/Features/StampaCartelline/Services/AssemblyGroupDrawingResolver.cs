﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupDrawingResolver
    {
        public void Resolve(
            IEnumerable<AssemblyGroupRuntimeItem> items)
        {
            if (items == null)
                return;

            foreach (AssemblyGroupRuntimeItem item
                in items)
            {
                ResolveSingleItem(
                    item);
            }
        }

        private static void ResolveSingleItem(
            AssemblyGroupRuntimeItem item)
        {
            item.DrawingPath =
                string.Empty;

            item.CanProcess =
                false;

            item.FailureReason =
                string.Empty;

            /*
             * Prima verifica:
             * proprietà Custom DISEGNO.
             */
            string drawingName =
                item.DrawingName
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                item.FailureReason =
                    "Proprietà DISEGNO vuota";

                return;
            }

            /*
             * Seconda verifica:
             * percorso IAM.
             */
            string assemblyPath =
                item.AssemblyPath
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    assemblyPath))
            {
                item.FailureReason =
                    "Percorso IAM non disponibile";

                return;
            }

            string? assemblyDirectory;

            try
            {
                assemblyDirectory =
                    Path.GetDirectoryName(
                        assemblyPath);
            }
            catch
            {
                item.FailureReason =
                    "Percorso IAM non valido";

                return;
            }

            if (string.IsNullOrWhiteSpace(
                    assemblyDirectory) ||
                !Directory.Exists(
                    assemblyDirectory))
            {
                item.FailureReason =
                    "Cartella IAM non trovata";

                return;
            }

            /*
             * Se DISEGNO non contiene estensione,
             * aggiungiamo automaticamente .idw.
             */
            if (string.IsNullOrWhiteSpace(
                    Path.GetExtension(
                        drawingName)))
            {
                drawingName +=
                    ".idw";
            }

            string drawingPath;

            try
            {
                drawingPath =
                    Path.Combine(
                        assemblyDirectory,
                        drawingName);
            }
            catch
            {
                item.FailureReason =
                    "Impossibile costruire il percorso IDW";

                return;
            }

            item.DrawingPath =
                drawingPath;

            /*
             * Il file indicato da DISEGNO
             * deve esistere esattamente lì.
             */
            if (!File.Exists(
                    drawingPath))
            {
                item.FailureReason =
                    "IDW non trovato: " +
                    drawingName;

                return;
            }

            /*
             * STL pronto per essere processato.
             */
            item.CanProcess =
                true;
        }
    }
}