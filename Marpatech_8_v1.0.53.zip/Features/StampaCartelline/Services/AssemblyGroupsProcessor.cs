﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupsProcessor
    {
        private readonly Inventor.Application _inventorApp;

        private readonly AssemblyGroupCollector _collector;

        private readonly AssemblyGroupDrawingResolver
                _drawingResolver;

        public AssemblyGroupsProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));

            _collector =
                new AssemblyGroupCollector();

            _drawingResolver =
                new AssemblyGroupDrawingResolver();
        }

        public bool Process(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * La sessione decide se il blocco
             * deve essere eseguito.
             */
            if (!session.IncludeAssemblyGroups)
            {
                return true;
            }

            AssemblyGroupsConfiguration?
                groupsConfiguration =
                    configuration.AssemblyGroups;

            if (groupsConfiguration == null)
            {
                return true;
            }

            /*
             * Nessun metodo selezionato:
             * saltiamo SOLO questo blocco.
             */
            if (!groupsConfiguration.Method1Enabled &&
                !groupsConfiguration.Method2Enabled)
            {
                MessageBox.Show(
                    owner,
                    "Nessun metodo di stampa dei gruppi selezionato, " +
                    "Selezionalo nella configurazione e ripeti il comando",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return true;
            }

            /*
             * Per ora implementiamo soltanto
             * il Metodo 1.
             */
            if (!groupsConfiguration.Method1Enabled)
            {
                return true;
            }

            if (_inventorApp.ActiveDocument
                is not AssemblyDocument mainAssembly)
            {
                MessageBox.Show(
                    owner,
                    "Il documento attivo non è un assieme Inventor.",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return true;
            }

            List<AssemblyGroupRuntimeItem> items =
                _collector.CollectMethod1(
                    mainAssembly,
                    groupsConfiguration.Method1Rows);

            _drawingResolver.Resolve(
              items);

            /*
             * TEMPORANEO:
             * serve solo per verificare
             * la raccolta prima di procedere.
             */
            ShowCollectorTestResult(
                owner,
                items);

            return true;
        }

        private static void ShowCollectorTestResult(
            IWin32Window owner,
            IReadOnlyCollection<AssemblyGroupRuntimeItem> items)
        {
            if (items.Count == 0)
            {
                MessageBox.Show(
                    owner,
                    "Nessun STL trovato per il Metodo 1.",
                    "Test Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            List<string> rows =
                new List<string>();

            foreach (AssemblyGroupRuntimeItem item
                in items)
            {
                if (item.CanProcess)
                {
                    rows.Add(
                        "[OK] " +
                        item.Code +
                        " | " +
                        item.DrawingPath);
                }
                else
                {
                    rows.Add(
                        "[NON PROCESSABILE] " +
                        item.Code +
                        " | " +
                        item.FailureReason);
                }
            }

            string text =
                string.Join(
                    System.Environment.NewLine,
                    rows);

            MessageBox.Show(
                owner,
                "STL trovati: " +
                items.Count +
                System.Environment.NewLine +
                System.Environment.NewLine +
                text,
                "Test Gruppi di montaggio",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
}