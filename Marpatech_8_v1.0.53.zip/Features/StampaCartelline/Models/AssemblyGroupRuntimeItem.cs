﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class AssemblyGroupRuntimeItem
    {
        public string Code
        {
            get;
            set;
        } = string.Empty;

        public string DrawingName
        {
            get;
            set;
        } = string.Empty;

        public string AssemblyPath
        {
            get;
            set;
        } = string.Empty;

        public string DrawingPath
        {
            get;
            set;
        } = string.Empty;

        public bool CanProcess
        {
            get;
            set;
        }

        public string FailureReason
        {
            get;
            set;
        } = string.Empty;
    }
}