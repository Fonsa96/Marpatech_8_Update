﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class SheetMetalPdfProcessor
    {
        [DllImport(
            "shell32.dll",
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern IntPtr ShellExecute(
            IntPtr hwnd,
            string lpOperation,
            string lpFile,
            string? lpParameters,
            string? lpDirectory,
            int nShowCmd);

        public bool Process(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }

            /*
             * Se la sezione PDF è disattivata
             * nella sessione, viene saltata.
             *
             * LOGICA INVARIATA.
             */
            if (!session.SheetMetalPdfs
                    .IncludeInPrintProcess)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Stampa PDF Lamiere disattivata nella sessione.");

                return true;
            }

            string resolvedPath =
                session.SheetMetalPdfs
                    .ResolvedPath
                    ?.Trim()
                ?? string.Empty;

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                string.IsNullOrWhiteSpace(
                    resolvedPath)
                    ? "Nessun percorso PDF risolto."
                    : "Percorso PDF risolto: " +
                      resolvedPath);

            /*
             * Se il percorso della sessione è vuoto
             * o non esiste, saltiamo il blocco.
             *
             * La scelta manuale del percorso viene
             * già gestita dalla Dashboard.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    resolvedPath) ||
                !Directory.Exists(
                    resolvedPath))
            {
                MessageBox.Show(
                    owner,
                    "Il percorso PDF della sessione non è valido.\n\n" +
                    "Il blocco Stampa PDF verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Pdf,
                    "Percorso PDF della sessione non valido: " +
                    resolvedPath +
                    ". Blocco PDF saltato.");

                return true;
            }

            string? pdfDirectory =
                ResolvePdfDirectory(
                    owner,
                    resolvedPath,
                    progress);

            /*
             * L'utente ha scelto No quando
             * Lamiera/Lamiere non era presente.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    pdfDirectory))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Stampa PDF annullata dall'utente.");

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "Cartella utilizzata per la stampa PDF: " +
                pdfDirectory);

            List<string> pdfFiles =
                FindPdfFiles(
                    pdfDirectory);

            if (pdfFiles.Count == 0)
            {
                MessageBox.Show(
                    owner,
                    "Nessun file PDF trovato nella cartella:\n\n" +
                    pdfDirectory,
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Nessun file PDF trovato nella cartella: " +
                    pdfDirectory);

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "File PDF trovati: " +
                pdfFiles.Count);

            try
            {
                PrintPdfFiles(
                    owner,
                    pdfFiles,
                    progress);
            }
            finally
            {
                /*
                 * LOGICA INVARIATA:
                 * chiusura Acrobat dopo la lista.
                 */
                CloseAllAcrobatProcesses();

                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Chiusura processi Acrobat completata.");
            }

            return true;
        }

        private static string?
            ResolvePdfDirectory(
                IWin32Window owner,
                string resolvedPath,
                StampaCartellineProcessProgress progress)
        {
            string? lamieraDirectory =
                FindSheetMetalDirectory(
                    resolvedPath);

            if (!string.IsNullOrWhiteSpace(
                    lamieraDirectory))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Cartella Lamiera/Lamiere rilevata: " +
                    lamieraDirectory);

                return lamieraDirectory;
            }

            progress.AddWarning(
                StampaCartellineProcessSection.Pdf,
                "Cartella Lamiera/Lamiere non trovata nel percorso: " +
                resolvedPath);

            DialogResult result =
                MessageBox.Show(
                    owner,
                    "Cartella Lamiere non trovata.\n\n" +
                    "Stampare i PDF nella cartella selezionata al percorso:\n\n" +
                    resolvedPath +
                    "\n\n" +
                    "ATTENZIONE: SE CLICCHI SÌ VERRANNO STAMPATI " +
                    "TUTTI I PDF TROVATI ALL'INTERNO DI QUEL PERCORSO " +
                    "(MA NON NELLE SOTTOCARTELLE).",
                    "Stampa PDF",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
            {
                return null;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "Confermata manualmente la stampa dei PDF presenti direttamente nel percorso selezionato.");

            return resolvedPath;
        }

        private static string?
            FindSheetMetalDirectory(
                string rootDirectory)
        {
            try
            {
                if (!Directory.Exists(
                        rootDirectory))
                {
                    return null;
                }

                /*
                 * Se il percorso selezionato è già
                 * una cartella che contiene la parola
                 * "Lamiere" oppure "Lamiera",
                 * usiamo direttamente questa.
                 */
                string rootFolderName =
                    Path.GetFileName(
                        rootDirectory.TrimEnd(
                            Path.DirectorySeparatorChar,
                            Path.AltDirectorySeparatorChar));

                if (ContainsSheetMetalWord(
                        rootFolderName))
                {
                    return rootDirectory;
                }

                /*
                 * Altrimenti controlliamo soltanto
                 * le cartelle immediatamente contenute
                 * nel percorso selezionato.
                 *
                 * NON facciamo ricerca ricorsiva.
                 */
                string[] directories =
                    Directory.GetDirectories(
                        rootDirectory);

                /*
                 * Prima priorità:
                 * nome cartella contenente "Lamiere".
                 */
                string? lamiere =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiere",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                if (!string.IsNullOrWhiteSpace(
                        lamiere))
                {
                    return lamiere;
                }

                /*
                 * Seconda priorità:
                 * nome cartella contenente "Lamiera".
                 */
                string? lamiera =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiera",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                return lamiera;
            }
            catch
            {
                return null;
            }
        }

        private static bool ContainsSheetMetalWord(
            string folderName)
        {
            if (string.IsNullOrWhiteSpace(
                    folderName))
            {
                return false;
            }

            return
                folderName.IndexOf(
                    "Lamiere",
                    StringComparison.OrdinalIgnoreCase) >= 0
                ||
                folderName.IndexOf(
                    "Lamiera",
                    StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static List<string>
            FindPdfFiles(
                string directory)
        {
            try
            {
                /*
                 * IMPORTANTE:
                 * processiamo solo ed esclusivamente
                 * i PDF presenti al primo livello.
                 *
                 * Le sottocartelle vengono ignorate.
                 */
                return Directory
                    .EnumerateFiles(
                        directory,
                        "*.pdf",
                        SearchOption.TopDirectoryOnly)
                    .OrderBy(
                        filePath =>
                            filePath,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        private static void PrintPdfFiles(
            IWin32Window owner,
            IEnumerable<string> pdfFiles,
            StampaCartellineProcessProgress progress)
        {
            foreach (string filePath
                in pdfFiles)
            {
                PrintSinglePdf(
                    owner,
                    filePath,
                    progress);
            }

            /*
             * Importante:
             * dopo l'ultimo PDF lasciamo a Reader
             * il tempo di completare l'invio allo spooler
             * prima che il finally chiuda Acrobat.
             *
             * LOGICA INVARIATA.
             */
            WaitSeconds(
                5);
        }

        private static void PrintSinglePdf(
            IWin32Window owner,
            string filePath,
            StampaCartellineProcessProgress progress)
        {
            string fileName;

            try
            {
                fileName =
                    Path.GetFileName(
                        filePath);

                if (string.IsNullOrWhiteSpace(
                        fileName))
                {
                    fileName =
                        filePath;
                }
            }
            catch
            {
                fileName =
                    filePath;
            }

            try
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Avvio stampa PDF: " +
                    fileName);

                /*
                 * IDENTICO alla VBA:
                 *
                 * ret = ShellExecute(
                 *     0,
                 *     "print",
                 *     file.path,
                 *     vbNullString,
                 *     vbNullString,
                 *     0)
                 */
                IntPtr result =
                    ShellExecute(
                        IntPtr.Zero,
                        "print",
                        filePath,
                        null,
                        null,
                        0);

                System.Windows.Forms.Application
                    .DoEvents();

                /*
                 * Nella VBA:
                 *
                 * If ret <= 32 Then
                 *     AttendiSecondi(2)
                 *     ret = ShellExecute(...)
                 *     DoEvents
                 * End If
                 */
                if (result.ToInt64() <= 32)
                {
                    progress.AddWarning(
                        StampaCartellineProcessSection.Pdf,
                        "Primo tentativo di stampa fallito per \"" +
                        fileName +
                        "\". Codice ShellExecute: " +
                        result.ToInt64() +
                        ". Verrà eseguito il retry.");

                    WaitSeconds(
                        2);

                    result =
                        ShellExecute(
                            IntPtr.Zero,
                            "print",
                            filePath,
                            null,
                            null,
                            0);

                    System.Windows.Forms.Application
                        .DoEvents();

                    if (result.ToInt64() <= 32)
                    {
                        MessageBox.Show(
                            owner,
                            "Errore stampa PDF:\n\n" +
                            filePath +
                            "\n\nCodice: " +
                            result.ToInt64(),
                            "Stampa PDF",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        progress.AddError(
                            StampaCartellineProcessSection.Pdf,
                            "Errore stampa PDF \"" +
                            fileName +
                            "\" dopo il retry. Codice ShellExecute: " +
                            result.ToInt64());
                    }
                    else
                    {
                        progress.AddSuccess(
                            StampaCartellineProcessSection.Pdf,
                            "PDF inviato alla stampa dopo il retry: " +
                            fileName);
                    }
                }
                else
                {
                    progress.AddSuccess(
                        StampaCartellineProcessSection.Pdf,
                        "PDF inviato alla stampa: " +
                        fileName);
                }

                /*
                 * IDENTICO alla VBA:
                 *
                 * Call AttendiSecondi(3)
                 *
                 * Viene eseguito anche dopo il retry,
                 * prima di passare al PDF successivo.
                 */
                WaitSeconds(
                    3);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Errore stampa PDF:\n\n" +
                    filePath +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl file verrà saltato.",
                    "Stampa PDF",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Pdf,
                    "Errore durante la stampa del PDF \"" +
                    fileName +
                    "\": " +
                    GetRealExceptionMessage(
                        exception));

                /*
                 * Anche in caso di eccezione su un file
                 * non interrompiamo la lista.
                 *
                 * PrintPdfFiles passerà al PDF successivo.
                 *
                 * LOGICA INVARIATA.
                 */
            }
        }

        private static void WaitSeconds(
            int seconds)
        {
            /*
             * Replica di AttendiSecondi della VBA:
             *
             * Do While Now < fine
             *     DoEvents
             * Loop
             *
             * Sleep(20) evita di saturare la CPU,
             * lasciando comunque viva la UI WinForms.
             */
            DateTime endTime =
                DateTime.Now.AddSeconds(
                    seconds);

            while (DateTime.Now < endTime)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }
        }

        private static void KillProcessByName(
            string processName)
        {
            try
            {
                System.Diagnostics.Process[] processes =
                    System.Diagnostics.Process.GetProcessesByName(
                        processName);

                foreach (System.Diagnostics.Process process
                    in processes)
                {
                    try
                    {
                        process.Kill();

                        process.WaitForExit(
                            5000);
                    }
                    catch
                    {
                    }
                    finally
                    {
                        process.Dispose();
                    }
                }
            }
            catch
            {
            }
        }

        private static void CloseAllAcrobatProcesses()
        {
            /*
             * Traduzione diretta di:
             *
             * taskkill /IM AcroRd32.exe /F
             * taskkill /IM Acrobat.exe /F
             */
            KillProcessByName(
                "AcroRd32");

            KillProcessByName(
                "Acrobat");
        }

        /*
         * ==================================================
         * SOLO SUPPORTO LOG
         * ==================================================
         */
        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;

            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }

            return realException.Message;
        }
    }
}