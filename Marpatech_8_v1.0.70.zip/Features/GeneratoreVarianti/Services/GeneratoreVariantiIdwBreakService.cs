﻿
using System;
using System.Collections.Generic;

namespace Marpatech_8.Features.GeneratoreVarianti.Services
{
    public sealed class InterruzioneVistaInfo
    {
        public int NumeroFoglio { get; init; }
        public string NomeVista { get; init; } = "";
        public int NumeroInterruzione { get; init; }

        public double? StartX { get; init; }
        public double? StartY { get; init; }
        public double? EndX { get; init; }
        public double? EndY { get; init; }

        public string Dettaglio { get; init; } = "";
    }

    public sealed class RisultatoAnalisiInterruzioni
    {
        public List<InterruzioneVistaInfo> Interruzioni { get; } = new();

        public List<string> Avvisi { get; } = new();

        public bool RichiedeControllo =>
            Interruzioni.Count > 0 || Avvisi.Count > 0;
    }

    public static class GeneratoreVariantiIdwBreakService
    {
        public static RisultatoAnalisiInterruzioni Analizza(
            Inventor.DrawingDocument tavola)
        {
            var risultato = new RisultatoAnalisiInterruzioni();

            for (int i = 1; i <= tavola.Sheets.Count; i++)
            {
                Inventor.Sheet foglio = tavola.Sheets[i];

                foreach (Inventor.DrawingView vista in
                         foglio.DrawingViews)
                {
                    try
                    {
                        // Accesso dinamico per evitare di assumere
                        // proprietà non verificate del tipo COM.
                        dynamic vistaCom = vista;
                        dynamic interruzioni =
                            vistaCom.BreakOperations;

                        int numeroInterruzioni =
                            (int)interruzioni.Count;

                        for (int j = 1;
                             j <= numeroInterruzioni;
                             j++)
                        {
                            dynamic interruzione =
                                interruzioni[j];

                            double? sx = null;
                            double? sy = null;
                            double? ex = null;
                            double? ey = null;

                            string dettaglio = "";

                            try
                            {
                                dynamic puntoIniziale =
                                    interruzione.StartPoint;

                                dynamic puntoFinale =
                                    interruzione.EndPoint;

                                sx = (double)puntoIniziale.X;
                                sy = (double)puntoIniziale.Y;

                                ex = (double)puntoFinale.X;
                                ey = (double)puntoFinale.Y;

                                dettaglio =
                                    "Coordinate interruzione lette.";
                            }
                            catch (Exception errore)
                            {
                                dettaglio =
                                    "Coordinate non disponibili: " +
                                    errore.Message;

                                risultato.Avvisi.Add(
                                    $"Foglio {i}, vista {vista.Name}, " +
                                    $"interruzione {j}: {dettaglio}");
                            }

                            risultato.Interruzioni.Add(
                                new InterruzioneVistaInfo
                                {
                                    NumeroFoglio = i,
                                    NomeVista = vista.Name,
                                    NumeroInterruzione = j,
                                    StartX = sx,
                                    StartY = sy,
                                    EndX = ex,
                                    EndY = ey,
                                    Dettaglio = dettaglio
                                });
                        }
                    }
                    catch (Exception ex)
                    {
                        risultato.Avvisi.Add(
                            $"Impossibile analizzare le interruzioni " +
                            $"della vista {vista.Name}, foglio {i}: " +
                            ex.Message);
                    }
                }
            }

            return risultato;
        }

        public static List<string> Confronta(
            RisultatoAnalisiInterruzioni originale,
            RisultatoAnalisiInterruzioni variante)
        {
            var avvisi = new List<string>();

            avvisi.AddRange(originale.Avvisi);
            avvisi.AddRange(variante.Avvisi);

            foreach (var interruzioneOriginale
                     in originale.Interruzioni)
            {
                bool presente = variante.Interruzioni.Exists(
                    x =>
                        x.NumeroFoglio ==
                        interruzioneOriginale.NumeroFoglio
                        &&
                        x.NomeVista ==
                        interruzioneOriginale.NomeVista
                        &&
                        x.NumeroInterruzione ==
                        interruzioneOriginale.NumeroInterruzione);

                if (!presente)
                {
                    avvisi.Add(
                        $"Interruzione {interruzioneOriginale.NumeroInterruzione} " +
                        $"della vista {interruzioneOriginale.NomeVista} " +
                        $"non rilevata nella variante.");
                }
                else
                {
                    avvisi.Add(
                        $"Vista {interruzioneOriginale.NomeVista}: " +
                        "interruzione presente, adattamento " +
                        "geometrico ancora da verificare.");
                }
            }

            return avvisi;
        }
    }
}
