﻿
using System;
using System.IO;

namespace Marpatech_8.Features.GeneratoreVarianti.Services
{
    public sealed class RisultatoGenerazioneIdw
    {
        public bool Successo { get; init; }
        public string PercorsoIdw { get; init; } = "";
        public string Messaggio { get; init; } = "";
    }

    public static class GeneratoreVariantiIdwService
    {
        public static RisultatoGenerazioneIdw Genera(
            Inventor.Application inventorApp,
            string percorsoIptOriginale,
            VariantePianificata variante)
        {
            Inventor.DrawingDocument? tavola = null;
            bool copiaCreata = false;
            bool salvata = false;

            string idwOriginale =
                Path.ChangeExtension(percorsoIptOriginale, ".idw");

            try
            {
                if (!File.Exists(idwOriginale))
                    throw new FileNotFoundException(
                        "Tavola originale non trovata.",
                        idwOriginale);

                if (!File.Exists(variante.PercorsoIpt))
                    throw new FileNotFoundException(
                        "IPT della variante non trovato.",
                        variante.PercorsoIpt);

                if (File.Exists(variante.PercorsoIdw))
                    throw new IOException(
                        "La tavola della variante esiste già.");

                // Evita di usare una tavola già aperta
                // con modifiche non salvate.
                foreach (Inventor.Document documento
                         in inventorApp.Documents)
                {
                    if (string.Equals(
                        documento.FullFileName,
                        idwOriginale,
                        StringComparison.OrdinalIgnoreCase)
                        && documento.Dirty)
                    {
                        throw new InvalidOperationException(
                            "Salva o annulla le modifiche " +
                            "della tavola originale prima di procedere.");
                    }
                }

                // Duplica esclusivamente la tavola originale.
                File.Copy(
                    idwOriginale,
                    variante.PercorsoIdw,
                    false);

                copiaCreata = true;

                tavola = inventorApp.Documents.Open(
                    variante.PercorsoIdw,
                    false) as Inventor.DrawingDocument
                    ?? throw new InvalidOperationException(
                        "La copia non è una tavola IDW valida.");

                bool riferimentoTrovato = false;

                Inventor.FileDescriptorsEnumerator riferimenti =
                    tavola.File.ReferencedFileDescriptors;

                foreach (Inventor.FileDescriptor riferimento
                         in riferimenti)
                {
                    string percorsoRiferimento =
                        riferimento.FullFileName;

                    if (!string.Equals(
                        Path.GetFullPath(percorsoRiferimento),
                        Path.GetFullPath(percorsoIptOriginale),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    // ReplaceReference richiede che il nuovo
                    // file condivida l'InternalName del vecchio.
                    // Le copie IPT ottenute con File.Copy
                    // normalmente rispettano questa condizione.
                    riferimento.ReplaceReference(
                        variante.PercorsoIpt);

                    riferimentoTrovato = true;
                }

                if (!riferimentoTrovato)
                {
                    throw new InvalidOperationException(
                        "Nessun riferimento diretto all'IPT " +
                        "originale trovato nella tavola.");
                }

                bool aggiornamentoRiuscito =
                    tavola.Update2(false);

                if (!aggiornamentoRiuscito ||
                    tavola.RequiresUpdate)
                {
                    throw new InvalidOperationException(
                        "Aggiornamento della tavola non riuscito.");
                }

                tavola.Save();
                salvata = true;

                // Chiude la tavola prima della verifica
                // indipendente su disco.
                tavola.Close(true);
                tavola = null;

                // Riapre la copia per verificare il
                // riferimento effettivamente salvato.
                tavola = inventorApp.Documents.Open(
                    variante.PercorsoIdw,
                    false) as Inventor.DrawingDocument
                    ?? throw new InvalidOperationException(
                        "Impossibile riaprire la tavola generata.");

                bool collegamentoCorretto = false;
                bool collegamentoOriginaleRimasto = false;

                foreach (Inventor.FileDescriptor riferimento
                         in tavola.File.ReferencedFileDescriptors)
                {
                    string percorso =
                        Path.GetFullPath(riferimento.FullFileName);

                    if (string.Equals(
                        percorso,
                        Path.GetFullPath(variante.PercorsoIpt),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        collegamentoCorretto = true;
                    }

                    if (string.Equals(
                        percorso,
                        Path.GetFullPath(percorsoIptOriginale),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        collegamentoOriginaleRimasto = true;
                    }
                }

                if (!collegamentoCorretto ||
                    collegamentoOriginaleRimasto)
                {
                    throw new InvalidOperationException(
                        "Verifica riferimenti non superata: " +
                        "la tavola non è collegata esclusivamente " +
                        "al nuovo IPT.");
                }

                return new RisultatoGenerazioneIdw
                {
                    Successo = true,
                    PercorsoIdw = variante.PercorsoIdw,
                    Messaggio =
                        "IDW salvato e riferimento IPT verificato."
                };
            }
            catch (Exception ex)
            {
                return new RisultatoGenerazioneIdw
                {
                    Successo = false,
                    PercorsoIdw = variante.PercorsoIdw,
                    Messaggio = ex.Message
                };
            }
            finally
            {
                if (tavola != null)
                {
                    try
                    {
                        tavola.Close(true);
                    }
                    catch
                    {
                        // Non intervenire mai sull'originale.
                    }
                }

                // Conserviamo la copia IDW quando è già
                // stata salvata, anche se la verifica fallisce,
                // per consentire l'analisi del problema.
                if (copiaCreata && !salvata)
                {
                    // Non eliminiamo automaticamente file
                    // potenzialmente utili alla diagnosi.
                }
            }
        }
    }
}
