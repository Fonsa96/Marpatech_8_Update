﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Settings
{
    public static class SettingsCommand
    {
        public static void Execute(
            Form owner,
            bool isDarkTheme)
        {
            SettingsDashboardForm form =
                new SettingsDashboardForm(
                    isDarkTheme);

            /*
             * Finestra modeless:
             * Inventor resta utilizzabile.
             *
             * Ma assegniamo un owner WinForms
             * così il focus tastiera viene gestito
             * correttamente quando si lavora nel Form.
             */
            form.Show(
                owner);

            form.BringToFront();

            form.Activate();

            form.Focus();
        }
    }
}