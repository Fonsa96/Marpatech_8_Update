﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public class FeatureOpenContext
    {
        public Form? MainDashboard
        {
            get;
            init;
        }

        public bool IsDarkTheme
        {
            get;
            init;
        }

        public bool HasMainDashboard =>
            MainDashboard != null;

        public static FeatureOpenContext FromDashboard(
            Form dashboard,
            bool isDarkTheme)
        {
            return new FeatureOpenContext
            {
                MainDashboard =
                    dashboard,

                IsDarkTheme =
                    isDarkTheme
            };
        }

        public static FeatureOpenContext FromInventor(
            bool isDarkTheme)
        {
            return new FeatureOpenContext
            {
                MainDashboard =
                    null,

                IsDarkTheme =
                    isDarkTheme
            };
        }
    }
}