﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public static class FeatureWindowService
    {
        public static void Open(
            Form featureForm,
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                dashboard.Hide();
            }

            featureForm.FormClosed +=
                (_, _) =>
                {
                    RestoreDashboard(
                        context);
                };

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                featureForm.Show(
                    dashboard);
            }
            else
            {
                featureForm.Show();
            }

            featureForm.BringToFront();

            featureForm.Activate();

            featureForm.Focus();
        }

        private static void RestoreDashboard(
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard == null ||
                dashboard.IsDisposed)
            {
                return;
            }

            dashboard.Show();

            if (dashboard.WindowState ==
                FormWindowState.Minimized)
            {
                dashboard.WindowState =
                    FormWindowState.Normal;
            }

            dashboard.BringToFront();

            dashboard.Activate();
        }
    }
}
