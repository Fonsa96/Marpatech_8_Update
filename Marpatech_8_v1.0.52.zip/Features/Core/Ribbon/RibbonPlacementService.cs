﻿using System;

using InventorApplication =
    global::Inventor.Application;

using InventorButtonDefinition =
    global::Inventor.ButtonDefinition;

using InventorRibbon =
    global::Inventor.Ribbon;

using InventorRibbonTab =
    global::Inventor.RibbonTab;

using InventorRibbonPanel =
    global::Inventor.RibbonPanel;

namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Servizio comune per posizionare un comando
    /// già esistente all'interno della Ribbon di Inventor.
    ///
    /// Questo servizio:
    /// - NON crea il ButtonDefinition;
    /// - NON contiene logica delle Feature;
    /// - NON gestisce eventi OnExecute;
    /// - decide solamente dove mostrare il comando.
    /// </summary>
    public static class RibbonPlacementService
    {
        public static void AddButton(
            InventorApplication inventorApp,
            InventorButtonDefinition buttonDefinition,
            RibbonPlacementDefinition placement)
        {
            if (inventorApp == null)
                return;

            if (buttonDefinition == null)
                return;

            if (placement == null)
                return;

            if (string.IsNullOrWhiteSpace(
                    placement.RibbonName))
            {
                return;
            }

            try
            {
                InventorRibbon ribbon =
                    inventorApp
                        .UserInterfaceManager
                        .Ribbons[
                            placement.RibbonName];

                InventorRibbonTab ribbonTab =
                    GetRibbonTab(
                        ribbon,
                        placement);

                InventorRibbonPanel ribbonPanel =
                    GetOrCreatePanel(
                        ribbonTab,
                        placement);

                AddButtonToPanel(
                    ribbonPanel,
                    buttonDefinition,
                    placement.UseLargeButton);
            }
            catch
            {
                /*
                 * Un problema nella Ribbon
                 * non deve impedire il caricamento
                 * dell'Addin.
                 */
            }
        }

        private static InventorRibbonTab GetRibbonTab(
            InventorRibbon ribbon,
            RibbonPlacementDefinition placement)
        {
            /*
             * ==========================================
             * 1. INTERNAL NAME
             * ==========================================
             *
             * È il metodo più affidabile.
             *
             * Se il JSON contiene un InternalName
             * valido, usiamo quello direttamente.
             */
            if (!string.IsNullOrWhiteSpace(
                    placement.TabInternalName))
            {
                try
                {
                    return ribbon
                        .RibbonTabs[
                            placement.TabInternalName];
                }
                catch
                {
                    /*
                     * Se non viene trovato,
                     * continuiamo con il nome visualizzato.
                     */
                }
            }

            /*
             * ==========================================
             * 2. DISPLAY NAME
             * ==========================================
             *
             * Utile soprattutto nella configurazione
             * iniziale, quando conosciamo il nome che
             * l'utente vede in Inventor ma non ancora
             * l'InternalName Autodesk.
             *
             * Esempio:
             * "Assembla"
             */
            if (!string.IsNullOrWhiteSpace(
                    placement.TabDisplayName))
            {
                foreach (InventorRibbonTab tab
                         in ribbon.RibbonTabs)
                {
                    try
                    {
                        if (string.Equals(
                                tab.DisplayName,
                                placement.TabDisplayName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return tab;
                        }
                    }
                    catch
                    {
                        /*
                         * Una singola tab non leggibile
                         * non deve interrompere la ricerca.
                         */
                    }
                }
            }

            /*
             * ==========================================
             * 3. STRUMENTI
             * ==========================================
             *
             * Manteniamo il comportamento già usato
             * dall'Addin come primo fallback.
             */
            try
            {
                return ribbon
                    .RibbonTabs[
                        "id_TabTools"];
            }
            catch
            {
            }

            /*
             * ==========================================
             * 4. ULTIMO FALLBACK
             * ==========================================
             *
             * Stesso comportamento che avevamo già
             * nello StandardAddInServer.
             */
            return ribbon.RibbonTabs[1];
        }

        private static InventorRibbonPanel GetOrCreatePanel(
            InventorRibbonTab ribbonTab,
            RibbonPlacementDefinition placement)
        {
            string panelInternalName =
                placement.PanelInternalName;

            if (string.IsNullOrWhiteSpace(
                    panelInternalName))
            {
                panelInternalName =
                    BuildDefaultPanelInternalName(
                        placement);
            }

            try
            {
                return ribbonTab
                    .RibbonPanels[
                        panelInternalName];
            }
            catch
            {
                string displayName =
                    string.IsNullOrWhiteSpace(
                        placement.PanelDisplayName)
                        ? "Marpatech"
                        : placement.PanelDisplayName;

                return ribbonTab
                    .RibbonPanels
                    .Add(
                        displayName,
                        panelInternalName,
                        "{A2F7D8B1-3C44-4A1F-9C8E-112233445566}");
            }
        }

        private static void AddButtonToPanel(
            InventorRibbonPanel ribbonPanel,
            InventorButtonDefinition buttonDefinition,
            bool useLargeButton)
        {
            try
            {
                /*
                 * Se il comando è già presente
                 * Inventor può generare un'eccezione.
                 *
                 * In quel caso non facciamo nulla.
                 */
                ribbonPanel
                    .CommandControls
                    .AddButton(
                        buttonDefinition,
                        useLargeButton);
            }
            catch
            {
            }
        }

        private static string BuildDefaultPanelInternalName(
            RibbonPlacementDefinition placement)
        {
            string ribbonName =
                CleanInternalName(
                    placement.RibbonName);

            string panelName =
                CleanInternalName(
                    placement.PanelDisplayName);

            return
                "Marpatech8_" +
                ribbonName +
                "_" +
                panelName;
        }

        private static string CleanInternalName(
            string value)
        {
            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return "Panel";
            }

            return value
                .Replace(
                    " ",
                    string.Empty)
                .Replace(
                    ".",
                    string.Empty)
                .Replace(
                    "-",
                    string.Empty)
                .Trim();
        }
    }
}