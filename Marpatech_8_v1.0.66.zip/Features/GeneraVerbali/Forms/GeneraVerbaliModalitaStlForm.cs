﻿using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.GeneraVerbali.Models;
using Marpatech_8.Features.GeneraVerbali.Services;
using Marpatech_8.Features.Mail;
using System.IO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

using InventorApplication = global::Inventor.Application;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliModalitaStlForm : Form
    {
        private readonly InventorApplication
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        private FlowLayoutPanel
            _contentFlow = null!;

        private FlowLayoutPanel
            _dynamicPropertiesFlow = null!;


        private TextBox
            _motoriduttoreTextBox = null!;

        private TextBox
            _ruotaTextBox = null!;

        private TextBox
            _velocitaTextBox = null!;


        private DataGridView
            _productsGrid = null!;


        private GeneraVerbaliSettingsModel
            _settings = new GeneraVerbaliSettingsModel();

        private bool
    _updatingVelocityAutomatically;

        private string
    _originalBeltSpeedValue =
        string.Empty;

        private DataGridViewColumn?
            _velocityColumn;

        private readonly List<(
    GeneraVerbaliStlPropertySetting Setting,
    TextBox TextBox)>
    _dynamicPropertyTextBoxes =
        new();

        private readonly Dictionary<TextBox, string>
    _originalInventorPropertyValues =
        new();

        private GeneraVerbaliCheckoutPromptForm?
    _generateCheckoutPrompt;

        private bool
            _generatingReport;

        private readonly GeneraVerbaliModalitaLSession?
    _modalitaLSession;

        private bool
            _closeWithoutPrompt;

        public bool ModalitaLStepCompleted { get; private set; }

        public bool CloseWholeFeature { get; private set; }

        private GeneraVerbaliExcelSession?
    _excelSession;

        private string
            _generatedReportPath =
                string.Empty;

        private enum PrepareOutputResult
        {
            Ready,
            SkipExisting,
            Error
        }


        public GeneraVerbaliModalitaStlForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext)
            : this(
                inventorApp,
                openContext,
                null)
        {
        }


        public GeneraVerbaliModalitaStlForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext,
            GeneraVerbaliModalitaLSession? modalitaLSession)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _modalitaLSession =
                modalitaLSession;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliModalitaSTL",
                    1100,
                    820);

            InitializeComponent();

            KeyPreview =
                 true;

            KeyDown +=
                GeneraVerbaliModalitaStlForm_KeyDown;

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            LoadConfiguration();

            RefreshBeltSpeedFromInventor();

            RefreshConfiguredInventorProperties();

            LoadProductsDataFromInventor();

            UpdateAutomaticVelocityForAllRows();

            GeneraVerbaliGridLayoutService
                .ApplyRowHeights(
                    "ModalitaSTL",
                    _productsGrid);

        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(42, 44, 50)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(185, 190, 200)
                    : Color.FromArgb(100, 116, 139);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Text =
                "Genera Verbali - Modalità STL";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    900,
                    700);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliModalitaStlForm_FormClosing;


            /*
             * ==========================================
             * ROOT
             * ==========================================
             */
            TableLayoutPanel rootLayout =
                new TableLayoutPanel
                {
                    Dock =
                        DockStyle.Fill,

                    RowCount =
                        2,

                    ColumnCount =
                        1,

                    Padding =
                        new Padding(
                            0),

                    Margin =
                        new Padding(
                            0),

                    BackColor =
                        backgroundColor
                };

            rootLayout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100F));

            rootLayout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    145F));


            /*
             * ==========================================
             * CONTENUTO SCORREVOLE
             * ==========================================
             */
            _contentFlow =
                new FlowLayoutPanel
                {
                    Dock =
                        DockStyle.Fill,

                    AutoScroll =
                        true,

                    FlowDirection =
                        FlowDirection.TopDown,

                    WrapContents =
                        false,

                    Padding =
                        new Padding(
                            28,
                            24,
                            28,
                            24),

                    BackColor =
                        backgroundColor
                };

            _contentFlow.Resize +=
                ContentFlow_Resize;

            /*
             * ==========================================
             * CALCOLO VELOCITÀ NASTRO
             * ==========================================
             */
            Panel speedSection =
                new Panel
                {
                    Height =
                        190,

                    BackColor =
                        panelColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            18)
                };

            speedSection.TabIndex =
             0;


            Label speedTitle =
                CreateSectionTitle(
                    "Calcolo Velocità Nastro",
                    20,
                    18,
                    textColor);


            /*
             * ==========================================
             * MOTORIDUTTORE
             * ==========================================
             */
            _motoriduttoreTextBox =
                CreateInputTextBox(
                    20,
                    60,
                    125,
                    inputColor,
                    textColor);

            _motoriduttoreTextBox.TabIndex =
                0;


            Button selectMotoriduttoreButton =
                CreateActionButton(
                    "Selezione Motoriduttore",
                    155,
                    59,
                    190,
                    Color.FromArgb(
                        126,
                        34,
                        206));

            selectMotoriduttoreButton.TabStop =
                 false;

            selectMotoriduttoreButton.Click +=
                SelectMotoriduttoreButton_Click;


            /*
             * ==========================================
             * RUOTA
             * ==========================================
             */
            _ruotaTextBox =
                CreateInputTextBox(
                    20,
                    115,
                    125,
                    inputColor,
                    textColor);

            _ruotaTextBox.TabIndex =
                1;


            Button selectRuotaButton =
                CreateActionButton(
                    "Seleziona Ruota",
                    155,
                    114,
                    190,
                    Color.FromArgb(
                        234,
                        179,
                        8));

            selectRuotaButton.TabStop =
                 false;

            selectRuotaButton.Click +=
                SelectRuotaButton_Click;


            /*
             * ==========================================
             * GRAFFA
             * ==========================================
             *
             * La graffa raggruppa Motoriduttore + Ruota.
             *
             * Non viene disegnata alcuna linea orizzontale.
             */
            Label calculationBraceLabel =
                new Label
                {
                    Text =
                        "}",

                    Location =
                        new Point(
                            360,
                            48),

                    Size =
                        new Size(
                            55,
                            110),

                    AutoSize =
                        false,

                    TextAlign =
                        ContentAlignment.MiddleCenter,

                    Font =
                        new Font(
                            "Segoe UI",
                            58F,
                            FontStyle.Regular),

                    ForeColor =
                        textColor,

                    BackColor =
                        Color.Transparent
                };


            /*
             * ==========================================
             * VELOCITÀ
             * ==========================================
             *
             * Il centro verticale della TextBox viene
             * posizionato in corrispondenza del centro
             * della graffa.
             */
            Label speedResultLabel =
                new Label
                {
                    Text =
                        "Velocità nastro",

                    Font =
                        new Font(
                            "Segoe UI",
                            9.5F,
                            FontStyle.Bold),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            430,
                            72)
                };


            _velocitaTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            430,
                            96),

                    Size =
                        new Size(
                            125,
                            31),

                    AutoSize =
                        false,

                    BackColor =
                        _isDarkTheme
                            ? Color.FromArgb(
                                37,
                                54,
                                70)
                            : Color.FromArgb(
                                239,
                                246,
                                255),

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold),

                        TabIndex =
                         2,
                };


            Button calculateSpeedButton =
                CreateActionButton(
                    "Calcola Velocità",
                    570,
                    95,
                    165,
                    Color.FromArgb(
                        14,
                        165,
                        233));

            calculateSpeedButton.TabStop =
                false;

            calculateSpeedButton.Click +=
                CalculateSpeedButton_Click;


            /*
             * ==========================================
             * AGGIUNTA CONTROLLI
             * ==========================================
             */
            speedSection.Controls.Add(
                speedTitle);

            speedSection.Controls.Add(
                _motoriduttoreTextBox);

            speedSection.Controls.Add(
                selectMotoriduttoreButton);

            speedSection.Controls.Add(
                _ruotaTextBox);

            speedSection.Controls.Add(
                selectRuotaButton);

            speedSection.Controls.Add(
                calculationBraceLabel);

            speedSection.Controls.Add(
                speedResultLabel);

            speedSection.Controls.Add(
                _velocitaTextBox);

            speedSection.Controls.Add(
                calculateSpeedButton);


            /*
             * ==========================================
             * SEPARATORE
             * ==========================================
             */
            Panel separator1 =
                CreateSeparator(
                    borderColor);


            /*
             * ==========================================
             * COMPOSIZIONE VERBALE
             * ==========================================
             */
            Panel propertiesSection =
                new Panel
                {
                    Height =
                        200,

                    BackColor =
                        backgroundColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            10)
                };
;

            Label propertiesTitle =
                CreateSectionTitle(
                    "Composizione Verbale di Collaudo",
                    0,
                    8,
                    textColor);


            Button refreshPropertiesButton =
                new Button
                {
                    Text =
                        "⟳",

                    Size =
                        new Size(
                            42,
                            36),

                    /*
                     * Subito dopo il titolo.
                     */
                    Location =
                        new Point(
                            310,
                            0),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            15F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            refreshPropertiesButton.TabStop =
                false;

            refreshPropertiesButton.FlatAppearance.BorderSize =
                0;

            refreshPropertiesButton.Click +=
                RefreshPropertiesButton_Click;


            refreshPropertiesButton.FlatAppearance.BorderColor =
                borderColor;


            _dynamicPropertiesFlow =
                new FlowLayoutPanel
                {
                    Location =
                        new Point(
                            0,
                            58),

                    Size =
                        new Size(
                            propertiesSection.Width,
                            120),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlowDirection =
                        FlowDirection.TopDown,

                    WrapContents =
                        false,

                    AutoScroll =
                        false,

                    BackColor =
                        backgroundColor,

                    Padding =
                        new Padding(
                            0),

                    Margin =
                        new Padding(
                            0)
                };

            _dynamicPropertiesFlow.TabIndex =
                 0;


            propertiesSection.Controls.Add(
                propertiesTitle);

            propertiesSection.Controls.Add(
                refreshPropertiesButton);

            propertiesSection.Controls.Add(
                _dynamicPropertiesFlow);


            /*
             * ==========================================
             * TABELLA PRODOTTI
             * ==========================================
             */
            Panel tableSection =
                new Panel
                {
                    Height =
                        330,

                    BackColor =
                        backgroundColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            18)
                };

            tableSection.TabIndex =
                2;


            _productsGrid =
                new DataGridView
                {
                    Location =
                        new Point(
                            0,
                            0),

                    Size =
                        new Size(
                            tableSection.Width,
                            265),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                        true,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    MultiSelect =
                        false,

                    SelectionMode =
                     DataGridViewSelectionMode.CellSelect,

                    BackgroundColor =
                        panelColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    GridColor =
                        borderColor,

                    EnableHeadersVisualStyles =
                        false,

                    EditMode =
                      DataGridViewEditMode.EditOnEnter,

                    StandardTab =
                     false,
                };

            _productsGrid.TabIndex =
                0;


            ConfigureGridStyle(
                _productsGrid,
                panelColor,
                inputColor,
                textColor,
                borderColor);

            _productsGrid.CellValueChanged +=
                ProductsGrid_CellValueChanged;

            _productsGrid.CellEndEdit +=
                ProductsGrid_CellEndEdit;

            _productsGrid.EditingControlShowing +=
                ProductsGrid_EditingControlShowing;


            Button addRowButton =
                CreateSecondaryButton(
                    "Aggiungi riga",
                    0,
                    282,
                    125,
                    panelColor,
                    textColor,
                    borderColor);

            addRowButton.TabStop =
                 false;

            addRowButton.Click +=
                AddRowButton_Click;


            Button removeRowButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    135,
                    282,
                    95,
                    panelColor,
                    textColor,
                    borderColor);

            removeRowButton.TabStop =
                 false;

            removeRowButton.Click +=
                RemoveRowButton_Click;


            Button moveUpButton =
                CreateSecondaryButton(
                    "▲",
                    240,
                    282,
                    45,
                    panelColor,
                    textColor,
                    borderColor);

            moveUpButton.TabStop =
                false;

            moveUpButton.Click +=
                MoveUpButton_Click;


            Button moveDownButton =
                CreateSecondaryButton(
                    "▼",
                    295,
                    282,
                    45,
                    panelColor,
                    textColor,
                    borderColor);

            moveDownButton.TabStop =
                false;


            moveDownButton.Click +=
                MoveDownButton_Click;


            tableSection.Controls.Add(
                _productsGrid);

            tableSection.Controls.Add(
                addRowButton);

            tableSection.Controls.Add(
                removeRowButton);

            tableSection.Controls.Add(
                moveUpButton);

            tableSection.Controls.Add(
                moveDownButton);


            /*
             * ==========================================
             * SEPARATORE FINALE
             * ==========================================
             */
            Panel separator2 =
                CreateSeparator(
                    borderColor);


            /*
             * ==========================================
             * GENERA VERBALE
             * ==========================================
             */
            Panel generatePanel =
                new Panel
                {
                    Dock =
                        DockStyle.Fill,

                    Padding =
                        new Padding(
                            28,
                            14,
                            28,
                            18),

                    BackColor =
                        backgroundColor
                };


            Button generateButton =
                new Button
                {
                    Text =
                        "GENERA VERBALE",

                    Dock =
                        DockStyle.Fill,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            22,
                            163,
                            74),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            13F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            generateButton.TabStop =
              false;

            generateButton.FlatAppearance.BorderSize =
                0;

            generateButton.Click +=
                GenerateButton_Click;


            generatePanel.Controls.Add(
                generateButton);


            /*
             * ==========================================
             * COMPOSIZIONE FINALE
             * ==========================================
             */
            _contentFlow.Controls.Add(
                speedSection);

            _contentFlow.Controls.Add(
                separator1);

            _contentFlow.Controls.Add(
                propertiesSection);

            _contentFlow.Controls.Add(
                tableSection);

            _contentFlow.Controls.Add(
                separator2);


            rootLayout.Controls.Add(
                _contentFlow,
                0,
                0);

            rootLayout.Controls.Add(
                generatePanel,
                0,
                1);


            Controls.Add(
                rootLayout);
        }


        /*
         * ==========================================
         * CONFIGURAZIONE DAL JSON
         * ==========================================
         */
        private void LoadConfiguration()
        {
            _settings =
                GeneraVerbaliSettingsService.Load();

            BuildDynamicProperties();

            BuildProductColumns();

            CreateInitialRows();

            ResizeDynamicSections();
        }


        /*
         * ==========================================
         * PROPRIETÀ DINAMICHE
         * ==========================================
         */
        private void BuildDynamicProperties()
        {
            _dynamicPropertiesFlow.Controls.Clear();

            _dynamicPropertyTextBoxes.Clear();


            /*
             * 0 = Motoriduttore
             * 1 = Ruota
             * 2 = Velocità
             *
             * Le proprietà dinamiche iniziano quindi da 3.
             */
            int nextPropertyTabIndex =
                0;


            if (_settings.ModalitaSTL?.Properties == null)
            {

                return;
            }


            foreach (GeneraVerbaliStlPropertySetting property in
                _settings.ModalitaSTL.Properties)
            {
                Panel propertyPanel =
                    new Panel
                    {
                        Height =
                            72,

                        Width =
                            Math.Max(
                                300,
                                _dynamicPropertiesFlow.ClientSize.Width - 5),

                        Margin =
                            new Padding(
                                0,
                                0,
                                0,
                                10),

                                    TabIndex =
                         nextPropertyTabIndex++
                    };


                Label titleLabel =
                    new Label
                    {
                        Text =
                            property.TextBoxName,

                        Font =
                            new Font(
                                "Segoe UI",
                                9.5F,
                                FontStyle.Bold),

                        ForeColor =
                            _isDarkTheme
                                ? Color.White
                                : Color.FromArgb(15, 23, 42),

                        AutoSize =
                            true,

                        Location =
                            new Point(
                                0,
                                0)
                    };


                TextBox valueTextBox =
                    new TextBox
                    {
                        Location =
                            new Point(
                                0,
                                28),

                        Size =
                            new Size(
                                300,
                                30),

                        Anchor =
                            AnchorStyles.Top |
                            AnchorStyles.Left,

                        BackColor =
                            _isDarkTheme
                                ? Color.FromArgb(42, 44, 50)
                                : Color.White,

                        ForeColor =
                            _isDarkTheme
                                ? Color.White
                                : Color.FromArgb(15, 23, 42),

                        BorderStyle =
                            BorderStyle.FixedSingle,

                        Font =
                            new Font(
                                "Segoe UI",
                                9.5F),

                        /*
                         * Se NON è proprietà Inventor,
                         * il testo configurato viene già mostrato.
                         *
                         * Se è proprietà Inventor,
                         * il valore verrà successivamente
                         * letto dall'assieme attivo.
                         */
                        Text =
                            property.IsInventorProperty
                                ? string.Empty
                                : property.TextBoxText,

                        Tag =
                            property,

                        /*
                         * Ogni TextBox dinamica riceve
                         * il TabIndex successivo.
                         */
                        TabIndex =
                        0
                    };


                /*
                 * Manteniamo il collegamento tra
                 * configurazione e relativa TextBox.
                 *
                 * Serve alla logica già esistente per:
                 * - refresh proprietà Inventor;
                 * - rilevamento modifiche;
                 * - scrittura iProperties;
                 * - compilazione Excel.
                 */
                _dynamicPropertyTextBoxes.Add(
                (
                    property,
                    valueTextBox
                ));


                propertyPanel.Controls.Add(
                    titleLabel);

                propertyPanel.Controls.Add(
                    valueTextBox);


                _dynamicPropertiesFlow.Controls.Add(
                    propertyPanel);
            }
        }


        /*
         * ==========================================
         * COLONNE TABELLA DAL JSON
         * ==========================================
         */
        private void BuildProductColumns()
        {
            _productsGrid.Columns.Clear();

            _velocityColumn =
                null;


            if (_settings.ModalitaSTL?.FormColumns == null)
                return;


            foreach (
                GeneraVerbaliStlFormColumnSetting configuredColumn
                in _settings.ModalitaSTL.FormColumns)
            {
                if (string.IsNullOrWhiteSpace(
                    configuredColumn.Name))
                {
                    continue;
                }


                DataGridViewTextBoxColumn column =
                    new DataGridViewTextBoxColumn
                    {
                        Name =
                            Guid.NewGuid().ToString(),

                        HeaderText =
                            configuredColumn.Name,

                        AutoSizeMode =
                            DataGridViewAutoSizeColumnMode.Fill,

                        SortMode =
                            DataGridViewColumnSortMode.NotSortable,

                        Tag =
                            configuredColumn
                    };


                _productsGrid.Columns.Add(
                    column);
            }


            /*
             * Solo DOPO aver creato tutte le colonne
             * individuiamo Velocità.
             */
            _velocityColumn =
                _productsGrid
                    .Columns
                    .Cast<DataGridViewColumn>()
                    .FirstOrDefault(
                        IsVelocityColumn);
        }

        /*
         * ==========================================
         * 5 RIGHE INIZIALI
         * ==========================================
         */
        private void CreateInitialRows()
        {
            if (_productsGrid.Columns.Count == 0)
                return;


            for (int i = 0;
                 i < 5;
                 i++)
            {
                _productsGrid.Rows.Add();
            }
        }


        /*
         * ==========================================
         * RIDIMENSIONAMENTO
         * ==========================================
         */
        private void ContentFlow_Resize(
            object? sender,
            EventArgs e)
        {
            ResizeDynamicSections();
        }


        private void ResizeDynamicSections()
        {
            int availableWidth =
                Math.Max(
                    600,
                    _contentFlow.ClientSize.Width -
                    _contentFlow.Padding.Left -
                    _contentFlow.Padding.Right -
                    24);


            foreach (Control control in
                _contentFlow.Controls)
            {
                control.Width =
                    availableWidth;
            }


            /*
             * Proprietà dinamiche.
             */
            foreach (Control control in
                _dynamicPropertiesFlow.Controls)
            {
                control.Width =
                    Math.Max(
                        300,
                        _dynamicPropertiesFlow.ClientSize.Width - 5);
            }


            Control? propertiesSection =
                _dynamicPropertiesFlow.Parent;

            if (propertiesSection != null)
            {
                int propertiesHeight =
                    Math.Max(
                        80,
                        _dynamicPropertiesFlow.Controls.Count * 82);


                _dynamicPropertiesFlow.Height =
                    propertiesHeight;


                propertiesSection.Height =
                    70 +
                    propertiesHeight;
            }
        }


        /*
         * ==========================================
         * HELPER UI
         * ==========================================
         */
        private Label CreateSectionTitle(
            string text,
            int x,
            int y,
            Color textColor)
        {
            return new Label
            {
                Text =
                    text,

                Location =
                    new Point(
                        x,
                        y),

                AutoSize =
                    true,

                ForeColor =
                    textColor,

                Font =
                    new Font(
                        "Segoe UI",
                        12F,
                        FontStyle.Bold)
            };
        }


        private TextBox CreateInputTextBox(
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor)
        {
            return new TextBox
            {
                Location =
                    new Point(
                        x,
                        y),

                Size =
                    new Size(
                        width,
                        31),

                AutoSize =
                    false,

                BackColor =
                    backgroundColor,

                ForeColor =
                    textColor,

                BorderStyle =
                    BorderStyle.FixedSingle,

                Font =
                    new Font(
                        "Segoe UI",
                        9.5F)
            };
        }


        private Button CreateActionButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            31),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };


            button.FlatAppearance.BorderSize =
                0;


            return button;
        }


        private Panel CreateSeparator(
            Color borderColor)
        {
            return new Panel
            {
                Height =
                    1,

                Margin =
                    new Padding(
                        0,
                        0,
                        0,
                        18),

                BackColor =
                    borderColor
            };
        }


        private Button CreateSecondaryButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor,
            Color borderColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };


            button.FlatAppearance.BorderColor =
                borderColor;


            return button;
        }


        private void ConfigureGridStyle(
            DataGridView grid,
            Color backgroundColor,
            Color cellColor,
            Color textColor,
            Color borderColor)
        {
            grid.DefaultCellStyle.BackColor =
                cellColor;

            grid.DefaultCellStyle.ForeColor =
                textColor;

            grid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            grid.DefaultCellStyle.SelectionForeColor =
                Color.White;

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F);

            grid.DefaultCellStyle.Padding =
                new Padding(
                    0);


            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                grid.ColumnHeadersDefaultCellStyle.BackColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold);

            /*
             * Le intestazioni possono andare su più righe
             * senza essere tagliate.
             */
            grid.ColumnHeadersDefaultCellStyle.WrapMode =
                DataGridViewTriState.True;

            grid.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;


            /*
             * Anche il testo delle celle può andare
             * a capo quando l'utente aumenta manualmente
             * l'altezza della riga.
             */
            grid.DefaultCellStyle.WrapMode =
                DataGridViewTriState.True;


            /*
             * Altezza standard delle nuove righe.
             * Le altezze modificate manualmente vengono
             * poi memorizzate dal GridLayoutService.
             */
            grid.RowTemplate.Height =
                34;
        }


        /*
         * ==========================================
         * GESTIONE RIGHE
         * ==========================================
         */
        private void AddRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.Columns.Count == 0)
                return;


            int rowIndex =
                _productsGrid.Rows.Add();


            _productsGrid.ClearSelection();

            _productsGrid.Rows[rowIndex]
                .Selected =
                true;


            _productsGrid.CurrentCell =
                _productsGrid.Rows[rowIndex]
                    .Cells[0];

            _productsGrid.BeginEdit(
                true);
        }


        private void RemoveRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int index =
                _productsGrid.CurrentRow.Index;


            if (index < 0 ||
                index >= _productsGrid.Rows.Count)
            {
                return;
            }


            _productsGrid.Rows.RemoveAt(
                index);
        }


        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int currentIndex =
                _productsGrid.CurrentRow.Index;


            if (currentIndex <= 0)
                return;


            SwapRows(
                currentIndex,
                currentIndex - 1);
        }


        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int currentIndex =
                _productsGrid.CurrentRow.Index;


            if (currentIndex < 0 ||
                currentIndex >=
                _productsGrid.Rows.Count - 1)
            {
                return;
            }


            SwapRows(
                currentIndex,
                currentIndex + 1);
        }


        private void SwapRows(
            int sourceIndex,
            int destinationIndex)
        {
            _productsGrid.EndEdit();


            object?[] sourceValues =
                new object?[
                    _productsGrid.Columns.Count];

            object?[] destinationValues =
                new object?[
                    _productsGrid.Columns.Count];


            for (int columnIndex = 0;
                 columnIndex < _productsGrid.Columns.Count;
                 columnIndex++)
            {
                sourceValues[columnIndex] =
                    _productsGrid.Rows[sourceIndex]
                        .Cells[columnIndex]
                        .Value;

                destinationValues[columnIndex] =
                    _productsGrid.Rows[destinationIndex]
                        .Cells[columnIndex]
                        .Value;
            }


            for (int columnIndex = 0;
                 columnIndex < _productsGrid.Columns.Count;
                 columnIndex++)
            {
                _productsGrid.Rows[destinationIndex]
                    .Cells[columnIndex]
                    .Value =
                    sourceValues[columnIndex];

                _productsGrid.Rows[sourceIndex]
                    .Cells[columnIndex]
                    .Value =
                    destinationValues[columnIndex];
            }


            _productsGrid.ClearSelection();

            _productsGrid.Rows[destinationIndex]
                .Selected =
                true;

            _productsGrid.CurrentCell =
                _productsGrid.Rows[destinationIndex]
                    .Cells[0];
        }


        /*
         * ==========================================
         * EVENTI - LOGICA SUCCESSIVA
         * ==========================================
         */
        private void SelectMotoriduttoreButton_Click(
            object? sender,
            EventArgs e)
        {
            string description =
                InventorService
                    .ReadSelectedDocumentProperty(
                        _inventorApp,
                        GeneraVerbaliStlVelocityService
                            .MotorReductionPropertyName);



            if (string.IsNullOrWhiteSpace(
                description))
            {
                MessageBox.Show(
                    this,
                    "Seleziona in Inventor il motoriduttore interessato " +
                    "prima di premere il pulsante.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (!GeneraVerbaliStlVelocityService
                .TryExtractReductionRatio(
                    description,
                    out string reductionRatio))
            {
                MessageBox.Show(
                    this,
                    "Nel RAPPORTO DI RID del componente selezionato " +
                    "non è stato trovato un rapporto di riduzione nel formato i=NUMERO.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            _motoriduttoreTextBox.Text =
                reductionRatio;
        }


        private void SelectRuotaButton_Click(
            object? sender,
            EventArgs e)
        {
            string primitiveDiameter =
                InventorService
                    .ReadSelectedDocumentCustomProperty(
                        _inventorApp,
                        GeneraVerbaliStlVelocityService
                            .PrimitiveDiameterPropertyName);


            if (string.IsNullOrWhiteSpace(
                primitiveDiameter))
            {
                MessageBox.Show(
                    this,
                    "Nel componente selezionato non è stata trovata " +
                    "la proprietà Custom \"D PRIMITIVO_S\".",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (!GeneraVerbaliStlVelocityService
                .TryExtractPrimitiveDiameter(
                    primitiveDiameter,
                    out string diameter))
            {
                MessageBox.Show(
                    this,
                    "Il valore della proprietà \"D PRIMITIVO_S\" " +
                    "non è in un formato valido.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            _ruotaTextBox.Text =
                diameter;
        }


        private void CalculateSpeedButton_Click(
            object? sender,
            EventArgs e)
        {
            if (!GeneraVerbaliStlVelocityService
                .TryParseNumber(
                    _motoriduttoreTextBox.Text,
                    out double reductionRatio))
            {
                MessageBox.Show(
                    this,
                    "Inserisci un rapporto di riduzione valido.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (!GeneraVerbaliStlVelocityService
                .TryParseNumber(
                    _ruotaTextBox.Text,
                    out double primitiveDiameter))
            {
                MessageBox.Show(
                    this,
                    "Inserisci un diametro primitivo valido.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (reductionRatio <= 0 ||
                primitiveDiameter <= 0)
            {
                MessageBox.Show(
                    this,
                    "Rapporto di riduzione e diametro primitivo " +
                    "devono essere maggiori di zero.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (!GeneraVerbaliStlVelocityService
                .TryCalculateBeltSpeed(
                    reductionRatio,
                    primitiveDiameter,
                    out double beltSpeed))
            {
                MessageBox.Show(
                    this,
                    "Non è stato possibile calcolare la velocità.",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Mostriamo solamente il valore numerico.
             * L'unità implicita è MT/MIN.
             */
            _velocitaTextBox.Text =
                Math.Round(
                    beltSpeed,
                    2)
                .ToString(
                    "0.##",
                    System.Globalization
                        .CultureInfo.CurrentCulture);

            UpdateAutomaticVelocityForAllRows();
        }


        private void RefreshPropertiesButton_Click(
            object? sender,
            EventArgs e)
        {
            /*
             * Rilegge VELOCITA MT_MIN.
             */
            RefreshBeltSpeedFromInventor();


            /*
             * Rilegge tutte le proprietà configurate
             * con "Proprietà Inventor? = true".
             */
            RefreshConfiguredInventorProperties();
        }


        private void GenerateButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_generatingReport)
                return;


            /*
             * ==========================================
             * MODALITÀ L
             * ==========================================
             *
             * Il checkout è già stato confermato
             * nel Form L.
             *
             * Quindi il popup checkout STL
             * viene bypassato completamente.
             */
            if (_modalitaLSession != null)
            {
                GenerateCheckoutPrompt_Confirmed(
                    null,
                    EventArgs.Empty);

                return;
            }


            /*
             * ==========================================
             * MODALITÀ STL SINGOLA
             * ==========================================
             */
            if (_generateCheckoutPrompt != null &&
                !_generateCheckoutPrompt.IsDisposed)
            {
                _generateCheckoutPrompt.Show();

                _generateCheckoutPrompt.BringToFront();

                _generateCheckoutPrompt.Activate();

                return;
            }


            _generateCheckoutPrompt =
                new GeneraVerbaliCheckoutPromptForm(
                    _isDarkTheme);


            _generateCheckoutPrompt.Confirmed +=
                GenerateCheckoutPrompt_Confirmed;


            _generateCheckoutPrompt.FormClosed +=
                (_, _) =>
                {
                    _generateCheckoutPrompt =
                        null;
                };


            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);


            _generateCheckoutPrompt.Show(
                owner);
        }


        /*
         * ==========================================
         * WINDOW SETTINGS
         * ==========================================
         */
        private void GeneraVerbaliModalitaStlForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            /*
             * ==========================================
             * CHIUSURA AUTOMATICA MODALITÀ L
             * ==========================================
             */
            if (_closeWithoutPrompt)
            {
                GeneraVerbaliGridLayoutService
                    .SaveRowHeights(
                        "ModalitaSTL",
                        _productsGrid);


                WindowSettingsService.Save(
                    this,
                    "GeneraVerbaliModalitaSTL");

                return;
            }


            /*
             * ==========================================
             * CHIUSURA MANUALE
             * ==========================================
             */
            if (e.CloseReason ==
                CloseReason.UserClosing)
            {
                using GeneraVerbaliStlCloseDialog dialog =
                    new GeneraVerbaliStlCloseDialog(
                        _isDarkTheme);


                DialogResult result =
                    dialog.ShowDialog(
                        this);


                /*
                 * Se l'utente chiude il popup con X
                 * NON chiudiamo il Form e quindi
                 * NON salviamo ancora il layout.
                 */
                if (result !=
                    DialogResult.OK)
                {
                    e.Cancel =
                        true;

                    return;
                }


                CloseWholeFeature =
                    dialog.CloseWholeFeature;
            }


            /*
             * ==========================================
             * SALVATAGGIO LAYOUT
             * ==========================================
             */
            GeneraVerbaliGridLayoutService
                .SaveRowHeights(
                    "ModalitaSTL",
                    _productsGrid);


            WindowSettingsService.Save(
                this,
                "GeneraVerbaliModalitaSTL");
        }
        private void RefreshBeltSpeedFromInventor()
        {
            string velocity =
                InventorService
                    .ReadActiveAssemblyCustomProperty(
                        _inventorApp,
                        GeneraVerbaliStlVelocityService
                            .BeltSpeedPropertyName)
                    .Trim();


            _velocitaTextBox.Text =
                velocity;


            /*
             * Fotografia del valore originale.
             */
            _originalBeltSpeedValue =
                velocity;


            UpdateAutomaticVelocityForAllRows();
        }
        private void RefreshConfiguredInventorProperties()
        {
            foreach (var item
                in _dynamicPropertyTextBoxes)
            {
                GeneraVerbaliStlPropertySetting setting =
                    item.Setting;

                TextBox textBox =
                    item.TextBox;


                /*
                 * Le textbox NON collegate a Inventor
                 * non devono essere toccate dal refresh.
                 */
                if (!setting.IsInventorProperty)
                    continue;


                string propertyName =
                    setting.TextBoxText?.Trim()
                    ?? string.Empty;


                /*
                 * Se nelle impostazioni non è stato
                 * specificato il nome della iProperty,
                 * lasciamo la textbox vuota.
                 */
                if (string.IsNullOrWhiteSpace(
                    propertyName))
                {
                    textBox.Text =
                        string.Empty;

                    continue;
                }


                string propertyValue =
                    InventorService
                        .ReadActiveAssemblyCustomProperty(
                            _inventorApp,
                            propertyName);


                string normalizedValue =
                    propertyValue?.Trim()
                    ?? string.Empty;

                textBox.Text =
                    normalizedValue;

                /*
                 * Il valore appena letto diventa il nuovo
                 * riferimento rispetto al quale capiremo
                 * se l'utente ha effettuato modifiche.
                 */
                _originalInventorPropertyValues[textBox] =
                    normalizedValue;
            }
        }
        private void LoadProductsDataFromInventor()
        {
            /*
             * Leggiamo la Custom iProperty
             * dall'assieme STL attualmente aperto.
             */
            string productsData =
                InventorService
                    .ReadActiveAssemblyCustomProperty(
                        _inventorApp,
                        "DATI_COLLAUDO_PRODOTTI");


            /*
             * Se la proprietà non esiste oppure
             * non contiene dati, manteniamo semplicemente
             * la tabella iniziale così com'è.
             */
            if (string.IsNullOrEmpty(
                productsData))
            {
                return;
            }


            List<string> values =
                GeneraVerbaliModalitaLService
                    .ParseProductsData(
                        productsData);


            if (values.Count == 0)
                return;


            /*
             * Individuiamo tutte le colonne sulle quali
             * devono essere riportati i dati.
             *
             * La colonna "Velocità" viene esclusa SEMPRE,
             * indipendentemente dalla sua posizione.
             */
            List<DataGridViewColumn> destinationColumns =
                _productsGrid
                    .Columns
                    .Cast<DataGridViewColumn>()
                    .Where(column =>
                        !IsVelocityColumn(column))
                    .OrderBy(column =>
                        column.Index)
                    .ToList();


            if (destinationColumns.Count == 0)
                return;


            /*
             * Ogni riga proveniente dalla Modalità L
             * contiene esattamente un valore per ogni
             * colonna STL esclusa Velocità.
             */
            int valuesPerRow =
                destinationColumns.Count;


            int requiredRows =
                (int)Math.Ceiling(
                    values.Count /
                    (double)valuesPerRow);


            /*
             * Puliamo le righe iniziali del Form STL.
             */
            _productsGrid.Rows.Clear();


            /*
             * Manteniamo comunque almeno 5 righe,
             * come previsto dalla UI originale.
             *
             * Se i prodotti sono più di 5,
             * ne creiamo automaticamente quante servono.
             */
            int rowsToCreate =
                Math.Max(
                    5,
                    requiredRows);


            for (int rowIndex = 0;
                 rowIndex < rowsToCreate;
                 rowIndex++)
            {
                _productsGrid.Rows.Add();
            }


            /*
             * Distribuzione:
             *
             * leggiamo DATI_COLLAUDO_PRODOTTI
             * in sequenza e scriviamo sulle colonne
             * in sequenza saltando Velocità.
             */
            int valueIndex =
                0;


            for (int rowIndex = 0;
                 rowIndex < requiredRows;
                 rowIndex++)
            {
                foreach (
                    DataGridViewColumn column
                    in destinationColumns)
                {
                    if (valueIndex >=
                        values.Count)
                    {
                        return;
                    }


                    _productsGrid
                        .Rows[rowIndex]
                        .Cells[column.Index]
                        .Value =
                        values[valueIndex];


                    valueIndex++;
                }
            }
        }
        private void UpdateAutomaticVelocityForRow(
    DataGridViewRow row)
        {
            if (_velocityColumn == null)
                return;

            if (row.IsNewRow)
                return;


            DataGridViewCell velocityCell =
                row.Cells[
                    _velocityColumn.Index];


            /*
             * Se l'utente ha modificato manualmente
             * questa specifica cella Velocità,
             * gli automatismi non devono più toccarla.
             */
            bool manuallyModified =
                velocityCell.Tag is bool manual &&
                manual;


            if (manuallyModified)
                return;


            /*
             * Una riga è considerata utilizzata
             * se almeno UNA colonna diversa da
             * Velocità contiene un valore.
             *
             * Velocità viene esclusa apposta,
             * altrimenti il proprio valore automatico
             * impedirebbe di riconoscere una riga vuota.
             */
            bool rowHasData =
                false;


            foreach (DataGridViewColumn column
                in _productsGrid.Columns)
            {
                if (column.Index ==
                    _velocityColumn.Index)
                {
                    continue;
                }


                string cellValue =
                    row.Cells[column.Index]
                        .Value
                        ?.ToString()
                        ?.Trim()
                    ?? string.Empty;


                if (!string.IsNullOrWhiteSpace(
                    cellValue))
                {
                    rowHasData =
                        true;

                    break;
                }
            }


            try
            {
                _updatingVelocityAutomatically =
                    true;


                if (rowHasData)
                {
                    /*
                     * Riga utilizzata:
                     * riportiamo la velocità attualmente
                     * presente nella textbox superiore.
                     */
                    velocityCell.Value =
                        _velocitaTextBox.Text?.Trim()
                        ?? string.Empty;
                }
                else
                {
                    /*
                     * Riga completamente vuota:
                     * eliminiamo la velocità automatica.
                     */
                    velocityCell.Value =
                        string.Empty;
                }
            }
            finally
            {
                _updatingVelocityAutomatically =
                    false;
            }
        }
        private void UpdateAutomaticVelocityForAllRows()
        {
            if (_velocityColumn == null)
                return;


            foreach (DataGridViewRow row
                in _productsGrid.Rows)
            {
                UpdateAutomaticVelocityForRow(
                    row);
            }
        }
        private void ProductsGrid_CellValueChanged(
    object? sender,
    DataGridViewCellEventArgs e)
        {
            if (_updatingVelocityAutomatically)
                return;

            if (e.RowIndex < 0 ||
                e.RowIndex >=
                _productsGrid.Rows.Count)
            {
                return;
            }

            if (_velocityColumn == null)
                return;


            /*
             * Se è cambiata una colonna normale,
             * rivalutiamo automaticamente la velocità
             * della riga.
             */
            if (e.ColumnIndex !=
                _velocityColumn.Index)
            {
                UpdateAutomaticVelocityForRow(
                    _productsGrid.Rows[e.RowIndex]);
            }
        }
        private void ProductsGrid_CellEndEdit(
    object? sender,
    DataGridViewCellEventArgs e)
        {
            if (_updatingVelocityAutomatically)
                return;

            if (_velocityColumn == null)
                return;

            if (e.RowIndex < 0 ||
                e.RowIndex >=
                _productsGrid.Rows.Count)
            {
                return;
            }


            if (e.ColumnIndex !=
                _velocityColumn.Index)
            {
                return;
            }


            /*
             * L'utente ha modificato direttamente
             * la cella Velocità.
             *
             * Da questo momento quella specifica cella
             * ha sempre la precedenza sugli automatismi.
             */
            _productsGrid
                .Rows[e.RowIndex]
                .Cells[e.ColumnIndex]
                .Tag =
                true;
        }
        private bool WriteModifiedInventorProperties(
           out string errorMessage)
        {
            errorMessage =
                string.Empty;

            global::Inventor.AssemblyDocument? assembly =
                InventorService.GetActiveAssembly(
                    _inventorApp);

            if (assembly == null)
            {
                errorMessage =
                    "Non è presente un assieme attivo in Inventor.";

                return false;
            }


            bool hasChanges =
                false;


            foreach (var item
                in _dynamicPropertyTextBoxes)
            {
                GeneraVerbaliStlPropertySetting setting =
                    item.Setting;

                TextBox textBox =
                    item.TextBox;


                /*
                 * Le proprietà non Inventor
                 * non devono essere scritte.
                 */
                if (!setting.IsInventorProperty)
                    continue;


                string propertyName =
                    setting.TextBoxText?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                    propertyName))
                {
                    continue;
                }


                string currentValue =
                    textBox.Text?.Trim()
                    ?? string.Empty;


                string originalValue =
                    _originalInventorPropertyValues
                        .TryGetValue(
                            textBox,
                            out string? storedValue)
                        ? storedValue
                        : string.Empty;


                /*
                 * Nessuna modifica:
                 * NON tocchiamo la iProperty.
                 */
                if (string.Equals(
                    currentValue,
                    originalValue,
                    StringComparison.Ordinal))
                {
                    continue;
                }


                if (!InventorService
                    .TryWriteUserDefinedProperty(
                        assembly,
                        propertyName,
                        currentValue,
                        out string writeError))
                {
                    errorMessage =
                        "Impossibile aggiornare la proprietà \"" +
                        propertyName +
                        "\".\r\n\r\n" +
                        writeError;

                    return false;
                }


                hasChanges =
                    true;
            }


            /*
             * ==========================================
             * VELOCITA MT_MIN
             * ==========================================
             */
            string currentBeltSpeed =
                _velocitaTextBox.Text?.Trim()
                ?? string.Empty;


            if (!string.Equals(
                currentBeltSpeed,
                _originalBeltSpeedValue,
                StringComparison.Ordinal))
            {
                if (!InventorService
                    .TryWriteUserDefinedProperty(
                        assembly,
                        GeneraVerbaliStlVelocityService
                            .BeltSpeedPropertyName,
                        currentBeltSpeed,
                        out string velocityWriteError))
                {
                    errorMessage =
                        "Impossibile aggiornare la proprietà \"" +
                        GeneraVerbaliStlVelocityService
                            .BeltSpeedPropertyName +
                        "\".\r\n\r\n" +
                        velocityWriteError;

                    return false;
                }


                hasChanges =
                    true;
            }


            /*
             * Se non è cambiato assolutamente nulla
             * non salviamo inutilmente l'assieme.
             */
            if (!hasChanges)
            {
                return true;
            }


            /*
             * Salviamo una sola volta dopo tutte
             * le modifiche.
             */
            if (!InventorService.TrySaveDocument(
                assembly,
                out string saveError))
            {
                errorMessage =
                    "Non è stato possibile salvare l'assieme.\r\n\r\n" +
                    saveError;

                return false;
            }


            /*
             * Dopo il salvataggio la velocità attuale
             * diventa il nuovo valore originale.
             */
            _originalBeltSpeedValue =
                currentBeltSpeed;


            /*
             * Dopo il salvataggio anche le proprietà
             * Inventor attuali diventano i nuovi
             * valori originali.
             */
            foreach (var item
                in _dynamicPropertyTextBoxes)
            {
                if (!item.Setting.IsInventorProperty)
                    continue;


                _originalInventorPropertyValues[
                    item.TextBox] =
                    item.TextBox.Text?.Trim()
                    ?? string.Empty;
            }


            return true;
        }
        private PrepareOutputResult TryPrepareOutputFile(
            out string generatedFilePath,
            out string errorMessage)
        {
            generatedFilePath =
                string.Empty;

            errorMessage =
                string.Empty;


            GeneraVerbaliSettingsModel settings =
                GeneraVerbaliSettingsService.Load();

            GeneraVerbaliModalitaStlSettings stlSettings =
                settings.ModalitaSTL
                ?? new GeneraVerbaliModalitaStlSettings();


            /*
             * ==========================================
             * TEMPLATE
             * ==========================================
             */
            string templatePath =
                settings.TemplatePath?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                templatePath))
            {
                errorMessage =
                    "Non è stato configurato il percorso del template.";

                return PrepareOutputResult.Error;
            }


            /*
             * ==========================================
             * ATTRIBUTO DETERMINANTE
             * ==========================================
             */
            string determiningPropertyName =
                stlSettings.DeterminingAttribute
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                determiningPropertyName))
            {
                errorMessage =
                    "Non è stato configurato l'attributo determinante.";

                return PrepareOutputResult.Error;
            }


            string determiningValue =
                InventorService
                    .ReadActiveAssemblyCustomProperty(
                        _inventorApp,
                        determiningPropertyName);


            if (string.IsNullOrWhiteSpace(
                determiningValue))
            {
                errorMessage =
                    "La proprietà determinante \"" +
                    determiningPropertyName +
                    "\" non contiene alcun valore.";

                return PrepareOutputResult.Error;
            }


            /*
             * ==========================================
             * RISOLUZIONE CARTELLA
             * ==========================================
             */
            if (!GeneraVerbaliOutputService
                .TryResolveOutputFolder(
                    stlSettings.OutputStartPath,
                    determiningValue.Trim(),
                    stlSettings.OutputEndPath,
                    out string outputFolder,
                    out string folderError))
            {
                errorMessage =
                    folderError;

                return PrepareOutputResult.Error;
            }


            /*
             * ==========================================
             * CODICE
             * ==========================================
             */
            string assemblyCode =
                InventorService
                    .ReadActiveAssemblyCustomProperty(
                        _inventorApp,
                        "CODICE")
                    .Trim();


            if (string.IsNullOrWhiteSpace(
                assemblyCode))
            {
                errorMessage =
                    "Nell'assieme corrente non è stata trovata " +
                    "la Custom iProperty \"CODICE\".";

                return PrepareOutputResult.Error;
            }


            /*
             * ==========================================
             * PERCORSO FINALE PREVISTO
             * ==========================================
             */
            string extension =
                Path.GetExtension(
                    templatePath);


            string expectedFilePath =
                Path.Combine(
                    outputFolder,
                    assemblyCode +
                    extension);


            bool overwriteExisting =
                false;


            /*
             * ==========================================
             * FILE GIÀ ESISTENTE
             * ==========================================
             */
            if (File.Exists(
                expectedFilePath))
            {
                DialogResult overwriteResult =
                    MessageBox.Show(
                        this,
                        "Il Verbale di collaudo di \"" +
                        assemblyCode +
                        "\" esiste già.\r\n\r\n" +
                        "Desideri sovrascriverlo?",
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);


                /*
                 * NO:
                 *
                 * non è un errore.
                 * Questo STL viene considerato concluso.
                 */
                if (overwriteResult ==
                    DialogResult.No)
                {
                    generatedFilePath =
                        expectedFilePath;

                    return PrepareOutputResult.SkipExisting;
                }


                overwriteExisting =
                    true;
            }


            /*
             * Copia template.
             */
            if (!GeneraVerbaliOutputService
                .TryCopyTemplate(
                    templatePath,
                    outputFolder,
                    assemblyCode,
                    overwriteExisting,
                    out generatedFilePath,
                    out string copyError))
            {
                errorMessage =
                    copyError;

                return PrepareOutputResult.Error;
            }


            return PrepareOutputResult.Ready;
        }

        private void GenerateCheckoutPrompt_Confirmed(
            object? sender,
            EventArgs e)
        {
            if (_generatingReport)
                return;


            /*
             * ==========================================
             * CHIUSURA IMMEDIATA POPUP CHECKOUT
             * ==========================================
             *
             * L'utente ha già confermato.
             * Il popup non deve rimanere visibile durante
             * la generazione del verbale.
             */
            if (_generateCheckoutPrompt != null)
            {
                GeneraVerbaliCheckoutPromptForm
                    checkoutPrompt =
                        _generateCheckoutPrompt;


                /*
                 * Azzeriamo prima il riferimento.
                 */
                _generateCheckoutPrompt =
                    null;


                if (!checkoutPrompt.IsDisposed)
                {
                    checkoutPrompt.Close();
                }
            }


            _generatingReport =
                true;


            try
            {

                /*
                 * ==========================================
                 * 1. SCRITTURA PROPRIETÀ MODIFICATE
                 * ==========================================
                 */
                if (!WriteModifiedInventorProperties(
                    out string propertyError))
                {
                    MessageBox.Show(
                        this,
                        propertyError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }


                /*
                 * ==========================================
                 * 2. PREPARAZIONE FILE VERBALE
                 * ==========================================
                 */
                PrepareOutputResult prepareResult =
                    TryPrepareOutputFile(
                        out string generatedFilePath,
                        out string outputError);


                /*
                 * ==========================================
                 * ERRORE REALE
                 * ==========================================
                 */
                if (prepareResult ==
                    PrepareOutputResult.Error)
                {
                    MessageBox.Show(
                        this,
                        outputError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }


                /*
                 * ==========================================
                 * FILE ESISTENTE - UTENTE HA SCELTO NO
                 * ==========================================
                 *
                 * Questo verbale viene considerato concluso.
                 */
                if (prepareResult ==
                    PrepareOutputResult.SkipExisting)
                {
                    CompleteSkippedReport();

                    return;
                }


                _generatedReportPath =
                    generatedFilePath;


                /*
                 * ==========================================
                 * AVVIO EXCEL IN BACKGROUND
                 * ==========================================
                 */
                /*
                 * ==========================================
                 * SESSIONE EXCEL
                 * ==========================================
                 *
                 * Modalità L:
                 * riutilizziamo l'istanza già aperta.
                 *
                 * Modalità STL singola:
                 * creiamo una nuova istanza dedicata.
                 */
                if (_modalitaLSession != null)
                {
                    _excelSession =
                        _modalitaLSession.ExcelSession;
                }
                else
                {
                    _excelSession =
                        new GeneraVerbaliExcelSession();


                    if (!_excelSession.Start(
                        out string excelStartError))
                    {
                        MessageBox.Show(
                            this,
                            excelStartError,
                            "Genera Verbali - Modalità STL",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

                        _excelSession =
                            null;

                        return;
                    }
                }


                if (!_excelSession.OpenWorkbook(
                    generatedFilePath,
                    out string excelOpenError))
                {
                    MessageBox.Show(
                        this,
                        excelOpenError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    CleanupExcelAfterGenerationError();

                    return;
                }


                /*
                 * ==========================================
                 * SCRITTURA PROPRIETÀ
                 * ==========================================
                 */
                if (!WritePropertiesToExcel(
                    _excelSession,
                    out string propertyExcelError))
                {
                    MessageBox.Show(
                        this,
                        propertyExcelError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    CleanupExcelAfterGenerationError();

                    return;
                }


                /*
                 * ==========================================
                 * SCRITTURA TABELLA
                 * ==========================================
                 */
                if (!WriteProductsTableToExcel(
                    _excelSession,
                    out string tableExcelError))
                {
                    MessageBox.Show(
                        this,
                        tableExcelError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    CleanupExcelAfterGenerationError();

                    return;
                }


                /*
                 * Salviamo già una prima volta dopo
                 * la compilazione automatica.
                 */
                if (!_excelSession.SaveCurrentWorkbook(
                    out string excelSaveError))
                {
                    MessageBox.Show(
                        this,
                        excelSaveError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }


                /*
                 * Ora l'utente può effettuare
                 * il controllo finale manuale.
                 */
                _excelSession.ShowExcel();


                ShowPrintConfirmation();

            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Si è verificato un errore durante la creazione del verbale.\r\n\r\n" +
                    ex.Message,
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                _generatingReport =
                    false;
            }
        }
        private bool WritePropertiesToExcel(
    GeneraVerbaliExcelSession excelSession,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;


            foreach (var item
                in _dynamicPropertyTextBoxes)
            {
                GeneraVerbaliStlPropertySetting setting =
                    item.Setting;

                TextBox textBox =
                    item.TextBox;


                string excelCell =
                    setting.ExcelCell?.Trim()
                    ?? string.Empty;


                /*
                 * Proprietà senza cella Excel configurata:
                 * semplicemente ignorata.
                 */
                if (string.IsNullOrWhiteSpace(
                    excelCell))
                {
                    continue;
                }


                string value =
                    textBox.Text
                    ?? string.Empty;


                if (!excelSession.WriteValue(
                    excelCell,
                    value,
                    out string writeError))
                {
                    errorMessage =
                        "Errore durante la scrittura di \"" +
                        setting.TextBoxName +
                        "\".\r\n\r\n" +
                        writeError;

                    return false;
                }
            }


            return true;
        }
        private bool WriteProductsTableToExcel(
    GeneraVerbaliExcelSession excelSession,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;


            List<GeneraVerbaliStlFormColumnSetting>
                configuredColumns =
                    _settings
                        .ModalitaSTL
                        .FormColumns;


            /*
             * Consideriamo solamente le righe
             * realmente utilizzate.
             */
            List<DataGridViewRow> usedRows =
                _productsGrid
                    .Rows
                    .Cast<DataGridViewRow>()
                    .Where(row =>
                        !row.IsNewRow &&
                        RowContainsAnyValue(row))
                    .ToList();


            for (int tableRowIndex = 0;
                 tableRowIndex < usedRows.Count;
                 tableRowIndex++)
            {
                DataGridViewRow gridRow =
                    usedRows[
                        tableRowIndex];


                foreach (
                    GeneraVerbaliStlFormColumnSetting columnSetting
                    in configuredColumns)
                {
                    string columnName =
                        columnSetting.Name?.Trim()
                        ?? string.Empty;

                    string excelCell =
                        columnSetting.ExcelCell?.Trim()
                        ?? string.Empty;


                    if (string.IsNullOrWhiteSpace(
                        columnName) ||
                        string.IsNullOrWhiteSpace(
                            excelCell))
                    {
                        continue;
                    }


                    DataGridViewColumn? gridColumn =
                        _productsGrid
                            .Columns
                            .Cast<DataGridViewColumn>()
                            .FirstOrDefault(column =>
                                string.Equals(
                                    column.HeaderText?.Trim(),
                                    columnName,
                                    StringComparison.OrdinalIgnoreCase));


                    if (gridColumn == null)
                        continue;


                    string value =
                        gridRow
                            .Cells[gridColumn.Index]
                            .Value
                            ?.ToString()
                        ?? string.Empty;


                    if (!excelSession.WriteTableValue(
                        excelCell,
                        tableRowIndex,
                        value,
                        out string writeError))
                    {
                        errorMessage =
                            "Errore durante la scrittura della colonna \"" +
                            columnName +
                            "\" alla riga " +
                            (tableRowIndex + 1) +
                            ".\r\n\r\n" +
                            writeError;

                        return false;
                    }
                }
            }


            return true;
        }
        private bool RowContainsAnyValue(
    DataGridViewRow row)
        {
            foreach (DataGridViewCell cell
                in row.Cells)
            {
                string value =
                    cell.Value
                        ?.ToString()
                        ?.Trim()
                    ?? string.Empty;


                if (!string.IsNullOrWhiteSpace(
                    value))
                {
                    return true;
                }
            }


            return false;
        }
        private void ShowPrintConfirmation()
        {
            string assemblyCode =
                InventorService
                    .ReadActiveAssemblyCustomProperty(
                        _inventorApp,
                        "CODICE")
                    .Trim();


            DialogResult result =
                MessageBox.Show(
                    this,
                    "Desideri stampare il Verbale di collaudo di " +
                    assemblyCode +
                    "?",
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);


            CompleteReportGeneration(
                result ==
                DialogResult.Yes);
        }
        private void CompleteReportGeneration(
    bool printReport)
        {
            if (_excelSession == null)
                return;


            /*
             * Se richiesto, stampiamo il workbook.
             */
            if (printReport)
            {
                if (!_excelSession
                    .PrintCurrentWorkbook(
                        out string printError))
                {
                    MessageBox.Show(
                        this,
                        "Errore durante la stampa:\r\n\r\n" +
                        printError,
                        "Genera Verbali - Modalità STL",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }
            }


            /*
             * Salviamo anche eventuali modifiche
             * manuali fatte dall'utente in Excel.
             */
            if (!_excelSession
                .SaveCurrentWorkbook(
                    out string saveError))
            {
                MessageBox.Show(
                    this,
                    saveError,
                    "Genera Verbali - Modalità STL",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }


            /*
             * Per ora siamo ancora nel comportamento
             * della Modalità STL SINGOLA.
             */
            /*
             * Chiudiamo il workbook corrente.
             * È già stato salvato.
             */
            _excelSession.CloseCurrentWorkbook(
                false);


            /*
             * ==========================================
             * MODALITÀ L
             * ==========================================
             */
            if (_modalitaLSession != null)
            {
                /*
                 * Excel NON viene chiuso.
                 * Torna semplicemente invisibile.
                 */
                _excelSession.HideExcel();


                ModalitaLStepCompleted =
                    true;


                /*
                 * Chiudiamo il Form STL senza mostrare
                 * il popup di chiusura.
                 */
                _closeWithoutPrompt =
                    true;


                Close();

                return;
            }


            /*
             * ==========================================
             * MODALITÀ STL SINGOLA
             * ==========================================
             */
            _excelSession.QuitExcel();

            _excelSession =
                null;

            MessageBox.Show(
                this,
                "Generazione del verbale completata.",
                "Genera Verbali - Modalità STL",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        private void CleanupExcelAfterGenerationError()
        {
            if (_excelSession == null)
                return;


            _excelSession.CloseCurrentWorkbook(
                false);


            if (_modalitaLSession != null)
            {
                /*
                 * Excel appartiene alla sessione L:
                 * NON va terminato.
                 */
                _excelSession.HideExcel();

                return;
            }


            /*
             * Modalità STL singola.
             */
            _excelSession.QuitExcel();

            _excelSession =
                null;
        }
        private void CompleteSkippedReport()
        {
            /*
             * ==========================================
             * MODALITÀ L
             * ==========================================
             *
             * Il verbale esiste già e l'utente
             * ha scelto di NON sovrascriverlo.
             *
             * Per la sequenza L questo STL
             * è comunque considerato completato.
             */
            if (_modalitaLSession != null)
            {
                ModalitaLStepCompleted =
                    true;


                _closeWithoutPrompt =
                    true;


                Close();

                return;
            }


            /*
             * ==========================================
             * MODALITÀ STL SINGOLA
             * ==========================================
             */
            MessageBox.Show(
                this,
                "Il verbale esistente è stato mantenuto.\r\n\r\n" +
                "Generazione conclusa senza sovrascrittura.",
                "Genera Verbali - Modalità STL",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        private static bool IsVelocityColumn(
    DataGridViewColumn? column)
        {
            if (column == null)
                return false;


            string columnName =
                column.HeaderText?.Trim()
                ?? string.Empty;


            return columnName.StartsWith(
                "Velocità",
                StringComparison.OrdinalIgnoreCase);
        }

        private void GeneraVerbaliModalitaStlForm_KeyDown(
    object? sender,
    KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Tab)
                return;


            /*
             * Se siamo dentro la tabella,
             * lasciamo alla DataGridView la gestione
             * naturale del TAB tra le celle.
             */
            if (_productsGrid.ContainsFocus)
                return;


            bool moveBackward =
                e.Shift;


            List<Control> tabControls =
                new List<Control>();


            /*
             * ==========================================
             * TEXTBOX PRINCIPALI
             * ==========================================
             */
            tabControls.Add(
                _motoriduttoreTextBox);

            tabControls.Add(
                _ruotaTextBox);

            tabControls.Add(
                _velocitaTextBox);


            /*
             * ==========================================
             * TEXTBOX DINAMICHE
             * ==========================================
             */
            foreach (var item
                in _dynamicPropertyTextBoxes)
            {
                if (item.TextBox.Enabled &&
                    item.TextBox.Visible)
                {
                    tabControls.Add(
                        item.TextBox);
                }
            }


            /*
             * ==========================================
             * TROVIAMO IL CONTROLLO ATTUALE
             * ==========================================
             */
            int currentIndex =
                tabControls.FindIndex(
                    control =>
                        control.Focused ||
                        control.ContainsFocus);


            /*
             * Nessuna TextBox attualmente attiva:
             * partiamo dalla prima.
             */
            if (currentIndex < 0)
            {
                if (tabControls.Count > 0)
                {
                    tabControls[0].Focus();

                    e.Handled =
                        true;

                    e.SuppressKeyPress =
                        true;
                }

                return;
            }


            /*
             * ==========================================
             * SHIFT + TAB
             * ==========================================
             */
            if (moveBackward)
            {
                if (currentIndex > 0)
                {
                    tabControls[
                        currentIndex - 1]
                        .Focus();
                }
                else
                {
                    /*
                     * Siamo sulla prima TextBox.
                     * Per ora restiamo lì.
                     */
                    tabControls[0].Focus();
                }


                e.Handled =
                    true;

                e.SuppressKeyPress =
                    true;

                return;
            }


            /*
             * ==========================================
             * TAB NORMALE
             * ==========================================
             */
            if (currentIndex <
                tabControls.Count - 1)
            {
                tabControls[
                    currentIndex + 1]
                    .Focus();


                e.Handled =
                    true;

                e.SuppressKeyPress =
                    true;

                return;
            }


            /*
             * ==========================================
             * ULTIMA TEXTBOX
             * → ENTRIAMO NELLA TABELLA
             * ==========================================
             */
            if (_productsGrid.Rows.Count > 0 &&
                _productsGrid.Columns.Count > 0)
            {
                _productsGrid.Focus();

                _productsGrid.CurrentCell =
                    _productsGrid
                        .Rows[0]
                        .Cells[0];

                _productsGrid.BeginEdit(
                    true);


                e.Handled =
                    true;

                e.SuppressKeyPress =
                    true;
            }
        }
        private void ProductsGrid_EditingControlShowing(
    object? sender,
    DataGridViewEditingControlShowingEventArgs e)
        {
            if (e.Control is not TextBox editingTextBox)
                return;


            /*
             * La DataGridView riutilizza lo stesso controllo
             * TextBox durante l'editing delle varie celle.
             *
             * Rimettiamo quindi sempre il cursore
             * all'inizio della nuova cella.
             */
            BeginInvoke(
                new Action(
                    () =>
                    {
                        if (editingTextBox.IsDisposed)
                            return;

                        editingTextBox.SelectionStart =
                            0;

                        editingTextBox.SelectionLength =
                            0;

                        editingTextBox.ScrollToCaret();
                    }));
        }
    }
}