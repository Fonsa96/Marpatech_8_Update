﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.MainDashboard.Services
{
    public static class TempFileService
    {
        public static string GetTempFolder(string featureName)
        {
            string baseFolder = Path.Combine(
                Application.StartupPath,
                "Features",
                "MainDashboard",
                "Temp");

            string featureFolder = Path.Combine(
                baseFolder,
                featureName);

            Directory.CreateDirectory(featureFolder);

            return featureFolder;
        }

        public static void ClearTempFolder(string featureName)
        {
            try
            {
                string folder = GetTempFolder(featureName);

                if (Directory.Exists(folder))
                    Directory.Delete(folder, true);
            }
            catch
            {
            }
        }
    }
}