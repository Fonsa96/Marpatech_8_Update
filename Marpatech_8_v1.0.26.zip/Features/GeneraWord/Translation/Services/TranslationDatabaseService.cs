﻿using System.IO;
using System.Text.Json;
using System.Windows.Forms;
using Marpatech_8.Features.GeneraWord.Translation.Models;

namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public static class TranslationDatabaseService
    {
        private static string DatabasePath
        {
            get
            {
                return Path.Combine(
                    Application.StartupPath,
                    "Features",
                    "GeneraWord",
                    "Translation",
                    "translations.json");
            }
        }

        public static TranslationDatabase Load()
        {
            try
            {
                if (!File.Exists(DatabasePath))
                    return new TranslationDatabase();

                string json = File.ReadAllText(DatabasePath);

                return JsonSerializer.Deserialize<TranslationDatabase>(
                           json)
                       ?? new TranslationDatabase();
            }
            catch
            {
                return new TranslationDatabase();
            }
        }

        public static void Save(
            TranslationDatabase database)
        {
            Directory.CreateDirectory(
                Path.GetDirectoryName(DatabasePath)!);

            string json =
                JsonSerializer.Serialize(
                    database,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

            File.WriteAllText(
                DatabasePath,
                json);
        }
    }
}