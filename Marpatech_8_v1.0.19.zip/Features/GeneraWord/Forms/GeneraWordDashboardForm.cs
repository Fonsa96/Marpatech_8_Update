﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Inventor;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using WinTextBox = System.Windows.Forms.TextBox;
using IOPath = System.IO.Path;
using System.Threading.Tasks;
using FormsApplication = System.Windows.Forms.Application;
using WinProgressBar = System.Windows.Forms.ProgressBar;
using WinEnvironment = System.Environment;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class GeneraWordDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly GeneraWordDashboardWindowSettings _windowSettings;

        private ManualSettings _settings = new ManualSettings();

        private FlowLayoutPanel? propertiesPanel;
        private readonly Dictionary<string, WinTextBox> propertyTextBoxes = new();

        private ComboBox? cmbPersonalizzazione;
        private ComboBox? cmbTipologia;
        private CheckedListBox? chkLingue;

        private CheckBox? chkCentraggioTela;
        private CheckBox? chkEsportaPdf;
        private CheckBox? chkEsportaSoloDichiarazione;
        private DataGridView? motorsPreviewGrid;
        private Label? lblLoading;

        private bool _pdfOptionsChangedManually = false;

        private WinProgressBar? generationProgressBar;
        private Label? lblGenerationStatus;
        private Button? btnViewErrorLog;
        private List<ManualGenerationError> lastGenerationErrors = new();

        public GeneraWordDashboardForm(Inventor.Application inventorApp, bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _settings = ManualSettingsService.Load();
            _windowSettings = GeneraWordDashboardWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();

            this.Shown += async (s, e) =>
            {
                await LoadDashboardDataAsync();
            };
        }

        private async Task LoadDashboardDataAsync()
        {
            if (lblLoading != null)
                lblLoading.Visible = true;

            LoadConfiguredProperties();
            LoadMotorsPreview();

           await Task.Run(() =>
            {
                LoadPersonalizzazioniSafe();
            });

            if (lblLoading != null)
                lblLoading.Visible = false;
        }

        private void LoadPersonalizzazioniSafe()
        {
            if (cmbPersonalizzazione == null)
                return;

            List<string> directories = new();

            if (Directory.Exists(_settings.BaseTemplatePath))
            {
                directories = Directory
                    .GetDirectories(_settings.BaseTemplatePath)
                    .Select(x => IOPath.GetFileName(x) ?? "")
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .OrderBy(x => x)
                    .ToList();
            }

            this.Invoke(() =>
            {
                cmbPersonalizzazione.Items.Clear();

                foreach (string dir in directories)
                {
                    cmbPersonalizzazione.Items.Add(dir);
                }
            });
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor lineColor = _isDarkTheme
                ? DrawingColor.FromArgb(70, 75, 85)
                : DrawingColor.FromArgb(203, 213, 225);

            this.Text = "Genera Word Manuali";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(1280, 820);
            this.MinimumSize = new DrawingSize(1100, 760);
            this.MaximumSize = new DrawingSize(0, 0);
            this.BackColor = backgroundColor;
            this.FormClosing += GeneraWordDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Genera Word Manuali";
            title.Font = new DrawingFont("Segoe UI", 26, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 15);

            Button btnSettings = CreateButton("⚙", DrawingColor.FromArgb(100, 116, 139), 50, 42);
            btnSettings.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSettings.Location = new DrawingPoint(this.ClientSize.Width - 85, 30);
            btnSettings.Click += BtnSettings_Click;

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 95);
            mainPanel.Size = new DrawingSize(this.ClientSize.Width - 70, this.ClientSize.Height - 125);
            mainPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(28);
            

            lblLoading = new Label();
            lblLoading.Text = "Caricamento dati...";
            lblLoading.Font = new DrawingFont("Segoe UI", 12, DrawingFontStyle.Bold);
            lblLoading.ForeColor = titleColor;
            lblLoading.AutoSize = true;
            lblLoading.Location = new DrawingPoint(35, 70);

            FlowLayoutPanel contentPanel = new FlowLayoutPanel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.FlowDirection = FlowDirection.TopDown;
            contentPanel.WrapContents = false;
            contentPanel.AutoScroll = true;
            contentPanel.BackColor = cardColor;

            int cardWidth = 920;

            Panel propertiesCard = CreateCard(cardColor, cardWidth, 205);
            Label propertiesTitle = CreateSectionTitle("1) Proprietà Inventor Manuali", titleColor);
            propertiesTitle.Location = new DrawingPoint(0, 0);

            Button btnManageProperties = CreateButton("Gestisci Proprietà", DrawingColor.FromArgb(124, 58, 237), 180, 38);
            btnManageProperties.Location = new DrawingPoint(385, 0);
            btnManageProperties.Click += BtnManageProperties_Click;

            Button btnRefreshProperties = CreateButton("🔄", DrawingColor.FromArgb(37, 99, 235), 45, 38);
            btnRefreshProperties.Location = new DrawingPoint(575, 0);
            btnRefreshProperties.Click += (s, e) => RefreshAllFromInventor();

            propertiesPanel = new FlowLayoutPanel();
            propertiesPanel.Location = new DrawingPoint(0, 58);
            propertiesPanel.Size = new DrawingSize(720, 130);
            propertiesPanel.FlowDirection = FlowDirection.TopDown;
            propertiesPanel.WrapContents = false;
            propertiesPanel.AutoScroll = true;
            propertiesPanel.BackColor = cardColor;

            propertiesCard.Controls.Add(propertiesTitle);
            propertiesCard.Controls.Add(btnManageProperties);
            propertiesCard.Controls.Add(propertiesPanel);
            propertiesCard.Controls.Add(btnRefreshProperties);

            Panel line1 = CreateSeparator(lineColor, cardWidth);

            Panel manualCard = CreateCard(cardColor, cardWidth, 295);
            Label manualTitle = CreateSectionTitle("2) Configurazione Manuale", titleColor);
            manualTitle.Location = new DrawingPoint(0, 0);

            Label lblPersonalizzazione = CreateLabel("1) Personalizzazione Manuale", titleColor);
            lblPersonalizzazione.Location = new DrawingPoint(0, 55);

            cmbPersonalizzazione = CreateComboBox(245);
            cmbPersonalizzazione.Location = new DrawingPoint(0, 82);
            cmbPersonalizzazione.SelectedIndexChanged += (s, e) =>
            {
                ApplyPdfPresetIfNeeded();
                LoadTipologie();
            };

            Label lblTipologia = CreateLabel("2) Tipologia Manuale", titleColor);
            lblTipologia.Location = new DrawingPoint(285, 55);

            cmbTipologia = CreateComboBox(245);
            cmbTipologia.Location = new DrawingPoint(285, 82);
            cmbTipologia.SelectedIndexChanged += (s, e) => LoadLingue();

            Label lblLingue = CreateLabel("3) Seleziona Lingua/e", titleColor);
            lblLingue.Location = new DrawingPoint(570, 55);

            chkLingue = new CheckedListBox();
            chkLingue.CheckOnClick = true;
            chkLingue.Location = new DrawingPoint(570, 82);
            chkLingue.Size = new DrawingSize(210, 95);
            chkLingue.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            chkLingue.BackColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            chkLingue.ForeColor = titleColor;
            chkLingue.BorderStyle = BorderStyle.FixedSingle;

            Label lblOptions = CreateLabel("4) Opzioni di Generazione", titleColor);
            lblOptions.Location = new DrawingPoint(0, 190);

            chkCentraggioTela = CreateCheckBox("Istruzioni di centraggio tela", titleColor);
            chkCentraggioTela.Location = new DrawingPoint(230, 188);

            chkEsportaPdf = CreateCheckBox("Esporta PDF", titleColor);
            chkEsportaPdf.Location = new DrawingPoint(230, 215);
            chkEsportaPdf.Checked = true;
            chkEsportaPdf.CheckedChanged += (s, e) => _pdfOptionsChangedManually = true;

            chkEsportaSoloDichiarazione = CreateCheckBox("Esporta PDF solo Dichiarazione", titleColor);
            chkEsportaSoloDichiarazione.Location = new DrawingPoint(230, 242);
            chkEsportaSoloDichiarazione.CheckedChanged += (s, e) => _pdfOptionsChangedManually = true;

            manualCard.Controls.Add(manualTitle);
            manualCard.Controls.Add(lblPersonalizzazione);
            manualCard.Controls.Add(cmbPersonalizzazione);
            manualCard.Controls.Add(lblTipologia);
            manualCard.Controls.Add(cmbTipologia);
            manualCard.Controls.Add(lblLingue);
            manualCard.Controls.Add(chkLingue);
            manualCard.Controls.Add(lblOptions);
            manualCard.Controls.Add(chkCentraggioTela);
            manualCard.Controls.Add(chkEsportaPdf);
            manualCard.Controls.Add(chkEsportaSoloDichiarazione);

            Panel line2 = CreateSeparator(lineColor, cardWidth);

            Panel motorsCard = CreateCard(cardColor, cardWidth, 200);
            Label motorsTitle = CreateSectionTitle("3) Gestione Motori", titleColor);
            motorsTitle.Location = new DrawingPoint(0, 0);

            Button btnMotori = CreateButton("Gestione Motori", DrawingColor.FromArgb(37, 99, 235), 190, 42);
            btnMotori.Location = new DrawingPoint(0, 45);
            btnMotori.Click += BtnMotori_Click;

            Button btnRefreshMotors = CreateButton("🔄", DrawingColor.FromArgb(37, 99, 235), 45, 42);
            btnRefreshMotors.Location = new DrawingPoint(0, 100);
            btnRefreshMotors.Click += (s, e) => RefreshAllFromInventor();

            motorsPreviewGrid = CreateMotorsPreviewGrid();
            motorsPreviewGrid.Location = new DrawingPoint(230, 5);

            motorsCard.Controls.Add(motorsTitle);
            motorsCard.Controls.Add(btnMotori);
            motorsCard.Controls.Add(motorsPreviewGrid);
            motorsCard.Controls.Add(btnRefreshMotors);


            Panel generateCard = CreateCard(cardColor, cardWidth, 170);

            Button btnGenera = CreateButton("GENERA WORD", DrawingColor.FromArgb(22, 163, 74), 760, 64);
            btnGenera.Font = new DrawingFont("Segoe UI", 15, DrawingFontStyle.Bold);
            btnGenera.Location = new DrawingPoint(0, 10);
            btnGenera.Click += BtnGenera_Click;

            generationProgressBar = new WinProgressBar();
            generationProgressBar.Location = new DrawingPoint(0, 85);
            generationProgressBar.Size = new DrawingSize(760, 24);
            generationProgressBar.Minimum = 0;
            generationProgressBar.Maximum = 100;
            generationProgressBar.Value = 0;

            lblGenerationStatus = CreateLabel("Pronto", titleColor);
            lblGenerationStatus.Location = new DrawingPoint(0, 118);

            btnViewErrorLog = CreateButton("Vedi Log Errori", DrawingColor.FromArgb(220, 38, 38), 170, 38);
            btnViewErrorLog.Location = new DrawingPoint(590, 112);
            btnViewErrorLog.Visible = false;
            btnViewErrorLog.Click += BtnViewErrorLog_Click;

            generateCard.Controls.Add(btnGenera);
            generateCard.Controls.Add(generationProgressBar);
            generateCard.Controls.Add(lblGenerationStatus);
            generateCard.Controls.Add(btnViewErrorLog);

            contentPanel.Controls.Add(propertiesCard);
            contentPanel.Controls.Add(line1);
            contentPanel.Controls.Add(manualCard);
            contentPanel.Controls.Add(line2);
            contentPanel.Controls.Add(motorsCard);
            contentPanel.Controls.Add(generateCard);

            mainPanel.Controls.Add(contentPanel);

            this.Controls.Add(title);
            this.Controls.Add(btnSettings);
            this.Controls.Add(mainPanel);
            this.Controls.Add(lblLoading);
        }

        private Panel CreateCard(DrawingColor color, int width, int height)
        {
            Panel panel = new Panel();
            panel.Size = new DrawingSize(width, height);
            panel.BackColor = color;
            panel.Margin = new Padding(0, 0, 0, 12);
            return panel;
        }

        private Panel CreateSeparator(DrawingColor color, int width)
        {
            Panel panel = new Panel();
            panel.Size = new DrawingSize(width, 2);
            panel.BackColor = color;
            panel.Margin = new Padding(0, 6, 0, 20);
            return panel;
        }

        private Label CreateSectionTitle(string text, DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont("Segoe UI", 15, DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;
            return label;
        }

        private Label CreateLabel(string text, DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;
            return label;
        }

        private ComboBox CreateComboBox(int width)
        {
            ComboBox combo = new ComboBox();
            combo.Size = new DrawingSize(width, 32);
            combo.Font = new DrawingFont("Segoe UI", 9);
            combo.DropDownStyle = ComboBoxStyle.DropDownList;
            return combo;
        }

        private CheckBox CreateCheckBox(string text, DrawingColor color)
        {
            CheckBox checkBox = new CheckBox();
            checkBox.Text = text;
            checkBox.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            checkBox.ForeColor = color;
            checkBox.AutoSize = true;
            return checkBox;
        }

        private Button CreateButton(string text, DrawingColor color, int width, int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private DataGridView CreateMotorsPreviewGrid()
        {
            DataGridView grid = new DataGridView();

            grid.Size = new DrawingSize(620, 190);
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.ReadOnly = true;
            grid.RowHeadersVisible = false;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.BackgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;
            grid.GridColor = DrawingColor.FromArgb(70, 75, 85);
            grid.BorderStyle = BorderStyle.FixedSingle;

            grid.Font = new DrawingFont("Segoe UI", 8, DrawingFontStyle.Regular);
            grid.ColumnHeadersDefaultCellStyle.Font =
                new DrawingFont("Segoe UI", 8, DrawingFontStyle.Bold);

            grid.DefaultCellStyle.BackColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            grid.DefaultCellStyle.ForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            grid.ColumnHeadersDefaultCellStyle.BackColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.FromArgb(226, 232, 240);

            grid.ColumnHeadersDefaultCellStyle.ForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            grid.EnableHeadersVisualStyles = false;

            grid.Columns.Add("Motore", "Motore");
            grid.Columns.Add("Potenza", "Potenza");
            grid.Columns.Add("IP", "IP");
            grid.Columns.Add("Tensione", "Tensione");
            grid.Columns.Add("Frequenza", "Frequenza");
            grid.Columns.Add("Lub", "Lub");

            grid.Columns["Motore"].Width = 55;
            grid.Columns["Potenza"].Width = 105;
            grid.Columns["IP"].Width = 75;
            grid.Columns["Tensione"].Width = 120;
            grid.Columns["Frequenza"].Width = 100;
            grid.Columns["Lub"].Width = 160;

            return grid;
        }

        private void LoadConfiguredProperties()
        {
            if (propertiesPanel == null)
                return;

            propertiesPanel.Controls.Clear();
            propertyTextBoxes.Clear();

            Inventor.Document? document =
                ManualInventorService.GetActiveDocument(_inventorApp);

            Dictionary<string, string> values = new Dictionary<string, string>();

            if (document != null)
            {
                values = ManualInventorService.ReadConfiguredProperties(
                    document,
                    _settings);
            }

            foreach (ManualPropertyConfig property in _settings.Properties)
            {
                Panel row = new Panel();
                row.Size = new DrawingSize(680, 32);
                row.Margin = new Padding(0, 0, 0, 4);

                Label lblTag = new Label();
                lblTag.Text = property.Tag;
                lblTag.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
                lblTag.ForeColor = _isDarkTheme ? DrawingColor.White : DrawingColor.FromArgb(30, 41, 59);
                lblTag.Location = new DrawingPoint(0, 5);
                lblTag.Size = new DrawingSize(210, 22);

                WinTextBox txtValue = new WinTextBox();
                txtValue.Text = values.ContainsKey(property.Tag) ? values[property.Tag] : "";
                txtValue.Font = new DrawingFont("Segoe UI", 9);
                txtValue.Location = new DrawingPoint(230, 2);
                txtValue.Size = new DrawingSize(360, 28);
                txtValue.BackColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
                txtValue.ForeColor = _isDarkTheme ? DrawingColor.White : DrawingColor.FromArgb(30, 41, 59);
                txtValue.BorderStyle = BorderStyle.FixedSingle;

                propertyTextBoxes[property.Tag] = txtValue;

                row.Controls.Add(lblTag);
                row.Controls.Add(txtValue);

                propertiesPanel.Controls.Add(row);
            }
        }

        private void LoadPersonalizzazioni()
        {
            if (cmbPersonalizzazione == null)
                return;

            cmbPersonalizzazione.Items.Clear();

            if (!Directory.Exists(_settings.BaseTemplatePath))
                return;

            foreach (string directory in Directory
                .GetDirectories(_settings.BaseTemplatePath)
                .OrderBy(IOPath.GetFileName))
            {
                cmbPersonalizzazione.Items.Add(IOPath.GetFileName(directory));
            }
        }

        private void LoadTipologie()
        {
            if (cmbPersonalizzazione == null || cmbTipologia == null || chkLingue == null)
                return;

            cmbTipologia.Items.Clear();
            chkLingue.Items.Clear();

            string selectedPersonalizzazione = cmbPersonalizzazione.Text;

            if (string.IsNullOrWhiteSpace(selectedPersonalizzazione))
                return;

            string path = IOPath.Combine(
                _settings.BaseTemplatePath,
                selectedPersonalizzazione);

            if (!Directory.Exists(path))
                return;

            foreach (string directory in Directory
                .GetDirectories(path)
                .OrderBy(IOPath.GetFileName))
            {
                cmbTipologia.Items.Add(IOPath.GetFileName(directory));
            }
        }

        private void LoadLingue()
        {
            if (cmbPersonalizzazione == null || cmbTipologia == null || chkLingue == null)
                return;

            chkLingue.Items.Clear();

            string selectedPersonalizzazione = cmbPersonalizzazione.Text;
            string selectedTipologia = cmbTipologia.Text;

            if (string.IsNullOrWhiteSpace(selectedPersonalizzazione) ||
                string.IsNullOrWhiteSpace(selectedTipologia))
                return;

            string path = IOPath.Combine(
                _settings.BaseTemplatePath,
                selectedPersonalizzazione,
                selectedTipologia);

            if (!Directory.Exists(path))
                return;

            foreach (string directory in Directory
                .GetDirectories(path)
                .OrderBy(IOPath.GetFileName))
            {
                chkLingue.Items.Add(IOPath.GetFileName(directory), false);
            }
        }

        private void LoadMotorsPreview()
        {
            if (motorsPreviewGrid == null)
                return;

            motorsPreviewGrid.Rows.Clear();

            Inventor.Document? document =
                ManualInventorService.GetActiveDocument(_inventorApp);

            for (int i = 0; i <= 5; i++)
            {
                string potenza = "";
                string ip = "";
                string tensione = "";
                string frequenza = "";
                string lub = "";

                if (document != null)
                {
                    potenza = ManualInventorService.ReadIProperty(document, "Potenza Motore " + i);
                    ip = ManualInventorService.ReadIProperty(document, "IP " + i);
                    tensione = ManualInventorService.ReadIProperty(document, "Tensione " + i);
                    frequenza = ManualInventorService.ReadIProperty(document, "Frequenza " + i);
                    lub = ManualInventorService.ReadIProperty(document, "Lub " + i);
                }

                motorsPreviewGrid.Rows.Add(
                    i.ToString(),
                    potenza,
                    ip,
                    tensione,
                    frequenza,
                    lub);
            }
        }

        private void ApplyPdfPresetIfNeeded()
        {
            if (_pdfOptionsChangedManually)
                return;

            if (chkEsportaPdf == null ||
                chkEsportaSoloDichiarazione == null ||
                cmbPersonalizzazione == null)
                return;

            if (string.Equals(cmbPersonalizzazione.Text, "LM", StringComparison.OrdinalIgnoreCase))
            {
                chkEsportaPdf.Checked = false;
                chkEsportaSoloDichiarazione.Checked = true;
            }
            else
            {
                chkEsportaPdf.Checked = true;
                chkEsportaSoloDichiarazione.Checked = false;
            }
        }

        private void BtnSettings_Click(object? sender, EventArgs e)
        {
            ManualSettingsForm form =
                new ManualSettingsForm(_isDarkTheme, _settings);

            form.FormClosed += (s, e2) =>
            {
                if (form.Saved)
                {
                    _settings = ManualSettingsService.Load();

                    LoadConfiguredProperties();
                    LoadMotorsPreview();
                    LoadPersonalizzazioniSafe();
                }
            };

            form.Show(this);
            form.Activate();
        }

        private void BtnManageProperties_Click(object? sender, EventArgs e)
        {
            using ManualPropertiesForm form =
                new ManualPropertiesForm(_isDarkTheme, _settings);

            if (form.ShowDialog() == DialogResult.OK)
            {
                _settings = ManualSettingsService.Load();

                LoadConfiguredProperties();
            }
        }

        private void BtnMotori_Click(object? sender, EventArgs e)
        {
            MotoriForm form = new MotoriForm(_inventorApp, _isDarkTheme);

            form.FormClosed += (s, e2) =>
            {
                if (form.Saved)
                    LoadMotorsPreview();
            };

            form.Show(this);
            form.Activate();
        }

        private async void BtnGenera_Click(object? sender, EventArgs e)
        {
            lastGenerationErrors.Clear();

            if (generationProgressBar != null)
                generationProgressBar.Value = 0;

            if (lblGenerationStatus != null)
                lblGenerationStatus.Text = "Preparazione generazione...";

            if (btnViewErrorLog != null)
                btnViewErrorLog.Visible = false;

            ManualGenerationRequest request = BuildGenerationRequest();

            Progress<ManualGenerationProgress> progress =
                new Progress<ManualGenerationProgress>(p =>
                {
                    if (generationProgressBar != null)
                        generationProgressBar.Value = Math.Max(0, Math.Min(100, p.Percentage));

                    if (lblGenerationStatus != null)
                        lblGenerationStatus.Text =
                            "Elaborazione: " + p.CurrentFile + " - " + p.Percentage + "%";
                });

            ManualGeneratorService generator =
                new ManualGeneratorService(_inventorApp, _settings, _isDarkTheme);

            ManualGenerationResult result =
                await generator.GenerateAsync(request, this, progress);

            lastGenerationErrors = result.Errors;

            if (generationProgressBar != null)
                generationProgressBar.Value = 100;

            if (lblGenerationStatus != null)
            {
                lblGenerationStatus.Text = result.Success
                    ? "Generazione avvenuta con successo"
                    : "Generazione avvenuta con errori";
            }

            if (btnViewErrorLog != null)
                btnViewErrorLog.Visible = !result.Success;

            LoadConfiguredProperties();
            LoadMotorsPreview();
        }

        private void ApplyWindowSettings()
        {
            this.Width = _windowSettings.Width;
            this.Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = _windowSettings.Left;
                this.Top = _windowSettings.Top;
            }

            if (_windowSettings.IsMaximized)
                this.WindowState = FormWindowState.Maximized;
        }

        private void GeneraWordDashboardForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = this.Width;
                _windowSettings.Height = this.Height;
                _windowSettings.Left = this.Left;
                _windowSettings.Top = this.Top;
            }

            _windowSettings.IsMaximized =
                this.WindowState == FormWindowState.Maximized;

            GeneraWordDashboardWindowSettingsService.Save(_windowSettings);
        }
        private ManualGenerationRequest BuildGenerationRequest()
        {
            ManualGenerationRequest request = new ManualGenerationRequest();

            foreach (KeyValuePair<string, WinTextBox> item in propertyTextBoxes)
            {
                request.PropertyValues[item.Key] = item.Value.Text.Trim();
            }

            request.PersonalizzazioneManuale =
                cmbPersonalizzazione?.Text.Trim() ?? "";

            request.TipologiaManuale =
                cmbTipologia?.Text.Trim() ?? "";

            if (chkLingue != null)
            {
                foreach (object item in chkLingue.CheckedItems)
                {
                    request.Lingue.Add(item.ToString() ?? "");
                }
            }

            request.IncludeCentraggioTela =
                chkCentraggioTela?.Checked ?? false;

            request.ExportPdf =
                chkEsportaPdf?.Checked ?? false;

            request.ExportOnlyDichiarazionePdf =
                chkEsportaSoloDichiarazione?.Checked ?? false;

            return request;
        }
        private void RefreshAllFromInventor()
        {
            LoadConfiguredProperties();
            LoadMotorsPreview();
        }
        private void BtnViewErrorLog_Click(object? sender, EventArgs e)
        {
            if (lastGenerationErrors.Count == 0)
                return;

            ManualErrorLogForm form =
                new ManualErrorLogForm(
                    _isDarkTheme,
                    lastGenerationErrors);

            form.Show(this);
            form.Activate();
        }
    }
}