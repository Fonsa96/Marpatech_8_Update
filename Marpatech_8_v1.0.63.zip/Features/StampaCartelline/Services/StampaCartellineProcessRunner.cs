﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class StampaCartellineProcessRunner
    {
        private readonly Inventor.Application
            _inventorApp;

        private readonly DashboardInventorPropertyWriter
            _propertyWriter;

        private readonly WordTemplateProcessor
            _wordTemplateProcessor;

        private readonly ExcelDrawingsProcessor
            _excelDrawingsProcessor;

        private readonly SheetMetalPdfProcessor
            _sheetMetalPdfProcessor;

        private readonly AssemblyGroupsProcessor
            _assemblyGroupsProcessor;


        public StampaCartellineProcessRunner(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp;

            _propertyWriter =
                new DashboardInventorPropertyWriter(
                    inventorApp);

            _wordTemplateProcessor =
                new WordTemplateProcessor();

            _excelDrawingsProcessor =
                new ExcelDrawingsProcessor();

            _sheetMetalPdfProcessor =
                new SheetMetalPdfProcessor();

            _assemblyGroupsProcessor =
                new AssemblyGroupsProcessor(
                    inventorApp);
        }


        public void Run(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }


            /*
             * ==================================================
             * CONFIGURAZIONE BLOCCHI
             * ==================================================
             *
             * La barra considera SOLAMENTE
             * i blocchi inclusi.
             *
             * Le sezioni escluse restano nel LOG
             * con "Funzione Saltata".
             */

            bool includeInventor =
                session.IncludePrintFolders;


            /*
             * Word non possiede attualmente
             * un flag IncludeInPrintProcess.
             *
             * Lo consideriamo incluso quando
             * esiste almeno un template configurato.
             */
            bool includeWord =
                session.IncludePrintFolders;


            bool includeExcel =
                session.ExcelDrawings != null &&
                session.ExcelDrawings.IncludeInPrintProcess;


            bool includePdf =
                session.SheetMetalPdfs != null &&
                session.SheetMetalPdfs.IncludeInPrintProcess;


            bool includeAssemblyGroups =
                configuration.AssemblyGroups != null &&
                configuration.AssemblyGroups
                    .IncludeInPrintProcess &&
                session.IncludeAssemblyGroups;


            progress.ConfigureSection(
                StampaCartellineProcessSection.Inventor,
                includeInventor);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Word,
                includeWord);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Excel,
                includeExcel);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Pdf,
                includePdf);

            progress.ConfigureSection(
                StampaCartellineProcessSection.AssemblyGroups,
                includeAssemblyGroups);


            /*
             * ==================================================
             * 1 - SCRITTURA IN INVENTOR
             * ==================================================
             */
            if (includeInventor)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Inventor,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Inventor,
                            "Controllo delle proprietà Inventor.");

                        if (!ValidateInventorProperties(
                                owner,
                                session,
                                progress))
                        {
                            return false;
                        }


                        progress.AddInformation(
                            StampaCartellineProcessSection.Inventor,
                            "Verifica delle proprietà modificate.");

                        if (!WriteModifiedInventorProperties(
                                owner,
                                session,
                                progress))
                        {
                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Inventor,
                            "Blocco Scrittura in Inventor completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 2 - WORD CARTELLINE
             * ==================================================
             */
            if (includeWord)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Word,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Word,
                            "Avvio elaborazione Word Cartelline.");

                        bool result =
                            _wordTemplateProcessor.Process(
                                owner,
                                configuration,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Word,
                                "Il processo Word Cartelline non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Word,
                            "Blocco Word Cartelline completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 3 - EXCEL LAMIERE / DISTINTE
             * ==================================================
             */
            if (includeExcel)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Excel,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Excel,
                            "Avvio elaborazione Excel.");

                        bool result =
                            _excelDrawingsProcessor.Process(
                                owner,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Excel,
                                "Il processo Excel non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Excel,
                            "Blocco Excel completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 4 - PDF LAMIERE
             * ==================================================
             */
            if (includePdf)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Pdf,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Pdf,
                            "Avvio elaborazione PDF Lamiere.");

                        bool result =
                            _sheetMetalPdfProcessor.Process(
                                owner,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Pdf,
                                "Il processo PDF Lamiere non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Pdf,
                            "Blocco PDF Lamiere completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 5 - GRUPPI DI MONTAGGIO
             * ==================================================
             */
            if (includeAssemblyGroups)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.AssemblyGroups,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Avvio Stampa Gruppi di montaggio.");

                        bool result =
                            _assemblyGroupsProcessor.Process(
                                owner,
                                configuration,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.AssemblyGroups,
                                "Il processo Gruppi di montaggio non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Blocco Stampa Gruppi di montaggio completato.");

                        return true;
                    });
            }
        }


        /*
         * ==================================================
         * ESECUZIONE SICURA DI UN BLOCCO
         * ==================================================
         *
         * Un errore in un blocco:
         *
         * - viene registrato;
         * - NON interrompe i blocchi successivi;
         * - il blocco viene comunque considerato
         *   terminato ai fini della barra.
         */
        private static void ExecuteSection(
            StampaCartellineProcessProgress progress,
            StampaCartellineProcessSection section,
            Func<bool> action)
        {
            try
            {
                action();
            }
            catch (Exception exception)
            {
                progress.AddError(
                    section,
                    "Errore non gestito:" +
                    System.Environment.NewLine +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                progress.MarkCompleted(
                    section);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        private bool ValidateInventorProperties(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            List<DashboardPropertySession> missingProperties =
                session.InventorProperties
                    .Where(
                        property =>
                            string.IsNullOrWhiteSpace(
                                property.Value))
                    .ToList();


            if (missingProperties.Count == 0)
            {
                progress.AddSuccess(
                    StampaCartellineProcessSection.Inventor,
                    "Tutte le proprietà Inventor richieste sono valorizzate.");

                return true;
            }


            string missingNames =
                string.Join(
                    ", ",
                    missingProperties
                        .Select(
                            property =>
                                property.Tag));


            /*
             * Manteniamo questo popup perché è
             * un avviso operativo immediato,
             * non un riepilogo finale.
             */
            MessageBox.Show(
                owner,
                "Attenzione proprietà di Inventor mancanti.",
                "Stampa Cartelline",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);


            progress.AddError(
                StampaCartellineProcessSection.Inventor,
                "Proprietà Inventor mancanti: " +
                missingNames);


            return false;
        }


        private bool WriteModifiedInventorProperties(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            List<DashboardPropertySession> modifiedProperties =
                session.InventorProperties
                    .Where(
                        property =>
                            !string.Equals(
                                property.Value?.Trim(),
                                property.OriginalValue?.Trim(),
                                StringComparison.Ordinal))
                    .ToList();


            if (modifiedProperties.Count == 0)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Inventor,
                    "Nessuna proprietà Inventor modificata da scrivere.");

                return true;
            }


            progress.AddInformation(
                StampaCartellineProcessSection.Inventor,
                "Proprietà Inventor modificate da scrivere: " +
                modifiedProperties.Count);


            /*
             * Questo popup resta perché richiede
             * una decisione dell'utente durante
             * il processo.
             */
            DialogResult result =
                MessageBox.Show(
                    owner,
                    "Stiamo per scrivere le proprietà modificate in Inventor.\n\n" +
                    "Assicurati prima di premere OK di avere l'assieme in Check-Out.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Information);


            if (result != DialogResult.OK)
            {
                progress.AddWarning(
                    StampaCartellineProcessSection.Inventor,
                    "Scrittura proprietà Inventor annullata dall'utente.");

                return false;
            }


            bool written =
                _propertyWriter.WriteProperties(
                    modifiedProperties);


            if (written)
            {
                foreach (DashboardPropertySession property
                    in modifiedProperties)
                {
                    progress.AddSuccess(
                        StampaCartellineProcessSection.Inventor,
                        "Proprietà scritta: " +
                        property.Tag +
                        " = " +
                        (property.Value ?? string.Empty));
                }

                return true;
            }


            /*
             * NON mostriamo più il vecchio popup finale
             * "Non è stato possibile scrivere...".
             *
             * L'errore confluisce nel LOG centrale.
             */
            progress.AddError(
                StampaCartellineProcessSection.Inventor,
                "Non è stato possibile scrivere una o più proprietà in Inventor.");


            return false;
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;


            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }


            return realException.Message;
        }
    }
}