﻿using Marpatech_8.Features.Core.Office;
using Marpatech_8.Features.Core.Windows;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using Marpatech_8.Features.GeneraWord.Translation.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using DrawingImage = System.Drawing.Image;
using IOPath = System.IO.Path;
using Word = Microsoft.Office.Interop.Word;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public class ManualWordService
    {
        public async Task<List<ManualGenerationError>> ProcessWordFilesAsync(
                            string generationFolder,
            Dictionary<string, string> propertyValues,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf,
            IProgress<ManualGenerationProgress>? progress)
        {
            List<string> wordFiles = ManualFileService
                .GetFiles(
                    generationFolder,
                    "*.*",
                    SearchOption.AllDirectories)
                            .Where(file =>
                    file.EndsWith(".doc", StringComparison.OrdinalIgnoreCase) ||
                    file.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                .Where(file => !IOPath.GetFileName(file).StartsWith("~$"))
                .ToList();

            List<ManualGenerationError> errors = new List<ManualGenerationError>();

            Word.Application? wordApp = null;

            try
            {
                wordApp =
                    WordAutomationService.CreateApplication(
                        visible: false,
                        displayAlerts: false);

                if (wordApp == null)
                {
                    throw new Exception(
                        "Impossibile avviare Microsoft Word.");
                }

                int current = 0;
                int total = wordFiles.Count;

                foreach (string wordFile in wordFiles)
                {
                    current++;

                    string currentWordFile = wordFile;
                    string languageCode = "IT";

                    List<string> fileWarnings = new List<string>();

                    try
                    {
                        languageCode =
                            GetLanguageCodeFromFile(
                                generationFolder,
                                wordFile);


                        currentWordFile =
                            RenameWordFileIfNeeded(
                                wordFile,
                                propertyValues);

                        progress?.Report(new ManualGenerationProgress
                        {
                            Current = current,
                            Total = total,
                            CurrentFile = languageCode + "\\" + IOPath.GetFileName(currentWordFile),
                            Percentage = total == 0 ? 100 : (int)((double)current / total * 100)
                        });

                        UiCompatibilityService.DoEventsSafe();

                        Dictionary<string, string> placeholderMap =
                            await BuildPlaceholderMapAsync(
                                propertyValues,
                                languageCode,
                                fileWarnings);

                        ProcessSingleDocument(
                            wordApp,
                            currentWordFile,
                            placeholderMap,
                            inventorImagePath,
                            exportPdf,
                            exportOnlyDichiarazionePdf,
                            fileWarnings);

                        if (fileWarnings.Count > 0)
                        {
                            errors.Add(new ManualGenerationError
                            {
                                FileName =
                                    languageCode + "\\" +
                                    IOPath.GetFileName(currentWordFile),

                                ErrorMessage = string.Join(
                                    System.Environment.NewLine +
                                    System.Environment.NewLine,
                                    fileWarnings)
                            });
                        }
                    }
                    catch (Exception ex)
                    {
                        errors.Add(new ManualGenerationError
                        {
                            FileName =
                                languageCode + "\\" +
                                IOPath.GetFileName(currentWordFile),
                            ErrorMessage =
                            string.Join(
                                System.Environment.NewLine +
                                System.Environment.NewLine,
                                fileWarnings.Concat(
                                    new[] { ex.ToString() }))
                        });
                    }
                }
            }
            finally
            {
                try
                {
                    WordAutomationService.ReleaseApplication(
                        ref wordApp);
                }
                finally

                {
                    ManualImageService.CleanTempFolder();
                }
            }
            return errors;
        }
        private string RenameWordFileIfNeeded(
            string wordFile,
            Dictionary<string, string> propertyValues)
        {
            WordPlaceholderSettings settings =
                WordPlaceholderSettingsService.Load();

            string replacementValue =
                ResolveSourceValue(
                    settings.ManualFolderProperty,
                    propertyValues);

            if (string.IsNullOrWhiteSpace(replacementValue))
                return wordFile;

            string fileName = IOPath.GetFileName(wordFile);

            if (!fileName.Contains("NCOM", StringComparison.OrdinalIgnoreCase))
                return wordFile;

            string directory = IOPath.GetDirectoryName(wordFile) ?? "";

            string newFileName = fileName.Replace(
                "NCOM",
                replacementValue,
                StringComparison.OrdinalIgnoreCase);

            string newPath = IOPath.Combine(directory, newFileName);

            if (ManualFileService.FileExists(newPath))
                ManualFileService.DeleteFileSafe(newPath);

            ManualFileService.MoveFileSafe(
                wordFile,
                newPath,
                true);

            return newPath;
        }
        private async Task<Dictionary<string, string>> BuildPlaceholderMapAsync(
            Dictionary<string, string> propertyValues,
            string languageCode,
            List<string> warnings)
        {
            WordPlaceholderSettings placeholderSettings =
                WordPlaceholderSettingsService.Load();

            TranslationService translationService =
                new TranslationService();

            Dictionary<string, string> map = new Dictionary<string, string>();

            foreach (WordPlaceholderConfig config in placeholderSettings.Placeholders)
            {
                if (string.IsNullOrWhiteSpace(config.Placeholder))
                    continue;

                string value =
                    ResolveSourceValue(
                        config.Source,
                        propertyValues);

                value =
                    await translationService.TranslateOrOriginalAsync(
                        value,
                        languageCode,
                        config.IncludeInTranslation,
                        warnings);

                map[config.Placeholder] = value;
            }

            return map;
        }

         private string GetValue(
            Dictionary<string, string> values,
            string key)
           {
                 if (values.ContainsKey(key))
                     return values[key];

                     return "";
                }
        private void ProcessSingleDocument(
            Word.Application wordApp,
            string wordFile,
            Dictionary<string, string> placeholderMap,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf,
            List<string> warnings)
        {
            Word.Document? document = null;

            try
            {
                document =
                    WordAutomationService.OpenDocument(
                        wordApp,
                        wordFile,
                        readOnly: false,
                        visible: false);

                if (document == null)
                {
                    throw new Exception(
                        "Impossibile aprire il documento Word:\n" +
                        wordFile);
                }

                ReplaceInRange(
                    document.Content,
                    placeholderMap);

                foreach (Word.Section section in document.Sections)
                {
                    foreach (Word.HeaderFooter footer in section.Footers)
                    {
                        ReplaceInRange(
                            footer.Range,
                            placeholderMap);
                    }
                }

                try
                {
                    InsertInventorImage(
                        wordApp,
                        document,
                        inventorImagePath);
                }
                catch (Exception ex)
                {
                    warnings.Add(
                        "Errore sostituzione immagine ImgInventor:" +
                        System.Environment.NewLine +
                        ex.Message);
                }

                bool saved =
                    WordAutomationService.SaveDocument(
                        document);

                if (!saved)
                {
                    throw new Exception(
                        "Impossibile salvare il documento Word:\n" +
                        wordFile);
                }

                try
                {
                    ExportPdfIfNeeded(
                        document,
                        wordFile,
                        exportPdf,
                        exportOnlyDichiarazionePdf);
                }
                catch (Exception ex)
                {
                    warnings.Add(
                        "Errore esportazione PDF:" +
                        System.Environment.NewLine +
                        ex.Message);
                }
            }
            finally
            {
                WordAutomationService.ReleaseDocument(
                    ref document,
                    saveChanges: false);
            }
        }
        private void ReplaceInRange(
              Word.Range range,
              Dictionary<string, string> placeholderMap)
             {
            foreach (KeyValuePair<string, string> item in placeholderMap)
            {
                Word.Find find = range.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = item.Key;
                find.Replacement.Text =
                    string.IsNullOrWhiteSpace(item.Value)
                        ? " "
                        : item.Value;

                object replaceAll =
                    Word.WdReplace.wdReplaceAll;

                find.Execute(
                    Replace: ref replaceAll);
            }
        }







        private void InsertInventorImage(
            Word.Application wordApp,
            Word.Document document,
            string inventorImagePath)
        {
            if (wordApp == null || document == null)
                return;

            const string bookmarkName = "ImgInventor";

            if (string.IsNullOrWhiteSpace(inventorImagePath))
                return;

            string absoluteImagePath =
                System.IO.Path.GetFullPath(inventorImagePath);

            if (!System.IO.File.Exists(absoluteImagePath))
            {
                throw new System.IO.FileNotFoundException(
                    "PNG Inventor non trovato.",
                    absoluteImagePath);
            }

            if (!document.Bookmarks.Exists(bookmarkName))
                return;

            // Recuperiamo il Range del bookmark.
            Word.Range bookmarkRange =
                document.Bookmarks[bookmarkName].Range;

            if (bookmarkRange.InlineShapes.Count == 0)
            {
                throw new InvalidOperationException(
                    "Il bookmark ImgInventor non contiene " +
                    "un'immagine InlineShape.");
            }

            Word.InlineShape oldImage =
                bookmarkRange.InlineShapes[1];

            float originalWidth =
                oldImage.Width;

            // Posizione dell'immagine originale.
            int insertionPosition =
                oldImage.Range.Start;

            // Inseriamo la nuova immagine prima
            // di eliminare quella originale.
            Word.Range insertionRange =
                document.Range(
                    insertionPosition,
                    insertionPosition);

            Word.InlineShape? newImage =
                document.InlineShapes.AddPicture(
                    FileName: absoluteImagePath,
                    LinkToFile: false,
                    SaveWithDocument: true,
                    Range: insertionRange);

            if (newImage == null)
            {
                throw new InvalidOperationException(
                    "Word non ha inserito il PNG Inventor. " +
                    "L'immagine originale non è stata eliminata.");
            }

            // Manteniamo le proporzioni dell'immagine.
            if (newImage.Width > 0 &&
                newImage.Height > 0 &&
                originalWidth > 0)
            {
                float newHeight =
                    newImage.Height *
                    (originalWidth / newImage.Width);

                newImage.Width = originalWidth;
                newImage.Height = newHeight;
            }

            // Solo dopo aver inserito la nuova
            // eliminiamo quella precedente.
            oldImage.Delete();

            // Ricreiamo il bookmark sulla nuova immagine.
            if (document.Bookmarks.Exists(bookmarkName))
            {
                document.Bookmarks[bookmarkName].Delete();
            }

            document.Bookmarks.Add(
                bookmarkName,
                newImage.Range);
        }


        private Word.InlineShape? FindClosestInlineShape(
    Word.Document document,
    int targetStart)
        {
            Word.InlineShape? bestShape = null;
            int bestDistance = int.MaxValue;

            try
            {
                foreach (Word.InlineShape shape in document.InlineShapes)
                {
                    try
                    {
                        int distance =
                            Math.Abs(shape.Range.Start - targetStart);

                        if (distance < bestDistance)
                        {
                            bestDistance = distance;
                            bestShape = shape;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return bestShape;
        }

        private void ExportPdfIfNeeded(
             Word.Document document,
             string wordFile,
              bool exportPdf,
              bool exportOnlyDichiarazionePdf)
        {
            if (!exportPdf && !exportOnlyDichiarazionePdf)
                return;

            string fileNameWithoutExtension =
                IOPath.GetFileNameWithoutExtension(wordFile);

            if (exportOnlyDichiarazionePdf && !exportPdf)
            {
                if (!fileNameWithoutExtension.StartsWith(
                    "DICHIARAZIONE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            string directory =
                IOPath.GetDirectoryName(wordFile) ?? "";

            string pdfPath =
                IOPath.Combine(
                    directory,
                    fileNameWithoutExtension + ".pdf");

            if (ManualFileService.FileExists(pdfPath))
                return;

            document.ExportAsFixedFormat(
                pdfPath,
                Word.WdExportFormat.wdExportFormatPDF);
        }

            private string ResolveSourceValue(
            string source,
            Dictionary<string, string> propertyValues)
            {
                if (string.IsNullOrWhiteSpace(source))
                    return "";

                if (source == "SPAZIO VUOTO")
                    return "";

                if (source == "DATA")
                    return DateTime.Today.ToString("dd/MM/yyyy");

                if (source == "EDIZIONE")
                    return DateTime.Today.ToString("MM/yyyy");

                if (source == "ANNO DI PRODUZIONE")
                    return DateTime.Today.ToString("yyyy");

                if (propertyValues.ContainsKey(source))
                    return propertyValues[source];

                return "";
            }

        private string GetLanguageCodeFromFile(
              string generationFolder,
              string wordFile)
              {
            string relativePath =
                IOPath.GetRelativePath(
                    generationFolder,
                    wordFile);

            string[] parts =
                relativePath.Split(
                    IOPath.DirectorySeparatorChar,
                    IOPath.AltDirectorySeparatorChar);

            if (parts.Length == 0)
                return "IT";

            return parts[0].Trim().ToUpperInvariant();
        }

    }
}