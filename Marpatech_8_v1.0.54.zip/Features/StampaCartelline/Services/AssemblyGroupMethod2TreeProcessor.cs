﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2TreeProcessor
    {
        private readonly Inventor.Application _inventorApp;

        private readonly AssemblyGroupMethod2InternalCollector
            _internalCollector;

        private readonly AssemblyGroupMethod2PrintSelectionService
            _printSelectionService;

        private readonly AssemblyGroupMethod2PrintProcessor
          _printProcessor;

        private readonly AssemblyGroupMethod2PrintSelectionCleanupService
    _printSelectionCleanupService;

        public AssemblyGroupMethod2TreeProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));

            _internalCollector =
                new AssemblyGroupMethod2InternalCollector();

            _printSelectionService =
                new AssemblyGroupMethod2PrintSelectionService();

            _printProcessor =
                new AssemblyGroupMethod2PrintProcessor(
                    inventorApp);

            _printSelectionCleanupService =
                new AssemblyGroupMethod2PrintSelectionCleanupService(
                    inventorApp);

        }



        public void Process(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupMethod2TreeNode> roots,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            if (roots == null)
                return;


            try
            {
                foreach (AssemblyGroupMethod2TreeNode root
                    in roots)
                {
                    ProcessNodePostOrder(
                        owner,
                        mainAssembly,
                        root,
                        mainCodePrefix,
                        method2Rules);
                }
                /*
                 * Terminati tutti gli STL,
                 * gestiamo anche la tavola MAIN.
                 */
                ProcessMainAssemblyDrawing(
                    owner,
                    mainAssembly);

                ShowTemporaryLogIfNeeded(
                    owner,
                    roots);
            }
            finally
            {
                try
                {
                    mainAssembly.Activate();

                    System.Windows.Forms.Application
                        .DoEvents();
                }
                catch
                {
                }
            }
        }


        private void ProcessNodePostOrder(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            AssemblyGroupMethod2TreeNode node,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules)
        {
            /*
             * Prima i figli.
             *
             * ATTENZIONE:
             * anche se il contenitore è FALSE,
             * i figli TRUE devono comunque
             * essere processati.
             */
            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                ProcessNodePostOrder(
                    owner,
                    mainAssembly,
                    child,
                    mainCodePrefix,
                    method2Rules);
            }

            /*
 * Nodo mostrato solamente per ricostruire
 * il ramo gerarchico.
 */
            if (!node.IsProcessable)
            {
                return;
            }


            /*
             * Questo STL è stato deselezionato
             * nel Form 1.
             */
            if (!node.ProcessStl)
            {
                return;
            }


            ProcessSingleStl(
                owner,
                mainAssembly,
                node,
                mainCodePrefix,
                method2Rules);
        }


        private void ProcessSingleStl(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            AssemblyGroupMethod2TreeNode node,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules)
        {
            AssemblyDocument? stlAssembly =
                null;

            try
            {
                string assemblyPath =
                    node.AssemblyPath
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        assemblyPath))
                {
                    return;
                }


                Document openedDocument =
                    _inventorApp.Documents.Open(
                        assemblyPath,
                        true);


                stlAssembly =
                    openedDocument
                        as AssemblyDocument;


                if (stlAssembly == null)
                {
                    try
                    {
                        openedDocument.Close(
                            true);
                    }
                    catch
                    {
                    }

                    return;
                }


                stlAssembly.Activate();

                System.Windows.Forms.Application
                    .DoEvents();


                /*
                 * Costruiamo la struttura interna
                 * dello STL corrente.
                 */
                AssemblyGroupMethod2PrintNode printTree =
                    _internalCollector.Collect(
                        stlAssembly,
                        mainCodePrefix,
                        method2Rules);


                /*
                 * FORM 2 MODELESS.
                 *
                 * TRUE  = stampa tavola
                 * FALSE = non stampare
                 *
                 * Gli assiemi appartenenti alla famiglia
                 * del prefisso principale partono FALSE.
                 */
                bool printSelectionConfirmed =
                    _printSelectionService.ShowAndWait(
                        owner,
                        printTree);


                /*
                 * ANNULLA nel FORM 2:
                 *
                 * annulla SOLO questo STL corrente.
                 *
                 * Il finally:
                 * - chiuderà IAM STL;
                 * - tornerà al MAIN;
                 *
                 * poi il processo passerà al prossimo
                 * STL TRUE del Form 1.
                 */
                if (!printSelectionConfirmed)
                {
                    return;
                }

                                    /*
                     * Sicurezza dopo il Form 2:
                     *
                     * chiudiamo ciò che l'utente può aver aperto
                     * durante l'ispezione e torniamo allo STL IAM.
                     */
                _printSelectionCleanupService.Cleanup(
                    stlAssembly,
                    printTree);


                /*
                 * STAMPA REALE DEL FORM 2.
                 */
                _printProcessor.Process(
                    stlAssembly,
                    printTree,
                    method2Rules);

                CollectPrintErrors(
                    printTree,
                    node.ProcessLog,
                    node.Code);
            }
            catch
            {
                /*
                 * Il log strutturato verrà aggiunto
                 * più avanti.
                 *
                 * Un singolo STL non deve interrompere
                 * l'intero Metodo 2.
                 */
            }
            finally
            {
                if (stlAssembly != null)
                {
                    try
                    {
                        stlAssembly.Close(
                            true);

                        System.Windows.Forms.Application
                            .DoEvents();
                    }
                    catch
                    {
                    }
                }


                /*
                 * Dopo OGNI STL torniamo al MAIN.
                 */
                try
                {
                    mainAssembly.Activate();

                    System.Windows.Forms.Application
                        .DoEvents();
                }
                catch
                {
                }
            }
        }
        private static void CollectPrintErrors(
    AssemblyGroupMethod2PrintNode node,
    ICollection<string> log,
    string stlCode)
        {
            if (!string.IsNullOrWhiteSpace(
                    node.FailureReason))
            {
                log.Add(
                    stlCode +
                    " > " +
                    node.Code +
                    " | " +
                    node.FailureReason);
            }

            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectPrintErrors(
                    child,
                    log,
                    stlCode);
            }
        }
        private void ProcessMainAssemblyDrawing(
    IWin32Window owner,
    AssemblyDocument mainAssembly)
        {
            DrawingDocument? drawingDocument =
                null;

            string drawingPath =
                string.Empty;

            string mainCode =
                ReadCustomProperty(
                    mainAssembly,
                    "CODICE");

            if (string.IsNullOrWhiteSpace(
                    mainCode))
            {
                mainCode =
                    System.IO.Path
                        .GetFileNameWithoutExtension(
                            mainAssembly.FullFileName);
            }


            try
            {
                mainAssembly.Activate();

                System.Windows.Forms.Application
                    .DoEvents();


                BrowserPane activeBrowser =
                    mainAssembly
                        .BrowserPanes
                        .ActivePane;

                if (activeBrowser == null)
                {
                    throw new InvalidOperationException(
                        "Browser attivo del MAIN non disponibile.");
                }


                BrowserNode topNode =
                    activeBrowser.TopNode;

                if (topNode == null)
                {
                    throw new InvalidOperationException(
                        "Nodo principale del MAIN non disponibile.");
                }


                topNode.DoSelect();

                System.Windows.Forms.Application
                    .DoEvents();


                ExecuteInventorCommand(
                    "CMxOpenDrawingCmd");

                System.Windows.Forms.Application
                    .DoEvents();


                drawingDocument =
                    _inventorApp.ActiveDocument
                        as DrawingDocument;


                if (drawingDocument == null)
                {
                    MessageBox.Show(
                        owner,
                        "Tavola di " +
                        mainCode +
                        " non trovata.",
                        "Gruppi di montaggio",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                try
                {
                    drawingPath =
                        drawingDocument.FullFileName
                            ?.Trim()
                        ?? string.Empty;
                }
                catch
                {
                }


                DialogResult answer =
                    MessageBox.Show(
                        owner,
                        "Vuoi stampare la tavola di " +
                        mainCode +
                        "?" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        "Posizione nell'albero:" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        mainCode,
                        "Gruppi di montaggio",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);


                if (answer == DialogResult.Yes)
                {
                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Errore durante la gestione della tavola di " +
                    mainCode +
                    ":" +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    GetRealExceptionMessage(
                        exception),
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                /*
                 * Primo tentativo.
                 */
                if (drawingDocument != null)
                {
                    try
                    {
                        drawingDocument.Activate();

                        System.Windows.Forms.Application
                            .DoEvents();

                        drawingDocument.Close(
                            true);

                        System.Windows.Forms.Application
                            .DoEvents();
                    }
                    catch
                    {
                    }
                }


                /*
                 * Secondo tentativo per percorso,
                 * così evitiamo lo stesso problema
                 * intermittente incontrato nel Metodo 1.
                 */
                if (!string.IsNullOrWhiteSpace(
                        drawingPath))
                {
                    TryCloseDrawingByPath(
                        drawingPath);
                }


                try
                {
                    mainAssembly.Activate();

                    System.Windows.Forms.Application
                        .DoEvents();
                }
                catch
                {
                }
            }
        }
        private void ExecuteInventorCommand(
    string commandInternalName)
        {
            try
            {
                ControlDefinition command =
                    _inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            commandInternalName];

                command.Execute2(
                    true);
            }
            catch (Exception exception)
            {
                throw new InvalidOperationException(
                    "Errore durante l'esecuzione del comando " +
                    commandInternalName +
                    ": " +
                    GetRealExceptionMessage(
                        exception),
                    exception);
            }
        }
        private void TryCloseDrawingByPath(
    string drawingPath)
        {
            List<Document> documentsToClose =
                new List<Document>();


            foreach (Document document
                in _inventorApp.Documents)
            {
                try
                {
                    if (document.DocumentType !=
                        DocumentTypeEnum.kDrawingDocumentObject)
                    {
                        continue;
                    }

                    if (string.Equals(
                            document.FullFileName,
                            drawingPath,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        documentsToClose.Add(
                            document);
                    }
                }
                catch
                {
                }
            }


            foreach (Document document
                in documentsToClose)
            {
                try
                {
                    document.Close(
                        true);

                    System.Windows.Forms.Application
                        .DoEvents();
                }
                catch
                {
                }
            }
        }
        private static string ReadCustomProperty(
    AssemblyDocument document,
    string propertyName)
        {
            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Inventor.Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        private static string GetRealExceptionMessage(
    Exception exception)
        {
            Exception realException =
                exception;

            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }

            return realException.Message;
        }
        private static void ShowTemporaryLogIfNeeded(
    IWin32Window owner,
    IEnumerable<AssemblyGroupMethod2TreeNode> roots)
        {
            List<string> lines =
                new List<string>();

            foreach (AssemblyGroupMethod2TreeNode root
                in roots)
            {
                AppendLogRecursive(
                    root,
                    0,
                    lines);
            }


            if (lines.Count == 0)
                return;


            string text =
                "LOG METODO 2 - GRUPPI DI MONTAGGIO" +
                System.Environment.NewLine +
                System.Environment.NewLine +
                string.Join(
                    System.Environment.NewLine,
                    lines);


            using Form dialog =
                new Form();

            dialog.Text =
                "Log Gruppi di montaggio";

            dialog.StartPosition =
                FormStartPosition.CenterParent;

            dialog.Width =
                800;

            dialog.Height =
                520;


            System.Windows.Forms.TextBox textBox =
                new System.Windows.Forms.TextBox();

            textBox.Multiline =
                true;

            textBox.ReadOnly =
                true;

            textBox.ScrollBars =
                ScrollBars.Both;

            textBox.WordWrap =
                false;

            textBox.Dock =
                DockStyle.Fill;

            textBox.Font =
                new System.Drawing.Font(
                    "Consolas",
                    10);

            textBox.Text =
                text;


            Panel bottomPanel =
                new Panel();

            bottomPanel.Dock =
                DockStyle.Bottom;

            bottomPanel.Height =
                60;


            Button copyButton =
                new Button();

            copyButton.Text =
                "Copia";

            copyButton.Width =
                100;

            copyButton.Height =
                32;

            copyButton.Top =
                14;


            Button closeButton =
                new Button();

            closeButton.Text =
                "Chiudi";

            closeButton.Width =
                100;

            closeButton.Height =
                32;

            closeButton.Top =
                14;

            closeButton.DialogResult =
                DialogResult.OK;


            bottomPanel.Resize +=
                (_, _) =>
                {
                    closeButton.Left =
                        bottomPanel.ClientSize.Width
                        - closeButton.Width
                        - 15;

                    copyButton.Left =
                        closeButton.Left
                        - copyButton.Width
                        - 10;
                };


            copyButton.Click +=
                (_, _) =>
                {
                    try
                    {
                        Clipboard.SetText(
                            text);
                    }
                    catch
                    {
                    }
                };


            bottomPanel.Controls.Add(
                copyButton);

            bottomPanel.Controls.Add(
                closeButton);

            dialog.Controls.Add(
                textBox);

            dialog.Controls.Add(
                bottomPanel);

            dialog.AcceptButton =
                closeButton;

            dialog.ShowDialog(
                owner);
        }
        private static void AppendLogRecursive(
    AssemblyGroupMethod2TreeNode node,
    int level,
    ICollection<string> lines)
        {
            /*
             * Aggiungiamo il nodo soltanto
             * se contiene almeno un errore.
             */
            bool hasOwnErrors =
                node.ProcessLog.Count > 0;

            bool hasChildErrors =
                HasErrorsRecursive(
                    node);

            if (!hasOwnErrors &&
                !hasChildErrors)
            {
                return;
            }


            string indent =
                new string(
                    ' ',
                    level * 4);


            lines.Add(
                indent +
                node.Code);


            foreach (string error
                in node.ProcessLog)
            {
                lines.Add(
                    indent +
                    "    ERRORE - " +
                    error);
            }


            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                AppendLogRecursive(
                    child,
                    level + 1,
                    lines);
            }
        }
        private static bool HasErrorsRecursive(
    AssemblyGroupMethod2TreeNode node)
        {
            if (node.ProcessLog.Count > 0)
                return true;

            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                if (HasErrorsRecursive(
                        child))
                {
                    return true;
                }
            }

            return false;
        }
    }
}