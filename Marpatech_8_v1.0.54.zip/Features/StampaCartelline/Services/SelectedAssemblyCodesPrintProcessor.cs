﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class SelectedAssemblyCodesPrintProcessor
    {
        private readonly Inventor.Application _inventorApp;


        public SelectedAssemblyCodesPrintProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }


        public void Process(
            IWin32Window owner,
            IEnumerable<AssemblyCodeSelection> items,
            string mainAssemblyPrefix)
        {
            if (items == null)
                return;


            string separatorPrefix =
                mainAssemblyPrefix
                    ?.Trim()
                ?? string.Empty;


            foreach (AssemblyCodeSelection item
                in items)
            {
                ProcessSingleItem(
                    item);


                /*
                 * ==================================================
                 * SEPARATORE STL / PREFISSO MAIN
                 * ==================================================
                 *
                 * NON hardcoded.
                 *
                 * Se CODICE inizia con il valore della
                 * textbox singola Metodo 2, il blocco
                 * corrente è concluso.
                 */
                bool isBlockSeparator =
                    !string.IsNullOrWhiteSpace(
                        separatorPrefix) &&
                    !string.IsNullOrWhiteSpace(
                        item.Code) &&
                    item.Code.StartsWith(
                        separatorPrefix,
                        StringComparison.OrdinalIgnoreCase);


                if (isBlockSeparator)
                {
                    MessageBox.Show(
                        owner,
                        "Stampa \"" +
                        item.DrawingName +
                        "\" conclusa." +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        "Quando premerai OK partirà la stampa " +
                        "fino al prossimo " +
                        separatorPrefix +
                        ".",
                        "Stampa Cartelline",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }


        private void ProcessSingleItem(
            AssemblyCodeSelection item)
        {
            string drawingName =
                NormalizeDrawingFileName(
                    item.DrawingName);


            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                return;
            }


            string searchPath =
                item.DrawingSearchPath
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    searchPath) ||
                !Directory.Exists(
                    searchPath))
            {
                return;
            }


            string? drawingPath =
                FindDrawingRecursive(
                    searchPath,
                    drawingName);


            if (string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                return;
            }


            DrawingDocument? drawingDocument =
                null;


            try
            {
                Document openedDocument =
                    _inventorApp.Documents.Open(
                        drawingPath,
                        true);


                drawingDocument =
                    openedDocument
                        as DrawingDocument;


                if (drawingDocument == null)
                {
                    try
                    {
                        openedDocument.Close(
                            true);
                    }
                    catch
                    {
                    }

                    return;
                }


                drawingDocument.Activate();

                System.Windows.Forms.Application
                    .DoEvents();


                int copies =
                    item.Copies < 1
                        ? 1
                        : item.Copies;


                /*
                 * Una sola apertura IDW.
                 *
                 * Il comando viene lanciato N volte
                 * secondo la colonna Quantità.
                 */
                for (int copyIndex = 0;
                    copyIndex < copies;
                    copyIndex++)
                {
                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");
                }
            }
            finally
            {
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }
            }
        }


        private void ExecuteInventorCommand(
            string commandInternalName)
        {
            ControlDefinition command =
                _inventorApp
                    .CommandManager
                    .ControlDefinitions[
                        commandInternalName];


            command.Execute2(
                true);
        }


        private static string NormalizeDrawingFileName(
            string? drawingName)
        {
            string value =
                drawingName
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }


            try
            {
                value =
                    IOPath.GetFileName(
                        value);
            }
            catch
            {
            }


            string extension =
                IOPath.GetExtension(
                    value);


            if (string.IsNullOrWhiteSpace(
                    extension))
            {
                return value +
                    ".idw";
            }


            if (!string.Equals(
                    extension,
                    ".idw",
                    StringComparison.OrdinalIgnoreCase))
            {
                return IOPath
                           .GetFileNameWithoutExtension(
                               value)
                       + ".idw";
            }


            return value;
        }


        private static string?
            FindDrawingRecursive(
                string searchRoot,
                string expectedFileName)
        {
            try
            {
                foreach (string file
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.TopDirectoryOnly))
                {
                    if (string.Equals(
                            IOPath.GetFileName(
                                file),
                            expectedFileName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return file;
                    }
                }


                foreach (string subDirectory
                    in Directory.EnumerateDirectories(
                        searchRoot))
                {
                    string? result =
                        FindDrawingRecursive(
                            subDirectory,
                            expectedFileName);

                    if (!string.IsNullOrWhiteSpace(
                            result))
                    {
                        return result;
                    }
                }
            }
            catch
            {
            }


            return null;
        }


        private void TryCloseDrawing(
            DrawingDocument drawing)
        {
            string path =
                string.Empty;


            try
            {
                path =
                    drawing.FullFileName
                        ?.Trim()
                    ?? string.Empty;
            }
            catch
            {
            }


            try
            {
                drawing.Close(
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }


            /*
             * Secondo tentativo per percorso.
             */
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return;
            }


            List<Document> toClose =
                new List<Document>();


            foreach (Document document
                in _inventorApp.Documents)
            {
                try
                {
                    if (document.DocumentType ==
                            DocumentTypeEnum.kDrawingDocumentObject &&
                        string.Equals(
                            document.FullFileName,
                            path,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        toClose.Add(
                            document);
                    }
                }
                catch
                {
                }
            }


            foreach (Document document
                in toClose)
            {
                try
                {
                    document.Close(
                        true);
                }
                catch
                {
                }
            }
        }
    }
}