﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{

    public sealed class AssemblyGroupsProcessor
    {
        private readonly Inventor.Application _inventorApp;


        private readonly AssemblyGroupMethod1TreeCollector
    _method1TreeCollector;

        private readonly AssemblyGroupMethod1TreeDrawingResolver
    _method1TreeDrawingResolver;

        private readonly AssemblyGroupMethod1TreeProcessor
    _method1TreeProcessor;

        private readonly AssemblyGroupMethod1SelectionService
            _method1SelectionService;

        private readonly AssemblyGroupMethod2TreeCollector
    _method2TreeCollector;

        private readonly AssemblyGroupMethod2SelectionService
            _method2SelectionService;

        private readonly AssemblyGroupMethod2SelectionCleanupService
    _method2SelectionCleanupService;

        private readonly AssemblyGroupMethod2TreeProcessor
            _method2TreeProcessor;

        private readonly AssemblyGroupSelectedStlService
    _selectedStlService;

        private readonly SelectedAssemblyCodesPrintProcessor
    _selectedAssemblyCodesPrintProcessor;

        public AssemblyGroupsProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));

                    _method1TreeCollector =
            new AssemblyGroupMethod1TreeCollector();

                    _method1TreeDrawingResolver =
            new AssemblyGroupMethod1TreeDrawingResolver();

            _method1TreeProcessor =
                new AssemblyGroupMethod1TreeProcessor(
                    inventorApp);

            _method1SelectionService =
                new AssemblyGroupMethod1SelectionService();
            _method2TreeCollector =
                 new AssemblyGroupMethod2TreeCollector();

            _method2SelectionService =
                new AssemblyGroupMethod2SelectionService();
            _method2SelectionCleanupService =
                  new AssemblyGroupMethod2SelectionCleanupService(
              inventorApp);

            _method2TreeProcessor =
                new AssemblyGroupMethod2TreeProcessor(
                    inventorApp);

            _selectedStlService =
             new AssemblyGroupSelectedStlService();

            _selectedAssemblyCodesPrintProcessor =
                new SelectedAssemblyCodesPrintProcessor(
                    inventorApp);
        }

        public bool Process(
           IWin32Window owner,
           PrintFolderConfiguration configuration,
           StampaCartellineDashboardSession session)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * La Dashboard di sessione ha priorità.
             *
             * Se Gruppi di montaggio è disattivato
             * nella sessione, saltiamo tutto il blocco
             * senza interrompere il processo generale.
             */
            if (!session.IncludeAssemblyGroups)
            {
                return true;
            }

            AssemblyGroupsConfiguration?
                groupsConfiguration =
                    configuration.AssemblyGroups;

            if (groupsConfiguration == null)
            {
                return true;
            }

            /*
             * Se nessuno dei due metodi è configurato,
             * mostriamo l'avviso ma consideriamo
             * completato il blocco.
             */
            if (!groupsConfiguration.Method1Enabled &&
                !groupsConfiguration.Method2Enabled)
            {
                MessageBox.Show(
                    owner,
                    "Nessun metodo di stampa dei gruppi selezionato, " +
                    "Selezionalo nella configurazione e ripeti il comando",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return true;
            }

            /*
             * Entrambi i metodi partono sempre
             * dall'assieme MAIN attualmente aperto.
             *
             * Lo recuperiamo UNA SOLA VOLTA.
             */
            if (_inventorApp.ActiveDocument
                is not AssemblyDocument mainAssembly)
            {
                MessageBox.Show(
                    owner,
                    "Il documento attivo non è un assieme Inventor.",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return true;
            }

            /*
 * ==================================================
 * MODALITÀ:
 * STAMPA SOLO SERIE DI CODICI SELEZIONATI
 * ==================================================
 *
 * Questa modalità ha priorità su Metodo 1 / Metodo 2.
 */
            if (session.PrintOnlySelectedAssemblyCodes)
            {
                if (session.SelectedAssemblyCodes == null ||
                    session.SelectedAssemblyCodes.Count == 0)
                {
                    MessageBox.Show(
                        owner,
                        "Hai selezionato \"Vuoi stampare solo una serie di codici contenuta nell’assieme\" " +
                        "ma la lista è vuota.",
                        "Gruppi di montaggio",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return true;
                }


                _selectedAssemblyCodesPrintProcessor.Process(
                    owner,
                    session.SelectedAssemblyCodes,
                    groupsConfiguration
                        .Method2MainAssemblyCodePrefix);


                return true;
            }

            /*
             * ==================================================
             * METODO 1
             * ==================================================
             */
            if (groupsConfiguration.Method1Enabled)
            {
                /*
                 * Costruiamo la nuova struttura gerarchica
                 * degli STL.
                 */
                List<AssemblyGroupMethod1TreeNode> method1Tree =
                    _method1TreeCollector.Collect(
                        mainAssembly,
                        groupsConfiguration.Method1Rows);

                /*
 * Dashboard:
 * "Vuoi stampare solo alcuni STL?"
 */
                if (session.PrintOnlySelectedStl)
                {
                    HashSet<string> selectedCodes =
                        _selectedStlService.ParseSelectedCodes(
                            session.SelectedStlList);

                    /*
                     * Se la funzione è attiva ma la textbox
                     * è vuota, non processiamo nessun STL.
                     */
                    if (selectedCodes.Count == 0)
                    {
                        MessageBox.Show(
                            owner,
                            "Hai selezionato \"Vuoi stampare solo alcuni STL\" " +
                            "ma non hai indicato alcun codice.",
                            "Gruppi di montaggio",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return true;
                    }

                    _selectedStlService.FilterMethod1Tree(
                        method1Tree,
                        selectedCodes);
                }


                /*
                 * Mostriamo la finestra MODELESS
                 * con tutte le checkbox Jenkins inizialmente FALSE.
                 *
                 * Inventor deve rimanere utilizzabile
                 * mentre l'utente effettua la scelta.
                 */
                bool confirmed =
                    _method1SelectionService.ShowAndWait(
                        owner,
                        method1Tree);


                /*
                 * ANNULLA:
                 *
                 * nessuna stampa e nessun Jenkins.
                 * Consideriamo completato Gruppi di montaggio.
                 */
                if (!confirmed)
                {
                    try
                    {
                        mainAssembly.Activate();
                    }
                    catch
                    {
                    }

                    return true;
                }


                /*
                 * Risolviamo tutti gli IDW della nuova
                 * struttura tramite:
                 *
                 * DISEGNO
                 * +
                 * DrawingSearchPath
                 */
                _method1TreeDrawingResolver.Resolve(
                    method1Tree);

                /*
                 * NUOVO PROCESSO GERARCHICO REALE.
                 */
                _method1TreeProcessor.Process(
                    owner,
                    mainAssembly,
                    method1Tree);

                return true;
            }


            /*
             * ==================================================
             * METODO 2
             * ==================================================
             */
            if (groupsConfiguration.Method2Enabled)
            {
                List<AssemblyGroupMethod2TreeNode> method2Tree =
                    _method2TreeCollector.Collect(
                        mainAssembly,
                        groupsConfiguration
                            .Method2MainAssemblyCodePrefix);

                if (session.PrintOnlySelectedStl)
                {
                    HashSet<string> selectedCodes =
                        _selectedStlService.ParseSelectedCodes(
                            session.SelectedStlList);

                    if (selectedCodes.Count == 0)
                    {
                        MessageBox.Show(
                            owner,
                            "Hai selezionato \"Vuoi stampare solo alcuni STL\" " +
                            "ma non hai indicato alcun codice.",
                            "Gruppi di montaggio",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return true;
                    }

                    _selectedStlService.FilterMethod2Tree(
                        method2Tree,
                        selectedCodes);
                }


                bool confirmed =
                    _method2SelectionService.ShowAndWait(
                        owner,
                        method2Tree);


                if (!confirmed)
                {
                    try
                    {
                        mainAssembly.Activate();
                    }
                    catch
                    {
                    }

                    return true;
                }


                /*
                 * Pulizia di sicurezza dopo il Form 1:
                 *
                 * - chiude eventuali IAM STL aperti;
                 * - chiude eventuali relative tavole;
                 * - non tocca documenti estranei;
                 * - ritorna al MAIN.
                 */
                _method2SelectionCleanupService
                    .CleanupAfterSelection(
                        mainAssembly,
                        method2Tree);


                /*
                 * Processamento gerarchico:
                 *
                 * figli prima dei contenitori;
                 * solo nodi TRUE.
                 */
                _method2TreeProcessor.Process(
                    owner,
                    mainAssembly,
                    method2Tree,
                    groupsConfiguration
                        .Method2MainAssemblyCodePrefix,
                    groupsConfiguration
                        .Method2Rows);

                return true;
            }

            return true;
        }
        private static void ShowMethod2TreeTestResult(
    IWin32Window owner,
    IEnumerable<AssemblyGroupMethod2TreeNode> roots)
        {
            List<string> lines =
                new List<string>();


            foreach (AssemblyGroupMethod2TreeNode root
                in roots)
            {
                AppendMethod2TreeNodeForTest(
                    root,
                    0,
                    lines);
            }


            string text =
                string.Join(
                    System.Environment.NewLine,
                    lines);


            MessageBox.Show(
                owner,
                text,
                "Test struttura Metodo 2",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }


        private static void AppendMethod2TreeNodeForTest(
            AssemblyGroupMethod2TreeNode node,
            int level,
            ICollection<string> lines)
        {
            string indent =
                new string(
                    ' ',
                    level * 4);


            lines.Add(
                indent +
                (node.ProcessStl
                    ? "[TRUE] "
                    : "[FALSE] ") +
                node.Code);


            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                AppendMethod2TreeNodeForTest(
                    child,
                    level + 1,
                    lines);
            }
        }
    }
}