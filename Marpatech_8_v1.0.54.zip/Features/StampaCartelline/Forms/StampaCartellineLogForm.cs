﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public sealed class StampaCartellineLogForm :
        Form
    {
        private readonly StampaCartellineProcessProgress
            _progress;

        private readonly bool
            _isDarkTheme;

        private readonly RichTextBox
            _logTextBox;

        private readonly Button
            _copyButton;

        private readonly Button
            _closeButton;


        public StampaCartellineLogForm(
            StampaCartellineProcessProgress progress,
            bool isDarkTheme)
        {
            _progress =
                progress
                ?? throw new ArgumentNullException(
                    nameof(progress));

            _isDarkTheme =
                isDarkTheme;


            _logTextBox =
                new RichTextBox();

            _copyButton =
                new Button();

            _closeButton =
                new Button();


            InitializeComponent();

            RefreshLog();


            /*
             * Se il LOG cambia mentre il form
             * è aperto, lo aggiorniamo.
             */
            _progress.LogChanged +=
                Progress_LogChanged;


            FormClosed +=
                (_, _) =>
                {
                    _progress.LogChanged -=
                        Progress_LogChanged;
                };
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        18,
                        18,
                        22)
                    : Color.FromArgb(
                        245,
                        247,
                        250);


            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        32,
                        34,
                        40)
                    : Color.White;


            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(
                        30,
                        41,
                        59);


            Text =
                "LOG - Stampa Cartelline";


            StartPosition =
                FormStartPosition.CenterParent;


            Width =
                900;


            Height =
                650;


            MinimumSize =
                new Size(
                    700,
                    500);


            BackColor =
                backgroundColor;


            FormBorderStyle =
                FormBorderStyle.Sizable;


            MinimizeBox =
                false;


            /*
             * ==================================================
             * HEADER
             * ==================================================
             */
            Panel headerPanel =
                new Panel();


            headerPanel.Dock =
                DockStyle.Top;


            headerPanel.Height =
                85;


            headerPanel.BackColor =
                panelColor;


            Label title =
                new Label();


            title.Text =
                "LOG processo Stampa Cartelline";


            title.Font =
                new Font(
                    "Segoe UI",
                    17,
                    FontStyle.Bold);


            title.ForeColor =
                textColor;


            title.AutoSize =
                true;


            title.Left =
                20;


            title.Top =
                15;


            Label subtitle =
                new Label();


            subtitle.Text =
                "Dettaglio completo delle operazioni eseguite.";


            subtitle.Font =
                new Font(
                    "Segoe UI",
                    9);


            subtitle.ForeColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        170,
                        178,
                        190)
                    : Color.FromArgb(
                        100,
                        116,
                        139);


            subtitle.AutoSize =
                true;


            subtitle.Left =
                22;


            subtitle.Top =
                50;


            headerPanel.Controls.Add(
                title);


            headerPanel.Controls.Add(
                subtitle);


            /*
             * ==================================================
             * PANNELLO INFERIORE
             * ==================================================
             */
            Panel bottomPanel =
                new Panel();


            bottomPanel.Dock =
                DockStyle.Bottom;


            bottomPanel.Height =
                65;


            bottomPanel.BackColor =
                panelColor;


            _copyButton.Text =
                "Copia LOG";


            _copyButton.Width =
                120;


            _copyButton.Height =
                36;


            _copyButton.Top =
                14;


            _copyButton.FlatStyle =
                FlatStyle.Flat;


            _copyButton.FlatAppearance.BorderSize =
                0;


            _copyButton.BackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);


            _copyButton.ForeColor =
                Color.White;


            _copyButton.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);


            _copyButton.Cursor =
                Cursors.Hand;


            _copyButton.Click +=
                CopyButton_Click;


            _closeButton.Text =
                "Chiudi";


            _closeButton.Width =
                110;


            _closeButton.Height =
                36;


            _closeButton.Top =
                14;


            _closeButton.FlatStyle =
                FlatStyle.Flat;


            _closeButton.FlatAppearance.BorderSize =
                0;


            _closeButton.BackColor =
                Color.FromArgb(
                    100,
                    116,
                    139);


            _closeButton.ForeColor =
                Color.White;


            _closeButton.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);


            _closeButton.Cursor =
                Cursors.Hand;


            _closeButton.Click +=
                (_, _) =>
                {
                    Close();
                };


            bottomPanel.Resize +=
                (_, _) =>
                {
                    _closeButton.Left =
                        bottomPanel.ClientSize.Width
                        - _closeButton.Width
                        - 15;


                    _copyButton.Left =
                        _closeButton.Left
                        - _copyButton.Width
                        - 10;
                };


            bottomPanel.Controls.Add(
                _copyButton);


            bottomPanel.Controls.Add(
                _closeButton);


            /*
             * ==================================================
             * RICH TEXT BOX
             * ==================================================
             */
            _logTextBox.Dock =
                DockStyle.Fill;


            _logTextBox.ReadOnly =
                true;


            _logTextBox.BorderStyle =
                BorderStyle.None;


            _logTextBox.BackColor =
                panelColor;


            _logTextBox.ForeColor =
                textColor;


            _logTextBox.Font =
                new Font(
                    "Consolas",
                    10);


            _logTextBox.WordWrap =
                false;


            _logTextBox.ScrollBars =
                RichTextBoxScrollBars.Both;


            /*
             * Ordine importante per DockStyle.
             */
            Controls.Add(
                _logTextBox);


            Controls.Add(
                bottomPanel);


            Controls.Add(
                headerPanel);
        }


        private void Progress_LogChanged(
            object? sender,
            EventArgs e)
        {
            if (IsDisposed)
                return;


            if (InvokeRequired)
            {
                BeginInvoke(
                    new Action(
                        RefreshLog));

                return;
            }


            RefreshLog();
        }


        private void RefreshLog()
        {
            if (_logTextBox.IsDisposed)
                return;


            _logTextBox.Clear();


            foreach (StampaCartellineProcessSectionState section
                in _progress.Sections)
            {
                AppendSection(
                    section);
            }


            _logTextBox.SelectionStart =
                0;


            _logTextBox.ScrollToCaret();
        }


        private void AppendSection(
            StampaCartellineProcessSectionState state)
        {
            /*
             * ==================================================
             * TITOLO SEZIONE
             * ==================================================
             */
            AppendText(
                GetSectionTitle(
                    state.Section) +
                Environment.NewLine,
                GetNormalColor(),
                FontStyle.Bold);


            AppendText(
                new string(
                    '-',
                    72) +
                Environment.NewLine,
                GetNormalColor(),
                FontStyle.Regular);


            /*
             * Una sezione non dovrebbe mai essere
             * completamente vuota dopo che il processo
             * è stato configurato.
             *
             * Ma manteniamo comunque una gestione sicura.
             */
            if (state.Entries.Count == 0)
            {
                AppendText(
                    "Nessuna informazione registrata." +
                    Environment.NewLine,
                    GetMutedColor(),
                    FontStyle.Italic);
            }
            else
            {
                foreach (StampaCartellineLogEntry entry
                    in state.Entries)
                {
                    AppendEntry(
                        entry);
                }
            }


            AppendText(
                Environment.NewLine,
                GetNormalColor(),
                FontStyle.Regular);
        }


        private void AppendEntry(
            StampaCartellineLogEntry entry)
        {
            string prefix =
                GetEntryPrefix(
                    entry.Type);


            Color color =
                GetEntryColor(
                    entry.Type);


            FontStyle style =
                entry.Type ==
                    StampaCartellineLogEntryType.Error
                    ? FontStyle.Bold
                    : FontStyle.Regular;


            string[] lines =
                entry.Message
                    .Replace(
                        "\r\n",
                        "\n")
                    .Replace(
                        "\r",
                        "\n")
                    .Split('\n');


            if (lines.Length == 0)
                return;


            /*
             * Prima riga.
             */
            AppendText(
                prefix +
                lines[0] +
                Environment.NewLine,
                color,
                style);


            /*
             * Eventuali righe successive vengono
             * indentate per rendere leggibili errori
             * o messaggi complessi.
             */
            for (int i = 1;
                i < lines.Length;
                i++)
            {
                AppendText(
                    "    " +
                    lines[i] +
                    Environment.NewLine,
                    color,
                    style);
            }
        }


        private void AppendText(
            string text,
            Color color,
            FontStyle style)
        {
            int start =
                _logTextBox.TextLength;


            _logTextBox.AppendText(
                text);


            int length =
                _logTextBox.TextLength
                - start;


            _logTextBox.Select(
                start,
                length);


            _logTextBox.SelectionColor =
                color;


            _logTextBox.SelectionFont =
                new Font(
                    _logTextBox.Font,
                    style);


            _logTextBox.Select(
                _logTextBox.TextLength,
                0);
        }


        private void CopyButton_Click(
            object? sender,
            EventArgs e)
        {
            string text =
                BuildPlainTextLog();


            if (string.IsNullOrWhiteSpace(
                    text))
            {
                return;
            }


            try
            {
                Clipboard.SetText(
                    text);


                MessageBox.Show(
                    this,
                    "LOG copiato negli appunti.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show(
                    this,
                    "Impossibile copiare il LOG negli appunti.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        private string BuildPlainTextLog()
        {
            StringBuilder builder =
                new StringBuilder();


            foreach (StampaCartellineProcessSectionState section
                in _progress.Sections)
            {
                builder.AppendLine(
                    GetSectionTitle(
                        section.Section));


                builder.AppendLine(
                    new string(
                        '-',
                        72));


                if (section.Entries.Count == 0)
                {
                    builder.AppendLine(
                        "Nessuna informazione registrata.");
                }
                else
                {
                    foreach (StampaCartellineLogEntry entry
                        in section.Entries)
                    {
                        string prefix =
                            GetEntryPrefix(
                                entry.Type);


                        string[] lines =
                            entry.Message
                                .Replace(
                                    "\r\n",
                                    "\n")
                                .Replace(
                                    "\r",
                                    "\n")
                                .Split('\n');


                        if (lines.Length == 0)
                            continue;


                        builder.AppendLine(
                            prefix +
                            lines[0]);


                        for (int i = 1;
                            i < lines.Length;
                            i++)
                        {
                            builder.AppendLine(
                                "    " +
                                lines[i]);
                        }
                    }
                }


                builder.AppendLine();
            }


            return builder.ToString();
        }


        private static string GetSectionTitle(
            StampaCartellineProcessSection section)
        {
            return section switch
            {
                StampaCartellineProcessSection.Inventor =>
                    "SEZIONE 1 - Scrittura in Inventor",

                StampaCartellineProcessSection.Word =>
                    "SEZIONE 2 - Word Cartelline",

                StampaCartellineProcessSection.Excel =>
                    "SEZIONE 3 - Excel Lamiere",

                StampaCartellineProcessSection.Pdf =>
                    "SEZIONE 4 - PDF Lamiere",

                StampaCartellineProcessSection.AssemblyGroups =>
                    "SEZIONE 5 - Stampa Gruppi di montaggio",

                _ =>
                    section.ToString()
            };
        }


        private static string GetEntryPrefix(
            StampaCartellineLogEntryType type)
        {
            return type switch
            {
                StampaCartellineLogEntryType.Information =>
                    "• ",

                StampaCartellineLogEntryType.Success =>
                    "✓ ",

                StampaCartellineLogEntryType.Warning =>
                    "ATTENZIONE: ",

                StampaCartellineLogEntryType.Error =>
                    "ERRORE: ",

                StampaCartellineLogEntryType.Skipped =>
                    "",

                _ =>
                    ""
            };
        }


        private Color GetEntryColor(
            StampaCartellineLogEntryType type)
        {
            return type switch
            {
                /*
                 * Gli ERRORI devono essere
                 * chiaramente ROSSI.
                 */
                StampaCartellineLogEntryType.Error =>
                    Color.FromArgb(
                        220,
                        38,
                        38),

                StampaCartellineLogEntryType.Warning =>
                    Color.FromArgb(
                        217,
                        119,
                        6),

                StampaCartellineLogEntryType.Success =>
                    Color.FromArgb(
                        22,
                        163,
                        74),

                StampaCartellineLogEntryType.Skipped =>
                    GetMutedColor(),

                _ =>
                    GetNormalColor()
            };
        }


        private Color GetNormalColor()
        {
            return _isDarkTheme
                ? Color.White
                : Color.FromArgb(
                    30,
                    41,
                    59);
        }


        private Color GetMutedColor()
        {
            return _isDarkTheme
                ? Color.FromArgb(
                    170,
                    178,
                    190)
                : Color.FromArgb(
                    100,
                    116,
                    139);
        }
    }
}