﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class WinFormsHtmlRichTextService
    {
        private const int WM_SETREDRAW =
    0x000B;

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(
            IntPtr hWnd,
            int msg,
            IntPtr wParam,
            IntPtr lParam);
        public static void LoadHtml(
    RichTextBox richTextBox,
    string? html)
        {
            richTextBox.Clear();

            if (string.IsNullOrWhiteSpace(
                    html))
            {
                return;
            }

            try
            {
                string normalized =
                    html.Replace(
                        "&nbsp;",
                        "&#160;",
                        StringComparison.OrdinalIgnoreCase);

                XDocument document =
                    XDocument.Parse(
                        "<root>" +
                        normalized +
                        "</root>",
                        LoadOptions.PreserveWhitespace);

                if (document.Root == null)
                    return;

                foreach (XNode node
                         in document.Root.Nodes())
                {
                    AppendBlockNode(
                        richTextBox,
                        node);
                }

                /*
                 * ==========================================
                 * RIMOZIONE RITORNO A CAPO FINALE
                 * ==========================================
                 *
                 * ATTENZIONE:
                 *
                 * NON dobbiamo fare:
                 *
                 * richTextBox.Text = richTextBox.Text.TrimEnd(...)
                 *
                 * perché assegnare nuovamente Text
                 * distrugge tutta la formattazione RTF
                 * appena applicata:
                 *
                 * - grassetto
                 * - corsivo
                 * - sottolineato
                 * - barrato
                 * - dimensione
                 * - colore
                 * - allineamento
                 *
                 * Eliminiamo quindi solamente gli eventuali
                 * caratteri CR/LF finali tramite selezione.
                 * In questo modo tutta la formattazione
                 * precedente rimane intatta.
                 */

                /*
                 * Ogni <p> aggiunge un newline.
                 *
                 * L'ultimo newline è solamente tecnico
                 * e non deve essere mostrato come riga
                 * supplementare.
                 *
                 * Rimuoviamo quindi UNA SOLA sequenza
                 * Environment.NewLine, non tutti i newline
                 * finali, perché eventuali righe vuote
                 * intenzionali devono rimanere.
                 */

                string newline =
                    Environment.NewLine;

                if (
                    richTextBox.Text.EndsWith(
                        newline,
                        StringComparison.Ordinal)
                )
                {
                    int removeStart =
                        richTextBox.TextLength -
                        newline.Length;

                    richTextBox.Select(
                        removeStart,
                        newline.Length);

                    richTextBox.SelectedText =
                        string.Empty;
                }
            }
            catch
            {
                /*
                 * Se il file HTML è stato modificato
                 * manualmente e contiene sintassi non valida,
                 * mostriamo almeno il testo leggibile.
                 */

                string plainText =
                    Regex.Replace(
                        html,
                        "<[^>]+>",
                        string.Empty);

                richTextBox.Text =
                    WebUtility.HtmlDecode(
                        plainText);
            }
        }
        public static string ToHtml(
            RichTextBox richTextBox)
        {
            if (richTextBox.TextLength == 0)
                return string.Empty;

            /*
             * ToHtml deve leggere font, colore e stile
             * dei singoli caratteri.
             *
             * Per farlo GetCharacterStyle utilizza
             * temporaneamente Select().
             *
             * Disabilitiamo quindi il ridisegno del
             * RichTextBox durante la conversione:
             * il cursore non deve lampeggiare o muoversi
             * visivamente mentre analizziamo il testo.
             */
            int originalSelectionStart =
                richTextBox.SelectionStart;

            int originalSelectionLength =
                richTextBox.SelectionLength;

            SendMessage(
                richTextBox.Handle,
                WM_SETREDRAW,
                IntPtr.Zero,
                IntPtr.Zero);

            try
            {
                var builder =
                    new StringBuilder();

                string[] lines =
                    richTextBox.Lines;

                bool inBulletList =
                    false;

                bool inNumberList =
                    false;

                int globalPosition =
                    0;

                for (int lineIndex = 0;
                     lineIndex < lines.Length;
                     lineIndex++)
                {
                    string line =
                        lines[lineIndex];

                    bool isBullet =
                        line.StartsWith(
                            "• ",
                            StringComparison.Ordinal);

                    bool isNumber =
                        Regex.IsMatch(
                            line,
                            @"^\d+\.\s");

                    if (isBullet)
                    {
                        if (inNumberList)
                        {
                            builder.AppendLine(
                                "</ol>");

                            inNumberList =
                                false;
                        }

                        if (!inBulletList)
                        {
                            builder.AppendLine(
                                "<ul>");

                            inBulletList =
                                true;
                        }

                        string content =
                            line.Length >= 2
                                ? line[2..]
                                : string.Empty;

                        int contentOffset =
                            globalPosition +
                            Math.Min(
                                2,
                                line.Length);

                        builder.Append(
                            "<li>");

                        builder.Append(
                            BuildFormattedLine(
                                richTextBox,
                                contentOffset,
                                content.Length));

                        builder.AppendLine(
                            "</li>");
                    }
                    else if (isNumber)
                    {
                        if (inBulletList)
                        {
                            builder.AppendLine(
                                "</ul>");

                            inBulletList =
                                false;
                        }

                        if (!inNumberList)
                        {
                            builder.AppendLine(
                                "<ol>");

                            inNumberList =
                                true;
                        }

                        Match match =
                            Regex.Match(
                                line,
                                @"^(?<prefix>\d+\.\s)(?<content>.*)$");

                        string prefix =
                            match.Groups["prefix"].Value;

                        string content =
                            match.Groups["content"].Value;

                        int contentOffset =
                            globalPosition +
                            prefix.Length;

                        builder.Append(
                            "<li>");

                        builder.Append(
                            BuildFormattedLine(
                                richTextBox,
                                contentOffset,
                                content.Length));

                        builder.AppendLine(
                            "</li>");
                    }
                    else
                    {
                        if (inBulletList)
                        {
                            builder.AppendLine(
                                "</ul>");

                            inBulletList =
                                false;
                        }

                        if (inNumberList)
                        {
                            builder.AppendLine(
                                "</ol>");

                            inNumberList =
                                false;
                        }

                        HorizontalAlignment alignment =
                            GetParagraphAlignment(
                                richTextBox,
                                globalPosition);

                        string alignmentText =
                            alignment switch
                            {
                                HorizontalAlignment.Center =>
                                    "center",

                                HorizontalAlignment.Right =>
                                    "right",

                                _ =>
                                    "left"
                            };

                        builder.Append(
                            $"<p style=\"text-align:{alignmentText};\">");

                        builder.Append(
                            BuildFormattedLine(
                                richTextBox,
                                globalPosition,
                                line.Length));

                        builder.AppendLine(
                            "</p>");
                    }

                    globalPosition +=
                        line.Length;

                    if (lineIndex <
                        lines.Length - 1)
                    {
                        globalPosition++;
                    }
                }

                if (inBulletList)
                {
                    builder.AppendLine(
                        "</ul>");
                }

                if (inNumberList)
                {
                    builder.AppendLine(
                        "</ol>");
                }

                return builder
                    .ToString()
                    .Trim();
            }
            finally
            {
                /*
                 * Qualunque cosa succeda durante
                 * la conversione, rimettiamo sempre
                 * la selezione esattamente dov'era.
                 */
                try
                {
                    int safeStart =
                        Math.Min(
                            originalSelectionStart,
                            richTextBox.TextLength);

                    int safeLength =
                        Math.Min(
                            originalSelectionLength,
                            richTextBox.TextLength -
                            safeStart);

                    richTextBox.Select(
                        safeStart,
                        safeLength);
                }
                catch
                {
                }

                /*
                 * Riabilitiamo il rendering.
                 */
                SendMessage(
                    richTextBox.Handle,
                    WM_SETREDRAW,
                    new IntPtr(1),
                    IntPtr.Zero);

                richTextBox.Invalidate();
            }
        }

        private static void AppendBlockNode(
            RichTextBox richTextBox,
            XNode node)
        {
            /*
             * Gli XText presenti direttamente
             * sotto <root> sono normalmente
             * whitespace tra:
             *
             * </p>
             * <p>
             *
             * Non rappresentano righe.
             */

            if (node is XText textNode)
            {
                string text =
                    textNode.Value;

                if (!string.IsNullOrWhiteSpace(
                        text))
                {
                    AppendText(
                        richTextBox,
                        text,
                        new TextFormat());
                }

                return;
            }


            if (node is not XElement element)
                return;


            string tag =
                element.Name.LocalName
                    .ToLowerInvariant();


            switch (tag)
            {
                /*
                 * ======================================
                 * PARAGRAFO
                 * ======================================
                 *
                 * REGOLA DEFINITIVA:
                 *
                 * ogni <p> / <div> = UNA riga.
                 */

                case "p":
                case "div":
                    {
                        int start =
                            richTextBox.TextLength;


                        /*
                         * Un vecchio file potrebbe avere:
                         *
                         * <p><br /></p>
                         *
                         * È equivalente a <p></p>.
                         */

                        bool emptyBlock =
                            IsEmptyBlock(
                                element);


                        if (!emptyBlock)
                        {
                            AppendInlineContainer(
                                richTextBox,
                                element,
                                new TextFormat());
                        }


                        int length =
                            richTextBox.TextLength -
                            start;


                        ApplyAlignment(
                            richTextBox,
                            start,
                            length,
                            GetElementAlignment(
                                element));


                        /*
                         * IMPORTANTISSIMO:
                         *
                         * ogni blocco produce SEMPRE
                         * esattamente un terminatore
                         * di riga.
                         *
                         * Anche <p></p>.
                         */

                        AppendBlockNewLine(
                            richTextBox);

                        break;
                    }


                /*
                 * ======================================
                 * LISTA PUNTATA
                 * ======================================
                 */

                case "ul":
                    {
                        foreach (XElement item
                                 in element.Elements()
                                     .Where(
                                         x =>
                                             string.Equals(
                                                 x.Name.LocalName,
                                                 "li",
                                                 StringComparison.OrdinalIgnoreCase)))
                        {
                            AppendText(
                                richTextBox,
                                "• ",
                                new TextFormat());


                            AppendInlineContainer(
                                richTextBox,
                                item,
                                new TextFormat());


                            AppendBlockNewLine(
                                richTextBox);
                        }

                        break;
                    }


                /*
                 * ======================================
                 * LISTA NUMERATA
                 * ======================================
                 */

                case "ol":
                    {
                        int number =
                            1;


                        foreach (XElement item
                                 in element.Elements()
                                     .Where(
                                         x =>
                                             string.Equals(
                                                 x.Name.LocalName,
                                                 "li",
                                                 StringComparison.OrdinalIgnoreCase)))
                        {
                            AppendText(
                                richTextBox,
                                $"{number}. ",
                                new TextFormat());


                            AppendInlineContainer(
                                richTextBox,
                                item,
                                new TextFormat());


                            AppendBlockNewLine(
                                richTextBox);


                            number++;
                        }

                        break;
                    }


                /*
                 * ======================================
                 * BR TOP LEVEL
                 * ======================================
                 *
                 * Solo compatibilità con file vecchi.
                 */

                case "br":
                    {
                        AppendBlockNewLine(
                            richTextBox);

                        break;
                    }


                default:
                    {
                        AppendInlineContainer(
                            richTextBox,
                            element,
                            new TextFormat());


                        AppendBlockNewLine(
                            richTextBox);

                        break;
                    }
            }
        }

        private static bool IsEmptyBlock(
    XElement element)
        {
            /*
             * <p></p>
             *
             * oppure:
             *
             * <p><br /></p>
             *
             * oppure whitespace tecnico
             *
             * rappresentano tutti UNA riga vuota.
             */

            string text =
                string.Concat(
                    element
                        .DescendantNodesAndSelf()
                        .OfType<XText>()
                        .Select(
                            x => x.Value));


            if (!string.IsNullOrWhiteSpace(
                    text))
            {
                return false;
            }


            bool hasMeaningfulElement =
                element
                    .Descendants()
                    .Any(
                        x =>
                            !string.Equals(
                                x.Name.LocalName,
                                "br",
                                StringComparison.OrdinalIgnoreCase));


            return !hasMeaningfulElement;
        }

        private static void AppendBlockNewLine(
    RichTextBox richTextBox)
        {
            /*
             * Questa funzione NON deve controllare
             * se esiste già un newline.
             *
             * Ogni blocco canonico rappresenta
             * esattamente una riga.
             */

            richTextBox.AppendText(
                Environment.NewLine);
        }

        private static void AppendInlineContainer(
            RichTextBox richTextBox,
            XElement container,
            TextFormat parentFormat)
        {
            foreach (XNode child
                     in container.Nodes())
            {
                AppendInlineNode(
                    richTextBox,
                    child,
                    parentFormat);
            }
        }

        private static void AppendInlineNode(
            RichTextBox richTextBox,
            XNode node,
            TextFormat parentFormat)
        {
            if (node is XText textNode)
            {
                AppendText(
                    richTextBox,
                    textNode.Value,
                    parentFormat);

                return;
            }

            if (node is not XElement element)
                return;

            string tag =
                element.Name.LocalName
                    .ToLowerInvariant();

            if (tag == "br")
            {
                AppendNewLine(
                    richTextBox);

                return;
            }

            TextFormat format =
                parentFormat.Clone();

            switch (tag)
            {
                case "strong":
                case "b":
                    format.Bold =
                        true;
                    break;

                case "em":
                case "i":
                    format.Italic =
                        true;
                    break;

                case "u":
                    format.Underline =
                        true;
                    break;

                case "s":
                case "strike":
                    format.Strikeout =
                        true;
                    break;
            }

            ApplyStyleAttribute(
                element,
                format);

            foreach (XNode child
                     in element.Nodes())
            {
                AppendInlineNode(
                    richTextBox,
                    child,
                    format);
            }
        }

        private static void AppendText(
            RichTextBox richTextBox,
            string text,
            TextFormat format)
        {
            if (string.IsNullOrEmpty(text))
                return;

            int start =
                richTextBox.TextLength;

            richTextBox.AppendText(
                WebUtility.HtmlDecode(
                    text));

            int length =
                richTextBox.TextLength -
                start;

            if (length <= 0)
                return;

            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                start,
                length);

            Font baseFont =
                richTextBox.Font ??
                new Font(
                    "Segoe UI",
                    10F);

            FontStyle style =
                FontStyle.Regular;

            if (format.Bold)
                style |= FontStyle.Bold;

            if (format.Italic)
                style |= FontStyle.Italic;

            if (format.Underline)
                style |= FontStyle.Underline;

            if (format.Strikeout)
                style |= FontStyle.Strikeout;

            float size =
                format.FontSize ??
                baseFont.Size;

            try
            {
                richTextBox.SelectionFont =
                    new Font(
                        baseFont.FontFamily,
                        Math.Max(
                            6F,
                            size),
                        style);
            }
            catch
            {
                // Se un font particolare non accetta
                // una combinazione, manteniamo quello base.
            }

            if (format.Color.HasValue)
            {
                richTextBox.SelectionColor =
                    format.Color.Value;
            }

            richTextBox.Select(
                oldStart,
                oldLength);
        }

        private static void AppendNewLine(
            RichTextBox richTextBox)
        {
            if (richTextBox.TextLength == 0)
                return;

            if (!richTextBox.Text.EndsWith(
                    "\n",
                    StringComparison.Ordinal))
            {
                richTextBox.AppendText(
                    Environment.NewLine);
            }
        }

        private static void ApplyAlignment(
            RichTextBox richTextBox,
            int start,
            int length,
            HorizontalAlignment alignment)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                start,
                Math.Max(
                    0,
                    length));

            richTextBox.SelectionAlignment =
                alignment;

            richTextBox.Select(
                oldStart,
                oldLength);
        }

        private static HorizontalAlignment
            GetElementAlignment(
                XElement element)
        {
            string style =
                element
                    .Attribute("style")
                    ?.Value ??
                string.Empty;

            string? value =
                GetCssValue(
                    style,
                    "text-align");

            return value?.ToLowerInvariant() switch
            {
                "center" =>
                    HorizontalAlignment.Center,

                "right" =>
                    HorizontalAlignment.Right,

                _ =>
                    HorizontalAlignment.Left
            };
        }

        private static void ApplyStyleAttribute(
            XElement element,
            TextFormat format)
        {
            string style =
                element
                    .Attribute("style")
                    ?.Value ??
                string.Empty;

            string? fontWeight =
                GetCssValue(
                    style,
                    "font-weight");

            if (string.Equals(
                    fontWeight,
                    "bold",
                    StringComparison.OrdinalIgnoreCase) ||
                fontWeight == "700")
            {
                format.Bold =
                    true;
            }

            string? fontStyle =
                GetCssValue(
                    style,
                    "font-style");

            if (string.Equals(
                    fontStyle,
                    "italic",
                    StringComparison.OrdinalIgnoreCase))
            {
                format.Italic =
                    true;
            }

            string? decoration =
                GetCssValue(
                    style,
                    "text-decoration");

            if (!string.IsNullOrWhiteSpace(
                    decoration))
            {
                if (decoration.Contains(
                        "underline",
                        StringComparison.OrdinalIgnoreCase))
                {
                    format.Underline =
                        true;
                }

                if (decoration.Contains(
                        "line-through",
                        StringComparison.OrdinalIgnoreCase))
                {
                    format.Strikeout =
                        true;
                }
            }

            string? colorValue =
                GetCssValue(
                    style,
                    "color");

            if (!string.IsNullOrWhiteSpace(
                    colorValue))
            {
                try
                {
                    format.Color =
                        ColorTranslator.FromHtml(
                            colorValue);
                }
                catch
                {
                    // Colore non valido: ignoriamo.
                }
            }

            string? fontSize =
                GetCssValue(
                    style,
                    "font-size");

            if (!string.IsNullOrWhiteSpace(
                    fontSize))
            {
                format.FontSize =
                    ParseFontSize(
                        fontSize);
            }
        }

        private static string BuildFormattedLine(
            RichTextBox richTextBox,
            int start,
            int length)
        {
            if (length <= 0)
                return string.Empty;

            var builder =
                new StringBuilder();

            TextStyle? currentStyle =
                null;

            var currentText =
                new StringBuilder();

            for (int index = 0;
                 index < length;
                 index++)
            {
                int charPosition =
                    start +
                    index;

                if (charPosition >=
                    richTextBox.TextLength)
                {
                    break;
                }

                TextStyle style =
                    GetCharacterStyle(
                        richTextBox,
                        charPosition);

                if (currentStyle == null ||
                    !currentStyle.Equals(style))
                {
                    if (currentStyle != null)
                    {
                        AppendStyledText(
                            builder,
                            currentText.ToString(),
                            currentStyle);
                    }

                    currentStyle =
                        style;

                    currentText.Clear();
                }

                currentText.Append(
                    richTextBox.Text[
                        charPosition]);
            }

            if (currentStyle != null &&
                currentText.Length > 0)
            {
                AppendStyledText(
                    builder,
                    currentText.ToString(),
                    currentStyle);
            }

            return builder.ToString();
        }

        private static TextStyle GetCharacterStyle(
       RichTextBox richTextBox,
       int position)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                position,
                1);

            Font font =
                richTextBox.SelectionFont ??
                richTextBox.Font;

            Color selectionColor =
                richTextBox.SelectionColor;

            /*
             * ==========================================
             * COLORE BASE / COLORE ESPLICITO
             * ==========================================
             *
             * Se il colore del carattere coincide
             * con ForeColor del RichTextBox,
             * significa che il testo sta utilizzando
             * il colore base del tema.
             *
             * In quel caso NON deve essere
             * serializzato nell'HTML.
             *
             * Gli altri colori rimangono invece
             * espliciti.
             */

            Color? explicitColor =
                selectionColor.ToArgb() ==
                richTextBox.ForeColor.ToArgb()
                    ? null
                    : selectionColor;

            var result =
                new TextStyle
                {
                    Bold =
                        font?.Bold ?? false,

                    Italic =
                        font?.Italic ?? false,

                    Underline =
                        font?.Underline ?? false,

                    Strikeout =
                        font?.Strikeout ?? false,

                    Size =
                        font?.Size ??
                        richTextBox.Font.Size,

                    Color =
                        explicitColor
                };

            richTextBox.Select(
                oldStart,
                oldLength);

            return result;
        }

        private static HorizontalAlignment
            GetParagraphAlignment(
                RichTextBox richTextBox,
                int position)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            if (richTextBox.TextLength > 0)
            {
                int safePosition =
                    Math.Min(
                        Math.Max(
                            position,
                            0),
                        richTextBox.TextLength - 1);

                richTextBox.Select(
                    safePosition,
                    0);
            }

            HorizontalAlignment alignment =
                richTextBox.SelectionAlignment;

            richTextBox.Select(
                oldStart,
                oldLength);

            return alignment;
        }

        private static void AppendStyledText(
            StringBuilder builder,
            string text,
            TextStyle style)
        {
            string encoded =
                WebUtility.HtmlEncode(
                    text);

            var css =
                new StringBuilder();

            if (style.Bold)
            {
                css.Append(
                    "font-weight:bold;");
            }

            if (style.Italic)
            {
                css.Append(
                    "font-style:italic;");
            }

            if (style.Underline ||
                style.Strikeout)
            {
                css.Append(
                    "text-decoration:");

                if (style.Underline)
                {
                    css.Append(
                        "underline ");
                }

                if (style.Strikeout)
                {
                    css.Append(
                        "line-through");
                }

                css.Append(
                    ';');
            }

            css.Append(
                $"font-size:{style.Size.ToString("0.##", CultureInfo.InvariantCulture)}pt;");

            /*
             * ==========================================
             * COLORE
             * ==========================================
             *
             * null = colore base del tema.
             *
             * In quel caso NON scriviamo color:
             * nell'HTML.
             */

            if (style.Color.HasValue)
            {
                Color color =
                    style.Color.Value;

                css.Append(
                    $"color:#{color.R:X2}{color.G:X2}{color.B:X2};");
            }

            builder.Append(
                "<span style=\"");

            builder.Append(
                css);

            builder.Append(
                "\">");

            builder.Append(
                encoded);

            builder.Append(
                "</span>");
        }

        private static string? GetCssValue(
            string style,
            string propertyName)
        {
            foreach (string declaration
                     in style.Split(
                         ';',
                         StringSplitOptions.RemoveEmptyEntries))
            {
                string[] parts =
                    declaration.Split(
                        ':',
                        2);

                if (parts.Length != 2)
                    continue;

                if (!string.Equals(
                        parts[0].Trim(),
                        propertyName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                return parts[1].Trim();
            }

            return null;
        }

        private static float? ParseFontSize(
            string value)
        {
            string cleaned =
                value
                    .Trim()
                    .ToLowerInvariant();

            if (cleaned.EndsWith(
                    "pt",
                    StringComparison.Ordinal))
            {
                cleaned =
                    cleaned[..^2];
            }
            else if (cleaned.EndsWith(
                         "px",
                         StringComparison.Ordinal))
            {
                cleaned =
                    cleaned[..^2];

                if (float.TryParse(
                        cleaned,
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out float pixels))
                {
                    return pixels * 72F / 96F;
                }
            }

            if (float.TryParse(
                    cleaned,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out float result))
            {
                return result;
            }

            return null;
        }

        private sealed class TextFormat
        {
            public bool Bold { get; set; }

            public bool Italic { get; set; }

            public bool Underline { get; set; }

            public bool Strikeout { get; set; }

            public float? FontSize { get; set; }

            public Color? Color { get; set; }

            public TextFormat Clone()
            {
                return new TextFormat
                {
                    Bold =
                        Bold,

                    Italic =
                        Italic,

                    Underline =
                        Underline,

                    Strikeout =
                        Strikeout,

                    FontSize =
                        FontSize,

                    Color =
                        Color
                };
            }
        }

        private sealed class TextStyle :
            IEquatable<TextStyle>
        {
            public bool Bold { get; set; }

            public bool Italic { get; set; }

            public bool Underline { get; set; }

            public bool Strikeout { get; set; }

            public float Size { get; set; }

            /*
             * null =
             * colore base / automatico del tema.
             *
             * valore =
             * colore scelto esplicitamente.
             */
            public Color? Color { get; set; }

            public bool Equals(
                TextStyle? other)
            {
                if (other == null)
                    return false;

                bool sameColor;

                if (!Color.HasValue &&
                    !other.Color.HasValue)
                {
                    sameColor =
                        true;
                }
                else if (Color.HasValue &&
                         other.Color.HasValue)
                {
                    sameColor =
                        Color.Value.ToArgb() ==
                        other.Color.Value.ToArgb();
                }
                else
                {
                    sameColor =
                        false;
                }

                return
                    Bold == other.Bold &&
                    Italic == other.Italic &&
                    Underline == other.Underline &&
                    Strikeout == other.Strikeout &&
                    Math.Abs(
                        Size -
                        other.Size) <
                    0.01F &&
                    sameColor;
            }

            public override bool Equals(
                object? obj)
            {
                return Equals(
                    obj as TextStyle);
            }

            public override int GetHashCode()
            {
                return HashCode.Combine(
                    Bold,
                    Italic,
                    Underline,
                    Strikeout,
                    Size,
                    Color?.ToArgb() ?? 0);
            }
        }
    }
}