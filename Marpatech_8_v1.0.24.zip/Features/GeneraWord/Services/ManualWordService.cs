﻿using Inventor;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using Marpatech_8.Features.GeneraWord.Translation.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using FormsApplication = System.Windows.Forms.Application;
using IOFile = System.IO.File;
using IOPath = System.IO.Path;
using Word = Microsoft.Office.Interop.Word;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public class ManualWordService
    {
        public async Task<List<ManualGenerationError>> ProcessWordFilesAsync(
                            string generationFolder,
            Dictionary<string, string> propertyValues,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf,
            IProgress<ManualGenerationProgress>? progress)
        {
            List<string> wordFiles = Directory
                .GetFiles(generationFolder, "*.*", SearchOption.AllDirectories)
                .Where(file =>
                    file.EndsWith(".doc", StringComparison.OrdinalIgnoreCase) ||
                    file.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                .Where(file => !IOPath.GetFileName(file).StartsWith("~$"))
                .ToList();

            List<ManualGenerationError> errors = new List<ManualGenerationError>();

            Word.Application? wordApp = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                wordApp.DisplayAlerts = Word.WdAlertLevel.wdAlertsNone;

                int current = 0;
                int total = wordFiles.Count;

                foreach (string wordFile in wordFiles)
                {
                    current++;

                    string currentWordFile = wordFile;

                    try
                    {
                        string languageCode =
                            GetLanguageCodeFromFile(
                                generationFolder,
                                wordFile);


                        currentWordFile =
                            RenameWordFileIfNeeded(
                                wordFile,
                                propertyValues);

                        progress?.Report(new ManualGenerationProgress
                        {
                            Current = current,
                            Total = total,
                            CurrentFile = languageCode + "\\" + IOPath.GetFileName(currentWordFile),
                            Percentage = total == 0 ? 100 : (int)((double)current / total * 100)
                        });

                        FormsApplication.DoEvents();

                        Dictionary<string, string> placeholderMap =
                            await BuildPlaceholderMapAsync(
                                propertyValues,
                                languageCode);

                        ProcessSingleDocument(
                            wordApp,
                            currentWordFile,
                            placeholderMap,
                            inventorImagePath,
                            exportPdf,
                            exportOnlyDichiarazionePdf);
                    }
                    catch (Exception ex)
                    {
                        errors.Add(new ManualGenerationError
                        {
                            FileName = IOPath.GetFileName(currentWordFile),
                            ErrorMessage = ex.ToString()
                        });
                    }
                }
            }
            finally
            {
                if (wordApp != null)
                {
                    wordApp.Quit(false);

                    Marshal.ReleaseComObject(wordApp);

                    wordApp = null;
                }
            }
            return errors;
        }
        private string RenameWordFileIfNeeded(
            string wordFile,
            Dictionary<string, string> propertyValues)
        {
            WordPlaceholderSettings settings =
                WordPlaceholderSettingsService.Load();

            string replacementValue =
                ResolveSourceValue(
                    settings.ManualFolderProperty,
                    propertyValues);

            if (string.IsNullOrWhiteSpace(replacementValue))
                return wordFile;

            string fileName = IOPath.GetFileName(wordFile);

            if (!fileName.Contains("NCOM", StringComparison.OrdinalIgnoreCase))
                return wordFile;

            string directory = IOPath.GetDirectoryName(wordFile) ?? "";

            string newFileName = fileName.Replace(
                "NCOM",
                replacementValue,
                StringComparison.OrdinalIgnoreCase);

            string newPath = IOPath.Combine(directory, newFileName);

            if (IOFile.Exists(newPath))
                IOFile.Delete(newPath);

            IOFile.Move(wordFile, newPath);

            return newPath;
        }
        private async Task<Dictionary<string, string>> BuildPlaceholderMapAsync(
            Dictionary<string, string> propertyValues,
            string languageCode)
        {
            WordPlaceholderSettings placeholderSettings =
                WordPlaceholderSettingsService.Load();

            TranslationService translationService =
                new TranslationService();

            Dictionary<string, string> map = new Dictionary<string, string>();

            foreach (WordPlaceholderConfig config in placeholderSettings.Placeholders)
            {
                if (string.IsNullOrWhiteSpace(config.Placeholder))
                    continue;

                string value =
                    ResolveSourceValue(
                        config.Source,
                        propertyValues);

                value =
                    await translationService.TranslateOrOriginalAsync(
                        value,
                        languageCode,
                        config.IncludeInTranslation);

                map[config.Placeholder] = value;
            }

            return map;
        }

         private string GetValue(
            Dictionary<string, string> values,
            string key)
           {
                 if (values.ContainsKey(key))
                     return values[key];

                     return "";
                }
        private void ProcessSingleDocument(
            Word.Application wordApp,
            string wordFile,
            Dictionary<string, string> placeholderMap,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf)
        {
            Word.Document? document = null;

            try
            {
                document = wordApp.Documents.Open(
                    wordFile,
                    ReadOnly: false,
                    Visible: false);

                ReplaceInRange(
                    document.Content,
                    placeholderMap);

                foreach (Word.Section section in document.Sections)
                {
                    foreach (Word.HeaderFooter footer in section.Footers)
                    {
                        ReplaceInRange(
                            footer.Range,
                            placeholderMap);
                    }
                }

                InsertInventorImage(
                             document,
                            inventorImagePath);

               document.Save();

                ExportPdfIfNeeded(
                    document,
                    wordFile,
                    exportPdf,
                    exportOnlyDichiarazionePdf);
            }
            finally
            {
                if (document != null)
                {
                    document.Close(false);

                    Marshal.ReleaseComObject(document);

                    document = null;
                }
            }
        }
        private void ReplaceInRange(
              Word.Range range,
              Dictionary<string, string> placeholderMap)
             {
            foreach (KeyValuePair<string, string> item in placeholderMap)
            {
                Word.Find find = range.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = item.Key;
                find.Replacement.Text =
                    string.IsNullOrWhiteSpace(item.Value)
                        ? " "
                        : item.Value;

                object replaceAll =
                    Word.WdReplace.wdReplaceAll;

                find.Execute(
                    Replace: ref replaceAll);
            }
        }
        private void InsertInventorImage(
            Word.Document document,
            string inventorImagePath)
        {
            if (string.IsNullOrWhiteSpace(inventorImagePath))
                return;

            if (!IOFile.Exists(inventorImagePath))
                return;

            if (!document.Bookmarks.Exists("ImgInventor"))
                return;

            Word.Range range =
                document.Bookmarks["ImgInventor"].Range;

            float targetHeight = 260;

            if (range.InlineShapes.Count > 0)
            {
                Word.InlineShape oldShape =
                    range.InlineShapes[1];

                targetHeight = oldShape.Height;

                oldShape.Delete();
            }
            else
            {
                try
                {
                    if (range.ShapeRange.Count > 0)
                    {
                        Word.Shape oldShape =
                            range.ShapeRange[1];

                        targetHeight = oldShape.Height;

                        oldShape.Delete();
                    }
                }
                catch
                {
                    range.Text = "";
                }
            }

            Word.InlineShape newShape =
                range.InlineShapes.AddPicture(
                    FileName: inventorImagePath,
                    LinkToFile: false,
                    SaveWithDocument: true);

            float originalWidth = newShape.Width;
            float originalHeight = newShape.Height;

            if (originalHeight <= 0)
                return;

            float scale = targetHeight / originalHeight;

            newShape.Height = targetHeight;
            newShape.Width = originalWidth * scale;
        }
        private void ExportPdfIfNeeded(
             Word.Document document,
             string wordFile,
              bool exportPdf,
              bool exportOnlyDichiarazionePdf)
        {
            if (!exportPdf && !exportOnlyDichiarazionePdf)
                return;

            string fileNameWithoutExtension =
                IOPath.GetFileNameWithoutExtension(wordFile);

            if (exportOnlyDichiarazionePdf && !exportPdf)
            {
                if (!fileNameWithoutExtension.StartsWith(
                    "DICHIARAZIONE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            string directory =
                IOPath.GetDirectoryName(wordFile) ?? "";

            string pdfPath =
                IOPath.Combine(
                    directory,
                    fileNameWithoutExtension + ".pdf");

            if (IOFile.Exists(pdfPath))
                return;

            document.ExportAsFixedFormat(
                pdfPath,
                Word.WdExportFormat.wdExportFormatPDF);
        }

            private string ResolveSourceValue(
            string source,
            Dictionary<string, string> propertyValues)
            {
                if (string.IsNullOrWhiteSpace(source))
                    return "";

                if (source == "SPAZIO VUOTO")
                    return "";

                if (source == "DATA")
                    return DateTime.Today.ToString("dd/MM/yyyy");

                if (source == "EDIZIONE")
                    return DateTime.Today.ToString("MM/yyyy");

                if (source == "ANNO DI PRODUZIONE")
                    return DateTime.Today.ToString("yyyy");

                if (propertyValues.ContainsKey(source))
                    return propertyValues[source];

                return "";
            }
        private void FitInlineShape(
            Word.InlineShape shape,
           float maxWidth,
              float maxHeight)
            {
            float originalWidth = shape.Width;
            float originalHeight = shape.Height;

            if (originalWidth <= 0 || originalHeight <= 0)
                return;

            float widthRatio = maxWidth / originalWidth;
            float heightRatio = maxHeight / originalHeight;

            float scale = Math.Min(widthRatio, heightRatio);

            shape.Width = originalWidth * scale;
            shape.Height = originalHeight * scale;
        }
        private string GetLanguageCodeFromFile(
              string generationFolder,
              string wordFile)
              {
            string relativePath =
                IOPath.GetRelativePath(
                    generationFolder,
                    wordFile);

            string[] parts =
                relativePath.Split(
                    IOPath.DirectorySeparatorChar,
                    IOPath.AltDirectorySeparatorChar);

            if (parts.Length == 0)
                return "IT";

            return parts[0].Trim().ToUpperInvariant();
        }

    }
}