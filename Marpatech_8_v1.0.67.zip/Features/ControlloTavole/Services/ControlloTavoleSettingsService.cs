﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.ControlloTavole.Models;

namespace Marpatech_8.Features.ControlloTavole.Services
{
    public static class ControlloTavoleSettingsService
    {
        private const string SettingsFileName =
            "ControlloTavoleSettings.json";


        // =============================================================
        // PERCORSI
        // =============================================================

        public static string GetSettingsFolder()
        {
            string appData =
                Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

            return Path.Combine(
                appData,
                "Marpatech",
                "Settings");
        }


        public static string GetSettingsPath()
        {
            return Path.Combine(
                GetSettingsFolder(),
                SettingsFileName);
        }


        // =============================================================
        // CARICAMENTO
        // =============================================================

        public static ControlloTavoleSettings Load()
        {
            try
            {
                string path =
                    GetSettingsPath();

                if (!File.Exists(path))
                {
                    return new ControlloTavoleSettings();
                }

                string json =
                    File.ReadAllText(path);

                ControlloTavoleSettings? settings =
                    Deserialize(json);

                return settings ??
                    new ControlloTavoleSettings();
            }
            catch
            {
                /*
                 * Un JSON danneggiato non deve impedire
                 * l'apertura di Controllo Tavole.
                 */
                return new ControlloTavoleSettings();
            }
        }


        // =============================================================
        // SALVATAGGIO
        // =============================================================

        public static void Save(
            ControlloTavoleSettings settings)
        {
            string folder =
                GetSettingsFolder();

            Directory.CreateDirectory(
                folder);

            string json =
                Serialize(settings);

            File.WriteAllText(
                GetSettingsPath(),
                json);
        }


        // =============================================================
        // IMPORT
        // =============================================================

        public static ControlloTavoleSettings Import(
            string sourcePath)
        {
            if (string.IsNullOrWhiteSpace(sourcePath))
            {
                throw new ArgumentException(
                    "Percorso configurazione non valido.");
            }

            if (!File.Exists(sourcePath))
            {
                throw new FileNotFoundException(
                    "Il file di configurazione selezionato non esiste.",
                    sourcePath);
            }

            /*
             * Prima leggiamo e deserializziamo.
             * Se il JSON non è valido NON tocchiamo
             * la configurazione esistente.
             */
            string json =
                File.ReadAllText(sourcePath);

            ControlloTavoleSettings? importedSettings =
                Deserialize(json);

            if (importedSettings == null)
            {
                throw new InvalidDataException(
                    "Il file selezionato non contiene una configurazione valida.");
            }

            /*
             * Solo dopo la validazione sovrascriviamo
             * il JSON utilizzato dall'addin.
             */
            Save(importedSettings);

            return importedSettings;
        }


        // =============================================================
        // EXPORT
        // =============================================================

        public static void Export(
            string destinationPath)
        {
            if (string.IsNullOrWhiteSpace(destinationPath))
            {
                throw new ArgumentException(
                    "Percorso di esportazione non valido.");
            }

            /*
             * Esportiamo il JSON realmente utilizzato
             * dall'addin.
             */
            string sourcePath =
                GetSettingsPath();

            /*
             * Se ancora non esiste, creiamo prima
             * la configurazione predefinita.
             */
            if (!File.Exists(sourcePath))
            {
                Save(
                    new ControlloTavoleSettings());
            }

            string sourceFullPath =
                Path.GetFullPath(sourcePath);

            string destinationFullPath =
                Path.GetFullPath(destinationPath);

            /*
             * Evita Copy() sullo stesso identico file.
             */
            if (string.Equals(
                    sourceFullPath,
                    destinationFullPath,
                    StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            File.Copy(
                sourcePath,
                destinationPath,
                true);
        }


        // =============================================================
        // SERIALIZZAZIONE
        // =============================================================

        private static string Serialize(
            ControlloTavoleSettings settings)
        {
            return JsonSerializer.Serialize(
                settings,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });
        }


        private static ControlloTavoleSettings? Deserialize(
            string json)
        {
            ControlloTavoleSettings? settings =
                JsonSerializer.Deserialize<ControlloTavoleSettings>(
                    json);

            if (settings == null)
                return null;

            settings.Exclusions ??=
                new List<CodeExclusionRule>();

            settings.DrawingSearchRules ??=
                 new List<DrawingSearchRule>();

            return settings;
        }
    }
}