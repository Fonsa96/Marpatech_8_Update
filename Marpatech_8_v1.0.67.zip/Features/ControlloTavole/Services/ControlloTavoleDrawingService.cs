﻿using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.Core.Inventor;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.ControlloTavole.Services
{
    public static class ControlloTavoleDrawingService
    {
        // =============================================================
        // RICERCA SINGOLA
        //
        // Mantenuta per compatibilità con il codice esistente.
        // La ricerca principale della funzione dovrà usare FindDrawings().
        // =============================================================

        public static string? FindDrawingPath(
            string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return null;

            Dictionary<string, ControlloTavoleDrawingResult> results =
                FindDrawings(
                    new[]
                    {
                        code
                    });

            if (!results.TryGetValue(
                    code,
                    out ControlloTavoleDrawingResult? result))
            {
                return null;
            }

            return result.Found
                ? result.DrawingPath
                : null;
        }


        // =============================================================
        // RICERCA BATCH
        // =============================================================

        public static Dictionary<string, ControlloTavoleDrawingResult>
            FindDrawings(
                IEnumerable<string> codes)
        {
            Dictionary<string, ControlloTavoleDrawingResult> results =
                new Dictionary<string, ControlloTavoleDrawingResult>(
                    StringComparer.OrdinalIgnoreCase);


            if (codes == null)
                return results;


            ControlloTavoleSettings settings =
                ControlloTavoleSettingsService.Load();


            List<DrawingSearchRule> rules =
                settings.DrawingSearchRules ??
                new List<DrawingSearchRule>();


            // =========================================================
            // PREPARAZIONE CODICI
            // =========================================================

            List<DrawingSearchRequest> requests =
                new List<DrawingSearchRequest>();


            foreach (string rawCode
                     in codes)
            {
                if (string.IsNullOrWhiteSpace(rawCode))
                    continue;


                string code =
                    rawCode.Trim();


                // Evitiamo doppioni.
                if (results.ContainsKey(code))
                    continue;


                DrawingSearchRule? rule =
                    FindBestRule(
                        code,
                        rules);


                if (rule == null)
                {
                    results[code] =
                        new ControlloTavoleDrawingResult
                        {
                            Code = code,
                            Found = false,
                            FallbackEnabled = false
                        };

                    continue;
                }


                string? normalizedCode =
                    NormalizeCode(
                        code,
                        rule);


                if (string.IsNullOrWhiteSpace(
                        normalizedCode))
                {
                    results[code] =
                        new ControlloTavoleDrawingResult
                        {
                            Code = code,
                            Found = false,
                            FallbackEnabled =
                                rule.EnableFallback
                        };

                    continue;
                }


                string fileName =
                    normalizedCode + ".idw";


                string root =
                    rule.ServerRootPath?.Trim() ??
                    "";


                ControlloTavoleDrawingResult result =
                    new ControlloTavoleDrawingResult
                    {
                        Code = code,
                        ExpectedFileName = fileName,
                        Found = false,
                        FallbackEnabled =
                            rule.EnableFallback,
                        FoundByFallback = false
                    };


                results[code] =
                    result;


                if (string.IsNullOrWhiteSpace(root))
                    continue;


                requests.Add(
                    new DrawingSearchRequest
                    {
                        Code = code,
                        NormalizedCode =
                            normalizedCode,
                        FileName = fileName,
                        Root = root,
                        Rule = rule,
                        Result = result
                    });
            }


            if (requests.Count == 0)
                return results;


            // =========================================================
            // FASE 1
            //
            // CONTROLLO DIRETTO NELLA ROOT
            // =========================================================

            foreach (DrawingSearchRequest request
                     in requests)
            {
                if (!Directory.Exists(
                        request.Root))
                {
                    continue;
                }


                string directPath =
                    Path.Combine(
                        request.Root,
                        request.FileName);


                if (File.Exists(directPath))
                {
                    MarkFound(
                        request,
                        directPath,
                        false);
                }
            }


            // =========================================================
            // FASE 2
            //
            // DEDUZIONE CARTELLA
            //
            // Qui NON cerchiamo ancora i file.
            // Determiniamo solamente la cartella dedotta per ogni codice.
            // =========================================================

            foreach (DrawingSearchRequest request
                     in requests.Where(
                         r =>
                             !r.Result.Found &&
                             r.Rule.DeduceSubfolders))
            {
                if (!Directory.Exists(
                        request.Root))
                {
                    continue;
                }


                string prefix =
                    request.Rule.CodePrefix?.Trim() ??
                    "";


                string remainingCode =
                    request.NormalizedCode.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase)
                        ? request.NormalizedCode.Substring(
                            prefix.Length)
                        : request.NormalizedCode;


                request.DeducedFolder =
                    FindDeductionFolder(
                        request.Root,
                        remainingCode);
            }


            // =========================================================
            // FASE 3
            //
            // RICERCA BATCH NELLE CARTELLE DEDOTTE
            //
            // Tutti i codici che finiscono nella stessa cartella vengono
            // cercati durante UNA SOLA enumerazione.
            // =========================================================

            IEnumerable<IGrouping<string, DrawingSearchRequest>>
                deductionGroups =
                    requests
                        .Where(
                            r =>
                                !r.Result.Found &&
                                r.Rule.DeduceSubfolders &&
                                !string.IsNullOrWhiteSpace(
                                    r.DeducedFolder))
                        .GroupBy(
                            r => r.DeducedFolder!,
                            StringComparer.OrdinalIgnoreCase);


            foreach (IGrouping<string, DrawingSearchRequest> group
                     in deductionGroups)
            {
                SearchGroupRecursive(
                    group.Key,
                    group.ToList(),
                    false);
            }


            // =========================================================
            // FASE 4
            //
            // FALLBACK
            //
            // IMPORTANTISSIMO:
            // viene eseguito SOLO ADESSO, dopo che TUTTA la ricerca
            // normale è terminata.
            //
            // Raggruppiamo per ROOT FISICA.
            // Quindi la stessa root viene attraversata una volta sola.
            // =========================================================

            IEnumerable<IGrouping<string, DrawingSearchRequest>>
                fallbackGroups =
                    requests
                        .Where(
                            r =>
                                !r.Result.Found &&
                                r.Rule.EnableFallback &&
                                Directory.Exists(
                                    r.Root))
                        .GroupBy(
                            r => r.Root,
                            StringComparer.OrdinalIgnoreCase);


            foreach (IGrouping<string, DrawingSearchRequest> group
                     in fallbackGroups)
            {
                SearchGroupRecursive(
                    group.Key,
                    group.ToList(),
                    true);
            }


            return results;
        }


        // =============================================================
        // RICERCA BATCH RICORSIVA
        //
        // Una cartella viene enumerata una volta per TUTTI i file
        // richiesti dal gruppo.
        // =============================================================

        private static void SearchGroupRecursive(
            string root,
            List<DrawingSearchRequest> requests,
            bool isFallback)
        {
            if (requests.Count == 0)
                return;


            Dictionary<string, List<DrawingSearchRequest>>
                pendingByFileName =
                    requests
                        .Where(
                            r => !r.Result.Found)
                        .GroupBy(
                            r => r.FileName,
                            StringComparer.OrdinalIgnoreCase)
                        .ToDictionary(
                            g => g.Key,
                            g => g.ToList(),
                            StringComparer.OrdinalIgnoreCase);


            if (pendingByFileName.Count == 0)
                return;


            SearchDirectoryRecursive(
                root,
                pendingByFileName,
                isFallback);
        }


        // =============================================================
        // ENUMERAZIONE DIRECTORY
        // =============================================================

        private static void SearchDirectoryRecursive(
            string directory,
            Dictionary<string, List<DrawingSearchRequest>>
                pendingByFileName,
            bool isFallback)
        {
            if (pendingByFileName.Count == 0)
                return;


            // =========================================================
            // FILE DELLA CARTELLA CORRENTE
            // =========================================================

            try
            {
                foreach (string file
                         in Directory.EnumerateFiles(
                             directory,
                             "*.idw",
                             SearchOption.TopDirectoryOnly))
                {
                    if (pendingByFileName.Count == 0)
                        return;


                    string fileName =
                        Path.GetFileName(file);


                    if (!pendingByFileName.TryGetValue(
                            fileName,
                            out List<DrawingSearchRequest>? matches))
                    {
                        continue;
                    }


                    foreach (DrawingSearchRequest request
                             in matches)
                    {
                        MarkFound(
                            request,
                            file,
                            isFallback);
                    }


                    pendingByFileName.Remove(
                        fileName);
                }
            }
            catch
            {
                // Cartella/file non accessibile.
                // Continuiamo con ciò che è possibile leggere.
            }


            if (pendingByFileName.Count == 0)
                return;


            // =========================================================
            // SOTTOCARTELLE
            // =========================================================

            IEnumerable<string> directories;

            try
            {
                // ToList intenzionale:
                // l'eventuale eccezione di enumerazione viene intercettata
                // qui e non durante il foreach.
                directories =
                    Directory
                        .EnumerateDirectories(
                            directory)
                        .ToList();
            }
            catch
            {
                return;
            }


            foreach (string subDirectory
                     in directories)
            {
                if (pendingByFileName.Count == 0)
                    return;


                SearchDirectoryRecursive(
                    subDirectory,
                    pendingByFileName,
                    isFallback);
            }
        }


        // =============================================================
        // MARCA RISULTATO TROVATO
        // =============================================================

        private static void MarkFound(
            DrawingSearchRequest request,
            string path,
            bool foundByFallback)
        {
            request.Result.DrawingPath =
                path;

            request.Result.Found =
                true;

            request.Result.FoundByFallback =
                foundByFallback;
        }


        // =============================================================
        // NORMALIZZAZIONE CODICE
        // =============================================================

        private static string? NormalizeCode(
            string code,
            DrawingSearchRule rule)
        {
            string normalizedCode =
                code.Trim();


            if (rule.RemoveTrailingCharacters <= 0)
                return normalizedCode;


            if (normalizedCode.Length <=
                rule.RemoveTrailingCharacters)
            {
                return null;
            }


            return normalizedCode.Substring(
                0,
                normalizedCode.Length -
                rule.RemoveTrailingCharacters);
        }


        // =============================================================
        // REGOLA PIÙ SPECIFICA
        //
        // Esempio:
        //
        // G
        // GAC
        // GACM
        //
        // GACM123 -> GACM
        // =============================================================

        private static DrawingSearchRule? FindBestRule(
            string code,
            IEnumerable<DrawingSearchRule> rules)
        {
            if (rules == null)
                return null;


            return rules
                .Where(
                    rule =>
                        rule != null &&
                        !string.IsNullOrWhiteSpace(
                            rule.CodePrefix) &&
                        code.StartsWith(
                            rule.CodePrefix.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(
                    rule =>
                        rule.CodePrefix.Trim().Length)
                .FirstOrDefault();
        }


        // =============================================================
        // DEDUZIONE DELLA PRIMA SOTTOCARTELLA
        //
        // Comportamento già esistente:
        //
        // prova progressivamente:
        // 0
        // 00
        // 001
        // ...
        //
        // Appena trova la prima cartella esistente si ferma.
        // =============================================================

        private static string? FindDeductionFolder(
            string root,
            string remainingCode)
        {
            if (string.IsNullOrWhiteSpace(
                    remainingCode))
            {
                return null;
            }


            for (int length = 1;
                 length <= remainingCode.Length;
                 length++)
            {
                string candidateName =
                    remainingCode.Substring(
                        0,
                        length);


                string candidateFolder =
                    Path.Combine(
                        root,
                        candidateName);


                if (Directory.Exists(
                        candidateFolder))
                {
                    return candidateFolder;
                }
            }


            return null;
        }


        // =============================================================
        // APERTURA IDW
        // =============================================================

        public static bool OpenDrawing(
            Inventor.Application inventorApp,
            string drawingPath)
        {
            if (inventorApp == null)
                return false;

            if (string.IsNullOrWhiteSpace(drawingPath))
                return false;

            if (!File.Exists(drawingPath))
                return false;

            return InventorService.OpenOrActivateDocumentByPath(
                inventorApp,
                drawingPath,
                out _);
        }


        // =============================================================
        // MODELLO INTERNO DI RICERCA
        // =============================================================

        private sealed class DrawingSearchRequest
        {
            public string Code { get; set; } = "";

            public string NormalizedCode { get; set; } = "";

            public string FileName { get; set; } = "";

            public string Root { get; set; } = "";

            public string? DeducedFolder { get; set; }

            public DrawingSearchRule Rule { get; set; } =
                new DrawingSearchRule();

            public ControlloTavoleDrawingResult Result { get; set; } =
                new ControlloTavoleDrawingResult();
        }
    }
}