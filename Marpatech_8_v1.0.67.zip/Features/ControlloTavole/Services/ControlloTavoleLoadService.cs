﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Marpatech_8.Features.ControlloTavole.Models;

namespace Marpatech_8.Features.ControlloTavole.Services
{
    public static class ControlloTavoleLoadService
    {
        public static async Task<ControlloTavoleLoadResult>
            LoadAsync(
                Inventor.Application inventorApp)
        {
            /*
             * ==========================================
             * INVENTOR COM
             * ==========================================
             *
             * Questa parte viene eseguita sul thread
             * chiamante.
             */
            List<ControlloTavoleItem> items =
                ControlloTavoleStructureService
                    .GetItems(inventorApp)
                    .ToList();


            List<string> codes =
                items
                    .Select(item => item.Code)
                    .Where(code =>
                        !string.IsNullOrWhiteSpace(code))
                    .Distinct(
                        System.StringComparer.OrdinalIgnoreCase)
                    .ToList();


            /*
             * ==========================================
             * FILESYSTEM / SERVER
             * ==========================================
             *
             * Da qui non utilizziamo più Inventor COM.
             */
            Dictionary<string, ControlloTavoleDrawingResult> drawings =
                await Task.Run(
                    () =>
                        ControlloTavoleDrawingService.FindDrawings(
                            codes));


            return new ControlloTavoleLoadResult
            {
                Items = items,
                Drawings = drawings
            };
        }
    }
}