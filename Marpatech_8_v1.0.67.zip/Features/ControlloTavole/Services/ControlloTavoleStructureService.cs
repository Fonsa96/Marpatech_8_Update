﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.Core.Inventor;

using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.ControlloTavole.Services
{
    public static class ControlloTavoleStructureService
    {
        public static List<ControlloTavoleItem> GetItems(
            InventorApp inventorApp)
        {
            List<ControlloTavoleItem> items =
                new List<ControlloTavoleItem>();


            ControlloTavoleSettings settings =
                ControlloTavoleSettingsService.Load();


            List<InventorService.InventorStructureItem> documents =
                InventorService.GetActiveDocumentStructure(
                    inventorApp);


            foreach (InventorService.InventorStructureItem document
                     in documents)
            {
                AddDocument(
                    document,
                    items,
                    settings.Exclusions);
            }


            return items
                .OrderBy(
                    item => GetCodeSortGroup(item.Code))
                .ThenBy(
                    item => item.Code,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }


        // =============================================================
        // AGGIUNTA DOCUMENTO
        // =============================================================

        private static void AddDocument(
            InventorService.InventorStructureItem document,
            List<ControlloTavoleItem> items,
            List<CodeExclusionRule> exclusions)
        {
            string fullPath =
                document.FullFileName ?? "";


            string fileName =
                string.IsNullOrWhiteSpace(fullPath)
                    ? document.DisplayName
                    : Path.GetFileName(fullPath);


            string code =
                Path.GetFileNameWithoutExtension(
                    fileName);


            if (string.IsNullOrWhiteSpace(code))
                return;


            if (IsCodeExcluded(
                    code,
                    exclusions))
            {
                return;
            }


            bool alreadyExists =
                items.Any(
                    item =>
                        string.Equals(
                            item.Code,
                            code,
                            StringComparison.OrdinalIgnoreCase));


            if (alreadyExists)
                return;


            items.Add(
                new ControlloTavoleItem
                {
                    Code = code,

                    SourceDocumentPath =
                        fullPath,

                    DocumentType =
                        document.DocumentType
                });
        }


        // =============================================================
        // ESCLUSIONI
        // =============================================================

        private static bool IsCodeExcluded(
            string code,
            List<CodeExclusionRule> exclusions)
        {
            if (string.IsNullOrWhiteSpace(code))
                return false;

            if (exclusions == null ||
                exclusions.Count == 0)
            {
                return false;
            }

            string normalizedCode =
                code.Trim();


            foreach (CodeExclusionRule rule
                     in exclusions)
            {
                if (rule == null)
                    continue;

                string value =
                    rule.Value?.Trim() ?? "";

                if (string.IsNullOrWhiteSpace(value))
                    continue;


                bool match =
                    rule.MatchType switch
                    {
                        CodeExclusionMatchType.StartsWith =>
                            normalizedCode.StartsWith(
                                value,
                                StringComparison.OrdinalIgnoreCase),

                        CodeExclusionMatchType.Contains =>
                            normalizedCode.IndexOf(
                                value,
                                StringComparison.OrdinalIgnoreCase) >= 0,

                        CodeExclusionMatchType.EndsWith =>
                            normalizedCode.EndsWith(
                                value,
                                StringComparison.OrdinalIgnoreCase),

                        CodeExclusionMatchType.Exact =>
                            string.Equals(
                                normalizedCode,
                                value,
                                StringComparison.OrdinalIgnoreCase),

                        _ => false
                    };


                if (match)
                    return true;
            }


            return false;
        }


        // =============================================================
        // ORDINAMENTO
        // =============================================================

        private static int GetCodeSortGroup(
            string code)
        {
            if (string.IsNullOrWhiteSpace(code))
                return 2;

            char firstCharacter =
                code.Trim()[0];

            if (char.IsLetter(firstCharacter))
                return 0;

            if (char.IsDigit(firstCharacter))
                return 1;

            return 2;
        }
    }
}