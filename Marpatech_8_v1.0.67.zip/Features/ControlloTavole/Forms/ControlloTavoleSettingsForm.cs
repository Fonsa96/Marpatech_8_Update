﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.ControlloTavole.Services;
using Marpatech_8.Features.Core.Settings;

namespace Marpatech_8.Features.ControlloTavole.Forms
{
    public class ControlloTavoleSettingsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly WindowSettings _windowSettings;

        private ControlloTavoleSettings _settings;

        private CheckBox? chkDetachedDimensions;
        private CheckBox? chkDetachedBalloons;
        private CheckBox? chkUnresolvedModelViews;
        private CheckBox? chkViewsNotUpdated;
        private CheckBox? chkSheetsWithoutViews;
        private CheckBox? chkOverlappingViews;
        private CheckBox? chkViewsOutsideSheet;

        private CheckBox? chkDetachedGeometries;

        // =============================================================
        // GRAVITÀ CONTROLLI
        // =============================================================

        private ComboBox? cmbDetachedDimensionsSeverity;
        private ComboBox? cmbDetachedBalloonsSeverity;
        private ComboBox? cmbUnresolvedModelViewsSeverity;
        private ComboBox? cmbViewsNotUpdatedSeverity;
        private ComboBox? cmbSheetsWithoutViewsSeverity;
        private ComboBox? cmbOverlappingViewsSeverity;
        private ComboBox? cmbViewsOutsideSheetSeverity;

        private ComboBox? cmbDetachedGeometriesSeverity;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryTextColor;
        private Color _inputColor;
        private Color _lineColor;


        public ControlloTavoleSettingsForm(
            bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;

            _settings =
                ControlloTavoleSettingsService.Load();

            _windowSettings =
                WindowSettingsService.Load(
                    "ControlloTavoleSettingsV2",
                    900,
                    600);

            InitializeTheme();
            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            LoadSettingsIntoUi();
        }


        // =============================================================
        // TEMA
        // =============================================================

        private void InitializeTheme()
        {
            _backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            _cardColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            _titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            _secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            _inputColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.White;

            _lineColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 85)
                    : Color.FromArgb(203, 213, 225);
        }


        // =============================================================
        // UI
        // =============================================================

        private void InitializeComponent()
        {
            Text =
                "Impostazioni - Controllo Tavole";

            StartPosition =
                FormStartPosition.CenterParent;

            Size =
                new Size(900, 1110);

            MinimumSize =
                new Size(800, 950);

            BackColor =
                _backgroundColor;

            FormClosing +=
                ControlloTavoleSettingsForm_FormClosing;


            // =========================================================
            // TITOLO
            // =========================================================

            Label title =
                new Label
                {
                    Text =
                        "Impostazioni Controllo Tavole",

                    AutoSize =
                        true,

                    Font =
                        new Font(
                            "Segoe UI",
                            22,
                            FontStyle.Bold),

                    ForeColor =
                        _titleColor,

                    Location =
                        new Point(30, 22)
                };


            Label subtitle =
                new Label
                {
                    Text =
                        "Configura i controlli e le impostazioni della funzione.",

                    AutoSize =
                        true,

                    Font =
                        new Font(
                            "Segoe UI",
                            9),

                    ForeColor =
                        _secondaryTextColor,

                    Location =
                        new Point(33, 64)
                };


            // =========================================================
            // IMPORT / EXPORT
            // =========================================================

            Button btnImport =
                CreateButton(
                    "IMPORTA CONFIGURAZIONE",
                    Color.FromArgb(22, 163, 74),
                    190,
                    38);

            btnImport.Location =
                new Point(30, 92);

            btnImport.Click +=
                BtnImport_Click;


            Button btnExport =
                CreateButton(
                    "ESPORTA CONFIGURAZIONE",
                    Color.FromArgb(234, 88, 12),
                    190,
                    38);

            btnExport.Location =
                new Point(230, 92);

            btnExport.Click +=
                BtnExport_Click;


            // =========================================================
            // CONTROLLI DA ESEGUIRE
            // =========================================================

            Panel checksCard =
                new Panel
                {
                    Location =
                        new Point(30, 150),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            560),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        _cardColor
                };


            Label checksTitle =
                CreateSectionTitle(
                    "Controlli da eseguire");

            checksTitle.Location =
                new Point(20, 15);


            chkDetachedDimensions =
                CreateCheckBox(
                    "Quote scollegate",
                    20,
                    52);


            Label dimensionsDescription =
                CreateDescription(
                    "Verifica se nella tavola sono presenti quote non più associate alla geometria.",
                    46,
                    80);


            chkDetachedBalloons =
                CreateCheckBox(
                    "Pallinature scollegate",
                    20,
                    108);


            Label balloonsDescription =
                CreateDescription(
                    "Verifica se nella tavola sono presenti pallinature non più associate al componente.",
                    46,
                    136);

            chkUnresolvedModelViews =
    CreateCheckBox(
        "Riferimenti modello / viste non risolti",
        20,
        164);


            Label unresolvedDescription =
                CreateDescription(
                    "Verifica se una vista non riesce più a risolvere correttamente il modello IPT/IAM collegato.",
                    46,
                    192);


            chkViewsNotUpdated =
                CreateCheckBox(
                    "Viste non aggiornate",
                    20,
                    220);


            Label viewsNotUpdatedDescription =
                CreateDescription(
                    "Verifica se Inventor segnala viste il cui aggiornamento non è stato completato.",
                    46,
                    248);


            chkSheetsWithoutViews =
                CreateCheckBox(
                    "Fogli senza viste",
                    20,
                    276);


            Label sheetsWithoutViewsDescription =
                CreateDescription(
                    "Verifica se nella tavola sono presenti fogli che non contengono alcuna vista.",
                    46,
                    304);


            chkOverlappingViews =
                CreateCheckBox(
                    "Viste sovrapposte",
                    20,
                    332);


            Label overlappingViewsDescription =
                CreateDescription(
                    "Verifica se due o più viste occupano aree sovrapposte sullo stesso foglio.",
                    46,
                    360);


            chkViewsOutsideSheet =
                CreateCheckBox(
                    "Viste fuori dall'area del foglio",
                    20,
                    388);


            Label viewsOutsideSheetDescription =
                CreateDescription(
                    "Verifica se una vista oltrepassa i limiti fisici del foglio.",
                    46,
                    416);


            chkDetachedGeometries =
                CreateCheckBox(
                    "Geometrie con riferimenti persi",
                    20,
                    444);

            Label detachedGeometriesDescription =
                CreateDescription(
                    "Verifica marcatori di centro e assi di mezzeria scollegati dalla geometria.",
                    46,
                    472);

            // =============================================================
            // MENU GRAVITÀ DEI SETTE CONTROLLI
            // =============================================================

            cmbDetachedDimensionsSeverity =
                CreateSeverityComboBox(50);

            cmbDetachedBalloonsSeverity =
                CreateSeverityComboBox(106);

            cmbUnresolvedModelViewsSeverity =
                CreateSeverityComboBox(162);

            cmbViewsNotUpdatedSeverity =
                CreateSeverityComboBox(218);

            cmbSheetsWithoutViewsSeverity =
                CreateSeverityComboBox(274);

            cmbOverlappingViewsSeverity =
                CreateSeverityComboBox(330);

            cmbViewsOutsideSheetSeverity =
                CreateSeverityComboBox(386);

            cmbDetachedGeometriesSeverity =
                CreateSeverityComboBox(442);


            checksCard.Controls.Add(
                checksTitle);

            checksCard.Controls.Add(
                chkDetachedDimensions);

            checksCard.Controls.Add(
                dimensionsDescription);

            checksCard.Controls.Add(
                chkDetachedBalloons);

            checksCard.Controls.Add(
                balloonsDescription);

            checksCard.Controls.Add(
                 chkUnresolvedModelViews);

            checksCard.Controls.Add(
                unresolvedDescription);

            checksCard.Controls.Add(
                chkViewsNotUpdated);

            checksCard.Controls.Add(
                viewsNotUpdatedDescription);

            checksCard.Controls.Add(
                chkSheetsWithoutViews);

            checksCard.Controls.Add(
                sheetsWithoutViewsDescription);

            checksCard.Controls.Add(
                chkOverlappingViews);

            checksCard.Controls.Add(
                overlappingViewsDescription);

            checksCard.Controls.Add(
                chkViewsOutsideSheet);

            checksCard.Controls.Add(
                viewsOutsideSheetDescription);

            checksCard.Controls.Add(
                 chkDetachedGeometries);

            checksCard.Controls.Add(
                detachedGeometriesDescription);

            // =============================================================
            // AGGIUNTA MENU GRAVITÀ ALLA SCHEDA
            // =============================================================

            checksCard.Controls.Add(cmbDetachedDimensionsSeverity);
            checksCard.Controls.Add(cmbDetachedBalloonsSeverity);
            checksCard.Controls.Add(cmbUnresolvedModelViewsSeverity);
            checksCard.Controls.Add(cmbViewsNotUpdatedSeverity);
            checksCard.Controls.Add(cmbSheetsWithoutViewsSeverity);
            checksCard.Controls.Add(cmbOverlappingViewsSeverity);
            checksCard.Controls.Add(cmbViewsOutsideSheetSeverity);
            checksCard.Controls.Add(cmbDetachedGeometriesSeverity);


            // =========================================================
            // CONFIGURAZIONE
            // =========================================================

            Panel configurationCard =
                new Panel
                {
                    // La card precedente parte a Y=150 ed è alta 220.
                    // 150 + 220 = 370.
                    // Lasciamo 15 px di spazio.
                    Location =
                        new Point(
                            30,
                            725),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            225),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        _cardColor
                };


            Label configurationTitle =
                CreateSectionTitle(
                    "Configurazione");

            configurationTitle.Location =
                new Point(
                    20,
                    15);


            // =========================================================
            // GESTISCI ESCLUSIONI
            // =========================================================

            Button btnManageExclusions =
                CreateButton(
                    "GESTISCI ESCLUSIONI",
                    Color.FromArgb(37, 99, 235),
                    300,
                    65);

            btnManageExclusions.Location =
                new Point(
                    20,
                    55);

            btnManageExclusions.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left;

            btnManageExclusions.Font =
                new Font(
                    "Segoe UI",
                    11,
                    FontStyle.Bold);

            btnManageExclusions.Click +=
                BtnManageExclusions_Click;


            // =========================================================
            // GESTISCI PERCORSI
            // =========================================================

            Button btnManagePaths =
                CreateButton(
                    "GESTISCI PERCORSI",
                    Color.FromArgb(124, 58, 237),
                    300,
                    65);

            btnManagePaths.Location =
                new Point(
                    20,
                    135);

            btnManagePaths.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left;

            btnManagePaths.Font =
                new Font(
                    "Segoe UI",
                    11,
                    FontStyle.Bold);

            btnManagePaths.Click +=
                BtnManagePaths_Click;


            // =========================================================
            // CONTROLLI CONFIGURAZIONE
            // =========================================================

            configurationCard.Controls.Add(
                configurationTitle);

            configurationCard.Controls.Add(
                btnManageExclusions);

            configurationCard.Controls.Add(
                btnManagePaths);


            // =========================================================
            // PULSANTI FINALI
            // =========================================================

            Button btnCancel =
                CreateButton(
                    "ANNULLA",
                    Color.FromArgb(100, 116, 139),
                    110,
                    38);

            btnCancel.Location =
                new Point(
                    ClientSize.Width - 265,
                    92);

            btnCancel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            btnCancel.Click +=
                BtnCancel_Click;


            Button btnSave =
                CreateButton(
                    "SALVA",
                    Color.FromArgb(22, 163, 74),
                    110,
                    38);

            btnSave.Location =
                new Point(
                    ClientSize.Width - 140,
                    92);

            btnSave.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            btnSave.Click +=
                BtnSave_Click;


            // =========================================================
            // CONTROLLI FORM
            // =========================================================

            Controls.Add(
                title);

            Controls.Add(
                subtitle);

            Controls.Add(
                btnImport);

            Controls.Add(
                btnExport);

            Controls.Add(
                checksCard);

            Controls.Add(
                configurationCard);

            Controls.Add(
                btnCancel);

            Controls.Add(
                btnSave);
        }


        // =============================================================
        // CARICAMENTO
        // =============================================================

        private void LoadSettingsIntoUi()
        {
            if (chkDetachedDimensions != null)
            {
                chkDetachedDimensions.Checked =
                    _settings.CheckDetachedDimensions;
            }

            if (chkDetachedBalloons != null)
            {
                chkDetachedBalloons.Checked =
                    _settings.CheckDetachedBalloons;
            }
            if (chkUnresolvedModelViews != null)
            {
                chkUnresolvedModelViews.Checked =
                    _settings.CheckUnresolvedModelViews;
            }

            if (chkViewsNotUpdated != null)
            {
                chkViewsNotUpdated.Checked =
                    _settings.CheckViewsNotUpdated;
            }

            if (chkSheetsWithoutViews != null)
            {
                chkSheetsWithoutViews.Checked =
                    _settings.CheckSheetsWithoutViews;
            }

            if (chkOverlappingViews != null)
            {
                chkOverlappingViews.Checked =
                    _settings.CheckOverlappingViews;
            }

            if (chkViewsOutsideSheet != null)
            {
                chkViewsOutsideSheet.Checked =
                    _settings.CheckViewsOutsideSheet;
            }

            if (chkDetachedGeometries != null)
            {
                chkDetachedGeometries.Checked =
                    _settings.CheckDetachedGeometries;
            }
            // =============================================================
            // CARICAMENTO GRAVITÀ
            // =============================================================

            if (cmbDetachedDimensionsSeverity != null)
                cmbDetachedDimensionsSeverity.SelectedIndex =
                    _settings.DetachedDimensionsSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbDetachedBalloonsSeverity != null)
                cmbDetachedBalloonsSeverity.SelectedIndex =
                    _settings.DetachedBalloonsSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbUnresolvedModelViewsSeverity != null)
                cmbUnresolvedModelViewsSeverity.SelectedIndex =
                    _settings.UnresolvedModelViewsSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbViewsNotUpdatedSeverity != null)
                cmbViewsNotUpdatedSeverity.SelectedIndex =
                    _settings.ViewsNotUpdatedSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbSheetsWithoutViewsSeverity != null)
                cmbSheetsWithoutViewsSeverity.SelectedIndex =
                    _settings.SheetsWithoutViewsSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbOverlappingViewsSeverity != null)
                cmbOverlappingViewsSeverity.SelectedIndex =
                    _settings.OverlappingViewsSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbViewsOutsideSheetSeverity != null)
                cmbViewsOutsideSheetSeverity.SelectedIndex =
                    _settings.ViewsOutsideSheetSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;

            if (cmbDetachedGeometriesSeverity != null)
                cmbDetachedGeometriesSeverity.SelectedIndex =
                    _settings.DetachedGeometriesSeverity ==
                    ControlloTavoleSeverity.Red ? 0 : 1;
        }



        // =============================================================
        // SALVA / ANNULLA
        // =============================================================

        private void BtnSave_Click(
            object? sender,
            EventArgs e)
        {
            if (chkDetachedDimensions != null)
            {
                _settings.CheckDetachedDimensions =
                    chkDetachedDimensions.Checked;
            }

            if (chkDetachedBalloons != null)
            {
                _settings.CheckDetachedBalloons =
                    chkDetachedBalloons.Checked;
            }

            if (chkUnresolvedModelViews != null)
            {
                _settings.CheckUnresolvedModelViews =
                    chkUnresolvedModelViews.Checked;
            }

            if (chkViewsNotUpdated != null)
            {
                _settings.CheckViewsNotUpdated =
                    chkViewsNotUpdated.Checked;
            }

            if (chkSheetsWithoutViews != null)
            {
                _settings.CheckSheetsWithoutViews =
                    chkSheetsWithoutViews.Checked;
            }

            if (chkOverlappingViews != null)
            {
                _settings.CheckOverlappingViews =
                    chkOverlappingViews.Checked;
            }

            if (chkViewsOutsideSheet != null)
            {
                _settings.CheckViewsOutsideSheet =
                    chkViewsOutsideSheet.Checked;
            }

            if (chkDetachedGeometries != null)
            {
                _settings.CheckDetachedGeometries =
                    chkDetachedGeometries.Checked;
            }

            // =============================================================
            // SALVATAGGIO GRAVITÀ
            // =============================================================

            if (cmbDetachedDimensionsSeverity != null)
                _settings.DetachedDimensionsSeverity =
                    cmbDetachedDimensionsSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbDetachedBalloonsSeverity != null)
                _settings.DetachedBalloonsSeverity =
                    cmbDetachedBalloonsSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbUnresolvedModelViewsSeverity != null)
                _settings.UnresolvedModelViewsSeverity =
                    cmbUnresolvedModelViewsSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbViewsNotUpdatedSeverity != null)
                _settings.ViewsNotUpdatedSeverity =
                    cmbViewsNotUpdatedSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbSheetsWithoutViewsSeverity != null)
                _settings.SheetsWithoutViewsSeverity =
                    cmbSheetsWithoutViewsSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbOverlappingViewsSeverity != null)
                _settings.OverlappingViewsSeverity =
                    cmbOverlappingViewsSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbViewsOutsideSheetSeverity != null)
                _settings.ViewsOutsideSheetSeverity =
                    cmbViewsOutsideSheetSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            if (cmbDetachedGeometriesSeverity != null)
                _settings.DetachedGeometriesSeverity =
                    cmbDetachedGeometriesSeverity.SelectedIndex == 0
                        ? ControlloTavoleSeverity.Red
                        : ControlloTavoleSeverity.Orange;

            try
            {
                ControlloTavoleSettingsService.Save(
                    _settings);

                DialogResult =
                    DialogResult.OK;

                Close();
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    "Impossibile salvare le impostazioni:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        private void BtnCancel_Click(
            object? sender,
            EventArgs e)
        {
            DialogResult =
                DialogResult.Cancel;

            Close();
        }


        // =============================================================
        // HELPERS
        // =============================================================

        // =============================================================
        // CREAZIONE MENU GRAVITÀ
        // =============================================================

        private ComboBox CreateSeverityComboBox(int y)
        {
            ComboBox combo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,

                Size = new Size(145, 30),

                Location = new Point(
                    675,
                   y),

                Font = new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold),

                BackColor = _inputColor,

                ForeColor = _titleColor,

                FlatStyle = FlatStyle.Flat,

                Anchor =
                    AnchorStyles.Top |
                    AnchorStyles.Right
            };

            combo.Items.Add("ROSSO");
            combo.Items.Add("ARANCIONE");

            combo.SelectedIndex = 0;

            return combo;
        }

        private CheckBox CreateCheckBox(
            string text,
            int x,
            int y)
        {
            return new CheckBox
            {
                Text = text,
                AutoSize = true,
                Font = new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold),
                ForeColor = _titleColor,
                Location = new Point(x, y),
                BackColor = Color.Transparent
            };
        }


        private Label CreateDescription(
            string text,
            int x,
            int y)
        {
            return new Label
            {
                Text = text,
                AutoSize = false,
                Size = new Size(
                    650,
                    20),
                Font = new Font(
                    "Segoe UI",
                    8),
                ForeColor =
                    _secondaryTextColor,
                Location =
                    new Point(x, y)
            };
        }


        private Label CreateSectionTitle(
            string text)
        {
            return new Label
            {
                Text = text,
                AutoSize = true,
                Font = new Font(
                    "Segoe UI",
                    13,
                    FontStyle.Bold),
                ForeColor = _titleColor
            };
        }


        private static Button CreateButton(
            string text,
            Color color,
            int width,
            int height)
        {
            return new Button
            {
                Text = text,
                Size = new Size(
                    width,
                    height),
                Font = new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = color,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
        }


        // =============================================================
        // CHIUSURA
        // =============================================================

        private void ControlloTavoleSettingsForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "ControlloTavoleSettingsV2");
        }
        private void BtnImport_Click(
    object? sender,
    EventArgs e)
        {
            using OpenFileDialog dialog =
                new OpenFileDialog
                {
                    Title =
                        "Importa configurazione Controllo Tavole",

                    Filter =
                        "File JSON (*.json)|*.json",

                    CheckFileExists =
                        true,

                    Multiselect =
                        false
                };

            if (dialog.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }

            try
            {
                ControlloTavoleSettings importedSettings =
                    ControlloTavoleSettingsService.Import(
                        dialog.FileName);

                _settings =
                    importedSettings;

                LoadSettingsIntoUi();

                MessageBox.Show(
                    this,
                    "Configurazione importata correttamente.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    "Impossibile importare la configurazione:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
        private void BtnExport_Click(
    object? sender,
    EventArgs e)
        {
            using SaveFileDialog dialog =
                new SaveFileDialog
                {
                    Title =
                        "Esporta configurazione Controllo Tavole",

                    Filter =
                        "File JSON (*.json)|*.json",

                    FileName =
                        "ControlloTavoleSettings.json",

                    DefaultExt =
                        "json",

                    AddExtension =
                        true,

                    OverwritePrompt =
                        true
                };

            if (dialog.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }

            try
            {
                ControlloTavoleSettingsService.Export(
                    dialog.FileName);

                MessageBox.Show(
                    this,
                    "Configurazione esportata correttamente.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    "Impossibile esportare la configurazione:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        private void BtnManageExclusions_Click(
    object? sender,
    EventArgs e)
        {
            using ControlloTavoleExclusionsForm form =
                new ControlloTavoleExclusionsForm(
                    _settings.Exclusions,
                    _isDarkTheme);

            form.ShowDialog(
                this);
        }
        private void BtnManagePaths_Click(
    object? sender,
    EventArgs e)
        {
            using ControlloTavoleDrawingPathsForm form =
                new ControlloTavoleDrawingPathsForm(
                    _settings.DrawingSearchRules,
                    _isDarkTheme);

            form.ShowDialog(
                this);
        }

    }
}