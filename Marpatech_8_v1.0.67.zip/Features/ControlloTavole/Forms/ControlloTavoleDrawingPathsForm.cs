﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.Core.Settings;

namespace Marpatech_8.Features.ControlloTavole.Forms
{
    public class ControlloTavoleDrawingPathsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly List<DrawingSearchRule> _rules;
        private readonly WindowSettings _windowSettings;

        private DataGridView? grid;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryTextColor;
        private Color _inputColor;
        private Color _lineColor;


        public ControlloTavoleDrawingPathsForm(
            List<DrawingSearchRule> rules,
            bool isDarkTheme)
        {
            _rules = rules;
            _isDarkTheme = isDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "ControlloTavoleDrawingPaths",
                    1200,
                    720);

            InitializeTheme();
            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            RefreshGrid();
        }


        // =============================================================
        // TEMA
        // =============================================================

        private void InitializeTheme()
        {
            _backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            _cardColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            _titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            _secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            _inputColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.White;

            _lineColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 85)
                    : Color.FromArgb(203, 213, 225);
        }


        // =============================================================
        // UI
        // =============================================================

        private void InitializeComponent()
        {
            Text =
                "Gestisci Percorsi Ricerca Tavole";

            StartPosition =
                FormStartPosition.CenterParent;

            Size =
                new Size(1200, 720);

            MinimumSize =
                new Size(950, 550);

            BackColor =
                _backgroundColor;

            FormClosing +=
                Form_FormClosing;


            Label title =
                new Label
                {
                    Text =
                        "Gestisci Percorsi Ricerca Tavole",

                    AutoSize =
                        true,

                    Font =
                        new Font(
                            "Segoe UI",
                            22,
                            FontStyle.Bold),

                    ForeColor =
                        _titleColor,

                    Location =
                        new Point(30, 22)
                };


            Label description =
                new Label
                {
                    Text =
                        "Configura le regole utilizzate per individuare sul server le tavole IDW.",

                    AutoSize =
                        true,

                    Font =
                        new Font(
                            "Segoe UI",
                            9),

                    ForeColor =
                        _secondaryTextColor,

                    Location =
                        new Point(33, 64)
                };


            Panel card =
                new Panel
                {
                    Location =
                        new Point(30, 100),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            ClientSize.Height - 190),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        _cardColor
                };


            grid =
                new DataGridView
                {
                    Location =
                        new Point(20, 20),

                    Size =
                        new Size(
                            card.Width - 40,
                            card.Height - 85),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right
                };


            ConfigureGrid();


            Button btnAdd =
                CreateButton(
                    "+ AGGIUNGI REGOLA",
                    Color.FromArgb(37, 99, 235),
                    170,
                    36);

            btnAdd.Location =
                new Point(
                    card.Width - 190,
                    card.Height - 55);

            btnAdd.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnAdd.Click +=
                BtnAdd_Click;


            Button btnClose =
                CreateButton(
                    "CHIUDI",
                    Color.FromArgb(22, 163, 74),
                    120,
                    38);

            btnClose.Location =
                new Point(
                    ClientSize.Width - 150,
                    ClientSize.Height - 65);

            btnClose.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnClose.Click +=
                (s, e) => Close();


            card.Controls.Add(grid);
            card.Controls.Add(btnAdd);

            Controls.Add(title);
            Controls.Add(description);
            Controls.Add(card);
            Controls.Add(btnClose);
        }


        // =============================================================
        // GRIGLIA
        // =============================================================

        private void ConfigureGrid()
        {
            if (grid == null)
                return;


            grid.AllowUserToAddRows =
                false;

            grid.AllowUserToDeleteRows =
                false;

            grid.AllowUserToResizeRows =
                false;

            grid.AllowUserToOrderColumns =
                false;

            grid.ReadOnly =
                true;

            grid.MultiSelect =
                false;

            grid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            grid.RowHeadersVisible =
                false;

            grid.BackgroundColor =
                _inputColor;

            grid.BorderStyle =
                BorderStyle.None;

            grid.GridColor =
                _lineColor;

            grid.EnableHeadersVisualStyles =
                false;

            grid.ColumnHeadersHeight =
                38;

            grid.RowTemplate.Height =
                36;


            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.FromArgb(241, 245, 249);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                _titleColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);


            grid.DefaultCellStyle.BackColor =
                _inputColor;

            grid.DefaultCellStyle.ForeColor =
                _titleColor;

            grid.DefaultCellStyle.SelectionBackColor =
                _isDarkTheme
                    ? Color.FromArgb(55, 65, 81)
                    : Color.FromArgb(219, 234, 254);

            grid.DefaultCellStyle.SelectionForeColor =
                _titleColor;

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9);


            // PREFISSO

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Prefix",
                    HeaderText = "Prefisso",
                    Width = 110,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });

            // FALLBACK

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Fallback",
                    HeaderText = "Fallback",
                    Width = 100,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });


            // DEDUZIONE

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Deduction",
                    HeaderText = "Deduzione",
                    Width = 110,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });


            // PERCORSO

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Path",
                    HeaderText = "Percorso server",
                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,
                    MinimumWidth = 300,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });


            // TAGLIA FINALI

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Trailing",
                    HeaderText = "Taglia finali",
                    Width = 110,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });


            // SU

            grid.Columns.Add(
                CreateGridButton(
                    "Up",
                    "↑",
                    50));


            // GIÙ

            grid.Columns.Add(
                CreateGridButton(
                    "Down",
                    "↓",
                    50));


            // MODIFICA

            grid.Columns.Add(
                CreateGridButton(
                    "Edit",
                    "Modifica",
                    90));


            // ELIMINA

            grid.Columns.Add(
                CreateGridButton(
                    "Delete",
                    "✕",
                    50));


            grid.CellClick +=
                Grid_CellClick;
        }


        // =============================================================
        // REFRESH
        // =============================================================

        private void RefreshGrid()
        {
            if (grid == null)
                return;

            grid.Rows.Clear();

            foreach (DrawingSearchRule rule
                     in _rules)
            {
                int rowIndex =
                    grid.Rows.Add(
                        rule.CodePrefix,
                        rule.EnableFallback ? "Sì" : "No",
                        rule.DeduceSubfolders ? "Sì" : "No",
                        rule.ServerRootPath,
                        rule.RemoveTrailingCharacters,
                        "↑",
                        "↓",
                        "Modifica",
                        "×");
            }
        }


        // =============================================================
        // CLICK GRIGLIA
        // =============================================================

        private void Grid_CellClick(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (grid == null ||
                e.RowIndex < 0 ||
                e.ColumnIndex < 0)
            {
                return;
            }


            string columnName =
                grid.Columns[e.ColumnIndex].Name;


            switch (columnName)
            {
                case "Up":

                    MoveUp(
                        e.RowIndex);

                    break;


                case "Down":

                    MoveDown(
                        e.RowIndex);

                    break;


                case "Edit":

                    EditRule(
                        e.RowIndex);

                    break;


                case "Delete":

                    DeleteRule(
                        e.RowIndex);

                    break;
            }
        }


        // =============================================================
        // AGGIUNGI
        // =============================================================

        private void BtnAdd_Click(
            object? sender,
            EventArgs e)
        {
            using DrawingSearchRuleForm form =
                new DrawingSearchRuleForm(
                    null,
                    _isDarkTheme);


            if (form.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }


            DrawingSearchRule newRule =
                form.Rule;


            if (PrefixAlreadyExists(
                    newRule.CodePrefix,
                    -1))
            {
                MessageBox.Show(
                    this,
                    "Esiste già una regola con il prefisso \"" +
                    newRule.CodePrefix +
                    "\".",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            _rules.Add(
                newRule);


            RefreshGrid();

            SelectRow(
                _rules.Count - 1);
        }


        // =============================================================
        // MODIFICA
        // =============================================================

        private void EditRule(
            int index)
        {
            if (index < 0 ||
                index >= _rules.Count)
            {
                return;
            }


            DrawingSearchRule current =
                _rules[index];


            using DrawingSearchRuleForm form =
                new DrawingSearchRuleForm(
                    current,
                    _isDarkTheme);


            if (form.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }


            DrawingSearchRule updated =
                form.Rule;


            if (PrefixAlreadyExists(
                    updated.CodePrefix,
                    index))
            {
                MessageBox.Show(
                    this,
                    "Esiste già una regola con il prefisso \"" +
                    updated.CodePrefix +
                    "\".",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            _rules[index] =
                updated;


            RefreshGrid();

            SelectRow(
                index);
        }


        // =============================================================
        // ELIMINA
        // =============================================================

        private void DeleteRule(
            int index)
        {
            if (index < 0 ||
                index >= _rules.Count)
            {
                return;
            }


            DrawingSearchRule rule =
                _rules[index];


            DialogResult result =
                MessageBox.Show(
                    this,
                    "Eliminare la regola \"" +
                    rule.CodePrefix +
                    "\"?",
                    "Controllo Tavole",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);


            if (result !=
                DialogResult.Yes)
            {
                return;
            }


            _rules.RemoveAt(
                index);


            RefreshGrid();


            if (_rules.Count > 0)
            {
                SelectRow(
                    Math.Min(
                        index,
                        _rules.Count - 1));
            }
        }


        // =============================================================
        // SPOSTA SU
        // =============================================================

        private void MoveUp(
            int index)
        {
            if (index <= 0 ||
                index >= _rules.Count)
            {
                return;
            }


            DrawingSearchRule rule =
                _rules[index];


            _rules.RemoveAt(
                index);


            _rules.Insert(
                index - 1,
                rule);


            RefreshGrid();

            SelectRow(
                index - 1);
        }


        // =============================================================
        // SPOSTA GIÙ
        // =============================================================

        private void MoveDown(
            int index)
        {
            if (index < 0 ||
                index >= _rules.Count - 1)
            {
                return;
            }


            DrawingSearchRule rule =
                _rules[index];


            _rules.RemoveAt(
                index);


            _rules.Insert(
                index + 1,
                rule);


            RefreshGrid();

            SelectRow(
                index + 1);
        }


        // =============================================================
        // DUPLICATO PREFISSO
        // =============================================================

        private bool PrefixAlreadyExists(
            string prefix,
            int ignoreIndex)
        {
            if (string.IsNullOrWhiteSpace(
                    prefix))
            {
                return false;
            }


            string normalized =
                prefix.Trim();


            return _rules
                .Where(
                    (rule, index) =>
                        index != ignoreIndex)
                .Any(
                    rule =>
                        string.Equals(
                            rule.CodePrefix?.Trim(),
                            normalized,
                            StringComparison.OrdinalIgnoreCase));
        }


        // =============================================================
        // SELEZIONE RIGA
        // =============================================================

        private void SelectRow(
            int index)
        {
            if (grid == null ||
                index < 0 ||
                index >= grid.Rows.Count)
            {
                return;
            }


            grid.ClearSelection();


            grid.Rows[index].Selected =
                true;


            grid.CurrentCell =
                grid.Rows[index].Cells["Prefix"];


            try
            {
                grid.FirstDisplayedScrollingRowIndex =
                    index;
            }
            catch
            {
                // Nessuna azione necessaria.
            }
        }


        // =============================================================
        // HELPERS UI
        // =============================================================

        private static DataGridViewButtonColumn
            CreateGridButton(
                string name,
                string text,
                int width)
        {
            return new DataGridViewButtonColumn
            {
                Name =
                    name,

                HeaderText =
                    "",

                Text =
                    text,

                UseColumnTextForButtonValue =
                    true,

                Width =
                    width,

                FlatStyle =
                    FlatStyle.Flat,

                SortMode =
                    DataGridViewColumnSortMode.NotSortable
            };
        }


        private static Button CreateButton(
            string text,
            Color color,
            int width,
            int height)
        {
            return new Button
            {
                Text =
                    text,

                Size =
                    new Size(
                        width,
                        height),

                Font =
                    new Font(
                        "Segoe UI",
                        8,
                        FontStyle.Bold),

                FlatStyle =
                    FlatStyle.Flat,

                BackColor =
                    color,

                ForeColor =
                    Color.White,

                Cursor =
                    Cursors.Hand
            };
        }


        // =============================================================
        // SALVATAGGIO POSIZIONE / DIMENSIONE
        // =============================================================

        private void Form_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "ControlloTavoleDrawingPaths");
        }
    }
}