﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Marpatech_8.Features.ControlloTavole.Models;
using System.IO;

namespace Marpatech_8.Features.ControlloTavole.Forms
{
    public sealed class DrawingSearchRuleForm : Form
    {
        private readonly TextBox txtPrefix;
        private readonly CheckBox chkDeduction;
        
        private readonly CheckBox chkFallback;

        private readonly TextBox txtPath;
        private readonly NumericUpDown numTrailing;

        public DrawingSearchRule ResultRule { get; private set; } =
            new DrawingSearchRule();

        public DrawingSearchRule Rule { get; private set; }


        public DrawingSearchRuleForm(
            DrawingSearchRule? rule,
            bool isDarkTheme)
        {
            Rule =
                rule == null
                    ? new DrawingSearchRule()
                    : new DrawingSearchRule
                    {
                        CodePrefix = rule.CodePrefix,
                        DeduceSubfolders = rule.DeduceSubfolders,
                        EnableFallback = rule.EnableFallback,
                        ServerRootPath = rule.ServerRootPath,
                        RemoveTrailingCharacters =
                            rule.RemoveTrailingCharacters
                    };

            Color background =
                isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color foreground =
                isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            BackColor = background;
            ForeColor = foreground;

            Text =
                rule == null
                    ? "Aggiungi percorso ricerca"
                    : "Modifica percorso ricerca";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox = false;
            MinimizeBox = false;

            ClientSize =
                new Size(650, 290);


            Label lblPrefix =
                CreateLabel(
                    "Iniziale / prefisso codice",
                    25,
                    25,
                    foreground);

            txtPrefix =
                new TextBox
                {
                    Location = new Point(25, 50),
                    Size = new Size(200, 27),
                    Font = new Font("Segoe UI", 10),
                    Text = Rule.CodePrefix
                };


            chkDeduction =
                new CheckBox
                {
                    Text = "Deduzione codice",
                    Location = new Point(260, 51),
                    AutoSize = true,
                    Font = new Font(
                        "Segoe UI",
                        9,
                        FontStyle.Bold),
                    ForeColor = foreground,
                    Checked = Rule.DeduceSubfolders
                };

            chkFallback =
                new CheckBox
                {
                    Text = "Ricerca Fallback",
                    Location = new Point(430, 51),
                    AutoSize = true,
                    Font = new Font(
                        "Segoe UI",
                        9,
                        FontStyle.Bold),
                    ForeColor = foreground,
                    Checked = Rule.EnableFallback
                };


            Label lblPath =
                CreateLabel(
                    "Percorso di partenza server",
                    25,
                    100,
                    foreground);

            txtPath =
                new TextBox
                {
                    Location = new Point(25, 125),
                    Size = new Size(500, 27),
                    Font = new Font("Segoe UI", 9),
                    Text = Rule.ServerRootPath
                };


            Button btnBrowse =
                new Button
                {
                    Text = "SFOGLIA",
                    Location = new Point(535, 123),
                    Size = new Size(90, 31),
                    FlatStyle = FlatStyle.Flat
                };

            btnBrowse.Click +=
                BtnBrowse_Click;


            Label lblTrailing =
                CreateLabel(
                    "Caratteri finali da rimuovere",
                    25,
                    175,
                    foreground);

            numTrailing =
                new NumericUpDown
                {
                    Location = new Point(230, 172),
                    Size = new Size(70, 27),
                    Minimum = 0,
                    Maximum = 20,
                    Value = Math.Max(
                        0,
                        Rule.RemoveTrailingCharacters)
                };


            Button btnCancel =
                new Button
                {
                    Text = "ANNULLA",
                    Location = new Point(405, 230),
                    Size = new Size(100, 36),
                    DialogResult = DialogResult.Cancel,
                    FlatStyle = FlatStyle.Flat
                };


            Button btnSave =
                new Button
                {
                    Text = "SALVA",
                    Location = new Point(520, 230),
                    Size = new Size(105, 36),
                    BackColor = Color.FromArgb(22, 163, 74),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat
                };

            btnSave.Click +=
                BtnSave_Click;


            Controls.AddRange(
                new Control[]
                {
                    lblPrefix,
                    txtPrefix,
                    chkDeduction,
                    chkFallback,
                    lblPath,
                    txtPath,
                    btnBrowse,
                    lblTrailing,
                    numTrailing,
                    btnCancel,
                    btnSave
                });

            CancelButton = btnCancel;
        }


        private static Label CreateLabel(
            string text,
            int x,
            int y,
            Color foreground)
        {
            return new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                Font = new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold),
                ForeColor = foreground
            };
        }


        private void BtnBrowse_Click(
            object? sender,
            EventArgs e)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog
                {
                    Description =
                        "Seleziona la cartella server di partenza"
                };

            if (Directory.Exists(txtPath.Text))
            {
                dialog.SelectedPath =
                    txtPath.Text;
            }

            if (dialog.ShowDialog(this) ==
                DialogResult.OK)
            {
                txtPath.Text =
                    dialog.SelectedPath;
            }
        }


        private void BtnSave_Click(
            object? sender,
            EventArgs e)
        {
            string prefix =
                txtPrefix.Text.Trim();

            string path =
                txtPath.Text.Trim();


            if (string.IsNullOrWhiteSpace(prefix))
            {
                MessageBox.Show(
                    this,
                    "Inserisci il prefisso del codice.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            if (string.IsNullOrWhiteSpace(path))
            {
                MessageBox.Show(
                    this,
                    "Inserisci il percorso server.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            Rule =
                new DrawingSearchRule
                {
                    CodePrefix = prefix,

                    DeduceSubfolders =
                        chkDeduction.Checked,

                    EnableFallback =
                        chkFallback.Checked,

                    ServerRootPath = path,

                    RemoveTrailingCharacters =
                        (int)numTrailing.Value
                };


            DialogResult =
                DialogResult.OK;

            Close();
        }
    }
}