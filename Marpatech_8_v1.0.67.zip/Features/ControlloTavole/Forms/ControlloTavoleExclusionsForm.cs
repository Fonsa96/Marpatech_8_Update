﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.Core.Settings;

namespace Marpatech_8.Features.ControlloTavole.Forms
{
    public class ControlloTavoleExclusionsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly List<CodeExclusionRule> _rules;
        private readonly WindowSettings _windowSettings;

        private DataGridView? grid;
        private ComboBox? cmbType;
        private TextBox? txtValue;
        private Button? btnAdd;
        private Button? btnCancelEdit;

        private int _editingIndex = -1;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryTextColor;
        private Color _inputColor;
        private Color _lineColor;


        public ControlloTavoleExclusionsForm(
            List<CodeExclusionRule> rules,
            bool isDarkTheme)
        {
            _rules = rules;
            _isDarkTheme = isDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "ControlloTavoleExclusions",
                    1100,
                    720);

            InitializeTheme();
            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            RefreshGrid();
        }


        private void InitializeTheme()
        {
            _backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            _cardColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            _titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            _secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            _inputColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.White;

            _lineColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 85)
                    : Color.FromArgb(203, 213, 225);
        }


        private void InitializeComponent()
        {
            Text = "Gestisci Esclusioni";

            StartPosition =
                FormStartPosition.CenterParent;

            Size =
                new Size(1100, 720);

            MinimumSize =
                new Size(850, 550);

            BackColor =
                _backgroundColor;

            FormClosing += Form_FormClosing;


            Label title =
                new Label
                {
                    Text = "Gestisci Esclusioni",
                    AutoSize = true,
                    Font = new Font(
                        "Segoe UI",
                        22,
                        FontStyle.Bold),
                    ForeColor = _titleColor,
                    Location = new Point(30, 22)
                };


            Label description =
                new Label
                {
                    Text =
                        "Configura i codici che devono essere ignorati durante il controllo.",
                    AutoSize = true,
                    Font = new Font(
                        "Segoe UI",
                        9),
                    ForeColor = _secondaryTextColor,
                    Location = new Point(33, 64)
                };


            Panel card =
                new Panel
                {
                    Location = new Point(30, 100),
                    Size = new Size(
                        ClientSize.Width - 60,
                        ClientSize.Height - 190),
                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,
                    BackColor = _cardColor
                };


            grid =
                new DataGridView
                {
                    Location = new Point(20, 20),
                    Size = new Size(
                        card.Width - 40,
                        card.Height - 95),
                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right
                };

            ConfigureGrid();


            cmbType =
                new ComboBox
                {
                    DropDownStyle =
                        ComboBoxStyle.DropDownList,

                    Location =
                        new Point(
                            20,
                            card.Height - 55),

                    Size =
                        new Size(150, 30),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left,

                    Font =
                        new Font(
                            "Segoe UI",
                            9),

                    BackColor =
                        _inputColor,

                    ForeColor =
                        _titleColor
                };


            cmbType.Items.Add("Inizia con");
            cmbType.Items.Add("Contiene");
            cmbType.Items.Add("Finisce con");
            cmbType.Items.Add("Codice esatto");

            cmbType.SelectedIndex = 0;


            txtValue =
                new TextBox
                {
                    Location =
                        new Point(
                            180,
                            card.Height - 55),

                    Size =
                        new Size(
                            card.Width - 465,
                            30),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    Font =
                        new Font(
                            "Segoe UI",
                            9),

                    BackColor =
                        _inputColor,

                    ForeColor =
                        _titleColor,

                    BorderStyle =
                        BorderStyle.FixedSingle
                };


            btnAdd =
                CreateButton(
                    "+ AGGIUNGI",
                    Color.FromArgb(37, 99, 235),
                    125,
                    30);

            btnAdd.Location =
                new Point(
                    card.Width - 275,
                    card.Height - 57);

            btnAdd.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnAdd.Click +=
                BtnAdd_Click;


            btnCancelEdit =
                CreateButton(
                    "ANNULLA",
                    Color.FromArgb(100, 116, 139),
                    110,
                    30);

            btnCancelEdit.Location =
                new Point(
                    card.Width - 140,
                    card.Height - 57);

            btnCancelEdit.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnCancelEdit.Visible =
                false;

            btnCancelEdit.Click +=
                (s, e) => ResetEditor();


            Button btnClose =
                CreateButton(
                    "CHIUDI",
                    Color.FromArgb(22, 163, 74),
                    120,
                    38);

            btnClose.Location =
                new Point(
                    ClientSize.Width - 150,
                    ClientSize.Height - 65);

            btnClose.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnClose.Click +=
                (s, e) => Close();


            card.Controls.Add(grid);
            card.Controls.Add(cmbType);
            card.Controls.Add(txtValue);
            card.Controls.Add(btnAdd);
            card.Controls.Add(btnCancelEdit);

            Controls.Add(title);
            Controls.Add(description);
            Controls.Add(card);
            Controls.Add(btnClose);
        }


        private void ConfigureGrid()
        {
            if (grid == null)
                return;


            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.AllowUserToResizeRows = false;
            grid.AllowUserToOrderColumns = false;
            grid.ReadOnly = true;
            grid.MultiSelect = false;

            grid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            grid.RowHeadersVisible = false;
            grid.BackgroundColor = _inputColor;
            grid.BorderStyle = BorderStyle.None;
            grid.GridColor = _lineColor;

            grid.EnableHeadersVisualStyles = false;

            grid.ColumnHeadersHeight = 38;
            grid.RowTemplate.Height = 36;


            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.FromArgb(241, 245, 249);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                _titleColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);


            grid.DefaultCellStyle.BackColor =
                _inputColor;

            grid.DefaultCellStyle.ForeColor =
                _titleColor;

            grid.DefaultCellStyle.SelectionBackColor =
                _isDarkTheme
                    ? Color.FromArgb(55, 65, 81)
                    : Color.FromArgb(219, 234, 254);

            grid.DefaultCellStyle.SelectionForeColor =
                _titleColor;


            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Type",
                    HeaderText = "Tipo",
                    Width = 180
                });


            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = "Value",
                    HeaderText = "Valore",
                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill
                });


            grid.Columns.Add(
                CreateGridButton(
                    "Up",
                    "↑",
                    50));


            grid.Columns.Add(
                CreateGridButton(
                    "Down",
                    "↓",
                    50));


            grid.Columns.Add(
                CreateGridButton(
                    "Edit",
                    "Modifica",
                    90));


            grid.Columns.Add(
                CreateGridButton(
                    "Delete",
                    "✕",
                    50));


            grid.CellClick +=
                Grid_CellClick;
        }


        private void RefreshGrid()
        {
            if (grid == null)
                return;

            grid.Rows.Clear();


            foreach (CodeExclusionRule rule in _rules)
            {
                grid.Rows.Add(
                    GetDisplayName(rule.MatchType),
                    rule.Value);
            }
        }


        private void Grid_CellClick(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (grid == null ||
                e.RowIndex < 0 ||
                e.ColumnIndex < 0)
            {
                return;
            }


            string column =
                grid.Columns[e.ColumnIndex].Name;


            switch (column)
            {
                case "Up":
                    MoveUp(e.RowIndex);
                    break;

                case "Down":
                    MoveDown(e.RowIndex);
                    break;

                case "Edit":
                    BeginEdit(e.RowIndex);
                    break;

                case "Delete":
                    DeleteRule(e.RowIndex);
                    break;
            }
        }


        private void MoveUp(int index)
        {
            if (index <= 0 ||
                index >= _rules.Count)
            {
                return;
            }


            CodeExclusionRule rule =
                _rules[index];

            _rules.RemoveAt(index);

            _rules.Insert(
                index - 1,
                rule);


            RefreshGrid();
            SelectRow(index - 1);
        }


        private void MoveDown(int index)
        {
            if (index < 0 ||
                index >= _rules.Count - 1)
            {
                return;
            }


            CodeExclusionRule rule =
                _rules[index];

            _rules.RemoveAt(index);

            _rules.Insert(
                index + 1,
                rule);


            RefreshGrid();
            SelectRow(index + 1);
        }


        private void SelectRow(int index)
        {
            if (grid == null ||
                index < 0 ||
                index >= grid.Rows.Count)
            {
                return;
            }

            grid.ClearSelection();

            grid.Rows[index].Selected =
                true;

            grid.CurrentCell =
                grid.Rows[index].Cells["Value"];
        }


        private void BeginEdit(int index)
        {
            if (cmbType == null ||
                txtValue == null ||
                btnAdd == null ||
                btnCancelEdit == null)
            {
                return;
            }


            if (index < 0 ||
                index >= _rules.Count)
            {
                return;
            }


            CodeExclusionRule rule =
                _rules[index];

            _editingIndex = index;


            cmbType.SelectedIndex =
                rule.MatchType switch
                {
                    CodeExclusionMatchType.StartsWith => 0,
                    CodeExclusionMatchType.Contains => 1,
                    CodeExclusionMatchType.EndsWith => 2,
                    CodeExclusionMatchType.Exact => 3,
                    _ => 0
                };


            txtValue.Text =
                rule.Value;

            btnAdd.Text =
                "SALVA MODIFICA";

            btnCancelEdit.Visible =
                true;

            txtValue.Focus();
        }


        private void BtnAdd_Click(
            object? sender,
            EventArgs e)
        {
            if (cmbType == null ||
                txtValue == null)
            {
                return;
            }


            string value =
                txtValue.Text.Trim();


            if (string.IsNullOrWhiteSpace(value))
            {
                MessageBox.Show(
                    this,
                    "Inserisci un valore.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            CodeExclusionMatchType type =
                GetSelectedType();


            bool duplicate =
                _rules
                    .Where(
                        (rule, index) =>
                            index != _editingIndex)
                    .Any(
                        rule =>
                            rule.MatchType == type &&
                            string.Equals(
                                rule.Value,
                                value,
                                StringComparison.OrdinalIgnoreCase));


            if (duplicate)
            {
                MessageBox.Show(
                    this,
                    "Questa esclusione è già presente.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            if (_editingIndex >= 0 &&
                _editingIndex < _rules.Count)
            {
                _rules[_editingIndex].MatchType =
                    type;

                _rules[_editingIndex].Value =
                    value;
            }
            else
            {
                _rules.Add(
                    new CodeExclusionRule
                    {
                        MatchType = type,
                        Value = value
                    });
            }


            RefreshGrid();
            ResetEditor();
        }


        private void DeleteRule(int index)
        {
            if (index < 0 ||
                index >= _rules.Count)
            {
                return;
            }


            DialogResult result =
                MessageBox.Show(
                    this,
                    "Eliminare l'esclusione \"" +
                    _rules[index].Value +
                    "\"?",
                    "Controllo Tavole",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);


            if (result != DialogResult.Yes)
                return;


            _rules.RemoveAt(index);

            RefreshGrid();
            ResetEditor();
        }


        private CodeExclusionMatchType GetSelectedType()
        {
            return cmbType?.SelectedIndex switch
            {
                1 => CodeExclusionMatchType.Contains,
                2 => CodeExclusionMatchType.EndsWith,
                3 => CodeExclusionMatchType.Exact,
                _ => CodeExclusionMatchType.StartsWith
            };
        }


        private static string GetDisplayName(
            CodeExclusionMatchType type)
        {
            return type switch
            {
                CodeExclusionMatchType.StartsWith =>
                    "Inizia con",

                CodeExclusionMatchType.Contains =>
                    "Contiene",

                CodeExclusionMatchType.EndsWith =>
                    "Finisce con",

                CodeExclusionMatchType.Exact =>
                    "Codice esatto",

                _ => ""
            };
        }


        private void ResetEditor()
        {
            _editingIndex = -1;

            if (cmbType != null)
                cmbType.SelectedIndex = 0;

            txtValue?.Clear();

            if (btnAdd != null)
                btnAdd.Text = "+ AGGIUNGI";

            if (btnCancelEdit != null)
                btnCancelEdit.Visible = false;
        }


        private static DataGridViewButtonColumn CreateGridButton(
            string name,
            string text,
            int width)
        {
            return new DataGridViewButtonColumn
            {
                Name = name,
                HeaderText = "",
                Text = text,
                UseColumnTextForButtonValue = true,
                Width = width,
                FlatStyle = FlatStyle.Flat,
                SortMode =
                    DataGridViewColumnSortMode.NotSortable
            };
        }


        private static Button CreateButton(
            string text,
            Color color,
            int width,
            int height)
        {
            return new Button
            {
                Text = text,
                Size = new Size(width, height),
                Font = new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                BackColor = color,
                ForeColor = Color.White,
                Cursor = Cursors.Hand
            };
        }


        private void Form_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "ControlloTavoleExclusions");
        }
    }
}