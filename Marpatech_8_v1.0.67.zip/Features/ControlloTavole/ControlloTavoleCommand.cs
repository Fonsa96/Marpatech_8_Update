﻿using Marpatech_8.Features.ControlloTavole.Forms;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Mail;
using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.ControlloTavole
{
    public static class ControlloTavoleCommand
    {
        public static void Execute(
            InventorApp inventorApp,
            FeatureOpenContext context)
        {
            /*
             * APERTURA DALLA MAIN DASHBOARD
             */
            if (context.MainDashboard != null &&
                !context.MainDashboard.IsDisposed)
            {
                FeatureNavigationService.OpenFeature(
                    context,
                    "ControlloTavole",
                    () =>
                        new ControlloTavoleDashboardForm(
                            inventorApp,
                            context.IsDarkTheme));

                return;
            }


            /*
             * APERTURA DA INVENTOR / RIBBON
             */
            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    inventorApp);


            SingleFormService.ShowSingle(
                "ControlloTavole",
                () =>
                    new ControlloTavoleDashboardForm(
                        inventorApp,
                        context.IsDarkTheme),
                owner);
        }


        public static void Execute(
            InventorApp inventorApp,
            bool isDarkTheme)
        {
            Execute(
                inventorApp,
                FeatureOpenContext.FromInventor(
                    isDarkTheme));
        }
    }
}