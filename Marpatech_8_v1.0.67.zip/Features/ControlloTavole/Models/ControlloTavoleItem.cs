﻿namespace Marpatech_8.Features.ControlloTavole.Models
{
    public sealed class ControlloTavoleItem
    {
        public string Code { get; set; } = "";

        public string SourceDocumentPath { get; set; } = "";

        public string DocumentType { get; set; } = "";
    }
}