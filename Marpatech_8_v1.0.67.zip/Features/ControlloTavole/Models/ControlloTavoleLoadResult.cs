﻿using System;
using System.Collections.Generic;

namespace Marpatech_8.Features.ControlloTavole.Models
{
    public sealed class ControlloTavoleLoadResult
    {
        public List<ControlloTavoleItem> Items { get; set; } =
            new List<ControlloTavoleItem>();

        public Dictionary<string, ControlloTavoleDrawingResult> Drawings
        { get; set; } =
            new Dictionary<string, ControlloTavoleDrawingResult>(
                StringComparer.OrdinalIgnoreCase);
    }
}