﻿using System.Collections.Generic;

namespace Marpatech_8.Features.ControlloTavole.Models
{
    public sealed class ControlloTavoleScanResult
    {
        public string DrawingPath { get; set; } = "";

        public bool Success { get; set; }

        public int DetachedDimensions { get; set; }

        public int DetachedBalloons { get; set; }

        /*
         * Numero di viste che non riescono più
         * a risolvere correttamente il modello sorgente.
         */
        public int UnresolvedModelViews { get; set; }

        public int SheetsWithoutViews { get; set; }

        public int OverlappingViews { get; set; }

        public int ViewsOutsideSheet { get; set; }

        public int ViewsNotUpdated { get; set; }

        // Geometrie e schizzi con riferimenti persi
        public int DetachedGeometries { get; set; }


        public string ErrorMessage { get; set; } = "";

        public List<string> Problems { get; set; } =
            new List<string>();


        public bool HasProblems =>
            DetachedDimensions > 0 ||
            DetachedBalloons > 0 ||
            UnresolvedModelViews > 0 ||
            ViewsNotUpdated > 0 ||
            SheetsWithoutViews > 0 ||
            OverlappingViews > 0 ||
            ViewsOutsideSheet > 0 ||
            DetachedGeometries > 0;


        public int TotalProblems =>
            DetachedDimensions +
            DetachedBalloons +
            UnresolvedModelViews +
            ViewsNotUpdated +
            SheetsWithoutViews +
            OverlappingViews +
            ViewsOutsideSheet +
            DetachedGeometries;
    }
}