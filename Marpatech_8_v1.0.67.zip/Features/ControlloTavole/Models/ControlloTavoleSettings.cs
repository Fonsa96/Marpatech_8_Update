﻿using System.Collections.Generic;

namespace Marpatech_8.Features.ControlloTavole.Models
{
    public enum ControlloTavoleSeverity
    {
        Orange = 1,
        Red = 2
    }
    public sealed class ControlloTavoleSettings
    {
        public bool CheckDetachedDimensions { get; set; } = true;

        public bool CheckDetachedBalloons { get; set; } = true;

        public bool CheckUnresolvedModelViews { get; set; } = true;

        public bool CheckViewsNotUpdated { get; set; } = true;

        public bool CheckSheetsWithoutViews { get; set; } = true;

        public bool CheckOverlappingViews { get; set; } = true;

        public bool CheckViewsOutsideSheet { get; set; } = true;

        public bool CheckDetachedGeometries { get; set; } = true;

        // =============================================================
        // GRAVITÀ DEI CONTROLLI
        // =============================================================

        public ControlloTavoleSeverity DetachedDimensionsSeverity
        { get; set; } = ControlloTavoleSeverity.Red;

        public ControlloTavoleSeverity DetachedBalloonsSeverity
        { get; set; } = ControlloTavoleSeverity.Red;

        public ControlloTavoleSeverity UnresolvedModelViewsSeverity
        { get; set; } = ControlloTavoleSeverity.Red;

        public ControlloTavoleSeverity ViewsNotUpdatedSeverity
        { get; set; } = ControlloTavoleSeverity.Orange;

        public ControlloTavoleSeverity SheetsWithoutViewsSeverity
        { get; set; } = ControlloTavoleSeverity.Orange;

        public ControlloTavoleSeverity OverlappingViewsSeverity
        { get; set; } = ControlloTavoleSeverity.Orange;

        public ControlloTavoleSeverity ViewsOutsideSheetSeverity
        { get; set; } = ControlloTavoleSeverity.Red;

        public ControlloTavoleSeverity DetachedGeometriesSeverity
        { get; set; } = ControlloTavoleSeverity.Red;

        public List<CodeExclusionRule> Exclusions { get; set; } =
            new List<CodeExclusionRule>();
        public List<DrawingSearchRule> DrawingSearchRules { get; set; } =
             new List<DrawingSearchRule>();
    }

    public sealed class CodeExclusionRule
    {
        public CodeExclusionMatchType MatchType { get; set; } =
            CodeExclusionMatchType.StartsWith;

        public string Value { get; set; } = "";
    }

    public enum CodeExclusionMatchType
    {
        StartsWith,
        Contains,
        Exact,
        EndsWith
    }

    public sealed class DrawingSearchRule
    {
        public string CodePrefix { get; set; } = "";

        public bool DeduceSubfolders { get; set; }

        public bool EnableFallback { get; set; }

        public string ServerRootPath { get; set; } = "";

        public int RemoveTrailingCharacters { get; set; }
    }
}