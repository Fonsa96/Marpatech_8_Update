﻿namespace Marpatech_8.Features.ControlloTavole.Models
{
    public sealed class ControlloTavoleDrawingResult
    {
        public string Code { get; set; } = "";

        public string ExpectedFileName { get; set; } = "";

        public string DrawingPath { get; set; } = "";

        public bool Found { get; set; }

        public bool FallbackEnabled { get; set; }

        public bool FoundByFallback { get; set; }
    }
}