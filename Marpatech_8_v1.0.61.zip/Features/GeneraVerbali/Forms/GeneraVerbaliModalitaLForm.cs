﻿using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.GeneraVerbali.Services;
using Marpatech_8.Features.Mail;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using InventorApplication = global::Inventor.Application;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliModalitaLForm : Form
    {
        private readonly InventorApplication
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        private TextBox
            _stlTextBox = null!;

        private DataGridView
            _dataGrid = null!;

        private GeneraVerbaliCheckoutPromptForm?
    _checkoutPromptForm;

        private bool
            _modalitaLProcessing;


        public GeneraVerbaliModalitaLForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliModalitaL",
                    1000,
                    700);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            BuildConfiguredColumns();

            CreateInitialRows();
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(241, 245, 249);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Text =
                "Genera Verbali - Modalità L";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    850,
                    600);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliModalitaLForm_FormClosing;

            Label stlTitleLabel =
    new Label
    {
        Text =
            "Gestione STL",

        Font =
            new Font(
                "Segoe UI",
                11F,
                FontStyle.Bold),

        ForeColor =
            textColor,

        AutoSize =
            true,

        Location =
            new Point(
                30,
                25)
    };


            /*
             * ==========================================
             * TEXTBOX STL
             * ==========================================
             */
            _stlTextBox =
                new TextBox
                {
                    PlaceholderText =
                        "Scrivi qui gli STL da gestire separandoli con una virgola",

                    Location =
                        new Point(
                            30,
                            50),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            34),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F)
                };


            /*
             * ==========================================
             * SEPARATORE SUPERIORE
             * ==========================================
             */
            Panel separatorTop =
                new Panel
                {
                    Location =
                        new Point(
                            30,
                            105),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            1),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        borderColor
                };

            Label tableTitleLabel =
    new Label
    {
        Text =
            "Tabella prodotti in Comune",

        Font =
            new Font(
                "Segoe UI",
                11F,
                FontStyle.Bold),

        ForeColor =
            textColor,

        AutoSize =
            true,

        Location =
            new Point(
                30,
                125)
    };


            /*
             * ==========================================
             * TABELLA
             * ==========================================
             */
            _dataGrid =
                new DataGridView
                {
                    Location =
                        new Point(
                            30,
                            158),

                                        Size =
                        new Size(
                            ClientSize.Width - 60,
                            ClientSize.Height - 328),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                        false,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    SelectionMode =
                        DataGridViewSelectionMode.FullRowSelect,

                    MultiSelect =
                        false,

                    BackgroundColor =
                        panelColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    GridColor =
                        borderColor,

                    EnableHeadersVisualStyles =
                        false,

                    EditMode =
                        DataGridViewEditMode.EditOnKeystrokeOrF2
                };


            /*
             * ==========================================
             * STILE CELLE
             * ==========================================
             */
            _dataGrid.DefaultCellStyle.BackColor =
                panelColor;

            _dataGrid.DefaultCellStyle.ForeColor =
                textColor;

            _dataGrid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            _dataGrid.DefaultCellStyle.SelectionForeColor =
                Color.White;

            _dataGrid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F);

            _dataGrid.DefaultCellStyle.Padding =
                new Padding(
                    4);


            _dataGrid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            _dataGrid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                _dataGrid.ColumnHeadersDefaultCellStyle.BackColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold);

            _dataGrid.ColumnHeadersHeight =
                38;

            _dataGrid.RowTemplate.Height =
                34;


            /*
             * ==========================================
             * PULSANTI GESTIONE RIGHE
             * ==========================================
             */
            Button addRowButton =
                CreateSecondaryButton(
                    "Aggiungi riga",
                    30,
                    ClientSize.Height - 150,
                    125,
                    secondaryColor,
                    textColor,
                    borderColor);

            addRowButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            addRowButton.Click +=
                AddRowButton_Click;


            Button removeRowButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    165,
                    ClientSize.Height - 150,
                    95,
                    secondaryColor,
                    textColor,
                    borderColor);

            removeRowButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            removeRowButton.Click +=
                RemoveRowButton_Click;


            Button moveUpButton =
                CreateSecondaryButton(
                    "▲",
                    270,
                    ClientSize.Height - 150,
                    45,
                    secondaryColor,
                    textColor,
                    borderColor);

            moveUpButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            moveUpButton.Click +=
                MoveUpButton_Click;


            Button moveDownButton =
                CreateSecondaryButton(
                    "▼",
                    325,
                    ClientSize.Height - 150,
                    45,
                    secondaryColor,
                    textColor,
                    borderColor);

            moveDownButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            moveDownButton.Click +=
                MoveDownButton_Click;


            /*
             * ==========================================
             * SEPARATORE INFERIORE
             * ==========================================
             */
            Panel separatorBottom =
                new Panel
                {
                    Location =
                        new Point(
                            30,
                            ClientSize.Height - 100),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            1),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        borderColor
                };


            /*
             * ==========================================
             * AVVIA FUNZIONE
             * ==========================================
             */
            Button startButton =
                new Button
                {
                    Text =
                        "Avvia Funzione",

                    Location =
                        new Point(
                            30,
                            ClientSize.Height - 76),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            46),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            22,
                            163,
                            74),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            startButton.FlatAppearance.BorderSize =
                0;

            startButton.Click +=
                StartButton_Click;


            Controls.Add(
                stlTitleLabel);

            Controls.Add(
                _stlTextBox);

            Controls.Add(
                separatorTop);

            Controls.Add(
                tableTitleLabel);

            Controls.Add(
                _dataGrid);

            Controls.Add(
                addRowButton);

            Controls.Add(
                removeRowButton);

            Controls.Add(
                moveUpButton);

            Controls.Add(
                moveDownButton);

            Controls.Add(
                separatorBottom);

            Controls.Add(
                startButton);
        }


        private Button CreateSecondaryButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor,
            Color borderColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            button.FlatAppearance.BorderColor =
                borderColor;

            return button;
        }


        /*
         * ==========================================
         * COLONNE DA IMPOSTAZIONI
         * ==========================================
         */
        private void BuildConfiguredColumns()
        {
            _dataGrid.Columns.Clear();


            var settings =
                GeneraVerbaliSettingsService.Load();


            List<string> columns =
                settings.ModalitaL?.Columns
                ?? new List<string>();


            foreach (string columnName in columns)
            {
                if (string.IsNullOrWhiteSpace(
                    columnName))
                {
                    continue;
                }


                DataGridViewTextBoxColumn column =
                    new DataGridViewTextBoxColumn
                    {
                        HeaderText =
                            columnName,

                        Name =
                            Guid.NewGuid().ToString(),

                        SortMode =
                            DataGridViewColumnSortMode.NotSortable,

                        AutoSizeMode =
                            DataGridViewAutoSizeColumnMode.Fill
                    };


                _dataGrid.Columns.Add(
                    column);
            }
        }


        /*
         * ==========================================
         * 5 RIGHE INIZIALI
         * ==========================================
         */
        private void CreateInitialRows()
        {
            if (_dataGrid.Columns.Count == 0)
                return;


            for (int i = 0;
                 i < 5;
                 i++)
            {
                _dataGrid.Rows.Add();
            }
        }


        /*
         * ==========================================
         * AGGIUNGI
         * ==========================================
         */
        private void AddRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.Columns.Count == 0)
                return;


            int rowIndex =
                _dataGrid.Rows.Add();


            _dataGrid.ClearSelection();

            _dataGrid.Rows[rowIndex]
                .Selected =
                true;


            if (_dataGrid.Columns.Count > 0)
            {
                _dataGrid.CurrentCell =
                    _dataGrid.Rows[rowIndex]
                        .Cells[0];

                _dataGrid.BeginEdit(
                    true);
            }
        }


        /*
         * ==========================================
         * RIMUOVI
         * ==========================================
         */
        private void RemoveRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int index =
                _dataGrid.CurrentRow.Index;


            if (index < 0 ||
                index >= _dataGrid.Rows.Count)
            {
                return;
            }


            _dataGrid.Rows.RemoveAt(
                index);
        }


        /*
         * ==========================================
         * SPOSTA SU
         * ==========================================
         */
        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int currentIndex =
                _dataGrid.CurrentRow.Index;


            if (currentIndex <= 0)
                return;


            SwapRows(
                currentIndex,
                currentIndex - 1);
        }


        /*
         * ==========================================
         * SPOSTA GIÙ
         * ==========================================
         */
        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int currentIndex =
                _dataGrid.CurrentRow.Index;


            if (currentIndex < 0 ||
                currentIndex >=
                _dataGrid.Rows.Count - 1)
            {
                return;
            }


            SwapRows(
                currentIndex,
                currentIndex + 1);
        }


        /*
         * ==========================================
         * SCAMBIA CONTENUTO RIGHE
         * ==========================================
         */
        private void SwapRows(
            int sourceIndex,
            int destinationIndex)
        {
            _dataGrid.EndEdit();


            object?[] sourceValues =
                new object?[
                    _dataGrid.Columns.Count];


            object?[] destinationValues =
                new object?[
                    _dataGrid.Columns.Count];


            for (int columnIndex = 0;
                 columnIndex < _dataGrid.Columns.Count;
                 columnIndex++)
            {
                sourceValues[columnIndex] =
                    _dataGrid.Rows[sourceIndex]
                        .Cells[columnIndex]
                        .Value;

                destinationValues[columnIndex] =
                    _dataGrid.Rows[destinationIndex]
                        .Cells[columnIndex]
                        .Value;
            }


            for (int columnIndex = 0;
                 columnIndex < _dataGrid.Columns.Count;
                 columnIndex++)
            {
                _dataGrid.Rows[destinationIndex]
                    .Cells[columnIndex]
                    .Value =
                    sourceValues[columnIndex];

                _dataGrid.Rows[sourceIndex]
                    .Cells[columnIndex]
                    .Value =
                    destinationValues[columnIndex];
            }


            _dataGrid.ClearSelection();

            _dataGrid.Rows[destinationIndex]
                .Selected =
                true;

            _dataGrid.CurrentCell =
                _dataGrid.Rows[destinationIndex]
                    .Cells[0];
        }


        /*
         * ==========================================
         * AVVIA FUNZIONE
         * ==========================================
         */
        private void StartButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_modalitaLProcessing)
                return;


            /*
             * Evitiamo più popup contemporaneamente.
             */
            if (_checkoutPromptForm != null &&
                !_checkoutPromptForm.IsDisposed)
            {
                _checkoutPromptForm.Show();

                _checkoutPromptForm.BringToFront();

                _checkoutPromptForm.Activate();

                return;
            }


            _checkoutPromptForm =
                new GeneraVerbaliCheckoutPromptForm(
                    _isDarkTheme);


            _checkoutPromptForm.Confirmed +=
                CheckoutPromptForm_Confirmed;


            _checkoutPromptForm.FormClosed +=
                (_, _) =>
                {
                    _checkoutPromptForm =
                        null;
                };


            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);


            /*
             * Show, NON ShowDialog.
             *
             * Inventor rimane completamente utilizzabile.
             */
            _checkoutPromptForm.Show(
                owner);
        }


        /*
         * ==========================================
         * WINDOW SETTINGS
         * ==========================================
         */
        private void GeneraVerbaliModalitaLForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "GeneraVerbaliModalitaL");
        }
        private void CheckoutPromptForm_Confirmed(
    object? sender,
    EventArgs e)
        {
            if (_modalitaLProcessing)
                return;


            /*
             * Prima di tutto deve esserci
             * un assieme aperto in Inventor.
             */
            if (!InventorService.IsActiveDocumentAssembly(
                _inventorApp))
            {
                MessageBox.Show(
                    this,
                    "Apri un assieme in Inventor prima di avviare la funzione.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Leggiamo la lista richiesta:
             *
             * STL123, STL234, STL567
             */
            List<string> requestedCodes =
                GeneraVerbaliModalitaLService.ParseStlCodes(
                    _stlTextBox.Text);


            if (requestedCodes.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Inserisci almeno un codice STL nella prima casella.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Costruiamo il contenuto della Custom iProperty
             * DATI_COLLAUDO_PRODOTTI.
             */
            string productsData =
                GeneraVerbaliModalitaLService.BuildProductsData(
                    _dataGrid);


            try
            {
                _modalitaLProcessing =
                    true;

                List<InventorService.InventorCustomCodeMatch>
                    foundAssemblies =
                        InventorService
                            .FindAssembliesByCustomCode(
                                _inventorApp,
                                requestedCodes,
                                "CODICE");


                HashSet<string> foundCodes =
    foundAssemblies
        .Select(item =>
            item.Code)
        .ToHashSet(
            StringComparer.OrdinalIgnoreCase);


                List<string> missingCodes =
                    requestedCodes
                        .Where(code =>
                            !foundCodes.Contains(code))
                        .ToList();


                if (missingCodes.Count > 0)
                {
                    string missingText =
                        string.Join(
                            "\r\n",
                            missingCodes.Select(
                                code =>
                                    "• " + code));


                    MessageBox.Show(
                        this,
                        "La Modalità L non può essere avviata perché " +
                        "i seguenti STL non sono stati trovati " +
                        "nell'assieme aperto:\r\n\r\n" +
                        missingText +
                        "\r\n\r\n" +
                        "Nessun STL è stato modificato.",
                        "Genera Verbali - Modalità L",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                /*
                 * Prima controlliamo se qualche STL trovato
                 * risulta non modificabile.
                 */
                List<InventorService.InventorCustomCodeMatch>
                    notModifiableAssemblies =
                        foundAssemblies
                            .Where(item =>
                                !item.IsModifiable)
                            .ToList();


                if (notModifiableAssemblies.Count > 0)
                {
                    string blockedCodes =
                        string.Join(
                            "\r\n",
                            notModifiableAssemblies.Select(
                                item =>
                                    "• " + item.Code));


                    MessageBox.Show(
                        this,
                        "La funzione non può essere avviata perché " +
                        "i seguenti STL risultano in sola lettura:\r\n\r\n" +
                        blockedCodes +
                        "\r\n\r\n" +
                        "Assicurati che tutti gli STL siano in check-out " +
                        "e riprova." +
                        "\r\n\r\n" +
                        "Nessun STL è stato modificato.",
                        "Genera Verbali - Modalità L",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                /*
                 * Nessun file in sola lettura:
                 * possiamo scrivere su TUTTI.
                 */
                bool writeSucceeded =
                    InventorService
                        .WriteCustomPropertyToMatchedDocuments(
                            _inventorApp,
                            foundAssemblies,
                            "DATI_COLLAUDO_PRODOTTI",
                            productsData,
                            out string writeError);


                if (!writeSucceeded)
                {
                    MessageBox.Show(
                        this,
                        writeError,
                        "Genera Verbali - Modalità L",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);

                    return;
                }


                HandleModalitaLScanResult(
                    requestedCodes,
                    foundAssemblies);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Si è verificato un errore durante " +
                    "la scansione dell'assieme.\r\n\r\n" +
                    ex.Message,
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                _modalitaLProcessing =
                    false;
            }
        }
        private void HandleModalitaLScanResult(
            List<string> requestedCodes,
            List<InventorService.InventorCustomCodeMatch>
                foundAssemblies)
        {
            HashSet<string> foundCodes =
                foundAssemblies
                    .Select(item =>
                        item.Code)
                    .ToHashSet(
                        StringComparer.OrdinalIgnoreCase);

            List<string> missingCodes =
                requestedCodes
                    .Where(code =>
                        !foundCodes.Contains(code))
                    .ToList();

            List<InventorService.InventorCustomCodeMatch>
                updatedAssemblies =
                    foundAssemblies
                        .Where(item =>
                            item.UpdatedSuccessfully)
                        .ToList();

            List<InventorService.InventorCustomCodeMatch>
                failedAssemblies =
                    foundAssemblies
                        .Where(item =>
                            !item.UpdatedSuccessfully)
                        .ToList();


            /*
             * Nessun codice trovato.
             */
            if (foundAssemblies.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Nessuno degli STL indicati è stato trovato " +
                    "nell'assieme aperto.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Prepariamo un unico resoconto.
             */
            List<string> messageLines =
                new List<string>();


            if (updatedAssemblies.Count > 0)
            {
                messageLines.Add(
                    "STL aggiornati correttamente: " +
                    updatedAssemblies.Count);

                foreach (
                    InventorService.InventorCustomCodeMatch item
                    in updatedAssemblies)
                {
                    messageLines.Add(
                        "  ✓ " + item.Code);
                }
            }


            if (failedAssemblies.Count > 0)
            {
                if (messageLines.Count > 0)
                    messageLines.Add(string.Empty);

                messageLines.Add(
                    "STL trovati ma NON aggiornati: " +
                    failedAssemblies.Count);

                foreach (
                    InventorService.InventorCustomCodeMatch item
                    in failedAssemblies)
                {
                    messageLines.Add(
                        "  ✕ " + item.Code);
                }

                messageLines.Add(string.Empty);

                messageLines.Add(
                    "Verifica che questi file siano in check-out " +
                    "e modificabili.");
            }


            if (missingCodes.Count > 0)
            {
                if (messageLines.Count > 0)
                    messageLines.Add(string.Empty);

                messageLines.Add(
                    "STL non trovati nell'assieme:");

                foreach (string code
                    in missingCodes)
                {
                    messageLines.Add(
                        "  - " + code);
                }
            }


            string message =
                string.Join(
                    "\r\n",
                    messageLines);


            MessageBoxIcon icon =
                failedAssemblies.Count > 0 ||
                missingCodes.Count > 0
                    ? MessageBoxIcon.Warning
                    : MessageBoxIcon.Information;


            MessageBox.Show(
                this,
                message,
                "Genera Verbali - Modalità L",
                MessageBoxButtons.OK,
                icon);
        }
    }
}