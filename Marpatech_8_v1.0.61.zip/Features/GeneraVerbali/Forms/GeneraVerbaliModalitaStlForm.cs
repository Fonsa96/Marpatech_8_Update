﻿using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.GeneraVerbali.Models;
using Marpatech_8.Features.GeneraVerbali.Services;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

using InventorApplication = global::Inventor.Application;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliModalitaStlForm : Form
    {
        private readonly InventorApplication
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        private FlowLayoutPanel
            _contentFlow = null!;

        private FlowLayoutPanel
            _dynamicPropertiesFlow = null!;


        private TextBox
            _motoriduttoreTextBox = null!;

        private TextBox
            _ruotaTextBox = null!;

        private TextBox
            _velocitaTextBox = null!;


        private DataGridView
            _productsGrid = null!;


        private GeneraVerbaliSettingsModel
            _settings = new GeneraVerbaliSettingsModel();

        public bool CloseWholeFeature { get; private set; }


        public GeneraVerbaliModalitaStlForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliModalitaSTL",
                    1100,
                    820);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            LoadConfiguration();
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(42, 44, 50)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(185, 190, 200)
                    : Color.FromArgb(100, 116, 139);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Text =
                "Genera Verbali - Modalità STL";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    900,
                    700);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliModalitaStlForm_FormClosing;


            /*
             * ==========================================
             * ROOT
             * ==========================================
             */
            TableLayoutPanel rootLayout =
                new TableLayoutPanel
                {
                    Dock =
                        DockStyle.Fill,

                    RowCount =
                        2,

                    ColumnCount =
                        1,

                    Padding =
                        new Padding(
                            0),

                    Margin =
                        new Padding(
                            0),

                    BackColor =
                        backgroundColor
                };

            rootLayout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100F));

            rootLayout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    145F));


            /*
             * ==========================================
             * CONTENUTO SCORREVOLE
             * ==========================================
             */
            _contentFlow =
                new FlowLayoutPanel
                {
                    Dock =
                        DockStyle.Fill,

                    AutoScroll =
                        true,

                    FlowDirection =
                        FlowDirection.TopDown,

                    WrapContents =
                        false,

                    Padding =
                        new Padding(
                            28,
                            24,
                            28,
                            24),

                    BackColor =
                        backgroundColor
                };

            _contentFlow.Resize +=
                ContentFlow_Resize;

            /*
             * ==========================================
             * CALCOLO VELOCITÀ NASTRO
             * ==========================================
             */
            Panel speedSection =
                new Panel
                {
                    Height =
                        190,

                    BackColor =
                        panelColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            18)
                };


            Label speedTitle =
                CreateSectionTitle(
                    "Calcolo Velocità Nastro",
                    20,
                    18,
                    textColor);


            /*
             * ==========================================
             * MOTORIDUTTORE
             * ==========================================
             */
            _motoriduttoreTextBox =
                CreateInputTextBox(
                    20,
                    60,
                    125,
                    inputColor,
                    textColor);


            Button selectMotoriduttoreButton =
                CreateActionButton(
                    "Selezione Motoriduttore",
                    155,
                    59,
                    190,
                    Color.FromArgb(
                        126,
                        34,
                        206));

            selectMotoriduttoreButton.Click +=
                SelectMotoriduttoreButton_Click;


            /*
             * ==========================================
             * RUOTA
             * ==========================================
             */
            _ruotaTextBox =
                CreateInputTextBox(
                    20,
                    115,
                    125,
                    inputColor,
                    textColor);


            Button selectRuotaButton =
                CreateActionButton(
                    "Seleziona Ruota",
                    155,
                    114,
                    190,
                    Color.FromArgb(
                        234,
                        179,
                        8));

            selectRuotaButton.Click +=
                SelectRuotaButton_Click;


            /*
             * ==========================================
             * GRAFFA
             * ==========================================
             *
             * La graffa raggruppa Motoriduttore + Ruota.
             *
             * Non viene disegnata alcuna linea orizzontale.
             */
            Label calculationBraceLabel =
                new Label
                {
                    Text =
                        "}",

                    Location =
                        new Point(
                            360,
                            48),

                    Size =
                        new Size(
                            55,
                            110),

                    AutoSize =
                        false,

                    TextAlign =
                        ContentAlignment.MiddleCenter,

                    Font =
                        new Font(
                            "Segoe UI",
                            58F,
                            FontStyle.Regular),

                    ForeColor =
                        textColor,

                    BackColor =
                        Color.Transparent
                };


            /*
             * ==========================================
             * VELOCITÀ
             * ==========================================
             *
             * Il centro verticale della TextBox viene
             * posizionato in corrispondenza del centro
             * della graffa.
             */
            Label speedResultLabel =
                new Label
                {
                    Text =
                        "Velocità nastro",

                    Font =
                        new Font(
                            "Segoe UI",
                            9.5F,
                            FontStyle.Bold),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            430,
                            72)
                };


            _velocitaTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            430,
                            96),

                    Size =
                        new Size(
                            125,
                            31),

                    AutoSize =
                        false,

                    BackColor =
                        _isDarkTheme
                            ? Color.FromArgb(
                                37,
                                54,
                                70)
                            : Color.FromArgb(
                                239,
                                246,
                                255),

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold)
                };


            Button calculateSpeedButton =
                CreateActionButton(
                    "Calcola Velocità",
                    570,
                    95,
                    165,
                    Color.FromArgb(
                        14,
                        165,
                        233));

            calculateSpeedButton.Click +=
                CalculateSpeedButton_Click;


            /*
             * ==========================================
             * AGGIUNTA CONTROLLI
             * ==========================================
             */
            speedSection.Controls.Add(
                speedTitle);

            speedSection.Controls.Add(
                _motoriduttoreTextBox);

            speedSection.Controls.Add(
                selectMotoriduttoreButton);

            speedSection.Controls.Add(
                _ruotaTextBox);

            speedSection.Controls.Add(
                selectRuotaButton);

            speedSection.Controls.Add(
                calculationBraceLabel);

            speedSection.Controls.Add(
                speedResultLabel);

            speedSection.Controls.Add(
                _velocitaTextBox);

            speedSection.Controls.Add(
                calculateSpeedButton);


            /*
             * ==========================================
             * SEPARATORE
             * ==========================================
             */
            Panel separator1 =
                CreateSeparator(
                    borderColor);


            /*
             * ==========================================
             * COMPOSIZIONE VERBALE
             * ==========================================
             */
            Panel propertiesSection =
                new Panel
                {
                    Height =
                        200,

                    BackColor =
                        backgroundColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            10)
                };


            Label propertiesTitle =
                CreateSectionTitle(
                    "Composizione Verbale di Collaudo",
                    0,
                    8,
                    textColor);


            Button refreshPropertiesButton =
                new Button
                {
                    Text =
                        "⟳",

                    Size =
                        new Size(
                            42,
                            36),

                    /*
                     * Subito dopo il titolo.
                     */
                    Location =
                        new Point(
                            310,
                            0),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            15F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            refreshPropertiesButton.FlatAppearance.BorderSize =
                0;

            refreshPropertiesButton.Click +=
                RefreshPropertiesButton_Click;


            refreshPropertiesButton.FlatAppearance.BorderColor =
                borderColor;

            refreshPropertiesButton.Click +=
                RefreshPropertiesButton_Click;


            _dynamicPropertiesFlow =
                new FlowLayoutPanel
                {
                    Location =
                        new Point(
                            0,
                            58),

                    Size =
                        new Size(
                            propertiesSection.Width,
                            120),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlowDirection =
                        FlowDirection.TopDown,

                    WrapContents =
                        false,

                    AutoScroll =
                        false,

                    BackColor =
                        backgroundColor,

                    Padding =
                        new Padding(
                            0),

                    Margin =
                        new Padding(
                            0)
                };


            propertiesSection.Controls.Add(
                propertiesTitle);

            propertiesSection.Controls.Add(
                refreshPropertiesButton);

            propertiesSection.Controls.Add(
                _dynamicPropertiesFlow);


            /*
             * ==========================================
             * TABELLA PRODOTTI
             * ==========================================
             */
            Panel tableSection =
                new Panel
                {
                    Height =
                        330,

                    BackColor =
                        backgroundColor,

                    Margin =
                        new Padding(
                            0,
                            0,
                            0,
                            18)
                };


            _productsGrid =
                new DataGridView
                {
                    Location =
                        new Point(
                            0,
                            0),

                    Size =
                        new Size(
                            tableSection.Width,
                            265),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                        false,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    MultiSelect =
                        false,

                    SelectionMode =
                        DataGridViewSelectionMode.FullRowSelect,

                    BackgroundColor =
                        panelColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    GridColor =
                        borderColor,

                    EnableHeadersVisualStyles =
                        false,

                    EditMode =
                        DataGridViewEditMode.EditOnKeystrokeOrF2
                };


            ConfigureGridStyle(
                _productsGrid,
                panelColor,
                inputColor,
                textColor,
                borderColor);


            Button addRowButton =
                CreateSecondaryButton(
                    "Aggiungi riga",
                    0,
                    282,
                    125,
                    panelColor,
                    textColor,
                    borderColor);

            addRowButton.Click +=
                AddRowButton_Click;


            Button removeRowButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    135,
                    282,
                    95,
                    panelColor,
                    textColor,
                    borderColor);

            removeRowButton.Click +=
                RemoveRowButton_Click;


            Button moveUpButton =
                CreateSecondaryButton(
                    "▲",
                    240,
                    282,
                    45,
                    panelColor,
                    textColor,
                    borderColor);

            moveUpButton.Click +=
                MoveUpButton_Click;


            Button moveDownButton =
                CreateSecondaryButton(
                    "▼",
                    295,
                    282,
                    45,
                    panelColor,
                    textColor,
                    borderColor);

            moveDownButton.Click +=
                MoveDownButton_Click;


            tableSection.Controls.Add(
                _productsGrid);

            tableSection.Controls.Add(
                addRowButton);

            tableSection.Controls.Add(
                removeRowButton);

            tableSection.Controls.Add(
                moveUpButton);

            tableSection.Controls.Add(
                moveDownButton);


            /*
             * ==========================================
             * SEPARATORE FINALE
             * ==========================================
             */
            Panel separator2 =
                CreateSeparator(
                    borderColor);


            /*
             * ==========================================
             * GENERA VERBALE
             * ==========================================
             */
            Panel generatePanel =
                new Panel
                {
                    Dock =
                        DockStyle.Fill,

                    Padding =
                        new Padding(
                            28,
                            14,
                            28,
                            18),

                    BackColor =
                        backgroundColor
                };


            Button generateButton =
                new Button
                {
                    Text =
                        "GENERA VERBALE",

                    Dock =
                        DockStyle.Fill,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            22,
                            163,
                            74),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            13F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            generateButton.FlatAppearance.BorderSize =
                0;

            generateButton.Click +=
                GenerateButton_Click;


            generatePanel.Controls.Add(
                generateButton);


            /*
             * ==========================================
             * COMPOSIZIONE FINALE
             * ==========================================
             */
            _contentFlow.Controls.Add(
                speedSection);

            _contentFlow.Controls.Add(
                separator1);

            _contentFlow.Controls.Add(
                propertiesSection);

            _contentFlow.Controls.Add(
                tableSection);

            _contentFlow.Controls.Add(
                separator2);


            rootLayout.Controls.Add(
                _contentFlow,
                0,
                0);

            rootLayout.Controls.Add(
                generatePanel,
                0,
                1);


            Controls.Add(
                rootLayout);
        }


        /*
         * ==========================================
         * CONFIGURAZIONE DAL JSON
         * ==========================================
         */
        private void LoadConfiguration()
        {
            _settings =
                GeneraVerbaliSettingsService.Load();

            BuildDynamicProperties();

            BuildProductColumns();

            CreateInitialRows();

            ResizeDynamicSections();
        }


        /*
         * ==========================================
         * PROPRIETÀ DINAMICHE
         * ==========================================
         */
        private void BuildDynamicProperties()
        {
            _dynamicPropertiesFlow.Controls.Clear();


            if (_settings.ModalitaSTL?.Properties == null)
                return;


            foreach (GeneraVerbaliStlPropertySetting property in
                _settings.ModalitaSTL.Properties)
            {
                Panel propertyPanel =
                    new Panel
                    {
                        Height =
                            72,

                        Width =
                            Math.Max(
                                300,
                                _dynamicPropertiesFlow.ClientSize.Width - 5),

                        Margin =
                            new Padding(
                                0,
                                0,
                                0,
                                10)
                    };


                Label titleLabel =
                    new Label
                    {
                        Text =
                            property.TextBoxName,

                        Font =
                            new Font(
                                "Segoe UI",
                                9.5F,
                                FontStyle.Bold),

                        ForeColor =
                            _isDarkTheme
                                ? Color.White
                                : Color.FromArgb(15, 23, 42),

                        AutoSize =
                            true,

                        Location =
                            new Point(
                                0,
                                0)
                    };


                TextBox valueTextBox =
                    new TextBox
                    {
                        Location =
                            new Point(
                                0,
                                28),

                        Size =
                            new Size(
                                300,
                                30),

                        Anchor =
                            AnchorStyles.Top |
                            AnchorStyles.Left,

                        BackColor =
                            _isDarkTheme
                                ? Color.FromArgb(42, 44, 50)
                                : Color.White,

                        ForeColor =
                            _isDarkTheme
                                ? Color.White
                                : Color.FromArgb(15, 23, 42),

                        BorderStyle =
                            BorderStyle.FixedSingle,

                        Font =
                            new Font(
                                "Segoe UI",
                                9.5F),

                        /*
                         * Se NON è proprietà Inventor,
                         * il testo configurato viene già mostrato.
                         *
                         * Se è proprietà Inventor, la lettura
                         * effettiva verrà implementata dopo.
                         */
                        Text =
                            property.IsInventorProperty
                                ? string.Empty
                                : property.TextBoxText,

                        Tag =
                            property
                    };


                propertyPanel.Controls.Add(
                    titleLabel);

                propertyPanel.Controls.Add(
                    valueTextBox);


                _dynamicPropertiesFlow.Controls.Add(
                    propertyPanel);
            }
        }


        /*
         * ==========================================
         * COLONNE TABELLA DAL JSON
         * ==========================================
         */
        private void BuildProductColumns()
        {
            _productsGrid.Columns.Clear();


            if (_settings.ModalitaSTL?.FormColumns == null)
                return;


            foreach (GeneraVerbaliStlFormColumnSetting configuredColumn in
                _settings.ModalitaSTL.FormColumns)
            {
                if (string.IsNullOrWhiteSpace(
                    configuredColumn.Name))
                {
                    continue;
                }


                DataGridViewTextBoxColumn column =
                    new DataGridViewTextBoxColumn
                    {
                        Name =
                            Guid.NewGuid().ToString(),

                        HeaderText =
                            configuredColumn.Name,

                        AutoSizeMode =
                            DataGridViewAutoSizeColumnMode.Fill,

                        SortMode =
                            DataGridViewColumnSortMode.NotSortable,

                        Tag =
                            configuredColumn
                    };


                _productsGrid.Columns.Add(
                    column);
            }
        }


        /*
         * ==========================================
         * 5 RIGHE INIZIALI
         * ==========================================
         */
        private void CreateInitialRows()
        {
            if (_productsGrid.Columns.Count == 0)
                return;


            for (int i = 0;
                 i < 5;
                 i++)
            {
                _productsGrid.Rows.Add();
            }
        }


        /*
         * ==========================================
         * RIDIMENSIONAMENTO
         * ==========================================
         */
        private void ContentFlow_Resize(
            object? sender,
            EventArgs e)
        {
            ResizeDynamicSections();
        }


        private void ResizeDynamicSections()
        {
            int availableWidth =
                Math.Max(
                    600,
                    _contentFlow.ClientSize.Width -
                    _contentFlow.Padding.Left -
                    _contentFlow.Padding.Right -
                    24);


            foreach (Control control in
                _contentFlow.Controls)
            {
                control.Width =
                    availableWidth;
            }


            /*
             * Proprietà dinamiche.
             */
            foreach (Control control in
                _dynamicPropertiesFlow.Controls)
            {
                control.Width =
                    Math.Max(
                        300,
                        _dynamicPropertiesFlow.ClientSize.Width - 5);
            }


            Control? propertiesSection =
                _dynamicPropertiesFlow.Parent;

            if (propertiesSection != null)
            {
                int propertiesHeight =
                    Math.Max(
                        80,
                        _dynamicPropertiesFlow.Controls.Count * 82);


                _dynamicPropertiesFlow.Height =
                    propertiesHeight;


                propertiesSection.Height =
                    70 +
                    propertiesHeight;
            }
        }


        /*
         * ==========================================
         * HELPER UI
         * ==========================================
         */
        private Label CreateSectionTitle(
            string text,
            int x,
            int y,
            Color textColor)
        {
            return new Label
            {
                Text =
                    text,

                Location =
                    new Point(
                        x,
                        y),

                AutoSize =
                    true,

                ForeColor =
                    textColor,

                Font =
                    new Font(
                        "Segoe UI",
                        12F,
                        FontStyle.Bold)
            };
        }


        private TextBox CreateInputTextBox(
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor)
        {
            return new TextBox
            {
                Location =
                    new Point(
                        x,
                        y),

                Size =
                    new Size(
                        width,
                        31),

                AutoSize =
                    false,

                BackColor =
                    backgroundColor,

                ForeColor =
                    textColor,

                BorderStyle =
                    BorderStyle.FixedSingle,

                Font =
                    new Font(
                        "Segoe UI",
                        9.5F)
            };
        }


        private Button CreateActionButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            31),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };


            button.FlatAppearance.BorderSize =
                0;


            return button;
        }


        private Panel CreateSeparator(
            Color borderColor)
        {
            return new Panel
            {
                Height =
                    1,

                Margin =
                    new Padding(
                        0,
                        0,
                        0,
                        18),

                BackColor =
                    borderColor
            };
        }


        private Button CreateSecondaryButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor,
            Color borderColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };


            button.FlatAppearance.BorderColor =
                borderColor;


            return button;
        }


        private void ConfigureGridStyle(
            DataGridView grid,
            Color backgroundColor,
            Color cellColor,
            Color textColor,
            Color borderColor)
        {
            grid.DefaultCellStyle.BackColor =
                cellColor;

            grid.DefaultCellStyle.ForeColor =
                textColor;

            grid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            grid.DefaultCellStyle.SelectionForeColor =
                Color.White;

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F);

            grid.DefaultCellStyle.Padding =
                new Padding(
                    4);


            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                grid.ColumnHeadersDefaultCellStyle.BackColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold);

            grid.ColumnHeadersHeight =
                38;

            grid.RowTemplate.Height =
                34;
        }


        /*
         * ==========================================
         * GESTIONE RIGHE
         * ==========================================
         */
        private void AddRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.Columns.Count == 0)
                return;


            int rowIndex =
                _productsGrid.Rows.Add();


            _productsGrid.ClearSelection();

            _productsGrid.Rows[rowIndex]
                .Selected =
                true;


            _productsGrid.CurrentCell =
                _productsGrid.Rows[rowIndex]
                    .Cells[0];

            _productsGrid.BeginEdit(
                true);
        }


        private void RemoveRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int index =
                _productsGrid.CurrentRow.Index;


            if (index < 0 ||
                index >= _productsGrid.Rows.Count)
            {
                return;
            }


            _productsGrid.Rows.RemoveAt(
                index);
        }


        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int currentIndex =
                _productsGrid.CurrentRow.Index;


            if (currentIndex <= 0)
                return;


            SwapRows(
                currentIndex,
                currentIndex - 1);
        }


        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_productsGrid.CurrentRow == null)
                return;


            int currentIndex =
                _productsGrid.CurrentRow.Index;


            if (currentIndex < 0 ||
                currentIndex >=
                _productsGrid.Rows.Count - 1)
            {
                return;
            }


            SwapRows(
                currentIndex,
                currentIndex + 1);
        }


        private void SwapRows(
            int sourceIndex,
            int destinationIndex)
        {
            _productsGrid.EndEdit();


            object?[] sourceValues =
                new object?[
                    _productsGrid.Columns.Count];

            object?[] destinationValues =
                new object?[
                    _productsGrid.Columns.Count];


            for (int columnIndex = 0;
                 columnIndex < _productsGrid.Columns.Count;
                 columnIndex++)
            {
                sourceValues[columnIndex] =
                    _productsGrid.Rows[sourceIndex]
                        .Cells[columnIndex]
                        .Value;

                destinationValues[columnIndex] =
                    _productsGrid.Rows[destinationIndex]
                        .Cells[columnIndex]
                        .Value;
            }


            for (int columnIndex = 0;
                 columnIndex < _productsGrid.Columns.Count;
                 columnIndex++)
            {
                _productsGrid.Rows[destinationIndex]
                    .Cells[columnIndex]
                    .Value =
                    sourceValues[columnIndex];

                _productsGrid.Rows[sourceIndex]
                    .Cells[columnIndex]
                    .Value =
                    destinationValues[columnIndex];
            }


            _productsGrid.ClearSelection();

            _productsGrid.Rows[destinationIndex]
                .Selected =
                true;

            _productsGrid.CurrentCell =
                _productsGrid.Rows[destinationIndex]
                    .Cells[0];
        }


        /*
         * ==========================================
         * EVENTI - LOGICA SUCCESSIVA
         * ==========================================
         */
        private void SelectMotoriduttoreButton_Click(
            object? sender,
            EventArgs e)
        {
            // Implementazione successiva.
        }


        private void SelectRuotaButton_Click(
            object? sender,
            EventArgs e)
        {
            // Implementazione successiva.
        }


        private void CalculateSpeedButton_Click(
            object? sender,
            EventArgs e)
        {
            // Implementazione successiva.
        }


        private void RefreshPropertiesButton_Click(
            object? sender,
            EventArgs e)
        {
            // In seguito rileggerà:
            // - proprietà Inventor configurate
            // - VELOCITÀ MT_MIN
        }


        private void GenerateButton_Click(
            object? sender,
            EventArgs e)
        {
            // Implementazione successiva.
        }


        /*
         * ==========================================
         * WINDOW SETTINGS
         * ==========================================
         */
        private void GeneraVerbaliModalitaStlForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            /*
             * Il popup viene mostrato solo quando
             * è l'utente a chiudere il Form STL.
             */
            if (e.CloseReason ==
                CloseReason.UserClosing)
            {
                using GeneraVerbaliStlCloseDialog dialog =
                    new GeneraVerbaliStlCloseDialog(
                        _isDarkTheme);


                DialogResult result =
                    dialog.ShowDialog(
                        this);


                /*
                 * Se l'utente chiude il popup con X
                 * non chiudiamo il Form STL.
                 */
                if (result !=
                    DialogResult.OK)
                {
                    e.Cancel =
                        true;

                    return;
                }


                CloseWholeFeature =
                    dialog.CloseWholeFeature;
            }


            WindowSettingsService.Save(
                this,
                "GeneraVerbaliModalitaSTL");
        }
    }
}