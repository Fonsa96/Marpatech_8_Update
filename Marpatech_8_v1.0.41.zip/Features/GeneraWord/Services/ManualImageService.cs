﻿using System;
using System.IO;
using Inventor;
using Marpatech_8.Features.GeneraWord.Forms;
using IOPath = System.IO.Path;
using IOFile = System.IO.File;
using System.Threading.Tasks;
using Marpatech_8.Features.MainDashboard.Services;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualImageService
    {
        private static string TempFolder
        {
            get
            {
                return TempFileService.GetTempFolder(
                    "GeneraWord");
            }
        }

        public static async Task<string> PrepareAndSaveCurrentViewAsync(
    Inventor.Application inventorApp,
    bool isDarkTheme,
    IWin32Window? owner)
        {

            CleanTempFolder();

            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            PositionImageForm form = new PositionImageForm(isDarkTheme);

            form.FormClosed += (s, e) =>
            {
                tcs.TrySetResult(form.ImageCaptured);
            };

            form.Show(owner);
            form.Activate();

            bool captured = await tcs.Task;

            form.Dispose();
            System.Windows.Forms.Application.DoEvents();

            if (!captured)
                throw new OperationCanceledException(
                    "Generazione manuale annullata dall'utente.");

            string imagePath = IOPath.Combine(
                TempFolder,
                "InventorView.png");

            try
            {
                inventorApp.Visible = true;

                if (inventorApp.MainFrameHWND != 0)
                {
                    NativeWindowHelper.BringWindowToFront(
                        new IntPtr(inventorApp.MainFrameHWND));
                }

                System.Windows.Forms.Application.DoEvents();
                await Task.Delay(300);
            }
            catch
            {
            }

            inventorApp.ActiveView.SaveAsBitmap(
                imagePath,
                1920,
                1080);

            if (!IOFile.Exists(imagePath))
                throw new Exception("Immagine Inventor non creata:\n" + imagePath);

            FileInfo imageInfo = new FileInfo(imagePath);

            if (imageInfo.Length == 0)
                throw new Exception("Immagine Inventor creata ma vuota:\n" + imagePath);

            return imagePath;
        }

        public static void CleanTempFolder()
        {
            if (!Directory.Exists(TempFolder))
                return;

            foreach (string file in Directory.GetFiles(TempFolder))
            {
                try
                {
                    IOFile.Delete(file);
                }
                catch
                {
                }
            }
        }
    }
}