﻿using System;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.MainDashboard.Services
{
    public static class NativeWindowHelper
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        private const int SW_RESTORE = 9;

        public static void BringWindowToFront(IntPtr handle)
        {
            if (handle == IntPtr.Zero)
                return;

            ShowWindow(handle, SW_RESTORE);
            SetForegroundWindow(handle);
        }
    }
}