﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class SheetMetalPdfProcessor
    {
        [DllImport(
            "shell32.dll",
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern IntPtr ShellExecute(
            IntPtr hwnd,
            string lpOperation,
            string lpFile,
            string? lpParameters,
            string? lpDirectory,
            int nShowCmd);

        public bool Process(
            IWin32Window owner,
            StampaCartellineDashboardSession session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * Se la sezione PDF è disattivata
             * nella sessione, viene saltata.
             */
            if (!session.SheetMetalPdfs
                    .IncludeInPrintProcess)
            {
                return true;
            }

            string resolvedPath =
                session.SheetMetalPdfs
                    .ResolvedPath
                    ?.Trim()
                ?? string.Empty;

            /*
             * Se il percorso della sessione è vuoto
             * o non esiste, saltiamo il blocco.
             *
             * La scelta manuale del percorso viene
             * già gestita dalla Dashboard.
             */
            if (string.IsNullOrWhiteSpace(
                    resolvedPath) ||
                !Directory.Exists(
                    resolvedPath))
            {
                MessageBox.Show(
                    owner,
                    "Il percorso PDF della sessione non è valido.\n\n" +
                    "Il blocco Stampa PDF verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return true;
            }

            string? pdfDirectory =
                ResolvePdfDirectory(
                    owner,
                    resolvedPath);

            /*
             * L'utente ha scelto No quando
             * Lamiera/Lamiere non era presente.
             */
            if (string.IsNullOrWhiteSpace(
                    pdfDirectory))
            {
                return true;
            }

            List<string> pdfFiles =
                FindPdfFiles(
                    pdfDirectory);

            if (pdfFiles.Count == 0)
            {
                MessageBox.Show(
                    owner,
                    "Nessun file PDF trovato nella cartella:\n\n" +
                    pdfDirectory,
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return true;
            }

            try
            {
                PrintPdfFiles(
                    owner,
                    pdfFiles);
            }
            finally
            {
                CloseAllAcrobatProcesses();
            }

            return true;

        }

        private static string?
            ResolvePdfDirectory(
                IWin32Window owner,
                string resolvedPath)
        {
            string? lamieraDirectory =
                FindSheetMetalDirectory(
                    resolvedPath);

            if (!string.IsNullOrWhiteSpace(
                    lamieraDirectory))
            {
                return lamieraDirectory;
            }

            DialogResult result =
                MessageBox.Show(
                    owner,
                    "Cartella Lamiere non trovata.\n\n" +
                    "Stampare i PDF nella cartella selezionata al percorso:\n\n" +
                    resolvedPath +
                    "\n\n" +
                    "ATTENZIONE: SE CLICCHI SÌ VERRANNO STAMPATI " +
                    "TUTTI I PDF TROVATI ALL'INTERNO DI QUEL PERCORSO " +
                    "(MA NON NELLE SOTTOCARTELLE).",
                    "Stampa PDF",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
            {
                return null;
            }

            return resolvedPath;
        }

        private static string?
            FindSheetMetalDirectory(
                string rootDirectory)
        {
            try
            {
                if (!Directory.Exists(
                        rootDirectory))
                {
                    return null;
                }

                /*
                 * Se il percorso selezionato è già
                 * una cartella che contiene la parola
                 * "Lamiere" oppure "Lamiera",
                 * usiamo direttamente questa.
                 */
                string rootFolderName =
                    Path.GetFileName(
                        rootDirectory.TrimEnd(
                            Path.DirectorySeparatorChar,
                            Path.AltDirectorySeparatorChar));

                if (ContainsSheetMetalWord(
                        rootFolderName))
                {
                    return rootDirectory;
                }

                /*
                 * Altrimenti controlliamo soltanto
                 * le cartelle immediatamente contenute
                 * nel percorso selezionato.
                 *
                 * NON facciamo ricerca ricorsiva.
                 */
                string[] directories =
                    Directory.GetDirectories(
                        rootDirectory);

                /*
                 * Prima priorità:
                 * nome cartella contenente "Lamiere".
                 */
                string? lamiere =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiere",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                if (!string.IsNullOrWhiteSpace(
                        lamiere))
                {
                    return lamiere;
                }

                /*
                 * Seconda priorità:
                 * nome cartella contenente "Lamiera".
                 */
                string? lamiera =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiera",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                return lamiera;
            }
            catch
            {
                return null;
            }
        }

        private static bool ContainsSheetMetalWord(
            string folderName)
        {
            if (string.IsNullOrWhiteSpace(
                    folderName))
            {
                return false;
            }

            return
                folderName.IndexOf(
                    "Lamiere",
                    StringComparison.OrdinalIgnoreCase) >= 0
                ||
                folderName.IndexOf(
                    "Lamiera",
                    StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static List<string>
            FindPdfFiles(
                string directory)
        {
            try
            {
                /*
                 * IMPORTANTE:
                 * processiamo solo ed esclusivamente
                 * i PDF presenti al primo livello.
                 *
                 * Le sottocartelle vengono ignorate.
                 */
                return Directory
                    .EnumerateFiles(
                        directory,
                        "*.pdf",
                        SearchOption.TopDirectoryOnly)
                    .OrderBy(
                        filePath =>
                            filePath,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        private static void PrintPdfFiles(
            IWin32Window owner,
            IEnumerable<string> pdfFiles)
        {
            foreach (string filePath
                in pdfFiles)
            {
                PrintSinglePdf(
                    owner,
                    filePath);
            }

            /*
             * Importante:
             * dopo l'ultimo PDF lasciamo a Reader
             * il tempo di completare l'invio allo spooler
             * prima che il finally chiuda Acrobat.
             */
            WaitSeconds(
                5);
        }

        private static void PrintSinglePdf(
            IWin32Window owner,
            string filePath)
        {
            try
            {
                /*
                 * IDENTICO alla VBA:
                 *
                 * ret = ShellExecute(
                 *     0,
                 *     "print",
                 *     file.path,
                 *     vbNullString,
                 *     vbNullString,
                 *     0)
                 */
                IntPtr result =
                    ShellExecute(
                        IntPtr.Zero,
                        "print",
                        filePath,
                        null,
                        null,
                        0);

                System.Windows.Forms.Application
                    .DoEvents();

                /*
                 * Nella VBA:
                 *
                 * If ret <= 32 Then
                 *     AttendiSecondi(2)
                 *     ret = ShellExecute(...)
                 *     DoEvents
                 * End If
                 */
                if (result.ToInt64() <= 32)
                {
                    WaitSeconds(
                        2);

                    result =
                        ShellExecute(
                            IntPtr.Zero,
                            "print",
                            filePath,
                            null,
                            null,
                            0);

                    System.Windows.Forms.Application
                        .DoEvents();

                    if (result.ToInt64() <= 32)
                    {
                        MessageBox.Show(
                            owner,
                            "Errore stampa PDF:\n\n" +
                            filePath +
                            "\n\nCodice: " +
                            result.ToInt64(),
                            "Stampa PDF",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }

                /*
                 * IDENTICO alla VBA:
                 *
                 * Call AttendiSecondi(3)
                 *
                 * Viene eseguito anche dopo il retry,
                 * prima di passare al PDF successivo.
                 */
                WaitSeconds(
                    3);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Errore stampa PDF:\n\n" +
                    filePath +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl file verrà saltato.",
                    "Stampa PDF",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                /*
                 * Anche in caso di eccezione su un file
                 * non interrompiamo la lista.
                 *
                 * PrintPdfFiles passerà al PDF successivo.
                 */
            }
        }

        private static void WaitSeconds(
            int seconds)
        {
            /*
             * Replica di AttendiSecondi della VBA:
             *
             * Do While Now < fine
             *     DoEvents
             * Loop
             *
             * Sleep(20) evita di saturare la CPU,
             * lasciando comunque viva la UI WinForms.
             */
            DateTime endTime =
                DateTime.Now.AddSeconds(
                    seconds);

            while (DateTime.Now < endTime)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }
        }

        private static void KillProcessByName(
            string processName)
        {
            try
            {
                System.Diagnostics.Process[] processes =
                    System.Diagnostics.Process.GetProcessesByName(
                        processName);

                foreach (System.Diagnostics.Process process
                    in processes)
                {
                    try
                    {
                        process.Kill();

                        process.WaitForExit(
                            5000);
                    }
                    catch
                    {
                    }
                    finally
                    {
                        process.Dispose();
                    }
                }
            }
            catch
            {
            }
        }

        private static void CloseAllAcrobatProcesses()
        {
            /*
             * Traduzione diretta di:
             *
             * taskkill /IM AcroRd32.exe /F
             * taskkill /IM Acrobat.exe /F
             */
            KillProcessByName(
                "AcroRd32");

            KillProcessByName(
                "Acrobat");
        }
    }
}