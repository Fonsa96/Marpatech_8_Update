﻿using System.Windows.Forms;
using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services;

public class StampaCartellineProcessRunner
{
    private readonly Inventor.Application _inventorApp;

    private readonly DashboardInventorPropertyWriter
    _propertyWriter;

    private readonly WordTemplateProcessor
    _wordTemplateProcessor;

    private readonly ExcelDrawingsProcessor
    _excelDrawingsProcessor;

    private readonly SheetMetalPdfProcessor
    _sheetMetalPdfProcessor;

    private readonly AssemblyGroupsProcessor
    _assemblyGroupsProcessor;

    public StampaCartellineProcessRunner(
        Inventor.Application inventorApp)
    {
        _inventorApp = inventorApp;

        _propertyWriter =
            new DashboardInventorPropertyWriter(
                inventorApp);

        _wordTemplateProcessor =
            new WordTemplateProcessor();

        _excelDrawingsProcessor =
            new ExcelDrawingsProcessor();

        _sheetMetalPdfProcessor =
            new SheetMetalPdfProcessor();

        _assemblyGroupsProcessor =
            new AssemblyGroupsProcessor(
                inventorApp);
    }

    public void Run(
        IWin32Window owner,
        PrintFolderConfiguration configuration,
        StampaCartellineDashboardSession session)
    {
        if (!ValidateInventorProperties(
                owner,
                session))
        {
            return;
        }

        if (!WriteModifiedInventorProperties(
                owner,
                session))
        {
            return;
        }

        if (!_wordTemplateProcessor.Process(
                owner,
                configuration,
                session))
        {
            return;
        }
        if (!_excelDrawingsProcessor.Process(
                owner,
                session))
        {
            return;
        }
        if (!_sheetMetalPdfProcessor.Process(
                owner,
                session))
        {
            return;
        }
        if (!_assemblyGroupsProcessor.Process(
        owner,
        configuration,
        session))
        {
            return;
        }
    }

    private bool ValidateInventorProperties(
    IWin32Window owner,
    StampaCartellineDashboardSession session)
    {
        bool missingProperties =
            session.InventorProperties.Any(
                p => string.IsNullOrWhiteSpace(
                    p.Value));

        if (!missingProperties)
            return true;

        MessageBox.Show(
            owner,
            "Attenzione proprietà di Inventor mancanti.",
            "Stampa Cartelline",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);

        return false;
    }
    private bool WriteModifiedInventorProperties(
        IWin32Window owner,
        StampaCartellineDashboardSession session)
        {
            List<DashboardPropertySession> modifiedProperties =
                session.InventorProperties
                    .Where(p =>
                        !string.Equals(
                            p.Value?.Trim(),
                            p.OriginalValue?.Trim(),
                            StringComparison.Ordinal))
                    .ToList();

            if (modifiedProperties.Count == 0)
                return true;

            DialogResult result =
                MessageBox.Show(
                    owner,
                    "Stiamo per scrivere le proprietà modificate in Inventor.\n\n" +
                    "Assicurati prima di premere OK di avere l'assieme in Check-Out.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Information);

            if (result != DialogResult.OK)
                return false;

            bool written =
                _propertyWriter.WriteProperties(
                    modifiedProperties);

            if (written)
                return true;

            MessageBox.Show(
                owner,
                "Non è stato possibile scrivere una o più proprietà in Inventor.",
                "Stampa Cartelline",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);

            return false;
        }
}