﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupCollector
    {
        public List<AssemblyGroupRuntimeItem> CollectMethod1(
            AssemblyDocument mainAssembly,
            IEnumerable<string> configuredPrefixes)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            List<string> prefixes =
                configuredPrefixes
                    ?.Select(
                        value =>
                            value?.Trim()
                            ?? string.Empty)
                    .Where(
                        value =>
                            !string.IsNullOrWhiteSpace(
                                value))
                    .Distinct(
                        StringComparer.OrdinalIgnoreCase)
                    .ToList()
                ?? new List<string>();

            if (prefixes.Count == 0)
            {
                return new List<AssemblyGroupRuntimeItem>();
            }

            Dictionary<string, AssemblyGroupRuntimeItem>
                itemsByAssemblyPath =
                    new Dictionary<string, AssemblyGroupRuntimeItem>(
                        StringComparer.OrdinalIgnoreCase);

            CollectOccurrencesRecursive(
                mainAssembly.ComponentDefinition.Occurrences,
                prefixes,
                itemsByAssemblyPath);

            return itemsByAssemblyPath
                .Values
                .OrderBy(
                    item =>
                        item.Code,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private static void CollectOccurrencesRecursive(
            ComponentOccurrences occurrences,
            IReadOnlyCollection<string> prefixes,
            IDictionary<string, AssemblyGroupRuntimeItem>
                itemsByAssemblyPath)
        {
            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                try
                {
                    Document? referencedDocument =
                        GetReferencedDocument(
                            occurrence);

                    if (referencedDocument == null)
                    {
                        continue;
                    }

                    /*
                     * Il Metodo 1 considera solamente
                     * documenti di assieme.
                     */
                    if (referencedDocument.DocumentType !=
                        DocumentTypeEnum.kAssemblyDocumentObject)
                    {
                        continue;
                    }

                    string assemblyPath =
                        referencedDocument.FullFileName
                            ?.Trim()
                        ?? string.Empty;

                    string code =
                        ReadCustomProperty(
                            referencedDocument,
                            "CODICE");

                    if (MatchesAnyPrefix(
                            code,
                            prefixes) &&
                        !string.IsNullOrWhiteSpace(
                            assemblyPath))
                    {
                        string normalizedPath =
                            NormalizePath(
                                assemblyPath);

                        /*
                         * VITALE:
                         * lo stesso IAM viene memorizzato
                         * e processato una sola volta,
                         * anche se compare in molte occorrenze.
                         */
                        if (!itemsByAssemblyPath.ContainsKey(
                                normalizedPath))
                        {
                            string drawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO");

                            itemsByAssemblyPath.Add(
                                normalizedPath,
                                new AssemblyGroupRuntimeItem
                                {
                                    Code =
                                        code,

                                    DrawingName =
                                        drawingName,

                                    AssemblyPath =
                                        assemblyPath
                                });
                        }
                    }

                    /*
                     * Se è un sottoassieme, continuiamo
                     * a scendere a qualsiasi profondità.
                     */
                    ComponentOccurrences? childOccurrences =
                        TryGetChildOccurrences(
                            occurrence);

                    if (childOccurrences != null)
                    {
                        CollectOccurrencesRecursive(
                            childOccurrences,
                            prefixes,
                            itemsByAssemblyPath);
                    }
                }
                catch
                {
                    /*
                     * Un singolo componente problematico
                     * non deve interrompere la scansione
                     * dell'intero assieme.
                     */
                }
            }
        }

        private static Document? GetReferencedDocument(
            ComponentOccurrence occurrence)
        {
            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject as Document;
            }
            catch
            {
                return null;
            }
        }

        private static ComponentOccurrences?
            TryGetChildOccurrences(
                ComponentOccurrence occurrence)
        {
            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }

            return null;
        }

        private static bool MatchesAnyPrefix(
            string code,
            IEnumerable<string> prefixes)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return false;
            }

            string normalizedCode =
                code.Trim();

            foreach (string prefix
                in prefixes)
            {
                if (normalizedCode.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static string ReadCustomProperty(
            Document document,
            string propertyName)
        {
            try
            {
                /*
                 * Inventor usa normalmente questo
                 * PropertySet per le Custom iProperties.
                 */
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }

        private static string NormalizePath(
            string path)
        {
            try
            {
                return IOPath
                    .GetFullPath(
                        path)
                    .TrimEnd(
                        IOPath.DirectorySeparatorChar,
                        IOPath.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }
    }
}