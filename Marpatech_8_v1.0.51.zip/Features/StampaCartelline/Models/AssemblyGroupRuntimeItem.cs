﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class AssemblyGroupRuntimeItem
    {
        public string Code
        {
            get;
            set;
        } = string.Empty;

        public string DrawingName
        {
            get;
            set;
        } = string.Empty;

        public string AssemblyPath
        {
            get;
            set;
        } = string.Empty;
    }
}