﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class AssemblyGroupsConfiguration
    {
        public bool IncludeInPrintProcess
        {
            get;
            set;
        }

        public bool Method1Enabled
        {
            get;
            set;
        }

        public List<string> Method1Rows
        {
            get;
            set;
        } =
            new List<string>();

        public bool Method2Enabled
        {
            get;
            set;
        }

        public List<string> Method2Rows
        {
            get;
            set;
        } =
            new List<string>();

        public List<AssemblyGroupDefinition>
            Groups
        {
            get;
            set;
        } =
            new List<AssemblyGroupDefinition>();
    }

    public class AssemblyGroupDefinition
    {
        public string Name
        {
            get;
            set;
        } = string.Empty;
    }
}