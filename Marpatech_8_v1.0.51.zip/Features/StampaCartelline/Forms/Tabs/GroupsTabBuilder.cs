﻿using Marpatech_8.Features.StampaCartelline.Managers;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class GroupsTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            EditorContext context)
        {
            DrawingColor backgroundColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        32,
                        34,
                        40)
                    : DrawingColor.White;

            DrawingColor titleColor =
                isDarkTheme
                    ? DrawingColor.White
                    : DrawingColor.FromArgb(
                        30,
                        41,
                        59);

            DrawingColor subtitleColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        170,
                        178,
                        190)
                    : DrawingColor.FromArgb(
                        100,
                        116,
                        139);

            DrawingColor inputBackgroundColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        43,
                        46,
                        55)
                    : DrawingColor.White;

            DrawingColor borderColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        70,
                        75,
                        85)
                    : DrawingColor.FromArgb(
                        203,
                        213,
                        225);

            DrawingColor primaryButtonColor =
                DrawingColor.FromArgb(
                    37,
                    99,
                    235);

            DrawingColor deleteButtonColor =
                DrawingColor.FromArgb(
                    220,
                    38,
                    38);


            TabPage page =
                new TabPage();

            page.Text =
                "Gruppi di montaggio";

            page.BackColor =
                backgroundColor;

            page.AutoScroll =
                true;


            /*
             * TITOLO
             */
            Label title =
                new Label();

            title.Text =
                "Gruppi di montaggio";

            title.Font =
                new DrawingFont(
                    "Segoe UI",
                    16,
                    DrawingFontStyle.Bold);

            title.ForeColor =
                titleColor;

            title.AutoSize =
                true;

            title.Left =
                25;

            title.Top =
                25;


            /*
             * DESCRIZIONE
             */
            Label description =
                new Label();

            description.Text =
                "Configura il metodo utilizzato per la stampa dei gruppi di montaggio.";

            description.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Regular);

            description.ForeColor =
                subtitleColor;

            description.AutoSize =
                true;

            description.Left =
                27;

            description.Top =
                70;


            /*
             * INCLUDI NEL PROCESSO DI STAMPA
             */
            CheckBox chkIncludeInPrint =
                context.GroupsIncludeInPrint;

            chkIncludeInPrint.Text =
                "Includi nel processo di stampa";

            chkIncludeInPrint.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkIncludeInPrint.AutoSize =
                true;

            chkIncludeInPrint.Left =
                30;

            chkIncludeInPrint.Top =
                120;

            chkIncludeInPrint.ForeColor =
                titleColor;

            chkIncludeInPrint.BackColor =
                backgroundColor;


            /*
             * ==================================================
             * METODO 1
             * ==================================================
             */
            CheckBox chkMethod1 =
                context.GroupsMethod1Enabled;

            chkMethod1.Text =
                "Metodo 1: Stampa gruppi di montaggio";

            chkMethod1.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkMethod1.AutoSize =
                true;

            chkMethod1.Left =
                30;

            chkMethod1.Top =
                175;

            chkMethod1.ForeColor =
                titleColor;

            chkMethod1.BackColor =
                backgroundColor;


            Label method1Description =
                new Label();

            method1Description.Text =
                "Testi utilizzati per individuare gli assiemi da processare con il Metodo 1.";

            method1Description.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method1Description.ForeColor =
                subtitleColor;

            method1Description.AutoSize =
                true;

            method1Description.Left =
                50;

            method1Description.Top =
                210;


            ListBox method1List =
                context.GroupsMethod1List;

            method1List.Left =
                50;

            method1List.Top =
                240;

            method1List.Width =
                610;

            method1List.Height =
                135;

            method1List.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method1List.BackColor =
                inputBackgroundColor;

            method1List.ForeColor =
                titleColor;

            method1List.BorderStyle =
                BorderStyle.FixedSingle;


            ConfigureButton(
                context.GroupsMethod1Add,
                "Aggiungi",
                primaryButtonColor,
                685,
                240,
                100);

            ConfigureButton(
                context.GroupsMethod1Edit,
                "Modifica",
                primaryButtonColor,
                685,
                280,
                100);

            ConfigureButton(
                context.GroupsMethod1Delete,
                "Elimina",
                deleteButtonColor,
                685,
                320,
                100);

            ConfigureButton(
                context.GroupsMethod1Up,
                "↑",
                primaryButtonColor,
                805,
                240,
                50);

            ConfigureButton(
                context.GroupsMethod1Down,
                "↓",
                primaryButtonColor,
                805,
                280,
                50);


            /*
             * SEPARATORE
             */
            Panel separator =
                new Panel();

            separator.Left =
                30;

            separator.Top =
                410;

            separator.Width =
                825;

            separator.Height =
                1;

            separator.BackColor =
                borderColor;


            /*
             * ==================================================
             * METODO 2
             * ==================================================
             */
            CheckBox chkMethod2 =
                context.GroupsMethod2Enabled;

            chkMethod2.Text =
                "Metodo 2: Stampa con ricerca dei codici";

            chkMethod2.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkMethod2.AutoSize =
                true;

            chkMethod2.Left =
                30;

            chkMethod2.Top =
                445;

            chkMethod2.ForeColor =
                titleColor;

            chkMethod2.BackColor =
                backgroundColor;


            Label method2Description =
                new Label();

            method2Description.Text =
                "Testi utilizzati per individuare gli assiemi da processare con il Metodo 2.";

            method2Description.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method2Description.ForeColor =
                subtitleColor;

            method2Description.AutoSize =
                true;

            method2Description.Left =
                50;

            method2Description.Top =
                480;


            ListBox method2List =
                context.GroupsMethod2List;

            method2List.Left =
                50;

            method2List.Top =
                510;

            method2List.Width =
                610;

            method2List.Height =
                135;

            method2List.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method2List.BackColor =
                inputBackgroundColor;

            method2List.ForeColor =
                titleColor;

            method2List.BorderStyle =
                BorderStyle.FixedSingle;


            ConfigureButton(
                context.GroupsMethod2Add,
                "Aggiungi",
                primaryButtonColor,
                685,
                510,
                100);

            ConfigureButton(
                context.GroupsMethod2Edit,
                "Modifica",
                primaryButtonColor,
                685,
                550,
                100);

            ConfigureButton(
                context.GroupsMethod2Delete,
                "Elimina",
                deleteButtonColor,
                685,
                590,
                100);

            ConfigureButton(
                context.GroupsMethod2Up,
                "↑",
                primaryButtonColor,
                805,
                510,
                50);

            ConfigureButton(
                context.GroupsMethod2Down,
                "↓",
                primaryButtonColor,
                805,
                550,
                50);


            /*
             * AGGIUNTA CONTROLLI ALLA TAB
             */
            page.Controls.Add(
                title);

            page.Controls.Add(
                description);

            page.Controls.Add(
                chkIncludeInPrint);


            page.Controls.Add(
                chkMethod1);

            page.Controls.Add(
                method1Description);

            page.Controls.Add(
                method1List);

            page.Controls.Add(
                context.GroupsMethod1Add);

            page.Controls.Add(
                context.GroupsMethod1Edit);

            page.Controls.Add(
                context.GroupsMethod1Delete);

            page.Controls.Add(
                context.GroupsMethod1Up);

            page.Controls.Add(
                context.GroupsMethod1Down);


            page.Controls.Add(
                separator);


            page.Controls.Add(
                chkMethod2);

            page.Controls.Add(
                method2Description);

            page.Controls.Add(
                method2List);

            page.Controls.Add(
                context.GroupsMethod2Add);

            page.Controls.Add(
                context.GroupsMethod2Edit);

            page.Controls.Add(
                context.GroupsMethod2Delete);

            page.Controls.Add(
                context.GroupsMethod2Up);

            page.Controls.Add(
                context.GroupsMethod2Down);


            return page;
        }


        private static void ConfigureButton(
            Button button,
            string text,
            DrawingColor backgroundColor,
            int left,
            int top,
            int width)
        {
            button.Text =
                text;

            button.Left =
                left;

            button.Top =
                top;

            button.Width =
                width;

            button.Height =
                32;

            button.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            button.FlatStyle =
                FlatStyle.Flat;

            button.FlatAppearance.BorderSize =
                0;

            button.BackColor =
                backgroundColor;

            button.ForeColor =
                DrawingColor.White;

            button.Cursor =
                Cursors.Hand;

            button.UseVisualStyleBackColor =
                false;
        }
    }
}