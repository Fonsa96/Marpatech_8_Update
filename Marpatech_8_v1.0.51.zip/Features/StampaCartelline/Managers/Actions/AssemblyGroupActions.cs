﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class AssemblyGroupAction
    {
        private readonly EditorContext _context;

        private readonly ConfigurationEditorModel _model;

        private bool _isLoading;

        private bool _isChangingMethod;

        private PrintFolderConfiguration Configuration
        {
            get
            {
                return _model.CurrentConfiguration;
            }
        }

        public AssemblyGroupAction(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context =
                context;

            _model =
                model;

            ConfigureEvents();

            UpdateMethodControls();
        }

        public void BeginLoading()
        {
            _isLoading =
                true;
        }

        public void EndLoading()
        {
            _isLoading =
                false;
        }

        public void Load()
        {
            bool wasLoading =
                _isLoading;

            _isLoading =
                true;

            try
            {
                AssemblyGroupsConfiguration configuration =
                    Configuration.AssemblyGroups
                    ?? new AssemblyGroupsConfiguration();

                _context.GroupsIncludeInPrint.Checked =
                    configuration.IncludeInPrintProcess;

                _context.GroupsMethod1Enabled.Checked =
                    configuration.Method1Enabled;

                _context.GroupsMethod2Enabled.Checked =
                    configuration.Method2Enabled;

                /*
                 * Sicurezza:
                 * se per qualche vecchio JSON risultassero
                 * entrambi true, manteniamo Metodo 1.
                 */
                if (_context.GroupsMethod1Enabled.Checked &&
                    _context.GroupsMethod2Enabled.Checked)
                {
                    _context.GroupsMethod2Enabled.Checked =
                        false;
                }

                LoadList(
                    _context.GroupsMethod1List,
                    configuration.Method1Rows);

                LoadList(
                    _context.GroupsMethod2List,
                    configuration.Method2Rows);

                UpdateMethodControls();
            }
            finally
            {
                _isLoading =
                    wasLoading;
            }
        }

        public void Save()
        {
            if (_isLoading)
                return;

            Configuration.AssemblyGroups ??=
                new AssemblyGroupsConfiguration();

            AssemblyGroupsConfiguration configuration =
                Configuration.AssemblyGroups;

            configuration.IncludeInPrintProcess =
                _context.GroupsIncludeInPrint.Checked;

            configuration.Method1Enabled =
                _context.GroupsMethod1Enabled.Checked;

            configuration.Method2Enabled =
                _context.GroupsMethod2Enabled.Checked;

            configuration.Method1Rows =
                ReadList(
                    _context.GroupsMethod1List);

            configuration.Method2Rows =
                ReadList(
                    _context.GroupsMethod2List);
        }

        private void ConfigureEvents()
        {
            _context.GroupsIncludeInPrint.CheckedChanged +=
                (_, _) =>
                {
                    Save();
                };

            _context.GroupsMethod1Enabled.CheckedChanged +=
                (_, _) =>
                {
                    Method1CheckedChanged();
                };

            _context.GroupsMethod2Enabled.CheckedChanged +=
                (_, _) =>
                {
                    Method2CheckedChanged();
                };


            _context.GroupsMethod1Add.Click +=
                (_, _) =>
                {
                    AddRow(
                        _context.GroupsMethod1List,
                        "Metodo 1");
                };

            _context.GroupsMethod1Edit.Click +=
                (_, _) =>
                {
                    EditRow(
                        _context.GroupsMethod1List,
                        "Metodo 1");
                };

            _context.GroupsMethod1Delete.Click +=
                (_, _) =>
                {
                    DeleteRow(
                        _context.GroupsMethod1List);
                };

            _context.GroupsMethod1Up.Click +=
                (_, _) =>
                {
                    MoveRow(
                        _context.GroupsMethod1List,
                        -1);
                };

            _context.GroupsMethod1Down.Click +=
                (_, _) =>
                {
                    MoveRow(
                        _context.GroupsMethod1List,
                        1);
                };


            _context.GroupsMethod2Add.Click +=
                (_, _) =>
                {
                    AddRow(
                        _context.GroupsMethod2List,
                        "Metodo 2");
                };

            _context.GroupsMethod2Edit.Click +=
                (_, _) =>
                {
                    EditRow(
                        _context.GroupsMethod2List,
                        "Metodo 2");
                };

            _context.GroupsMethod2Delete.Click +=
                (_, _) =>
                {
                    DeleteRow(
                        _context.GroupsMethod2List);
                };

            _context.GroupsMethod2Up.Click +=
                (_, _) =>
                {
                    MoveRow(
                        _context.GroupsMethod2List,
                        -1);
                };

            _context.GroupsMethod2Down.Click +=
                (_, _) =>
                {
                    MoveRow(
                        _context.GroupsMethod2List,
                        1);
                };


            /*
             * Doppio clic su una riga:
             * modifica immediata.
             */
            _context.GroupsMethod1List.DoubleClick +=
                (_, _) =>
                {
                    EditRow(
                        _context.GroupsMethod1List,
                        "Metodo 1");
                };

            _context.GroupsMethod2List.DoubleClick +=
                (_, _) =>
                {
                    EditRow(
                        _context.GroupsMethod2List,
                        "Metodo 2");
                };
        }

        private void Method1CheckedChanged()
        {
            if (_isLoading ||
                _isChangingMethod)
            {
                return;
            }

            _isChangingMethod =
                true;

            try
            {
                if (_context.GroupsMethod1Enabled.Checked)
                {
                    /*
                     * Metodo 1 true
                     * forza Metodo 2 false.
                     */
                    _context.GroupsMethod2Enabled.Checked =
                        false;
                }

                UpdateMethodControls();

                Save();
            }
            finally
            {
                _isChangingMethod =
                    false;
            }
        }

        private void Method2CheckedChanged()
        {
            if (_isLoading ||
                _isChangingMethod)
            {
                return;
            }

            _isChangingMethod =
                true;

            try
            {
                if (_context.GroupsMethod2Enabled.Checked)
                {
                    /*
                     * Metodo 2 true
                     * forza Metodo 1 false.
                     */
                    _context.GroupsMethod1Enabled.Checked =
                        false;
                }

                UpdateMethodControls();

                Save();
            }
            finally
            {
                _isChangingMethod =
                    false;
            }
        }

        private void UpdateMethodControls()
        {
            bool method1Enabled =
                _context.GroupsMethod1Enabled.Checked;

            bool method2Enabled =
                _context.GroupsMethod2Enabled.Checked;

            _context.GroupsMethod1List.Enabled =
                method1Enabled;

            _context.GroupsMethod1Add.Enabled =
                method1Enabled;

            _context.GroupsMethod1Edit.Enabled =
                method1Enabled;

            _context.GroupsMethod1Delete.Enabled =
                method1Enabled;

            _context.GroupsMethod1Up.Enabled =
                method1Enabled;

            _context.GroupsMethod1Down.Enabled =
                method1Enabled;


            _context.GroupsMethod2List.Enabled =
                method2Enabled;

            _context.GroupsMethod2Add.Enabled =
                method2Enabled;

            _context.GroupsMethod2Edit.Enabled =
                method2Enabled;

            _context.GroupsMethod2Delete.Enabled =
                method2Enabled;

            _context.GroupsMethod2Up.Enabled =
                method2Enabled;

            _context.GroupsMethod2Down.Enabled =
                method2Enabled;
        }

        private void AddRow(
            ListBox listBox,
            string methodName)
        {
            string? value =
                ShowTextEditor(
                    "Aggiungi riga",
                    methodName,
                    string.Empty);

            if (value == null)
                return;

            value =
                value.Trim();

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return;
            }

            listBox.Items.Add(
                value);

            listBox.SelectedIndex =
                listBox.Items.Count - 1;

            Save();
        }

        private void EditRow(
            ListBox listBox,
            string methodName)
        {
            if (listBox.SelectedIndex < 0)
                return;

            int selectedIndex =
                listBox.SelectedIndex;

            string currentValue =
                listBox.Items[selectedIndex]
                    ?.ToString()
                ?? string.Empty;

            string? value =
                ShowTextEditor(
                    "Modifica riga",
                    methodName,
                    currentValue);

            if (value == null)
                return;

            value =
                value.Trim();

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return;
            }

            listBox.Items[selectedIndex] =
                value;

            listBox.SelectedIndex =
                selectedIndex;

            Save();
        }

        private void DeleteRow(
            ListBox listBox)
        {
            if (listBox.SelectedIndex < 0)
                return;

            string value =
                listBox.SelectedItem
                    ?.ToString()
                ?? string.Empty;

            DialogResult result =
                MessageBox.Show(
                    _context.EditorForm,
                    "Vuoi eliminare questa riga?\n\n" +
                    value,
                    "Gruppi di montaggio",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
                return;

            int selectedIndex =
                listBox.SelectedIndex;

            listBox.Items.RemoveAt(
                selectedIndex);

            if (listBox.Items.Count > 0)
            {
                listBox.SelectedIndex =
                    Math.Min(
                        selectedIndex,
                        listBox.Items.Count - 1);
            }

            Save();
        }

        private void MoveRow(
            ListBox listBox,
            int direction)
        {
            int selectedIndex =
                listBox.SelectedIndex;

            if (selectedIndex < 0)
                return;

            int newIndex =
                selectedIndex +
                direction;

            if (newIndex < 0 ||
                newIndex >=
                    listBox.Items.Count)
            {
                return;
            }

            object item =
                listBox.Items[selectedIndex];

            listBox.Items.RemoveAt(
                selectedIndex);

            listBox.Items.Insert(
                newIndex,
                item);

            listBox.SelectedIndex =
                newIndex;

            Save();
        }

        private static void LoadList(
            ListBox listBox,
            IEnumerable<string>? values)
        {
            listBox.BeginUpdate();

            try
            {
                listBox.Items.Clear();

                if (values == null)
                    return;

                foreach (string value
                    in values)
                {
                    string text =
                        value?.Trim()
                        ?? string.Empty;

                    if (string.IsNullOrWhiteSpace(
                            text))
                    {
                        continue;
                    }

                    listBox.Items.Add(
                        text);
                }
            }
            finally
            {
                listBox.EndUpdate();
            }
        }

        private static List<string> ReadList(
            ListBox listBox)
        {
            return listBox.Items
                .Cast<object>()
                .Select(
                    item =>
                        item?.ToString()?.Trim()
                        ?? string.Empty)
                .Where(
                    value =>
                        !string.IsNullOrWhiteSpace(
                            value))
                .ToList();
        }

        private string? ShowTextEditor(
            string title,
            string methodName,
            string initialValue)
        {
            using Form dialog =
                new Form();

            dialog.Text =
                title;

            dialog.StartPosition =
                FormStartPosition.CenterParent;

            dialog.FormBorderStyle =
                FormBorderStyle.FixedDialog;

            dialog.MaximizeBox =
                false;

            dialog.MinimizeBox =
                false;

            dialog.ShowInTaskbar =
                false;

            dialog.ClientSize =
                new Size(
                    520,
                    155);

            Label label =
                new Label();

            label.Text =
                methodName +
                " - Testo della riga";

            label.AutoSize =
                true;

            label.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            label.Location =
                new Point(
                    20,
                    20);


            TextBox textBox =
                new TextBox();

            textBox.Text =
                initialValue;

            textBox.Font =
                new Font(
                    "Segoe UI",
                    10);

            textBox.Location =
                new Point(
                    20,
                    50);

            textBox.Size =
                new Size(
                    480,
                    28);


            Button btnOk =
                new Button();

            btnOk.Text =
                "OK";

            btnOk.DialogResult =
                DialogResult.OK;

            btnOk.Size =
                new Size(
                    100,
                    32);

            btnOk.Location =
                new Point(
                    290,
                    105);


            Button btnCancel =
                new Button();

            btnCancel.Text =
                "Annulla";

            btnCancel.DialogResult =
                DialogResult.Cancel;

            btnCancel.Size =
                new Size(
                    100,
                    32);

            btnCancel.Location =
                new Point(
                    400,
                    105);


            dialog.Controls.Add(
                label);

            dialog.Controls.Add(
                textBox);

            dialog.Controls.Add(
                btnOk);

            dialog.Controls.Add(
                btnCancel);

            dialog.AcceptButton =
                btnOk;

            dialog.CancelButton =
                btnCancel;


            dialog.Shown +=
                (_, _) =>
                {
                    textBox.Focus();

                    textBox.SelectAll();
                };


            DialogResult result =
                dialog.ShowDialog(
                    _context.EditorForm);

            if (result != DialogResult.OK)
                return null;

            return textBox.Text;
        }
    }
}