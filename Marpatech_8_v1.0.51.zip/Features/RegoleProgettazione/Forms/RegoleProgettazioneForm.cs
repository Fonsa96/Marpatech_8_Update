﻿using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.RegoleProgettazione.Models;
using Marpatech_8.Features.RegoleProgettazione.Services;
using Marpatech_8.Features.RegoleProgettazione.UI;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;

using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

namespace Marpatech_8.Features.RegoleProgettazione.Forms
{
    public class RegoleProgettazioneForm : Form
    {
        private readonly bool _isDarkTheme;

        private readonly RuleFileSystemService
            _fileSystemService;

        private readonly RuleTreeEditorService
            _treeEditorService;

        private readonly RuleSaveService
            _saveService;

        private readonly RuleSettingsService
            _settingsService;

        private readonly CoreWindowSettings
            _windowSettings;

        private readonly List<RuleNode>
            _pendingDeletedNodes = new();

        private ObservableCollection<RuleNode>
            _rootNodes = new();

        private RuleNode?
            _selectedNode;

        private string
            _rootPath = string.Empty;

        private bool
            _isReadOnly;

        private bool
            _hasUnsavedChanges;

        private bool
            _isLoading;

        private bool
            _isLoadingEditor;

        private TreeView
            rulesTreeView = null!;

        private Label
            emptyTreeLabel = null!;

        private Panel
            editorPanel = null!;

        private Label
            selectedTypeLabel = null!;

        private TextBox
            titleTextBox = null!;

        private Label
    titleEditorLabel = null!;

        private RichTextBox
            contentRichTextBox = null!;

        private ListBox
            attachmentsListBox = null!;

        private Button
            addParagraphButton = null!;

        private Button
            deleteParagraphButton = null!;

        private Button
            addTextButton = null!;

        private Button
            deleteTextButton = null!;

        private Button
            moveUpButton = null!;

        private Button
            moveDownButton = null!;

        private Button
            saveButton = null!;

        private Button
            settingsButton = null!;

        private FlowLayoutPanel
            editToolbarPanel = null!;

        private FlowLayoutPanel
            textFormatToolbarPanel = null!;

        private FlowLayoutPanel
            attachmentsToolbarPanel = null!;

        private Label
            attachmentsLabel = null!;

        private string
            _loadedStructureSnapshot =
                string.Empty;

        private readonly RuleExternalChangesService?
    _externalChangesService;

        public RegoleProgettazioneForm(
            string rootPath,
            bool isReadOnly,
            bool isDarkTheme,
            RuleExternalChangesService? externalChangesService = null)
        {
            _rootPath =
                rootPath;

            _isReadOnly =
                isReadOnly;

            _isDarkTheme =
                isDarkTheme;

            _externalChangesService =
                externalChangesService;

            _fileSystemService =
                new RuleFileSystemService();

            _treeEditorService =
                new RuleTreeEditorService();

            _saveService =
                new RuleSaveService();

            _settingsService =
                new RuleSettingsService();

            _windowSettings =
                WindowSettingsService.Load(
                    "RegoleProgettazione",
                    1200,
                    760);

            InitializeComponent();

            ShowInTaskbar = false;
            KeyPreview = false;

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            Load +=
                RegoleProgettazioneForm_Load;

            FormClosing +=
                RegoleProgettazioneForm_FormClosing;
        }

        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Color subtitleColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 88)
                    : Color.FromArgb(190, 200, 215);

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(26, 28, 34)
                    : Color.White;

            Text =
                "Regole di progettazione";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    950,
                    620);

            BackColor =
                backgroundColor;

            Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Regular);

            Label titleLabel =
                new Label
                {
                    Text =
                        "Regole di progettazione",

                    Font =
                        new Font(
                            "Segoe UI",
                            24F,
                            FontStyle.Bold),

                    ForeColor =
                        titleColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            35,
                            25)
                };

            Label pathLabel =
                new Label
                {
                    Text =
                        _rootPath,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Regular),

                    ForeColor =
                        subtitleColor,

                    AutoEllipsis =
                        true,

                    Location =
                        new Point(
                            38,
                            72),

                    Size =
                        new Size(
                            700,
                            22),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right
                };

            settingsButton =
                new Button
                {
                    Text =
                        "⚙",

                    Font =
                        new Font(
                            "Segoe UI",
                            18F,
                            FontStyle.Regular),

                    Size =
                        new Size(
                            42,
                            42),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        titleColor,

                    Cursor =
                        Cursors.Hand,

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    Location =
                        new Point(
                            ClientSize.Width - 70,
                            25)
                };

            settingsButton
                .FlatAppearance
                .BorderSize = 0;

            settingsButton.Click +=
                SettingsButton_Click;

            editToolbarPanel =
                new FlowLayoutPanel
                {
                    Location =
                        new Point(
                            35,
                            105),

                    Size =
                        new Size(
                            ClientSize.Width - 70,
                            42),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlowDirection =
                        FlowDirection.LeftToRight,

                    WrapContents =
                        false,

                    BackColor =
                        backgroundColor
                };

            addParagraphButton =
                CreateToolbarButton(
                    "+ Paragrafo");

            deleteParagraphButton =
                CreateToolbarButton(
                    "- Paragrafo");

            addTextButton =
                CreateToolbarButton(
                    "+ Testo");

            deleteTextButton =
                CreateToolbarButton(
                    "- Testo");

            moveUpButton =
                CreateToolbarButton(
                    "↑",
                    40);

            moveDownButton =
                CreateToolbarButton(
                    "↓",
                    40);

            saveButton =
                CreateToolbarButton(
                    "Salva Modifiche",
                    145);

            /*
 * STILI TOOLBAR PRINCIPALE
 *
 * Viola  = aggiunta
 * Rosso  = eliminazione
 * Grigio = spostamento
 * Verde  = salvataggio
 */
            RuleButtonStyle.ApplyPrimary(
                addParagraphButton);

            RuleButtonStyle.ApplyDelete(
                deleteParagraphButton);

            RuleButtonStyle.ApplyPrimary(
                addTextButton);

            RuleButtonStyle.ApplyDelete(
                deleteTextButton);

            RuleButtonStyle.ApplySecondary(
                moveUpButton);

            RuleButtonStyle.ApplySecondary(
                moveDownButton);

            RuleButtonStyle.ApplySave(
                saveButton);

            addParagraphButton.Click +=
                AddParagraphButton_Click;

            deleteParagraphButton.Click +=
                DeleteParagraphButton_Click;

            addTextButton.Click +=
                AddTextButton_Click;

            deleteTextButton.Click +=
                DeleteTextButton_Click;

            moveUpButton.Click +=
                MoveUpButton_Click;

            moveDownButton.Click +=
                MoveDownButton_Click;

            saveButton.Click +=
                SaveButton_Click;

            editToolbarPanel.Controls.Add(
                addParagraphButton);

            editToolbarPanel.Controls.Add(
                deleteParagraphButton);

            editToolbarPanel.Controls.Add(
                addTextButton);

            editToolbarPanel.Controls.Add(
                deleteTextButton);

            editToolbarPanel.Controls.Add(
                moveUpButton);

            editToolbarPanel.Controls.Add(
                moveDownButton);

            editToolbarPanel.Controls.Add(
                saveButton);

            SplitContainer mainSplit =
                new SplitContainer
                {
                    Location =
                        new Point(
                            35,
                            155),

                    Size =
                        new Size(
                            ClientSize.Width - 70,
                            ClientSize.Height - 190),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    SplitterDistance =
                        340,

                    BackColor =
                        backgroundColor,

                    BorderStyle =
                        BorderStyle.None,

                    FixedPanel =
                        FixedPanel.Panel1
                };

            Panel treePanel =
                new Panel
                {
                    Dock =
                        DockStyle.Fill,

                    BackColor =
                        panelColor,

                    Padding =
                        new Padding(
                            12)
                };

            Label structureLabel =
                new Label
                {
                    Text =
                        "Struttura",

                    Dock =
                        DockStyle.Top,

                    Height =
                        32,

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold),

                    ForeColor =
                        titleColor
                };

            rulesTreeView =
                new TreeView
                {
                    Dock =
                        DockStyle.Fill,

                    BorderStyle =
                        BorderStyle.None,

                    BackColor =
                        panelColor,

                    ForeColor =
                        titleColor,

                    HideSelection =
                        false,

                    FullRowSelect =
                        true,

                    ShowLines =
                        false,

                    ShowPlusMinus =
                        true,

                    ShowRootLines =
                        false
                };

            rulesTreeView.AfterSelect +=
                RulesTreeView_AfterSelect;

            rulesTreeView.AfterExpand +=
                RulesTreeView_AfterExpand;

            rulesTreeView.AfterCollapse +=
                RulesTreeView_AfterCollapse;

            rulesTreeView.MouseDown +=
                (_, _) =>
                {
                    rulesTreeView.Focus();
                };

            emptyTreeLabel =
                new Label
                {
                    Text =
                        "Nessuna regola presente.\r\n\r\n" +
                        "Usa “Aggiungi Paragrafo” o “Aggiungi Testo” per iniziare.",

                    Dock =
                        DockStyle.Fill,

                    TextAlign =
                        ContentAlignment.MiddleCenter,

                    ForeColor =
                        subtitleColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Regular),

                    Visible =
                        false
                };

            treePanel.Controls.Add(
                rulesTreeView);

            treePanel.Controls.Add(
                emptyTreeLabel);

            treePanel.Controls.Add(
                structureLabel);

            editorPanel =
                new Panel
                {
                    Dock =
                        DockStyle.Fill,

                    BackColor =
                        panelColor,

                    Padding =
                        new Padding(
                            18)
                };

            selectedTypeLabel =
                new Label
                {
                    Text =
                        string.Empty,

                    Location =
                        new Point(
                            18,
                            15),

                    Size =
                        new Size(
                            300,
                            20),

                    ForeColor =
                        subtitleColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            8.5F,
                            FontStyle.Bold),

                    Visible =
                        false
                };

            titleEditorLabel =
                new Label
                {
                    Text =
                        "Titolo",

                    Location =
                        new Point(
                            18,
                            42),

                    AutoSize =
                        true,

                    ForeColor =
                        titleColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold)
                };

            titleTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            18,
                            66),

                    Width =
                        500,

                    Height =
                        32,

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        inputColor,

                    ForeColor =
                        titleColor,

                    BorderStyle =
                        BorderStyle.FixedSingle
                };

            titleTextBox.TextChanged +=
                TitleTextBox_TextChanged;

            titleTextBox.Enter +=
    (_, _) =>
    {
        titleTextBox.Focus();
    };

            textFormatToolbarPanel =
                new FlowLayoutPanel
                {
                    Location =
                        new Point(
                            18,
                            115),

                    Size =
                        new Size(
                            650,
                            38),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    WrapContents =
                        true,

                    Visible =
                        false,

                    BackColor =
                        panelColor
                };

            Button boldButton =
    CreateFormatButton(
        "B",
        FontStyle.Bold);

            Button italicButton =
                CreateFormatButton(
                    "I",
                    FontStyle.Italic);

            Button underlineButton =
                CreateFormatButton(
                    "U",
                    FontStyle.Underline);

            Button strikeButton =
                CreateFormatButton(
                    "S",
                    FontStyle.Strikeout);

            ComboBox fontSizeComboBox =
                new ComboBox
                {
                    Width =
                        70,

                    Height =
                        30,

                    DropDownStyle =
                        ComboBoxStyle.DropDownList,

                    Margin =
                        new Padding(
                            0,
                            0,
                            6,
                            0)
                };

            fontSizeComboBox.Items.AddRange(
                new object[]
                {
        "8",
        "9",
        "10",
        "11",
        "12",
        "14",
        "16",
        "18",
        "20",
        "24",
        "28",
        "32"
                });

            fontSizeComboBox.SelectedItem =
                "10";

            Button colorButton =
                CreateToolbarButton(
                    "Colore",
                    70);

            Button alignLeftButton =
                CreateToolbarButton(
                    "←",
                    38);

            Button alignCenterButton =
                CreateToolbarButton(
                    "↔",
                    38);

            Button alignRightButton =
                CreateToolbarButton(
                    "→",
                    38);

            Button bulletButton =
                CreateToolbarButton(
                    "• Lista",
                    75);

            Button numberButton =
                CreateToolbarButton(
                    "1. Lista",
                    75);

            /*
 * STILI EDITOR TESTO
 */
            RuleButtonStyle.ApplySecondary(
                boldButton);

            RuleButtonStyle.ApplySecondary(
                italicButton);

            RuleButtonStyle.ApplySecondary(
                underlineButton);

            RuleButtonStyle.ApplySecondary(
                strikeButton);

            RuleButtonStyle.ApplySecondary(
                alignLeftButton);

            RuleButtonStyle.ApplySecondary(
                alignCenterButton);

            RuleButtonStyle.ApplySecondary(
                alignRightButton);

            RuleButtonStyle.ApplySecondary(
                bulletButton);

            RuleButtonStyle.ApplySecondary(
                numberButton);

            boldButton.Click +=
                (_, _) =>
                    ToggleFontStyle(
                        FontStyle.Bold);

            italicButton.Click +=
                (_, _) =>
                    ToggleFontStyle(
                        FontStyle.Italic);

            underlineButton.Click +=
                (_, _) =>
                    ToggleFontStyle(
                        FontStyle.Underline);

            strikeButton.Click +=
                (_, _) =>
                    ToggleFontStyle(
                        FontStyle.Strikeout);

            fontSizeComboBox.SelectedIndexChanged +=
                (_, _) =>
                    ApplyFontSize(
                        fontSizeComboBox);

            colorButton.Click +=
                ColorButton_Click;

            alignLeftButton.Click +=
                (_, _) =>
                    ApplyAlignment(
                        HorizontalAlignment.Left);

            alignCenterButton.Click +=
                (_, _) =>
                    ApplyAlignment(
                        HorizontalAlignment.Center);

            alignRightButton.Click +=
                (_, _) =>
                    ApplyAlignment(
                        HorizontalAlignment.Right);

            bulletButton.Click +=
                (_, _) =>
                    ToggleBulletList();

            numberButton.Click +=
                (_, _) =>
                    ToggleNumberList();

            textFormatToolbarPanel.Controls.Add(
                boldButton);

            textFormatToolbarPanel.Controls.Add(
                italicButton);

            textFormatToolbarPanel.Controls.Add(
                underlineButton);

            textFormatToolbarPanel.Controls.Add(
                strikeButton);

            textFormatToolbarPanel.Controls.Add(
                fontSizeComboBox);

            textFormatToolbarPanel.Controls.Add(
                colorButton);

            textFormatToolbarPanel.Controls.Add(
                alignLeftButton);

            textFormatToolbarPanel.Controls.Add(
                alignCenterButton);

            textFormatToolbarPanel.Controls.Add(
                alignRightButton);

            textFormatToolbarPanel.Controls.Add(
                bulletButton);

            textFormatToolbarPanel.Controls.Add(
                numberButton);

            contentRichTextBox =
                new RichTextBox
                {
                    Location =
                        new Point(
                            18,
                            160),

                    Size =
                        new Size(
                            650,
                            300),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        inputColor,

                    ForeColor =
                        titleColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    DetectUrls =
                        true,

                    HideSelection =
                        false,

                    Visible =
                        false
                };

            contentRichTextBox.TextChanged +=
                ContentRichTextBox_TextChanged;

            contentRichTextBox.Enter +=
    (_, _) =>
    {
        contentRichTextBox.Focus();
    };

            contentRichTextBox.MouseDown +=
                (_, _) =>
                {
                    contentRichTextBox.Focus();
                };

            attachmentsLabel =
                new Label
                {
                    Text =
                        "Allegati",

                    AutoSize =
                        true,

                    ForeColor =
                        titleColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Bold),

                    Visible =
                        false
                };

            attachmentsToolbarPanel =
                new FlowLayoutPanel
                {
                    Height =
                        34,

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlowDirection =
                        FlowDirection.LeftToRight,

                    Visible =
                        false,

                    BackColor =
                        panelColor
                };

            Button addAttachmentButton =
    CreateToolbarButton(
        "+ Aggiungi file",
        120);

            Button removeAttachmentButton =
                CreateToolbarButton(
                    "- Rimuovi",
                    95);

            RuleButtonStyle.ApplyPrimary(
    addAttachmentButton);

            RuleButtonStyle.ApplyDelete(
                removeAttachmentButton);

            addAttachmentButton.Click +=
                AddAttachmentButton_Click;

            removeAttachmentButton.Click +=
                RemoveAttachmentButton_Click;

            attachmentsToolbarPanel.Controls.Add(
                addAttachmentButton);

            attachmentsToolbarPanel.Controls.Add(
                removeAttachmentButton);

            attachmentsListBox =
                new ListBox
                {
                    Height =
                        95,

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        inputColor,

                    ForeColor =
                        titleColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Visible =
                        false
                };

            attachmentsListBox.DoubleClick +=
                AttachmentsListBox_DoubleClick;

            editorPanel.Controls.Add(
                selectedTypeLabel);

            editorPanel.Controls.Add(
                titleEditorLabel);

            editorPanel.Controls.Add(
                titleTextBox);

            editorPanel.Controls.Add(
                textFormatToolbarPanel);

            editorPanel.Controls.Add(
                contentRichTextBox);

            editorPanel.Controls.Add(
                attachmentsToolbarPanel);

            editorPanel.Controls.Add(
                attachmentsListBox);

            editorPanel.Resize +=
                EditorPanel_Resize;

            editorPanel.Controls.Add(
                 attachmentsLabel);

            mainSplit.Panel1.Controls.Add(
                treePanel);

            mainSplit.Panel2.Controls.Add(
                editorPanel);

            Controls.Add(
                titleLabel);

            Controls.Add(
                pathLabel);

            Controls.Add(
                settingsButton);

            Controls.Add(
                editToolbarPanel);

            Controls.Add(
                mainSplit);

            ApplyReadOnlyMode();

            UpdateSaveButtonState();
        }

        protected override void OnActivated(
    EventArgs e)
        {
            base.OnActivated(e);

            /*
             * Non forziamo un controllo specifico,
             * ma garantiamo che il Form dell'addin
             * sia la finestra attiva quando l'utente
             * ci clicca sopra.
             */
            Activate();
        }

        private void AddAttachmentButton_Click(
    object? sender,
    EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null ||
                !_selectedNode.IsText)
            {
                return;
            }

            using OpenFileDialog dialog =
                new OpenFileDialog
                {
                    Title =
                        "Seleziona uno o più allegati",

                    Multiselect =
                        true,

                    Filter =
                        "Tutti i file (*.*)|*.*"
                };

            DialogResult result =
                dialog.ShowDialog(
                    this);

            if (result !=
                DialogResult.OK)
            {
                return;
            }

            bool somethingAdded =
                false;

            foreach (string sourcePath
                     in dialog.FileNames)
            {
                if (!File.Exists(
                        sourcePath))
                {
                    continue;
                }

                string fileName =
                    Path.GetFileName(
                        sourcePath);

                /*
                 * Evitiamo due allegati con lo stesso nome
                 * all'interno dello stesso testo.
                 */
                bool alreadyExists =
                    _selectedNode.Attachments.Any(
                        x =>
                            string.Equals(
                                x.FileName,
                                fileName,
                                StringComparison.OrdinalIgnoreCase));

                if (alreadyExists)
                {
                    MessageBox.Show(
                        this,
                        "Esiste già un allegato con questo nome:\r\n\r\n" +
                        fileName,
                        "Regole di progettazione",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    continue;
                }

                /*
                 * Potrebbe esistere tra quelli che l'utente
                 * aveva precedentemente deciso di eliminare.
                 */
                RuleAttachment? pendingDeletion =
                    _selectedNode
                        .PendingDeletedAttachments
                        .FirstOrDefault(
                            x =>
                                string.Equals(
                                    x.FileName,
                                    fileName,
                                    StringComparison.OrdinalIgnoreCase));

                if (pendingDeletion != null)
                {
                    /*
                     * Caso:
                     *
                     * rimuovo Catalogo.pdf
                     * poi, prima di salvare, aggiungo di nuovo
                     * Catalogo.pdf.
                     *
                     * Annulliamo semplicemente la cancellazione.
                     */
                    pendingDeletion.State =
                        RuleNodeState.Unchanged;

                    _selectedNode
                        .PendingDeletedAttachments
                        .Remove(
                            pendingDeletion);

                    _selectedNode.Attachments.Add(
                        pendingDeletion);

                    somethingAdded =
                        true;

                    continue;
                }

                _selectedNode.Attachments.Add(
                    new RuleAttachment
                    {
                        FileName =
                            fileName,

                        PendingSourcePath =
                            sourcePath,

                        OriginalPath =
                            string.Empty,

                        State =
                            RuleNodeState.Added
                    });

                somethingAdded =
                    true;
            }

            if (!somethingAdded)
                return;

            RefreshAttachmentsList();

            MarkUnsaved();
        }

        private void RemoveAttachmentButton_Click(
    object? sender,
    EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null ||
                !_selectedNode.IsText)
            {
                return;
            }

            if (attachmentsListBox.SelectedItem
                is not RuleAttachment attachment)
            {
                MessageBox.Show(
                    this,
                    "Seleziona prima l'allegato da rimuovere.",
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            DialogResult result =
                MessageBox.Show(
                    this,
                    "Vuoi rimuovere l'allegato:\r\n\r\n" +
                    $"\"{attachment.FileName}\"?\r\n\r\n" +
                    "La rimozione diventerà effettiva solamente premendo \"Salva Modifiche\".",
                    "Conferma rimozione allegato",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

            if (result !=
                DialogResult.Yes)
            {
                return;
            }

            /*
             * Se era stato appena aggiunto e non è mai
             * stato salvato sul filesystem:
             *
             * basta toglierlo dalla memoria.
             */
            if (attachment.State ==
                RuleNodeState.Added)
            {
                _selectedNode
                    .Attachments
                    .Remove(
                        attachment);

                RefreshAttachmentsList();

                MarkUnsaved();

                return;
            }

            /*
             * Allegato già esistente nella cartella aziendale:
             *
             * scompare dall'interfaccia ma rimane fisicamente
             * sul disco fino a Salva Modifiche.
             */
            attachment.State =
                RuleNodeState.Deleted;

            _selectedNode
                .PendingDeletedAttachments
                .Add(
                    attachment);

            _selectedNode
                .Attachments
                .Remove(
                    attachment);

            RefreshAttachmentsList();

            MarkUnsaved();
        }

        private Button CreateToolbarButton(
            string text,
            int width = 115)
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.FromArgb(248, 250, 252);

            Color hoverColor =
                _isDarkTheme
                    ? Color.FromArgb(38, 42, 52)
                    : Color.FromArgb(235, 241, 248);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 88)
                    : Color.FromArgb(190, 200, 215);

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Button button =
                new Button
                {
                    Text =
                        text,

                    Width =
                        width,

                    Height =
                        32,

                    Margin =
                        new Padding(
                            0,
                            0,
                            7,
                            0),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold)
                };

            button
                .FlatAppearance
                .BorderColor =
                    borderColor;

            button
                .FlatAppearance
                .MouseOverBackColor =
                    hoverColor;

            return button;
        }

        private Button CreateFormatButton(
    string text,
    FontStyle fontStyle)
        {
            Button button =
                CreateToolbarButton(
                    text,
                    36);

            button.Font =
                new Font(
                    "Segoe UI",
                    10F,
                    fontStyle);

            return button;
        }

        private void ToggleFontStyle(
    FontStyle style)
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            Font currentFont =
                contentRichTextBox.SelectionFont ??
                contentRichTextBox.Font;

            FontStyle newStyle =
                currentFont.Style;

            if (newStyle.HasFlag(style))
            {
                newStyle &=
                    ~style;
            }
            else
            {
                newStyle |=
                    style;
            }

            try
            {
                contentRichTextBox.SelectionFont =
                    new Font(
                        currentFont.FontFamily,
                        currentFont.Size,
                        newStyle);
            }
            catch
            {
                return;
            }

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void ApplyFontSize(
    ComboBox fontSizeComboBox)
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            if (fontSizeComboBox.SelectedItem == null)
                return;

            if (!float.TryParse(
                    fontSizeComboBox.SelectedItem.ToString(),
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out float size))
            {
                return;
            }

            Font currentFont =
                contentRichTextBox.SelectionFont ??
                contentRichTextBox.Font;

            contentRichTextBox.SelectionFont =
                new Font(
                    currentFont.FontFamily,
                    size,
                    currentFont.Style);

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void ColorButton_Click(
    object? sender,
    EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            using ColorDialog dialog =
                new ColorDialog
                {
                    FullOpen =
                        true,

                    Color =
                        contentRichTextBox.SelectionColor
                };

            DialogResult result =
                dialog.ShowDialog(
                    this);

            if (result !=
                DialogResult.OK)
            {
                return;
            }

            contentRichTextBox.SelectionColor =
                dialog.Color;

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void ApplyAlignment(
    HorizontalAlignment alignment)
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            contentRichTextBox.SelectionAlignment =
                alignment;

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void ToggleBulletList()
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            int lineIndex =
                contentRichTextBox.GetLineFromCharIndex(
                    contentRichTextBox.SelectionStart);

            if (lineIndex < 0 ||
                lineIndex >=
                contentRichTextBox.Lines.Length)
            {
                return;
            }

            string line =
                contentRichTextBox.Lines[
                    lineIndex];

            int lineStart =
                contentRichTextBox.GetFirstCharIndexFromLine(
                    lineIndex);

            if (line.StartsWith(
                    "• ",
                    StringComparison.Ordinal))
            {
                contentRichTextBox.Select(
                    lineStart,
                    Math.Min(
                        2,
                        contentRichTextBox.TextLength -
                        lineStart));

                contentRichTextBox.SelectedText =
                    string.Empty;
            }
            else
            {
                contentRichTextBox.Select(
                    lineStart,
                    0);

                contentRichTextBox.SelectedText =
                    "• ";
            }

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void ToggleNumberList()
        {
            if (_isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            int lineIndex =
                contentRichTextBox.GetLineFromCharIndex(
                    contentRichTextBox.SelectionStart);

            if (lineIndex < 0 ||
                lineIndex >=
                contentRichTextBox.Lines.Length)
            {
                return;
            }

            string line =
                contentRichTextBox.Lines[
                    lineIndex];

            Match numberMatch =
                Regex.Match(
                    line,
                    @"^\d+\.\s");

            int lineStart =
                contentRichTextBox.GetFirstCharIndexFromLine(
                    lineIndex);

            if (numberMatch.Success)
            {
                contentRichTextBox.Select(
                    lineStart,
                    numberMatch.Length);

                contentRichTextBox.SelectedText =
                    string.Empty;
            }
            else
            {
                int number =
                    CalculateNumberForLine(
                        lineIndex);

                contentRichTextBox.Select(
                    lineStart,
                    0);

                contentRichTextBox.SelectedText =
                    $"{number}. ";
            }

            contentRichTextBox.Focus();

            SyncHtmlFromEditor();
        }

        private void SyncHtmlFromEditor()
        {
            if (_isLoading ||
                _isLoadingEditor ||
                _isReadOnly ||
                _selectedNode?.IsText != true)
            {
                return;
            }

            string html =
                WinFormsHtmlRichTextService.ToHtml(
                    contentRichTextBox);

            if (_selectedNode.HtmlContent ==
                html)
            {
                return;
            }

            _selectedNode.HtmlContent =
                html;

            MarkUnsaved();
        }

        private int CalculateNumberForLine(
    int lineIndex)
        {
            if (lineIndex <= 0)
                return 1;

            string[] lines =
                contentRichTextBox.Lines;

            int number =
                1;

            for (int index =
                     lineIndex - 1;
                 index >= 0;
                 index--)
            {
                Match match =
                    Regex.Match(
                        lines[index],
                        @"^(?<number>\d+)\.\s");

                if (!match.Success)
                    break;

                if (int.TryParse(
                        match.Groups["number"].Value,
                        out int previousNumber))
                {
                    number =
                        previousNumber +
                        1;

                    break;
                }
            }

            return number;
        }

        private async void RegoleProgettazioneForm_Load(
            object? sender,
            EventArgs e)
        {
            await LoadStructureAsync();
        }
        private async System.Threading.Tasks.Task
            LoadStructureAsync()
        {
            if (_isLoading)
                return;

            _isLoading =
                true;

            try
            {
                /*
                 * La lettura può avvenire in maniera asincrona.
                 *
                 * Una cartella completamente vuota è valida:
                 * LoadAsync deve semplicemente restituire
                 * una lista vuota.
                 */
                List<RuleNode> nodes =
                    await _fileSystemService.LoadAsync(
                        _rootPath);

                /*
                 * Tutto ciò che modifica controlli WinForms
                 * viene riportato esplicitamente sul thread UI.
                 */
                RunOnUiThread(
                    () =>
                    {
                        _rootNodes =
                            new System.Collections.ObjectModel.ObservableCollection<RuleNode>(
                                nodes);

                        _pendingDeletedNodes.Clear();

                        _selectedNode =
                            null;

                        _hasUnsavedChanges =
                            false;

                        /*
                         * Fotografia multiutente della struttura
                         * caricata dal server.
                         */
                        _loadedStructureSnapshot =
                            RuleStructureSnapshotService.CreateSnapshot(
                                _rootPath);

                        RebuildTree();

                        ClearEditor();

                        ApplyReadOnlyMode();

                        UpdateSaveButtonState();
                    });
            }
            catch (Exception ex)
            {
                RunOnUiThread(
                    () =>
                    {
                        MessageBox.Show(
                            this,
                            "Non è stato possibile leggere la cartella delle Regole di progettazione.\r\n\r\n" +
                            ex.Message,
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    });
            }
            finally
            {
                _isLoading =
                    false;
            }
        }

        private void RunOnUiThread(
    Action action)
        {
            if (IsDisposed)
                return;

            if (InvokeRequired)
            {
                Invoke(
                    action);

                return;
            }

            action();
        }

        private void RebuildTree()
        {
            rulesTreeView
                .BeginUpdate();

            try
            {
                rulesTreeView
                    .Nodes
                    .Clear();

                foreach (RuleNode node
                         in _rootNodes
                             .OrderBy(
                                 x => x.Order))
                {
                    rulesTreeView
                        .Nodes
                        .Add(
                            CreateTreeNode(
                                node));
                }

                bool isEmpty =
                    rulesTreeView
                        .Nodes
                        .Count == 0;

                rulesTreeView.Visible =
                    !isEmpty;

                emptyTreeLabel.Visible =
                    isEmpty;
            }
            finally
            {
                rulesTreeView
                    .EndUpdate();
            }
        }

        private TreeNode CreateTreeNode(
            RuleNode ruleNode)
        {
            TreeNode treeNode =
                new TreeNode
                {
                    Text =
                        ruleNode.Title,

                    Tag =
                        ruleNode
                };

            if (ruleNode.IsParagraph)
            {
                foreach (RuleNode child
                         in ruleNode.Children
                             .OrderBy(
                                 x => x.Order))
                {
                    treeNode.Nodes.Add(
                        CreateTreeNode(
                            child));
                }

                /*
                 * Un paragrafo deve essere sempre
                 * espandibile/collassabile.
                 *
                 * TreeView WinForms mostra il simbolo +/-
                 * soltanto se esistono figli.
                 *
                 * Per ora la logica funzionale è corretta;
                 * nel passaggio grafico definitivo creeremo
                 * un rendering personalizzato per mostrare
                 * sempre la freccia anche sul paragrafo vuoto.
                 */
                if (ruleNode.IsExpanded)
                {
                    treeNode.Expand();
                }
            }

            return treeNode;
        }

        private void RulesTreeView_AfterSelect(
            object? sender,
            TreeViewEventArgs e)
        {
            if (e.Node?.Tag
                is not RuleNode node)
            {
                return;
            }

            _selectedNode =
                node;

            LoadSelectedNodeIntoEditor();

            UpdateCommandState();
        }

        private void RulesTreeView_AfterExpand(
            object? sender,
            TreeViewEventArgs e)
        {
            if (e.Node?.Tag
                is RuleNode node)
            {
                node.IsExpanded =
                    true;
            }
        }

        private void RulesTreeView_AfterCollapse(
            object? sender,
            TreeViewEventArgs e)
        {
            if (e.Node?.Tag
                is RuleNode node)
            {
                node.IsExpanded =
                    false;
            }
        }

        private void LoadSelectedNodeIntoEditor()
        {
            _isLoadingEditor =
                true;

            try
            {
                if (_selectedNode == null)
                {
                    ClearEditor();
                    return;
                }

                selectedTypeLabel.Visible =
                    true;

                selectedTypeLabel.Text =
                    _selectedNode.IsParagraph
                        ? "PARAGRAFO"
                        : "TESTO";

                titleTextBox.Text =
                    _selectedNode.Title;

                /*
                 * PARAGRAFO
                 */
                if (_selectedNode.IsParagraph)
                {
                    contentRichTextBox.Clear();

                    attachmentsListBox.Items.Clear();

                    ApplyReadOnlyMode();

                    return;
                }

                /*
                 * TESTO
                 */
                WinFormsHtmlRichTextService.LoadHtml(
                    contentRichTextBox,
                    _selectedNode.HtmlContent);

                RefreshAttachmentsList();

                ApplyReadOnlyMode();
            }
            finally
            {
                _isLoadingEditor =
                    false;
            }
        }
        private void ClearEditor()
        {
            _isLoadingEditor =
                true;

            try
            {
                _selectedNode =
                    null;

                selectedTypeLabel.Visible =
                    false;

                titleEditorLabel.Visible =
                    false;

                titleTextBox.Text =
                    string.Empty;

                titleTextBox.Visible =
                    false;

                contentRichTextBox.Clear();

                contentRichTextBox.Visible =
                    false;

                textFormatToolbarPanel.Visible =
                    false;

                attachmentsLabel.Visible =
                    false;

                attachmentsToolbarPanel.Visible =
                    false;

                attachmentsListBox.Items.Clear();

                attachmentsListBox.Visible =
                    false;

                UpdateCommandState();

                /*
                 * ATTENZIONE:
                 * non tocchiamo rulesTreeView.
                 *
                 * La struttura a sinistra deve rimanere.
                 */
            }
            finally
            {
                _isLoadingEditor =
                    false;
            }
        }

        private void ApplyReadOnlyMode()
        {
            /*
             * ==========================================
             * TOOLBAR PRINCIPALE
             * ==========================================
             *
             * In Sola Lettura deve SPARIRE,
             * non diventare semplicemente disabilitata.
             */
            editToolbarPanel.Visible =
                !_isReadOnly;

            /*
             * ==========================================
             * STRUTTURA
             * ==========================================
             *
             * Deve SEMPRE rimanere visibile.
             *
             * L'utente deve poter:
             * - navigare;
             * - aprire/chiudere paragrafi;
             * - selezionare testi;
             * - consultare tutto.
             */
            bool treeIsEmpty =
                rulesTreeView.Nodes.Count == 0;

            rulesTreeView.Visible =
                !treeIsEmpty;

            emptyTreeLabel.Visible =
                treeIsEmpty;

            /*
             * ==========================================
             * TITOLO
             * ==========================================
             *
             * In Sola Lettura la barra di modifica
             * del titolo deve scomparire completamente.
             *
             * Il titolo resta comunque visibile
             * nella struttura a sinistra.
             */
            bool showTitleEditor =
                !_isReadOnly &&
                _selectedNode != null;

            titleEditorLabel.Visible =
                showTitleEditor;

            titleTextBox.Visible =
                showTitleEditor;

            titleTextBox.ReadOnly =
                _isReadOnly ||
                _selectedNode == null;

            /*
             * ==========================================
             * EDITOR TESTO
             * ==========================================
             */

            bool isTextSelected =
                _selectedNode?.IsText == true;

            /*
             * Il testo vero rimane SEMPRE visibile
             * se è selezionato un nodo Text.
             */
            contentRichTextBox.Visible =
                isTextSelected;

            contentRichTextBox.ReadOnly =
                _isReadOnly;

            /*
             * Toolbar formattazione:
             * sparisce completamente in Sola Lettura.
             */
            textFormatToolbarPanel.Visible =
                !_isReadOnly &&
                isTextSelected;

            /*
             * ==========================================
             * ALLEGATI
             * ==========================================
             */

            attachmentsLabel.Visible =
                isTextSelected;

            /*
             * La lista allegati resta consultabile
             * anche in Sola Lettura.
             */
            attachmentsListBox.Visible =
                isTextSelected;

            /*
             * Aggiungi/Rimuovi spariscono.
             */
            attachmentsToolbarPanel.Visible =
                !_isReadOnly &&
                isTextSelected;

            /*
             * Impostazioni rimane sempre accessibile.
             */
            settingsButton.Visible =
                true;

            UpdateCommandState();

            EditorPanel_Resize(
                editorPanel,
                EventArgs.Empty);
        }

        private void UpdateCommandState()
        {
            if (_isReadOnly)
                return;

            deleteParagraphButton.Enabled =
                _selectedNode?.IsParagraph == true;

            deleteTextButton.Enabled =
                _selectedNode?.IsText == true;

            moveUpButton.Enabled =
                _selectedNode != null;

            moveDownButton.Enabled =
                _selectedNode != null;
        }

        private void MarkUnsaved()
        {
            if (_isReadOnly ||
                _isLoading)
            {
                return;
            }

            _hasUnsavedChanges =
                true;

            UpdateSaveButtonState();
        }

        private void UpdateSaveButtonState()
        {
            saveButton.Enabled =
                !_isReadOnly &&
                _hasUnsavedChanges;
        }

        private void EditorPanel_Resize(
            object? sender,
            EventArgs e)
        {
            if (editorPanel == null ||
                contentRichTextBox == null ||
                attachmentsListBox == null ||
                attachmentsToolbarPanel == null ||
                attachmentsLabel == null)
            {
                return;
            }

            /*
             * Tutti gli elementi del pannello destro
             * devono avere lo stesso margine laterale.
             */
            const int leftMargin =
                18;

            const int rightMargin =
                18;

            int availableWidth =
                Math.Max(
                    100,
                    editorPanel.ClientSize.Width -
                    leftMargin -
                    rightMargin);

            /*
             * ==========================================
             * LARGHEZZA CONTROLLI
             * ==========================================
             */

            titleTextBox.Left =
                leftMargin;

            titleTextBox.Width =
                availableWidth;

            textFormatToolbarPanel.Left =
                leftMargin;

            textFormatToolbarPanel.Width =
                availableWidth;

            contentRichTextBox.Left =
                leftMargin;

            contentRichTextBox.Width =
                availableWidth;

            /*
             * IMPORTANTE:
             *
             * Allegati, toolbar allegati e RichTextBox
             * partono tutti dallo stesso identico punto.
             */
            attachmentsLabel.Left =
                leftMargin;

            attachmentsToolbarPanel.Left =
                leftMargin;

            attachmentsToolbarPanel.Width =
                availableWidth;

            attachmentsListBox.Left =
                leftMargin;

            attachmentsListBox.Width =
                availableWidth;

            /*
             * ==========================================
             * AREA ALLEGATI
             * ==========================================
             */

            int attachmentsListHeight;

            if (_isReadOnly)
            {
                /*
                 * SOLA LETTURA:
                 *
                 * + Aggiungi file / - Rimuovi non esistono
                 * visivamente.
                 *
                 * Recuperiamo quindi anche quello spazio
                 * aumentando l'area disponibile per
                 * consultare gli allegati.
                 */
                attachmentsListHeight =
                    135;
            }
            else
            {
                /*
                 * MODALITÀ NORMALE:
                 *
                 * Manteniamo esattamente l'altezza
                 * utilizzata fino ad ora.
                 */
                attachmentsListHeight =
                    95;
            }

            attachmentsListBox.Height =
                attachmentsListHeight;

            attachmentsListBox.Top =
                editorPanel.ClientSize.Height -
                attachmentsListHeight -
                18;

            /*
             * ==========================================
             * POSIZIONE INTESTAZIONE ALLEGATI
             * ==========================================
             */

            if (_isReadOnly)
            {
                /*
                 * Non c'è la toolbar degli allegati.
                 *
                 * L'etichetta si posiziona direttamente
                 * sopra alla lista.
                 */
                attachmentsLabel.Top =
                    attachmentsListBox.Top -
                    attachmentsLabel.Height -
                    8;
            }
            else
            {
                /*
                 * Layout normale:
                 *
                 * Allegati (x)
                 * [+ Aggiungi] [- Rimuovi]
                 * [lista]
                 */
                attachmentsToolbarPanel.Top =
                    attachmentsListBox.Top -
                    attachmentsToolbarPanel.Height -
                    6;

                attachmentsLabel.Top =
                    attachmentsToolbarPanel.Top -
                    attachmentsLabel.Height -
                    8;
            }

            /*
             * ==========================================
             * AREA TESTO
             * ==========================================
             */

            int contentTop;

            if (_isReadOnly)
            {
                /*
                 * SOLA LETTURA:
                 *
                 * sono spariti:
                 *
                 * - Titolo
                 * - casella modifica Titolo
                 * - toolbar B/I/U/S...
                 *
                 * Quindi il testo può partire quasi
                 * immediatamente sotto TESTO/PARAGRAFO.
                 */
                contentTop =
                    42;
            }
            else
            {
                /*
                 * MODALITÀ NORMALE:
                 *
                 * manteniamo il layout attuale.
                 */
                contentTop =
                    160;
            }

            int contentBottom;

            if (attachmentsListBox.Visible)
            {
                contentBottom =
                    attachmentsLabel.Top -
                    12;
            }
            else
            {
                contentBottom =
                    editorPanel.ClientSize.Height -
                    18;
            }

            contentRichTextBox.Top =
                contentTop;

            contentRichTextBox.Height =
                Math.Max(
                    80,
                    contentBottom -
                    contentTop);
        }

        private void AddParagraphButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly)
                return;

            RuleNode? insertionTarget =
                ResolveFirstLevelInsertionTarget(
                    "paragrafo");

            RuleNode newNode =
                _treeEditorService.AddParagraph(
                    _rootNodes,
                    insertionTarget);

            MarkUnsaved();

            RebuildTree();

            SelectRuleNode(
                newNode);
        }

        private void DeleteParagraphButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null ||
                !_selectedNode.IsParagraph)
            {
                return;
            }

            RuleNode nodeToDelete =
                _selectedNode;

            using var dialog =
                new DeleteRuleConfirmationForm(
                    nodeToDelete,
                    _isDarkTheme);

            DialogResult result =
                dialog.ShowDialog(
                    this);

            if (result !=
                    DialogResult.OK ||
                !dialog.DeleteConfirmed)
            {
                return;
            }

            RemoveSelectedNode(
                nodeToDelete);
        }

        private void AddTextButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly)
                return;

            RuleNode? insertionTarget =
                ResolveFirstLevelInsertionTarget(
                    "testo");

            RuleNode newNode =
                _treeEditorService.AddText(
                    _rootNodes,
                    insertionTarget);

            MarkUnsaved();

            RebuildTree();

            SelectRuleNode(
                newNode);
        }

        private void DeleteTextButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null ||
                !_selectedNode.IsText)
            {
                return;
            }

            RuleNode nodeToDelete =
                _selectedNode;

            using var dialog =
                new DeleteRuleConfirmationForm(
                    nodeToDelete,
                    _isDarkTheme);

            DialogResult result =
                dialog.ShowDialog(
                    this);

            if (result !=
                    DialogResult.OK ||
                !dialog.DeleteConfirmed)
            {
                return;
            }

            RemoveSelectedNode(
                nodeToDelete);
        }

        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null)
            {
                return;
            }

            RuleNode selected =
                _selectedNode;

            bool moved =
                _treeEditorService.MoveUp(
                    _rootNodes,
                    selected);

            if (!moved)
                return;

            MarkUnsaved();

            RebuildTree();

            SelectRuleNode(
                selected);
        }

        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly ||
                _selectedNode == null)
            {
                return;
            }

            RuleNode selected =
                _selectedNode;

            bool moved =
                _treeEditorService.MoveDown(
                    _rootNodes,
                    selected);

            if (!moved)
                return;

            MarkUnsaved();

            RebuildTree();

            SelectRuleNode(
                selected);
        }

        private async void SaveButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_isReadOnly ||
                !_hasUnsavedChanges ||
                _isLoading)
            {
                return;
            }

            RuleNode? invalidNode =
                FindFirstInvalidTitle(
                    _rootNodes);

            if (invalidNode != null)
            {
                MessageBox.Show(
                    this,
                    "Non è possibile salvare perché esiste un elemento senza titolo.\r\n\r\n" +
                    "Assegna un titolo prima di continuare.",
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                SelectRuleNode(
                    invalidNode);

                titleTextBox.Focus();

                return;
            }

            _isLoading =
                true;

            /*
             * Siamo ancora sicuramente sul thread UI.
             */
            UpdateSaveButtonState();

            try
            {
                using var saveLock =
                    new RuleSaveLockService();

                if (!saveLock.TryAcquire(
                        _rootPath,
                        out string lockError))
                {
                    RunOnUiThread(
                        () =>
                        {
                            MessageBox.Show(
                                this,
                                lockError,
                                "Regole di progettazione",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        });

                    return;
                }

                /*
                 * Controllo multiutente effettuato
                 * DOPO avere acquisito il lock.
                 */
                string currentSnapshot =
                    RuleStructureSnapshotService.CreateSnapshot(
                        _rootPath);

                if (!string.Equals(
                        currentSnapshot,
                        _loadedStructureSnapshot,
                        StringComparison.OrdinalIgnoreCase))
                {
                    RunOnUiThread(
                        () =>
                        {
                            MessageBox.Show(
                                this,
                                "Le Regole di progettazione sono state modificate da un altro utente.\r\n\r\n" +
                                "Qualcuno ha salvato delle modifiche dopo che hai aperto questa funzione.\r\n\r\n" +
                                "Per evitare di sovrascrivere o perdere informazioni, le tue modifiche NON sono state salvate.\r\n\r\n" +
                                "Prima di chiudere, copia in un file di Blocco note le modifiche che vuoi conservare.\r\n\r\n" +
                                "Successivamente chiudi e riapri \"Regole di progettazione\" per caricare la versione più recente e reinserisci le tue modifiche.",
                                "Versione non più aggiornata",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        });

                    return;
                }

                /*
                 * Da questo punto la continuazione potrebbe
                 * NON trovarsi più sul thread UI di WinForms.
                 */
                RuleSaveResult result =
                    await _saveService.SaveAsync(
                        _rootPath,
                        _rootNodes,
                        _pendingDeletedNodes);

                if (!result.Success)
                {
                    if (result.HasConflicts)
                    {
                        string conflictMessage =
                            "Le modifiche non sono state salvate perché sono stati rilevati conflitti:\r\n\r\n" +
                            string.Join(
                                "\r\n",
                                result.Conflicts.Select(
                                    x => "• " + x));

                        RunOnUiThread(
                            () =>
                            {
                                MessageBox.Show(
                                    this,
                                    conflictMessage,
                                    "Conflitto durante il salvataggio",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                            });

                        return;
                    }

                    string errorMessage =
                        "Non è stato possibile completare il salvataggio:\r\n\r\n" +
                        string.Join(
                            "\r\n",
                            result.Errors.Select(
                                x => "• " + x));

                    RunOnUiThread(
                        () =>
                        {
                            MessageBox.Show(
                                this,
                                errorMessage,
                                "Errore di salvataggio",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                        });

                    return;
                }

                /*
                 * Rilettura filesystem.
                 * Questa parte non deve toccare controlli WinForms.
                 */
                List<RuleNode> refreshed =
                    await _fileSystemService.LoadAsync(
                        _rootPath);

                string refreshedSnapshot =
                    RuleStructureSnapshotService.CreateSnapshot(
                        _rootPath);

                if (_externalChangesService?.HasClaim == true)
                {
                    try
                    {
                        _externalChangesService.CompleteRequest();
                    }
                    catch (Exception ex)
                    {
                        /*
                         * Le Regole sono già state salvate.
                         *
                         * Però NON fingiamo che anche la richiesta
                         * esterna sia stata chiusa correttamente.
                         */
                        MessageBox.Show(
                            this,
                            "Le modifiche alle Regole di progettazione sono state salvate correttamente.\r\n\r\n" +
                            "Non è stato però possibile chiudere e rigenerare il file \"File per aggiunta modifiche.txt\".\r\n\r\n" +
                            ex.Message,
                            "File aggiunta modifiche",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }

                /*
                 * SOLO ORA riportiamo tutto ciò che riguarda
                 * i controlli WinForms sul thread della UI.
                 */
                RunOnUiThread(
                    () =>
                    {
                        _rootNodes =
                            new System.Collections.ObjectModel.ObservableCollection<RuleNode>(
                                refreshed);

                        _loadedStructureSnapshot =
                            refreshedSnapshot;

                        _pendingDeletedNodes.Clear();

                        _selectedNode =
                            null;

                        _hasUnsavedChanges =
                            false;

                        RebuildTree();

                        ClearEditor();

                        ApplyReadOnlyMode();

                        UpdateSaveButtonState();

                        MessageBox.Show(
                            this,
                            BuildSaveSummary(
                                result),
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    });
            }
            catch (Exception ex)
            {
                /*
                 * Anche il MessageBox con owner è un'operazione UI.
                 */
                RunOnUiThread(
                    () =>
                    {
                        MessageBox.Show(
                            this,
                            ex.Message,
                            "Errore di salvataggio",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    });
            }
            finally
            {
                _isLoading =
                    false;

                /*
                 * UpdateSaveButtonState modifica un Button:
                 * deve sempre essere eseguito sul thread UI.
                 */
                RunOnUiThread(
                    () =>
                    {
                        UpdateSaveButtonState();
                    });
            }
        }

        private async void SettingsButton_Click(
            object? sender,
            EventArgs e)
        {
            using var settingsForm =
                new RegoleProgettazioneSettingsForm(
                    _settingsService,
                    _isDarkTheme);

            DialogResult result =
                settingsForm.ShowDialog(
                    this);

            if (result !=
                    DialogResult.OK ||
                !settingsForm.SettingsChanged)
            {
                return;
            }

            RuleSettings settings =
                _settingsService.Load();

            if (_hasUnsavedChanges)
            {
                MessageBox.Show(
                    this,
                    "Le impostazioni sono state salvate.\r\n\r\n" +
                    "Sono presenti modifiche non salvate nella struttura. " +
                    "Le nuove impostazioni verranno applicate alla prossima apertura della funzione.",
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            _rootPath =
                settings.RootPath;

            _isReadOnly =
                settings.IsReadOnly;

            ApplyReadOnlyMode();

            await LoadStructureAsync();
        }

        private static RuleNode?
    FindFirstInvalidTitle(
        IEnumerable<RuleNode> nodes)
        {
            foreach (RuleNode node
                     in nodes)
            {
                if (string.IsNullOrWhiteSpace(
                        node.Title))
                {
                    return node;
                }

                RuleNode? invalidChild =
                    FindFirstInvalidTitle(
                        node.Children);

                if (invalidChild != null)
                    return invalidChild;
            }

            return null;
        }
        private static string BuildSaveSummary(
    RuleSaveResult result)
        {
            List<string> lines =
                new List<string>
                {
            "Modifiche salvate correttamente."
                };

            if (result.CreatedItems > 0)
            {
                lines.Add(
                    $"Elementi creati: {result.CreatedItems}");
            }

            if (result.ModifiedItems > 0)
            {
                lines.Add(
                    $"Elementi modificati: {result.ModifiedItems}");
            }

            if (result.MovedItems > 0)
            {
                lines.Add(
                    $"Elementi spostati/rinominati: {result.MovedItems}");
            }

            if (result.DeletedItems > 0)
            {
                lines.Add(
                    $"Elementi eliminati: {result.DeletedItems}");
            }

            if (result.AddedAttachments > 0)
            {
                lines.Add(
                    $"Allegati aggiunti: {result.AddedAttachments}");
            }

            if (result.DeletedAttachments > 0)
            {
                lines.Add(
                    $"Allegati eliminati: {result.DeletedAttachments}");
            }

            return string.Join(
                "\r\n",
                lines);
        }

        private void TitleTextBox_TextChanged(
            object? sender,
            EventArgs e)
        {
            if (_isLoading ||
                _isLoadingEditor ||
                _isReadOnly ||
                _selectedNode == null)
            {
                return;
            }

            string newTitle =
                titleTextBox.Text;

            if (_selectedNode.Title ==
                newTitle)
            {
                return;
            }

            _selectedNode.Title =
                newTitle;

            /*
             * Aggiorniamo immediatamente il titolo
             * visualizzato nel TreeView.
             */
            TreeNode? selectedTreeNode =
                FindTreeNode(
                    _selectedNode);

            if (selectedTreeNode != null)
            {
                selectedTreeNode.Text =
                    newTitle;
            }

            MarkUnsaved();
        }

        private void ContentRichTextBox_TextChanged(
            object? sender,
            EventArgs e)
        {
            SyncHtmlFromEditor();
        }

        private void RemoveSelectedNode(
    RuleNode node)
        {
            bool mustDeleteFromDisk =
                _treeEditorService.RemoveNode(
                    _rootNodes,
                    node);

            /*
             * Se il nodo esisteva già quando abbiamo
             * aperto la funzione, dobbiamo ricordarci
             * di eliminarlo fisicamente solo al salvataggio.
             */
            if (mustDeleteFromDisk)
            {
                MarkDeletedRecursive(
                    node);

                _pendingDeletedNodes.Add(
                    node);
            }

            /*
             * Se invece era Added, non esiste ancora
             * su Windows.
             *
             * È sufficiente eliminarlo dalla struttura
             * temporanea.
             */

            _selectedNode =
                null;

            MarkUnsaved();

            RebuildTree();

            ClearEditor();
        }
        private static void MarkDeletedRecursive(
    RuleNode node)
        {
            node.State =
                RuleNodeState.Deleted;

            foreach (RuleNode child
                     in node.Children)
            {
                MarkDeletedRecursive(
                    child);
            }

            foreach (RuleAttachment attachment
                     in node.Attachments)
            {
                attachment.State =
                    RuleNodeState.Deleted;
            }
        }

        private void SelectRuleNode(
    RuleNode ruleNode)
        {
            TreeNode? treeNode =
                FindTreeNode(
                    ruleNode);

            if (treeNode == null)
                return;

            /*
             * Apriamo tutti i genitori così
             * l'elemento è sicuramente visibile.
             */
            TreeNode? parent =
                treeNode.Parent;

            while (parent != null)
            {
                parent.Expand();

                parent =
                    parent.Parent;
            }

            rulesTreeView.SelectedNode =
                treeNode;

            treeNode.EnsureVisible();

            rulesTreeView.Focus();
        }

        private TreeNode? FindTreeNode(
    RuleNode ruleNode)
        {
            foreach (TreeNode root
                     in rulesTreeView.Nodes)
            {
                TreeNode? found =
                    FindTreeNodeRecursive(
                        root,
                        ruleNode);

                if (found != null)
                    return found;
            }

            return null;
        }

        private static TreeNode?
    FindTreeNodeRecursive(
        TreeNode treeNode,
        RuleNode ruleNode)
        {
            if (ReferenceEquals(
                    treeNode.Tag,
                    ruleNode))
            {
                return treeNode;
            }

            foreach (TreeNode child
                     in treeNode.Nodes)
            {
                TreeNode? found =
                    FindTreeNodeRecursive(
                        child,
                        ruleNode);

                if (found != null)
                    return found;
            }

            return null;
        }

        private static int CountParagraphs(
            RuleNode node)
        {
            int count = 0;

            foreach (RuleNode child
                     in node.Children)
            {
                if (child.IsParagraph)
                {
                    count++;
                }

                count +=
                    CountParagraphs(
                        child);
            }

            return count;
        }

        private static int CountTexts(
    RuleNode node)
        {
            int count = 0;

            foreach (RuleNode child
                     in node.Children)
            {
                if (child.IsText)
                {
                    count++;
                }

                count +=
                    CountTexts(
                        child);
            }

            return count;
        }

        private static int CountAttachments(
    RuleNode node)
        {
            int count =
                node.Attachments.Count;

            foreach (RuleNode child
                     in node.Children)
            {
                count +=
                    CountAttachments(
                        child);
            }

            return count;
        }

        private void RefreshAttachmentsList()
        {
            attachmentsListBox
                .BeginUpdate();

            try
            {
                attachmentsListBox
                    .Items
                    .Clear();

                if (_selectedNode?.IsText != true)
                    return;

                foreach (RuleAttachment attachment
                         in _selectedNode
                             .Attachments
                             .OrderBy(
                                 x => x.FileName,
                                 StringComparer.OrdinalIgnoreCase))
                {
                    attachmentsListBox
                        .Items
                        .Add(
                            attachment);
                }

                attachmentsListBox.DisplayMember =
                    nameof(
                        RuleAttachment.FileName);
            }
            finally
            {
                attachmentsListBox
                    .EndUpdate();
            }
                        int count =
                _selectedNode?.Attachments.Count ?? 0;

                        attachmentsLabel.Text =
                            count == 1
                                ? "Allegati (1)"
                                : $"Allegati ({count})";
        }

        private void AttachmentsListBox_DoubleClick(
    object? sender,
    EventArgs e)
        {
            if (attachmentsListBox.SelectedItem
                is not RuleAttachment attachment)
            {
                return;
            }

            string path =
                attachment.DisplayPath;

            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return;
            }

            if (!File.Exists(
                    path))
            {
                MessageBox.Show(
                    this,
                    "L'allegato non è disponibile:\r\n\r\n" +
                    path,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            try
            {
                Process.Start(
                    new ProcessStartInfo
                    {
                        FileName =
                            path,

                        UseShellExecute =
                            true
                    });
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Non è stato possibile aprire l'allegato.\r\n\r\n" +
                    ex.Message,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void RegoleProgettazioneForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "RegoleProgettazione");

            if (_hasUnsavedChanges)
            {
                DialogResult result =
                    MessageBox.Show(
                        this,
                        "Sono presenti modifiche non salvate.\r\n\r\n" +
                        "Chiudendo la funzione verranno perse.\r\n\r\n" +
                        "Vuoi uscire senza salvare?",
                        "Regole di progettazione",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                if (result !=
                    DialogResult.Yes)
                {
                    e.Cancel =
                        true;
                }
            }

            /*
             * Se l'utente ha scelto di NON chiudere,
             * non tocchiamo il TXT e manteniamo il claim.
             */
            if (e.Cancel)
                return;

            /*
             * La finestra si sta chiudendo realmente.
             *
             * Se avevamo preso in carico un TXT ma
             * NON era stato completato tramite Salva Modifiche:
             *
             * - non cancelliamo il TXT;
             * - non lo svuotiamo;
             * - chiudiamo l'editor aperto dalla sessione;
             * - liberiamo il claim.
             *
             * Al prossimo avvio potrà essere preso
             * nuovamente in carico.
             */
            _externalChangesService?
                .CancelRequestHandling();
        }
        private RuleNode? ResolveFirstLevelInsertionTarget(
    string elementType)
        {
            /*
             * Nessuna selezione:
             * manteniamo il comportamento già esistente.
             *
             * Il nuovo elemento viene creato alla radice.
             */
            if (_selectedNode == null)
            {
                return null;
            }

            /*
             * La domanda speciale deve comparire
             * SOLAMENTE quando è selezionato un elemento
             * del primo livello.
             *
             * Parent == null significa che il nodo
             * si trova direttamente nella cartella radice.
             */
            if (_selectedNode.Parent != null)
            {
                return _selectedNode;
            }

            /*
             * Questa scelta ha senso come "entra dentro"
             * solamente se il nodo selezionato è un paragrafo.
             *
             * Un testo non può contenere figli.
             */
            if (!_selectedNode.IsParagraph)
            {
                return null;
            }

            DialogResult result =
                MessageBox.Show(
                    this,
                    $"Vuoi inserire il nuovo {elementType} allo stesso livello di quello selezionato?\r\n\r\n" +
                    "SÌ = stesso primo livello\r\n" +
                    "NO = all'interno del paragrafo selezionato",
                    "Regole di progettazione",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

            if (result ==
                DialogResult.Yes)
            {
                /*
                 * Passando null al TreeEditorService
                 * il nuovo elemento viene creato
                 * direttamente alla radice.
                 */
                return null;
            }

            /*
             * Manteniamo il nodo selezionato:
             * il comportamento normale del servizio
             * inserirà il nuovo elemento al suo interno.
             */
            return _selectedNode;
        }
    }
}