﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class WinFormsHtmlRichTextService
    {
        public static void LoadHtml(
            RichTextBox richTextBox,
            string? html)
        {
            richTextBox.Clear();

            if (string.IsNullOrWhiteSpace(html))
                return;

            try
            {
                string normalized =
                    html.Replace(
                        "&nbsp;",
                        "&#160;",
                        StringComparison.OrdinalIgnoreCase);

                XDocument document =
                    XDocument.Parse(
                        "<root>" +
                        normalized +
                        "</root>",
                        LoadOptions.PreserveWhitespace);

                if (document.Root == null)
                    return;

                foreach (XNode node
                         in document.Root.Nodes())
                {
                    AppendBlockNode(
                        richTextBox,
                        node);
                }

                /*
                 * Evitiamo un ritorno a capo vuoto
                 * supplementare alla fine.
                 */
                richTextBox.Text =
                    richTextBox.Text
                        .TrimEnd('\r', '\n');
            }
            catch
            {
                /*
                 * Se il file HTML è stato modificato
                 * manualmente e contiene sintassi non valida,
                 * mostriamo almeno il testo leggibile.
                 */
                string plainText =
                    Regex.Replace(
                        html,
                        "<[^>]+>",
                        string.Empty);

                richTextBox.Text =
                    WebUtility.HtmlDecode(
                        plainText);
            }
        }

        public static string ToHtml(
            RichTextBox richTextBox)
        {
            if (richTextBox.TextLength == 0)
                return string.Empty;

            var builder =
                new StringBuilder();

            string[] lines =
                richTextBox.Lines;

            bool inBulletList =
                false;

            bool inNumberList =
                false;

            int globalPosition =
                0;

            for (int lineIndex = 0;
                 lineIndex < lines.Length;
                 lineIndex++)
            {
                string line =
                    lines[lineIndex];

                bool isBullet =
                    line.StartsWith(
                        "• ",
                        StringComparison.Ordinal);

                bool isNumber =
                    Regex.IsMatch(
                        line,
                        @"^\d+\.\s");

                if (isBullet)
                {
                    if (inNumberList)
                    {
                        builder.AppendLine(
                            "</ol>");

                        inNumberList =
                            false;
                    }

                    if (!inBulletList)
                    {
                        builder.AppendLine(
                            "<ul>");

                        inBulletList =
                            true;
                    }

                    string content =
                        line.Length >= 2
                            ? line[2..]
                            : string.Empty;

                    int contentOffset =
                        globalPosition +
                        Math.Min(
                            2,
                            line.Length);

                    builder.Append(
                        "<li>");

                    builder.Append(
                        BuildFormattedLine(
                            richTextBox,
                            contentOffset,
                            content.Length));

                    builder.AppendLine(
                        "</li>");
                }
                else if (isNumber)
                {
                    if (inBulletList)
                    {
                        builder.AppendLine(
                            "</ul>");

                        inBulletList =
                            false;
                    }

                    if (!inNumberList)
                    {
                        builder.AppendLine(
                            "<ol>");

                        inNumberList =
                            true;
                    }

                    Match match =
                        Regex.Match(
                            line,
                            @"^(?<prefix>\d+\.\s)(?<content>.*)$");

                    string prefix =
                        match.Groups["prefix"].Value;

                    string content =
                        match.Groups["content"].Value;

                    int contentOffset =
                        globalPosition +
                        prefix.Length;

                    builder.Append(
                        "<li>");

                    builder.Append(
                        BuildFormattedLine(
                            richTextBox,
                            contentOffset,
                            content.Length));

                    builder.AppendLine(
                        "</li>");
                }
                else
                {
                    if (inBulletList)
                    {
                        builder.AppendLine(
                            "</ul>");

                        inBulletList =
                            false;
                    }

                    if (inNumberList)
                    {
                        builder.AppendLine(
                            "</ol>");

                        inNumberList =
                            false;
                    }

                    HorizontalAlignment alignment =
                        GetParagraphAlignment(
                            richTextBox,
                            globalPosition);

                    string alignmentText =
                        alignment switch
                        {
                            HorizontalAlignment.Center =>
                                "center",

                            HorizontalAlignment.Right =>
                                "right",

                            _ =>
                                "left"
                        };

                    builder.Append(
                        $"<p style=\"text-align:{alignmentText};\">");

                    builder.Append(
                        BuildFormattedLine(
                            richTextBox,
                            globalPosition,
                            line.Length));

                    builder.AppendLine(
                        "</p>");
                }

                /*
                 * RichTextBox usa normalmente un carattere
                 * \n tra le righe.
                 */
                globalPosition +=
                    line.Length;

                if (lineIndex <
                    lines.Length - 1)
                {
                    globalPosition++;
                }
            }

            if (inBulletList)
            {
                builder.AppendLine(
                    "</ul>");
            }

            if (inNumberList)
            {
                builder.AppendLine(
                    "</ol>");
            }

            return builder
                .ToString()
                .Trim();
        }

        private static void AppendBlockNode(
            RichTextBox richTextBox,
            XNode node)
        {
            if (node is XText textNode)
            {
                string text =
                    textNode.Value;

                if (!string.IsNullOrWhiteSpace(text))
                {
                    AppendText(
                        richTextBox,
                        text,
                        new TextFormat());
                }

                return;
            }

            if (node is not XElement element)
                return;

            string tag =
                element.Name.LocalName
                    .ToLowerInvariant();

            switch (tag)
            {
                case "p":
                case "div":
                    {
                        int start =
                            richTextBox.TextLength;

                        AppendInlineContainer(
                            richTextBox,
                            element,
                            new TextFormat());

                        ApplyAlignment(
                            richTextBox,
                            start,
                            richTextBox.TextLength - start,
                            GetElementAlignment(
                                element));

                        AppendNewLine(
                            richTextBox);

                        break;
                    }

                case "ul":
                    {
                        foreach (XElement item
                                 in element.Elements()
                                     .Where(
                                         x =>
                                             string.Equals(
                                                 x.Name.LocalName,
                                                 "li",
                                                 StringComparison.OrdinalIgnoreCase)))
                        {
                            AppendText(
                                richTextBox,
                                "• ",
                                new TextFormat());

                            AppendInlineContainer(
                                richTextBox,
                                item,
                                new TextFormat());

                            AppendNewLine(
                                richTextBox);
                        }

                        break;
                    }

                case "ol":
                    {
                        int number =
                            1;

                        foreach (XElement item
                                 in element.Elements()
                                     .Where(
                                         x =>
                                             string.Equals(
                                                 x.Name.LocalName,
                                                 "li",
                                                 StringComparison.OrdinalIgnoreCase)))
                        {
                            AppendText(
                                richTextBox,
                                $"{number}. ",
                                new TextFormat());

                            AppendInlineContainer(
                                richTextBox,
                                item,
                                new TextFormat());

                            AppendNewLine(
                                richTextBox);

                            number++;
                        }

                        break;
                    }

                case "br":
                    {
                        AppendNewLine(
                            richTextBox);

                        break;
                    }

                default:
                    {
                        AppendInlineContainer(
                            richTextBox,
                            element,
                            new TextFormat());

                        AppendNewLine(
                            richTextBox);

                        break;
                    }
            }
        }

        private static void AppendInlineContainer(
            RichTextBox richTextBox,
            XElement container,
            TextFormat parentFormat)
        {
            foreach (XNode child
                     in container.Nodes())
            {
                AppendInlineNode(
                    richTextBox,
                    child,
                    parentFormat);
            }
        }

        private static void AppendInlineNode(
            RichTextBox richTextBox,
            XNode node,
            TextFormat parentFormat)
        {
            if (node is XText textNode)
            {
                AppendText(
                    richTextBox,
                    textNode.Value,
                    parentFormat);

                return;
            }

            if (node is not XElement element)
                return;

            string tag =
                element.Name.LocalName
                    .ToLowerInvariant();

            if (tag == "br")
            {
                AppendNewLine(
                    richTextBox);

                return;
            }

            TextFormat format =
                parentFormat.Clone();

            switch (tag)
            {
                case "strong":
                case "b":
                    format.Bold =
                        true;
                    break;

                case "em":
                case "i":
                    format.Italic =
                        true;
                    break;

                case "u":
                    format.Underline =
                        true;
                    break;

                case "s":
                case "strike":
                    format.Strikeout =
                        true;
                    break;
            }

            ApplyStyleAttribute(
                element,
                format);

            foreach (XNode child
                     in element.Nodes())
            {
                AppendInlineNode(
                    richTextBox,
                    child,
                    format);
            }
        }

        private static void AppendText(
            RichTextBox richTextBox,
            string text,
            TextFormat format)
        {
            if (string.IsNullOrEmpty(text))
                return;

            int start =
                richTextBox.TextLength;

            richTextBox.AppendText(
                WebUtility.HtmlDecode(
                    text));

            int length =
                richTextBox.TextLength -
                start;

            if (length <= 0)
                return;

            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                start,
                length);

            Font baseFont =
                richTextBox.Font ??
                new Font(
                    "Segoe UI",
                    10F);

            FontStyle style =
                FontStyle.Regular;

            if (format.Bold)
                style |= FontStyle.Bold;

            if (format.Italic)
                style |= FontStyle.Italic;

            if (format.Underline)
                style |= FontStyle.Underline;

            if (format.Strikeout)
                style |= FontStyle.Strikeout;

            float size =
                format.FontSize ??
                baseFont.Size;

            try
            {
                richTextBox.SelectionFont =
                    new Font(
                        baseFont.FontFamily,
                        Math.Max(
                            6F,
                            size),
                        style);
            }
            catch
            {
                // Se un font particolare non accetta
                // una combinazione, manteniamo quello base.
            }

            if (format.Color.HasValue)
            {
                richTextBox.SelectionColor =
                    format.Color.Value;
            }

            richTextBox.Select(
                oldStart,
                oldLength);
        }

        private static void AppendNewLine(
            RichTextBox richTextBox)
        {
            if (richTextBox.TextLength == 0)
                return;

            if (!richTextBox.Text.EndsWith(
                    "\n",
                    StringComparison.Ordinal))
            {
                richTextBox.AppendText(
                    Environment.NewLine);
            }
        }

        private static void ApplyAlignment(
            RichTextBox richTextBox,
            int start,
            int length,
            HorizontalAlignment alignment)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                start,
                Math.Max(
                    0,
                    length));

            richTextBox.SelectionAlignment =
                alignment;

            richTextBox.Select(
                oldStart,
                oldLength);
        }

        private static HorizontalAlignment
            GetElementAlignment(
                XElement element)
        {
            string style =
                element
                    .Attribute("style")
                    ?.Value ??
                string.Empty;

            string? value =
                GetCssValue(
                    style,
                    "text-align");

            return value?.ToLowerInvariant() switch
            {
                "center" =>
                    HorizontalAlignment.Center,

                "right" =>
                    HorizontalAlignment.Right,

                _ =>
                    HorizontalAlignment.Left
            };
        }

        private static void ApplyStyleAttribute(
            XElement element,
            TextFormat format)
        {
            string style =
                element
                    .Attribute("style")
                    ?.Value ??
                string.Empty;

            string? fontWeight =
                GetCssValue(
                    style,
                    "font-weight");

            if (string.Equals(
                    fontWeight,
                    "bold",
                    StringComparison.OrdinalIgnoreCase) ||
                fontWeight == "700")
            {
                format.Bold =
                    true;
            }

            string? fontStyle =
                GetCssValue(
                    style,
                    "font-style");

            if (string.Equals(
                    fontStyle,
                    "italic",
                    StringComparison.OrdinalIgnoreCase))
            {
                format.Italic =
                    true;
            }

            string? decoration =
                GetCssValue(
                    style,
                    "text-decoration");

            if (!string.IsNullOrWhiteSpace(
                    decoration))
            {
                if (decoration.Contains(
                        "underline",
                        StringComparison.OrdinalIgnoreCase))
                {
                    format.Underline =
                        true;
                }

                if (decoration.Contains(
                        "line-through",
                        StringComparison.OrdinalIgnoreCase))
                {
                    format.Strikeout =
                        true;
                }
            }

            string? colorValue =
                GetCssValue(
                    style,
                    "color");

            if (!string.IsNullOrWhiteSpace(
                    colorValue))
            {
                try
                {
                    format.Color =
                        ColorTranslator.FromHtml(
                            colorValue);
                }
                catch
                {
                    // Colore non valido: ignoriamo.
                }
            }

            string? fontSize =
                GetCssValue(
                    style,
                    "font-size");

            if (!string.IsNullOrWhiteSpace(
                    fontSize))
            {
                format.FontSize =
                    ParseFontSize(
                        fontSize);
            }
        }

        private static string BuildFormattedLine(
            RichTextBox richTextBox,
            int start,
            int length)
        {
            if (length <= 0)
                return string.Empty;

            var builder =
                new StringBuilder();

            TextStyle? currentStyle =
                null;

            var currentText =
                new StringBuilder();

            for (int index = 0;
                 index < length;
                 index++)
            {
                int charPosition =
                    start +
                    index;

                if (charPosition >=
                    richTextBox.TextLength)
                {
                    break;
                }

                TextStyle style =
                    GetCharacterStyle(
                        richTextBox,
                        charPosition);

                if (currentStyle == null ||
                    !currentStyle.Equals(style))
                {
                    if (currentStyle != null)
                    {
                        AppendStyledText(
                            builder,
                            currentText.ToString(),
                            currentStyle);
                    }

                    currentStyle =
                        style;

                    currentText.Clear();
                }

                currentText.Append(
                    richTextBox.Text[
                        charPosition]);
            }

            if (currentStyle != null &&
                currentText.Length > 0)
            {
                AppendStyledText(
                    builder,
                    currentText.ToString(),
                    currentStyle);
            }

            return builder.ToString();
        }

        private static TextStyle GetCharacterStyle(
            RichTextBox richTextBox,
            int position)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            richTextBox.Select(
                position,
                1);

            Font font =
                richTextBox.SelectionFont ??
                richTextBox.Font;

            Color color =
                richTextBox.SelectionColor;

            var result =
                new TextStyle
                {
                    Bold =
                        font?.Bold ?? false,

                    Italic =
                        font?.Italic ?? false,

                    Underline =
                        font?.Underline ?? false,

                    Strikeout =
                        font?.Strikeout ?? false,

                    Size =
                        font?.Size ??
                        richTextBox.Font.Size,

                    Color =
                        color
                };

            richTextBox.Select(
                oldStart,
                oldLength);

            return result;
        }

        private static HorizontalAlignment
            GetParagraphAlignment(
                RichTextBox richTextBox,
                int position)
        {
            int oldStart =
                richTextBox.SelectionStart;

            int oldLength =
                richTextBox.SelectionLength;

            if (richTextBox.TextLength > 0)
            {
                int safePosition =
                    Math.Min(
                        Math.Max(
                            position,
                            0),
                        richTextBox.TextLength - 1);

                richTextBox.Select(
                    safePosition,
                    0);
            }

            HorizontalAlignment alignment =
                richTextBox.SelectionAlignment;

            richTextBox.Select(
                oldStart,
                oldLength);

            return alignment;
        }

        private static void AppendStyledText(
            StringBuilder builder,
            string text,
            TextStyle style)
        {
            string encoded =
                WebUtility.HtmlEncode(
                    text);

            var css =
                new StringBuilder();

            if (style.Bold)
            {
                css.Append(
                    "font-weight:bold;");
            }

            if (style.Italic)
            {
                css.Append(
                    "font-style:italic;");
            }

            if (style.Underline ||
                style.Strikeout)
            {
                css.Append(
                    "text-decoration:");

                if (style.Underline)
                    css.Append("underline ");

                if (style.Strikeout)
                    css.Append("line-through");

                css.Append(';');
            }

            css.Append(
                $"font-size:{style.Size.ToString("0.##", CultureInfo.InvariantCulture)}pt;");

            css.Append(
                $"color:#{style.Color.R:X2}{style.Color.G:X2}{style.Color.B:X2};");

            builder.Append(
                "<span style=\"");

            builder.Append(
                css);

            builder.Append(
                "\">");

            builder.Append(
                encoded);

            builder.Append(
                "</span>");
        }

        private static string? GetCssValue(
            string style,
            string propertyName)
        {
            foreach (string declaration
                     in style.Split(
                         ';',
                         StringSplitOptions.RemoveEmptyEntries))
            {
                string[] parts =
                    declaration.Split(
                        ':',
                        2);

                if (parts.Length != 2)
                    continue;

                if (!string.Equals(
                        parts[0].Trim(),
                        propertyName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                return parts[1].Trim();
            }

            return null;
        }

        private static float? ParseFontSize(
            string value)
        {
            string cleaned =
                value
                    .Trim()
                    .ToLowerInvariant();

            if (cleaned.EndsWith(
                    "pt",
                    StringComparison.Ordinal))
            {
                cleaned =
                    cleaned[..^2];
            }
            else if (cleaned.EndsWith(
                         "px",
                         StringComparison.Ordinal))
            {
                cleaned =
                    cleaned[..^2];

                if (float.TryParse(
                        cleaned,
                        NumberStyles.Float,
                        CultureInfo.InvariantCulture,
                        out float pixels))
                {
                    return pixels * 72F / 96F;
                }
            }

            if (float.TryParse(
                    cleaned,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out float result))
            {
                return result;
            }

            return null;
        }

        private sealed class TextFormat
        {
            public bool Bold { get; set; }

            public bool Italic { get; set; }

            public bool Underline { get; set; }

            public bool Strikeout { get; set; }

            public float? FontSize { get; set; }

            public Color? Color { get; set; }

            public TextFormat Clone()
            {
                return new TextFormat
                {
                    Bold =
                        Bold,

                    Italic =
                        Italic,

                    Underline =
                        Underline,

                    Strikeout =
                        Strikeout,

                    FontSize =
                        FontSize,

                    Color =
                        Color
                };
            }
        }

        private sealed class TextStyle :
            IEquatable<TextStyle>
        {
            public bool Bold { get; set; }

            public bool Italic { get; set; }

            public bool Underline { get; set; }

            public bool Strikeout { get; set; }

            public float Size { get; set; }

            public Color Color { get; set; }

            public bool Equals(
                TextStyle? other)
            {
                if (other == null)
                    return false;

                return
                    Bold == other.Bold &&
                    Italic == other.Italic &&
                    Underline == other.Underline &&
                    Strikeout == other.Strikeout &&
                    Math.Abs(
                        Size -
                        other.Size) <
                    0.01F &&
                    Color.ToArgb() ==
                    other.Color.ToArgb();
            }

            public override bool Equals(
                object? obj)
            {
                return Equals(
                    obj as TextStyle);
            }

            public override int GetHashCode()
            {
                return HashCode.Combine(
                    Bold,
                    Italic,
                    Underline,
                    Strikeout,
                    Size,
                    Color.ToArgb());
            }
        }
    }
}