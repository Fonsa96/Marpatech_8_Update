﻿using Marpatech_8.Features.RegoleProgettazione.Forms;
using Marpatech_8.Features.RegoleProgettazione.Models;
using System;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class RegoleProgettazioneLauncher
    {
        private static RegoleProgettazioneForm?
            _currentForm;

        private static Form?
            _dashboardForm;

        private static RuleExternalChangesService?
    _externalChangesService;

        public static void Open(
            Form owner,
            bool isDarkTheme)
        {
            /*
             * ==========================================
             * 1. FUNZIONE GIÀ APERTA
             * ==========================================
             *
             * Non permettiamo più istanze contemporanee
             * della funzione sullo stesso PC.
             */

            _dashboardForm =
                 owner;

            if (_currentForm != null &&
                !_currentForm.IsDisposed)
            {
                if (_currentForm.WindowState ==
                    FormWindowState.Minimized)
                {
                    _currentForm.WindowState =
                        FormWindowState.Normal;
                }

                _currentForm.Show();

                _currentForm.BringToFront();

                _currentForm.Activate();

                return;
            }

            var settingsService =
                new RuleSettingsService();

            RuleSettings settings =
                settingsService.Load();

            /*
             * ==========================================
             * 2. PRIMO AVVIO
             * ==========================================
             *
             * Nessun percorso impostato:
             * apriamo automaticamente Impostazioni.
             */
            if (string.IsNullOrWhiteSpace(
                    settings.RootPath))
            {
                bool configured =
                    ShowSettings(
                        owner,
                        settingsService,
                        isDarkTheme,
                        forcePathEditing: true);

                if (!configured)
                    return;

                settings =
                    settingsService.Load();
            }

            /*
             * ==========================================
             * 3. PERCORSO NON DISPONIBILE
             * ==========================================
             *
             * Una cartella VUOTA è valida.
             * Qui verifichiamo soltanto che la cartella
             * esista e sia raggiungibile.
             */
            if (!Directory.Exists(
                    settings.RootPath))
            {
                DialogResult result =
                    MessageBox.Show(
                        owner,
                        "La cartella configurata per le Regole di progettazione non è disponibile:\r\n\r\n" +
                        settings.RootPath +
                        "\r\n\r\nVuoi aprire le Impostazioni per selezionare un altro percorso?",
                        "Regole di progettazione",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                if (result !=
                    DialogResult.Yes)
                {
                    return;
                }

                bool configured =
                    ShowSettings(
                        owner,
                        settingsService,
                        isDarkTheme,
                        forcePathEditing: true);

                if (!configured)
                    return;

                settings =
                    settingsService.Load();

                if (string.IsNullOrWhiteSpace(
                        settings.RootPath) ||
                    !Directory.Exists(
                        settings.RootPath))
                {
                    return;
                }
            }

            bool externalChangesClaimed =
           false;

            _externalChangesService =
                null;

            /*
             * Il sistema del file
             * "File per aggiunta modifiche.txt"
             * funziona SOLO quando la funzione
             * NON è in Sola Lettura.
             */
            if (!settings.IsReadOnly)
            {
                RuleExternalChangesService.EnsureRequestFile(
                    settings.RootPath);

                bool hasExternalChanges =
                    RuleExternalChangesService.HasPendingChanges(
                        settings.RootPath);

                if (hasExternalChanges)
                {
                    _externalChangesService =
                        new RuleExternalChangesService();

                    externalChangesClaimed =
                        _externalChangesService.TryClaim(
                            settings.RootPath);

                    if (!externalChangesClaimed)
                    {
                        _externalChangesService.Dispose();

                        _externalChangesService =
                            null;

                        MessageBox.Show(
                            owner,
                            "File già aperto in un altro PC.\r\n\r\n" +
                            "La modifica è già stata presa in carico.",
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(
                            owner,
                            "ATTENZIONE\r\n\r\n" +
                            "Qualcuno ha modificato il file di aggiunta regole.\r\n\r\n" +
                            "Il file sarà aperto per permettere l'aggiunta dei dati alla funzione.",
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }

            /*
             * ==========================================
             * 4. APERTURA DEL FORM PRINCIPALE
             * ==========================================
             */
            try
            {
                var form =
                  new RegoleProgettazioneForm(
                      settings.RootPath,
                      settings.IsReadOnly,
                      isDarkTheme,
                      _externalChangesService);

                _currentForm =
                    form;

                form.FormClosed +=
                    CurrentForm_FormClosed;

                /*
                 * Show(owner), non ShowDialog().
                 *
                 * In questo modo la funzione rimane una
                 * finestra normale dell'Addin e non blocca
                 * completamente la Main Dashboard.
                 */
                /*
                 * Nascondiamo la Main Dashboard
                 * mentre Regole di progettazione è aperta.
                 */
                owner.Hide();

                form.Show(owner);

                form.BringToFront();

                form.Activate();

                form.Focus();

                if (externalChangesClaimed &&
                   _externalChangesService != null)
                {
                    _externalChangesService.OpenRequestFile();
                }
            }
            catch (Exception ex)
            {
                _currentForm =
                    null;

                MessageBox.Show(
                    owner,
                    "Non è stato possibile aprire Regole di progettazione.\r\n\r\n" +
                    ex.Message,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private static bool ShowSettings(
            Form owner,
            RuleSettingsService settingsService,
            bool isDarkTheme,
            bool forcePathEditing)
        {
            try
            {
                using var settingsForm =
                    new RegoleProgettazioneSettingsForm(
                        settingsService,
                        isDarkTheme,
                        forcePathEditing);

                DialogResult result =
                    settingsForm.ShowDialog(
                        owner);

                return
                    result ==
                        DialogResult.OK &&
                    settingsForm.SettingsChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    owner,
                    "Non è stato possibile aprire le Impostazioni di Regole di progettazione.\r\n\r\n" +
                    ex.Message,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return false;
            }
        }

        private static void CurrentForm_FormClosed(
            object? sender,
            FormClosedEventArgs e)
        {
            if (_currentForm != null)
            {
                _currentForm.FormClosed -=
                    CurrentForm_FormClosed;
            }

            _currentForm =
                null;

            /*
             * Quando Regole di progettazione viene chiusa,
             * rendiamo nuovamente visibile la Main Dashboard.
             */
            if (_dashboardForm != null &&
                !_dashboardForm.IsDisposed)
            {
                _dashboardForm.Show();

                if (_dashboardForm.WindowState ==
                    FormWindowState.Minimized)
                {
                    _dashboardForm.WindowState =
                        FormWindowState.Normal;
                }

                _dashboardForm.BringToFront();

                _dashboardForm.Activate();
            }

            _dashboardForm =
                null;
        }
    }
}