﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Marpatech_8.Features.Updater;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using Marpatech_8.Features.Settings.Services;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

namespace Marpatech_8.Features.Settings
{
    public class SettingsDashboardForm : Form
    {
        private readonly bool _isDarkTheme;
        private Button? btnUpdate;
        private readonly CoreWindowSettings _windowSettings;

        private FlowLayoutPanel? settingsPanel;
        private Panel? mainPanel;

        private Label? lblCurrentVersion;

        public SettingsDashboardForm(bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "SettingsDashboard",
                680,
                430);

            InitializeComponent();

            WindowSettingsService.Apply(
               this,
               _windowSettings);
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor buttonColor = DrawingColor.FromArgb(37, 99, 235);

            this.Text = "Impostazioni";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(680, 430);
            this.MinimumSize = new DrawingSize(580, 380);
            this.BackColor = backgroundColor;
            this.FormClosing += SettingsDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Impostazioni";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);

            lblCurrentVersion = new Label();
            lblCurrentVersion.Text = "Versione corrente: " + GetCurrentVersion();
            lblCurrentVersion.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            lblCurrentVersion.ForeColor = titleColor;
            lblCurrentVersion.AutoSize = true;
            lblCurrentVersion.Location = new DrawingPoint(34, 70);

            mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(25, 110);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 50,
                this.ClientSize.Height - 145);

            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(12);

            settingsPanel = new FlowLayoutPanel();
            settingsPanel.Dock = DockStyle.Fill;
            settingsPanel.AutoScroll = true;
            settingsPanel.WrapContents = true;
            settingsPanel.Padding = new Padding(8);
            settingsPanel.BackColor = cardColor;

            btnUpdate = new Button();
            btnUpdate.Text = "Aggiorna versione";
            btnUpdate.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            btnUpdate.Size = new DrawingSize(210, 48);
            btnUpdate.Location = new DrawingPoint(25, 25);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.FlatAppearance.BorderSize = 0;
            btnUpdate.BackColor = buttonColor;
            btnUpdate.ForeColor = DrawingColor.White;
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.Click += BtnUpdate_Click;

            settingsPanel.Controls.Add(btnUpdate);
            mainPanel.Controls.Add(settingsPanel);

            this.Controls.Add(title);
            this.Controls.Add(lblCurrentVersion);
            this.Controls.Add(mainPanel);
        }

        private async void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (btnUpdate == null)
                return;

            btnUpdate.Enabled = false;
            btnUpdate.Text = "Controllo aggiornamenti...";

            await UpdateCommand.ExecuteAsync();

            btnUpdate.Text = "Aggiorna versione";
            btnUpdate.Enabled = true;
        }

        private void SettingsDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "SettingsDashboard");
        }
        private string GetCurrentVersion()
        {
            try
            {
                UpdateSettings settings = new UpdateSettings();

                if (!SettingsFileService.FileExists(
                    settings.LocalVersionFile))
                {
                    return "non trovata";
                }

                LocalVersionInfo? versionInfo =
                    SettingsJsonService.LoadFromFile<LocalVersionInfo>(
                        settings.LocalVersionFile);

                return versionInfo?.Version ?? "non trovata";
            }
            catch
            {
                return "non trovata";
            }
        }
    }

}