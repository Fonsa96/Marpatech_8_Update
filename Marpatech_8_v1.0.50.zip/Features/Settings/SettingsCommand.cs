﻿namespace Marpatech_8.Features.Settings
{
    public static class SettingsCommand
    {
        public static void Execute(bool isDarkTheme)
        {
            SettingsDashboardForm form = new SettingsDashboardForm(isDarkTheme);
            form.Show();
        }
    }
}