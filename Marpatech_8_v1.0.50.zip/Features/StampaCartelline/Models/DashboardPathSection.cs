﻿using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class DashboardPathSection
    {
        public Panel Card { get; }

        public TextBox InitialPathTextBox { get; }

        public Button InitialBrowseButton { get; }

        public Label DeterminingAttributeLabel { get; }

        public Label DeterminingValueLabel { get; }

        public TextBox FinalPathTextBox { get; }

        public Button FinalBrowseButton { get; }

        public CheckBox IncludeInPrintCheckBox { get; }

        public DashboardPathSession? Session
        {
            get;
            set;
        }

        public DashboardPathSection(
            Panel card,
            TextBox initialPathTextBox,
            Button initialBrowseButton,
            Label determiningAttributeLabel,
            Label determiningValueLabel,
            TextBox finalPathTextBox,
            Button finalBrowseButton,
            CheckBox includeInPrintCheckBox)
        {
            Card =
                card;

            InitialPathTextBox =
                initialPathTextBox;

            InitialBrowseButton =
                initialBrowseButton;

            DeterminingAttributeLabel =
                determiningAttributeLabel;

            DeterminingValueLabel =
                determiningValueLabel;

            FinalPathTextBox =
                finalPathTextBox;

            FinalBrowseButton =
                finalBrowseButton;

            IncludeInPrintCheckBox =
                includeInPrintCheckBox;
        }
    }
}