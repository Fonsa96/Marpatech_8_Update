﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class AssemblyCodeSelection
    {
        public string Code
        {
            get;
            set;
        } = string.Empty;

        public int Copies
        {
            get;
            set;
        } = 1;

        public AssemblyCodeSelection()
        {
        }

        public AssemblyCodeSelection(
            string code,
            int copies = 1)
        {
            Code =
                code?.Trim()
                ?? string.Empty;

            Copies =
                copies < 1
                    ? 1
                    : copies;
        }

        public AssemblyCodeSelection Clone()
        {
            return new AssemblyCodeSelection
            {
                Code =
                    Code,

                Copies =
                    Copies
            };
        }
    }
}