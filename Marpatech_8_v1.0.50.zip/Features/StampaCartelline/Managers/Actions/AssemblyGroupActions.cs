﻿using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class AssemblyGroupAction
    {
        private readonly EditorContext _context;

        private readonly ConfigurationEditorModel _model;

        private bool _isLoading;

        private PrintFolderConfiguration Configuration
        {
            get
            {
                return _model.CurrentConfiguration;
            }
        }

        public AssemblyGroupAction(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context =
                context;

            _model =
                model;
        }

        public void BeginLoading()
        {
            _isLoading =
                true;
        }

        public void EndLoading()
        {
            _isLoading =
                false;
        }

        public void Load()
        {
            bool wasLoading =
                _isLoading;

            _isLoading =
                true;

            try
            {
                _context.GroupsIncludeInPrint.Checked =
                    Configuration.AssemblyGroups
                        ?.IncludeInPrintProcess
                    ?? false;
            }
            finally
            {
                _isLoading =
                    wasLoading;
            }
        }

        public void Save()
        {
            if (_isLoading)
                return;

            Configuration.AssemblyGroups ??=
                new AssemblyGroupsConfiguration();

            Configuration.AssemblyGroups
                .IncludeInPrintProcess =
                    _context.GroupsIncludeInPrint.Checked;
        }
    }
}