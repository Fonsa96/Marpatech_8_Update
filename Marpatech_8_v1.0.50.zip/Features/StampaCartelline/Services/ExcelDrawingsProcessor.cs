﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

using System.Runtime.InteropServices;

using ExcelApplication =
    Microsoft.Office.Interop.Excel.Application;

using ExcelWorkbook =
    Microsoft.Office.Interop.Excel.Workbook;

using ExcelWorkbooks =
    Microsoft.Office.Interop.Excel.Workbooks;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class ExcelDrawingsProcessor
    {
        public bool Process(
            IWin32Window owner,
            StampaCartellineDashboardSession session)
        {
            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * La sessione corrente determina
             * completamente il comportamento.
             */
            if (!session.ExcelDrawings
                    .IncludeInPrintProcess)
            {
                return true;
            }

            string detectedPath =
                BuildDetectedPath(
                    session);

            string? selectedPath =
                ResolveWorkingDirectory(
                    owner,
                    detectedPath);

            /*
             * L'utente ha annullato la scelta:
             * si salta soltanto il blocco Excel.
             */
            if (string.IsNullOrWhiteSpace(
                    selectedPath))
            {
                return true;
            }

            List<string> excelFiles =
                FindExcelFiles(
                    selectedPath);

            if (excelFiles.Count == 0)
            {
                MessageBox.Show(
                    owner,
                    "Nessun file Excel trovato " +
                    "nel percorso selezionato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return true;
            }

            PrintExcelFiles(
                owner,
                excelFiles);

            return true;
        }

        private static string BuildDetectedPath(
            StampaCartellineDashboardSession session)
        {
            DashboardPathSession excelSession =
                session.ExcelDrawings;

            string initialPath =
                excelSession.InitialPath?.Trim()
                ?? string.Empty;

            string finalPath =
                excelSession.FinalPath?.Trim()
                ?? string.Empty;

            string determiningTag =
                excelSession.DeterminingAttributeTag
                    ?.Trim()
                ?? string.Empty;

            DashboardPropertySession? property =
                session.GetPropertyByTag(
                    determiningTag);

            string determiningValue =
                property?.Value?.Trim()
                ?? string.Empty;

            /*
             * Se manca uno degli elementi essenziali,
             * il percorso viene considerato non valido
             * e verrà richiesta la scelta manuale.
             */
            if (string.IsNullOrWhiteSpace(
                    initialPath) ||
                string.IsNullOrWhiteSpace(
                    determiningTag) ||
                string.IsNullOrWhiteSpace(
                    determiningValue))
            {
                return string.Empty;
            }

            try
            {
                if (string.IsNullOrWhiteSpace(
                        finalPath))
                {
                    return Path.Combine(
                        initialPath,
                        determiningValue);
                }

                return Path.Combine(
                    initialPath,
                    determiningValue,
                    finalPath);
            }
            catch
            {
                return string.Empty;
            }
        }

        private static string?
            ResolveWorkingDirectory(
                IWin32Window owner,
                string detectedPath)
        {
            if (!string.IsNullOrWhiteSpace(
                    detectedPath) &&
                Directory.Exists(
                    detectedPath))
            {
                DetectedExcelPathChoice choice =
                    ShowDetectedPathDialog(
                        owner,
                        detectedPath);

                if (choice ==
                    DetectedExcelPathChoice.Print)
                {
                    return detectedPath;
                }

                if (choice ==
                    DetectedExcelPathChoice.Cancel)
                {
                    return null;
                }
            }

            return SelectFolder(
                owner,
                detectedPath);
        }

        private static string?
            SelectFolder(
                IWin32Window owner,
                string detectedPath)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog();

            dialog.Description =
                "Seleziona la cartella contenente " +
                "le distinte Excel da stampare.";

            dialog.UseDescriptionForTitle =
                true;

            if (!string.IsNullOrWhiteSpace(
                    detectedPath))
            {
                string? existingParent =
                    FindExistingParentDirectory(
                        detectedPath);

                if (!string.IsNullOrWhiteSpace(
                        existingParent))
                {
                    dialog.SelectedPath =
                        existingParent;
                }
            }

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            if (result != DialogResult.OK)
                return null;

            string selectedPath =
                dialog.SelectedPath?.Trim()
                ?? string.Empty;

            return Directory.Exists(
                    selectedPath)
                ? selectedPath
                : null;
        }

        private static string?
            FindExistingParentDirectory(
                string path)
        {
            try
            {
                DirectoryInfo? directory =
                    new DirectoryInfo(path);

                while (directory != null)
                {
                    if (directory.Exists)
                    {
                        return directory.FullName;
                    }

                    directory =
                        directory.Parent;
                }
            }
            catch
            {
            }

            return null;
        }

        private static List<string>
            FindExcelFiles(
                string rootDirectory)
        {
            try
            {
                return Directory
                    .EnumerateFiles(
                        rootDirectory,
                        "*.xlsx",
                        SearchOption.AllDirectories)
                    .OrderBy(
                        filePath =>
                            filePath,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        private static DetectedExcelPathChoice
            ShowDetectedPathDialog(
                IWin32Window owner,
                string detectedPath)
        {
            using DetectedExcelPathDialog dialog =
                new DetectedExcelPathDialog(
                    detectedPath);

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            if (result != DialogResult.OK)
            {
                return DetectedExcelPathChoice.Cancel;
            }

            return dialog.SelectedChoice;
        }

        private enum DetectedExcelPathChoice
        {
            Cancel,
            Print,
            ChooseFolder
        }

        private sealed class DetectedExcelPathDialog
            : Form
        {
            public DetectedExcelPathChoice
                SelectedChoice
            {
                get;
                private set;
            } =
                DetectedExcelPathChoice.Cancel;

            public DetectedExcelPathDialog(
                string detectedPath)
            {
                Text =
                    "Distinte Excel";

                StartPosition =
                    FormStartPosition.CenterParent;

                ClientSize =
                    new System.Drawing.Size(
                        700,
                        285);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;

                Label message =
                    new Label();

                message.Text =
                    "Il percorso rilevato è la cartella:\n\n" +
                    detectedPath +
                    "\n\nProcediamo con la stampa " +
                    "dei file Excel?\n\n" +
                    "ATTENZIONE: SE IL PERCORSO È ERRATO " +
                    "STAMPERÀ COMUNQUE TUTTI I FILE EXCEL PRESENTI.";

                message.Location =
                    new System.Drawing.Point(
                        25,
                        20);

                message.Size =
                    new System.Drawing.Size(
                        650,
                        175);

                message.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        10);

                Button btnPrint =
                    new Button();

                btnPrint.Text =
                    "Stampa";

                btnPrint.Size =
                    new System.Drawing.Size(
                        130,
                        38);

                btnPrint.Location =
                    new System.Drawing.Point(
                        365,
                        220);

                btnPrint.Click +=
                    (_, _) =>
                    {
                        SelectedChoice =
                            DetectedExcelPathChoice.Print;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Button btnChoose =
                    new Button();

                btnChoose.Text =
                    "Scegli Cartella";

                btnChoose.Size =
                    new System.Drawing.Size(
                        150,
                        38);

                btnChoose.Location =
                    new System.Drawing.Point(
                        510,
                        220);

                btnChoose.Click +=
                    (_, _) =>
                    {
                        SelectedChoice =
                            DetectedExcelPathChoice
                                .ChooseFolder;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Controls.Add(
                    message);

                Controls.Add(
                    btnPrint);

                Controls.Add(
                    btnChoose);
            }
        }
        private static void PrintExcelFiles(
            IWin32Window owner,
            IEnumerable<string> excelFiles)
        {
            ExcelApplication? excelApplication =
                null;

            ExcelWorkbooks? workbooks =
                null;

            try
            {
                excelApplication =
                    new ExcelApplication
                    {
                        Visible =
                            false,

                        DisplayAlerts =
                            false,

                        AskToUpdateLinks =
                            false,

                        ScreenUpdating =
                            false,

                        EnableEvents =
                            false
                    };

                workbooks =
                    excelApplication.Workbooks;

                foreach (string filePath
                    in excelFiles)
                {
                    PrintSingleWorkbook(
                        owner,
                        workbooks,
                        filePath);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Si è verificato un errore durante " +
                    "la stampa delle distinte Excel.\n\n" +
                    exception.Message +
                    "\n\nIl blocco Excel verrà terminato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                CloseExcelApplication(
                    excelApplication,
                    workbooks);
            }
        }
        private static void PrintSingleWorkbook(
    IWin32Window owner,
    ExcelWorkbooks workbooks,
    string filePath)
        {
            ExcelWorkbook? workbook =
                null;

            try
            {
                workbook =
                    workbooks.Open(
                        Filename:
                            filePath,
                        UpdateLinks:
                            0,
                        ReadOnly:
                            true,
                        AddToMru:
                            false,
                        Notify:
                            false);

                workbook.PrintOut();

                /*
                 * Excel può accodare la stampa.
                 * Attendiamo che termini prima
                 * di chiudere il file.
                 */
                WaitForExcelPrintCompletion();
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Non è stato possibile stampare il file Excel:\n\n" +
                    filePath +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl file verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                CloseWorkbook(
                    workbook);
            }
        }
        private static void WaitForExcelPrintCompletion()
        {
            System.Windows.Forms.Application
                .DoEvents();

            System.Threading.Thread.Sleep(
                150);
        }
        private static void CloseWorkbook(
    ExcelWorkbook? workbook)
        {
            if (workbook == null)
                return;

            try
            {
                workbook.Close(
                    SaveChanges:
                        false);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    workbook);
            }
        }
        private static void CloseExcelApplication(
            ExcelApplication? excelApplication,
            ExcelWorkbooks? workbooks)
        {
            try
            {
                ReleaseComObject(
                    workbooks);

                if (excelApplication != null)
                {
                    excelApplication.Quit();
                }
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    excelApplication);

                GC.Collect();
                GC.WaitForPendingFinalizers();

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }
        private static void ReleaseComObject(
    object? comObject)
        {
            if (comObject == null)
                return;

            try
            {
                if (Marshal.IsComObject(
                        comObject))
                {
                    Marshal.FinalReleaseComObject(
                        comObject);
                }
            }
            catch
            {
            }
        }
    }
}