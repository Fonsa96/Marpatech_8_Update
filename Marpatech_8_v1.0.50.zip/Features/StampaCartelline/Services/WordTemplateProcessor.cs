﻿using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Runtime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Threading;

using WordApplication =
    Microsoft.Office.Interop.Word.Application;

using WordDocument =
    Microsoft.Office.Interop.Word.Document;

using WordSaveOptions =
    Microsoft.Office.Interop.Word.WdSaveOptions;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class WordTemplateProcessor
    {
        private readonly WordTemplateRuntimeBuilder
            _runtimeBuilder;

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(
    IntPtr hWnd);

        public WordTemplateProcessor()
        {
            _runtimeBuilder =
                new WordTemplateRuntimeBuilder();
        }

        public bool Process(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * La configurazione originale stabilisce
             * quali template esistono.
             *
             * La sessione stabilisce se la parte Word
             * deve essere eseguita.
             */
            if (!session.IncludePrintFolders)
                return true;

            List<WordTemplateRuntime> runtimes =
                _runtimeBuilder.Build(
                    configuration,
                    session);

            if (runtimes.Count == 0)
                return true;

            string temporaryDirectory =
                WordTemplateRuntimeBuilder
                    .GetTemporaryDirectory();

            Directory.CreateDirectory(
                temporaryDirectory);

            WordApplication? wordApplication =
                null;

            try
            {
                wordApplication =
                    new WordApplication
                    {
                        Visible =
                            false,

                        DisplayAlerts =
                            Microsoft.Office.Interop.Word
                                .WdAlertLevel
                                .wdAlertsNone
                    };

                foreach (
                    WordTemplateRuntime runtime
                    in runtimes)
                {
                    if (!ValidateTemplate(
                            owner,
                            runtime))
                    {
                        continue;
                    }

                    if (!PrepareTemporaryTemplate(
                            owner,
                            temporaryDirectory,
                            runtime))
                    {
                        continue;
                    }

                    ProcessSingleTemplate(
                        owner,
                        wordApplication,
                        runtime);
                }

                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Si è verificato un errore durante " +
                    "l'elaborazione dei template Word.\n\n" +
                    exception.Message,
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                /*
                 * L'errore Word non interrompe
                 * il processo generale.
                 */
                return true;
            }
            finally
            {
                CloseWordApplication(
                    wordApplication);

                try
                {
                    ClearTemporaryDirectory(
                        temporaryDirectory);
                }
                catch
                {
                    /*
                     * La cartella verrà ripulita nuovamente
                     * all'avvio del prossimo processo.
                     */
                }
            }
        }

        private static bool ValidateTemplate(
            IWin32Window owner,
            WordTemplateRuntime runtime)
        {
            string sourcePath =
                runtime.Template.TemplatePath
                    ?.Trim()
                ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(
                    sourcePath) &&
                File.Exists(sourcePath))
            {
                return true;
            }

            string templateDescription =
                !string.IsNullOrWhiteSpace(
                    runtime.Template.Name)
                    ? runtime.Template.Name
                    : sourcePath;

            if (string.IsNullOrWhiteSpace(
                    templateDescription))
            {
                templateDescription =
                    "Percorso non specificato";
            }

            MessageBox.Show(
                owner,
                "Template non trovato:\n\n" +
                templateDescription +
                "\n\nIl template verrà saltato.",
                "Stampa Cartelline",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            return false;
        }
        private static bool PrepareTemporaryTemplate(
    IWin32Window owner,
    string temporaryDirectory,
    WordTemplateRuntime runtime)
        {
            try
            {
                ClearTemporaryDirectory(
                    temporaryDirectory);

                string sourcePath =
                    runtime.Template.TemplatePath
                        ?.Trim()
                    ?? string.Empty;

                string fileName =
                    Path.GetFileName(
                        sourcePath);

                if (string.IsNullOrWhiteSpace(
                        fileName))
                {
                    MessageBox.Show(
                        owner,
                        "Il nome del template Word non è valido.\n\n" +
                        "Il template verrà saltato.",
                        "Stampa Cartelline",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return false;
                }

                string destinationPath =
                    Path.Combine(
                        temporaryDirectory,
                        fileName);

                File.Copy(
                    sourcePath,
                    destinationPath,
                    true);

                runtime.TemporaryFilePath =
                    destinationPath;

                return true;
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Non è stato possibile preparare il template Word:\n\n" +
                    runtime.Template.Name +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl template verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }
        }
        private static void ClearTemporaryDirectory(
    string temporaryDirectory)
        {
            Directory.CreateDirectory(
                temporaryDirectory);

            foreach (string filePath
                in Directory.GetFiles(
                    temporaryDirectory))
            {
                File.SetAttributes(
                    filePath,
                    FileAttributes.Normal);

                File.Delete(
                    filePath);
            }

            foreach (string directoryPath
                in Directory.GetDirectories(
                    temporaryDirectory))
            {
                Directory.Delete(
                    directoryPath,
                    true);
            }
        }
        private static void ProcessSingleTemplate(
    IWin32Window owner,
    WordApplication wordApplication,
    WordTemplateRuntime runtime)
        {
            WordDocument? document =
                null;

            try
            {
                document =
                    wordApplication.Documents.Open(
                        FileName:
                            runtime.TemporaryFilePath,
                        ReadOnly:
                            false,
                        AddToRecentFiles:
                            false,
                        Visible:
                            false);

                ReplacePlaceholders(
                    document,
                    runtime);

                ShowWordInForeground(
    wordApplication,
    document);

                DialogResult printResult =
                    MessageBox.Show(
                        "Desideri stampare la cartellina Word?",
                        "Stampa Cartelline",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);

                if (printResult == DialogResult.Yes)
                {
                    PrintDocument(
                        document);
                }

                /*
                 * Prossimo passaggio:
                 *
                 * 1. sostituzione dei placeholder;
                 * 2. Word visibile e in primo piano;
                 * 3. domanda di stampa;
                 * 4. eventuale stampa.
                 */
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Non è stato possibile elaborare il template Word:\n\n" +
                    runtime.Template.Name +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl template verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                CloseWordDocument(
                    document);

                DeleteTemporaryTemplate(
                    runtime.TemporaryFilePath);

                runtime.TemporaryFilePath =
                    string.Empty;

                /*
                 * Dopo ogni template Word torna
                 * sempre nascosto.
                 */
                try
                {
                    wordApplication.Visible =
                        false;
                }
                catch
                {
                }
            }
        }
        private static void CloseWordDocument(
    WordDocument? document)
        {
            if (document == null)
                return;

            try
            {
                document.Close(
                    SaveChanges:
                        WordSaveOptions
                            .wdDoNotSaveChanges);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    document);
            }
        }
        private static void DeleteTemporaryTemplate(
    string temporaryFilePath)
        {
            if (string.IsNullOrWhiteSpace(
                    temporaryFilePath))
            {
                return;
            }

            try
            {
                if (!File.Exists(
                        temporaryFilePath))
                {
                    return;
                }

                File.SetAttributes(
                    temporaryFilePath,
                    FileAttributes.Normal);

                File.Delete(
                    temporaryFilePath);
            }
            catch
            {

            }
        }
        private static void CloseWordApplication(
    WordApplication? wordApplication)
        {
            if (wordApplication == null)
                return;

            try
            {
                wordApplication.Quit(
                    SaveChanges:
                        WordSaveOptions
                            .wdDoNotSaveChanges);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    wordApplication);

                GC.Collect();
                GC.WaitForPendingFinalizers();

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }
        private static void ReleaseComObject(
    object? comObject)
        {
            if (comObject == null)
                return;

            try
            {
                if (Marshal.IsComObject(
                        comObject))
                {
                    Marshal.FinalReleaseComObject(
                        comObject);
                }
            }
            catch
            {
            }
        }
        private static void ReplacePlaceholders(
    WordDocument document,
    WordTemplateRuntime runtime)
        {
            foreach (
                KeyValuePair<string, string> replacement
                in runtime.Replacements)
            {
                ReplaceText(
                    document,
                    replacement.Key,
                    replacement.Value);
            }
        }
        private static void ReplaceText(
    WordDocument document,
    string placeholder,
    string replacementValue)
        {
            if (string.IsNullOrWhiteSpace(
                    placeholder))
            {
                return;
            }

            Microsoft.Office.Interop.Word.Range? range =
                null;

            Microsoft.Office.Interop.Word.Find? find =
                null;

            try
            {
                range =
                    document.Content;

                find =
                    range.Find;

                find.ClearFormatting();

                find.Replacement.ClearFormatting();

                find.Text =
                    placeholder;

                find.Replacement.Text =
                    replacementValue
                    ?? string.Empty;

                find.Forward =
                    true;

                find.Wrap =
                    Microsoft.Office.Interop.Word
                        .WdFindWrap
                        .wdFindContinue;

                find.Format =
                    false;

                find.MatchCase =
                    false;

                find.MatchWholeWord =
                    false;

                find.MatchWildcards =
                    false;

                find.MatchSoundsLike =
                    false;

                find.MatchAllWordForms =
                    false;

                find.Execute(
                    Replace:
                        Microsoft.Office.Interop.Word
                            .WdReplace
                            .wdReplaceAll);
            }
            finally
            {
                ReleaseComObject(
                    find);

                ReleaseComObject(
                    range);
            }
        }
        private static void ShowWordInForeground(
    WordApplication wordApplication,
    WordDocument document)
        {
            Microsoft.Office.Interop.Word.Window?
                activeWindow =
                    null;

            try
            {
                wordApplication.Visible =
                    true;

                document.Activate();

                wordApplication.Activate();

                Application.DoEvents();

                Thread.Sleep(
                    150);

                activeWindow =
                    wordApplication.ActiveWindow;

                if (activeWindow == null)
                    return;

                SetForegroundWindow(
                    new IntPtr(
                        activeWindow.Hwnd));
            }
            finally
            {
                ReleaseComObject(
                    activeWindow);
            }
        }
        private static void PrintDocument(
    WordDocument document)
        {
            document.PrintOut(
                Background:
                    false);
        }
    }
}