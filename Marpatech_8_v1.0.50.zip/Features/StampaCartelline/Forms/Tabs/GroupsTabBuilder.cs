﻿using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class GroupsTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            CheckBox chkIncludeInPrint)
        {
            DrawingColor backgroundColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        32,
                        34,
                        40)
                    : DrawingColor.White;

            DrawingColor titleColor =
                isDarkTheme
                    ? DrawingColor.White
                    : DrawingColor.FromArgb(
                        30,
                        41,
                        59);

            DrawingColor subtitleColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        170,
                        178,
                        190)
                    : DrawingColor.FromArgb(
                        100,
                        116,
                        139);

            TabPage page =
                new TabPage();

            page.Text =
                "Gruppi di montaggio";

            page.BackColor =
                backgroundColor;


            Label title =
                new Label();

            title.Text =
                "Gruppi di montaggio";

            title.Font =
                new DrawingFont(
                    "Segoe UI",
                    16,
                    DrawingFontStyle.Bold);

            title.ForeColor =
                titleColor;

            title.AutoSize =
                true;

            title.Left =
                25;

            title.Top =
                25;


            Label description =
                new Label();

            description.Text =
                "Abilita la gestione dei gruppi di montaggio nella Dashboard.";

            description.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Regular);

            description.ForeColor =
                subtitleColor;

            description.AutoSize =
                true;

            description.Left =
                27;

            description.Top =
                70;


            chkIncludeInPrint.Text =
                "Includi nel processo di stampa";

            chkIncludeInPrint.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkIncludeInPrint.AutoSize =
                true;

            chkIncludeInPrint.Left =
                30;

            chkIncludeInPrint.Top =
                120;

            chkIncludeInPrint.ForeColor =
                titleColor;

            chkIncludeInPrint.BackColor =
                backgroundColor;


            page.Controls.Add(
                title);

            page.Controls.Add(
                description);

            page.Controls.Add(
                chkIncludeInPrint);

            return page;
        }
    }
}