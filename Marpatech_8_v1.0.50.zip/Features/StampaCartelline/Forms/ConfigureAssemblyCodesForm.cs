﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class ConfigureAssemblyCodesForm : Form
    {
        private readonly bool _isDarkTheme;

        private readonly DataGridView dgvCodes;

        private readonly Button btnPasteClipboard;
        private readonly Button btnAddRow;
        private readonly Button btnDeleteRow;
        private readonly Button btnOk;
        private readonly Button btnCancel;

        public List<AssemblyCodeSelection> Result
        {
            get;
            private set;
        } = new List<AssemblyCodeSelection>();

        public ConfigureAssemblyCodesForm(
            IEnumerable<AssemblyCodeSelection>? currentCodes,
            bool isDarkTheme)
        {
            _isDarkTheme =
                isDarkTheme;

            dgvCodes =
                new DataGridView();

            btnPasteClipboard =
                new Button();

            btnAddRow =
                new Button();

            btnDeleteRow =
                new Button();

            btnOk =
                new Button();

            btnCancel =
                new Button();

            InitializeComponent();

            LoadCodes(
                currentCodes);

            UpdateButtonsState();
        }

        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        18,
                        18,
                        22)
                    : Color.FromArgb(
                        245,
                        247,
                        250);

            Color cardColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        32,
                        34,
                        40)
                    : Color.White;

            Color titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(
                        30,
                        41,
                        59);

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        43,
                        46,
                        55)
                    : Color.White;

            Text =
                "Configura codici";

            StartPosition =
                FormStartPosition.CenterParent;

            Size =
                new Size(
                    780,
                    590);

            MinimumSize =
                new Size(
                    680,
                    500);

            BackColor =
                backgroundColor;

            FormBorderStyle =
                FormBorderStyle.Sizable;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            Label lblTitle =
                new Label();

            lblTitle.Text =
                "Codici selezionati";

            lblTitle.Font =
                new Font(
                    "Segoe UI",
                    18,
                    FontStyle.Bold);

            lblTitle.ForeColor =
                titleColor;

            lblTitle.AutoSize =
                true;

            lblTitle.Location =
                new Point(
                    25,
                    20);

            Label lblSubtitle =
                new Label();

            lblSubtitle.Text =
                "Inserisci i codici e indica il numero di copie.";

            lblSubtitle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            lblSubtitle.ForeColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        170,
                        178,
                        190)
                    : Color.FromArgb(
                        100,
                        116,
                        139);

            lblSubtitle.AutoSize =
                true;

            lblSubtitle.Location =
                new Point(
                    28,
                    60);

            Panel gridCard =
                new Panel();

            gridCard.Location =
                new Point(
                    25,
                    95);

            gridCard.Size =
                new Size(
                    ClientSize.Width - 50,
                    ClientSize.Height - 205);

            gridCard.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            gridCard.BackColor =
                cardColor;

            gridCard.Padding =
                new Padding(
                    10);

            ConfigureDataGridView(
                titleColor,
                inputColor);

            dgvCodes.Dock =
                DockStyle.Fill;

            gridCard.Controls.Add(
                dgvCodes);

            btnPasteClipboard.Text =
                "Incolla da appunti";

            ConfigureButton(
                btnPasteClipboard,
                Color.FromArgb(
                    37,
                    99,
                    235),
                165,
                38);

            btnPasteClipboard.Location =
                new Point(
                    25,
                    ClientSize.Height - 90);

            btnPasteClipboard.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            btnPasteClipboard.Click +=
                BtnPasteClipboard_Click;

            btnAddRow.Text =
                "Aggiungi riga";

            ConfigureButton(
                btnAddRow,
                Color.FromArgb(
                    100,
                    116,
                    139),
                130,
                38);

            btnAddRow.Location =
                new Point(
                    200,
                    ClientSize.Height - 90);

            btnAddRow.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            btnAddRow.Click +=
                BtnAddRow_Click;

            btnDeleteRow.Text =
                "Elimina riga";

            ConfigureButton(
                btnDeleteRow,
                Color.FromArgb(
                    220,
                    38,
                    38),
                130,
                38);

            btnDeleteRow.Location =
                new Point(
                    340,
                    ClientSize.Height - 90);

            btnDeleteRow.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            btnDeleteRow.Click +=
                BtnDeleteRow_Click;

            btnOk.Text =
                "OK";

            ConfigureButton(
                btnOk,
                Color.FromArgb(
                    22,
                    163,
                    74),
                95,
                38);

            btnOk.Location =
                new Point(
                    ClientSize.Width - 230,
                    ClientSize.Height - 90);

            btnOk.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnOk.Click +=
                BtnOk_Click;

            btnCancel.Text =
                "Annulla";

            ConfigureButton(
                btnCancel,
                Color.FromArgb(
                    100,
                    116,
                    139),
                105,
                38);

            btnCancel.Location =
                new Point(
                    ClientSize.Width - 125,
                    ClientSize.Height - 90);

            btnCancel.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnCancel.Click +=
                BtnCancel_Click;

            Controls.Add(
                lblTitle);

            Controls.Add(
                lblSubtitle);

            Controls.Add(
                gridCard);

            Controls.Add(
                btnPasteClipboard);

            Controls.Add(
                btnAddRow);

            Controls.Add(
                btnDeleteRow);

            Controls.Add(
                btnOk);

            Controls.Add(
                btnCancel);

            AcceptButton =
                btnOk;

            CancelButton =
                btnCancel;
        }

        private void ConfigureDataGridView(
            Color titleColor,
            Color inputColor)
        {
            dgvCodes.AllowUserToAddRows =
                false;

            dgvCodes.AllowUserToDeleteRows =
                false;

            dgvCodes.AllowUserToResizeRows =
                false;

            dgvCodes.MultiSelect =
                false;

            dgvCodes.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dgvCodes.EditMode =
                DataGridViewEditMode.EditOnEnter;

            dgvCodes.AutoGenerateColumns =
                false;

            dgvCodes.RowHeadersVisible =
                false;

            dgvCodes.BackgroundColor =
                inputColor;

            dgvCodes.BorderStyle =
                BorderStyle.None;

            dgvCodes.GridColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        70,
                        75,
                        85)
                    : Color.FromArgb(
                        203,
                        213,
                        225);

            dgvCodes.EnableHeadersVisualStyles =
                false;

            dgvCodes.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        43,
                        46,
                        55)
                    : Color.FromArgb(
                        241,
                        245,
                        249);

            dgvCodes.ColumnHeadersDefaultCellStyle.ForeColor =
                titleColor;

            dgvCodes.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            dgvCodes.DefaultCellStyle.BackColor =
                inputColor;

            dgvCodes.DefaultCellStyle.ForeColor =
                titleColor;

            dgvCodes.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            dgvCodes.DefaultCellStyle.SelectionForeColor =
                Color.White;

            dgvCodes.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            dgvCodes.RowTemplate.Height =
                30;

            DataGridViewTextBoxColumn codeColumn =
                new DataGridViewTextBoxColumn();

            codeColumn.Name =
                "Code";

            codeColumn.HeaderText =
                "Codice";

            codeColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            codeColumn.FillWeight =
                75;

            codeColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            DataGridViewTextBoxColumn copiesColumn =
                new DataGridViewTextBoxColumn();

            copiesColumn.Name =
                "Copies";

            copiesColumn.HeaderText =
                "Quantità";

            copiesColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            copiesColumn.FillWeight =
                25;

            copiesColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            dgvCodes.Columns.Add(
                codeColumn);

            dgvCodes.Columns.Add(
                copiesColumn);

            dgvCodes.SelectionChanged +=
                DgvCodes_SelectionChanged;

            dgvCodes.CellValueChanged +=
                DgvCodes_CellValueChanged;

            dgvCodes.CellEndEdit +=
                DgvCodes_CellEndEdit;

            dgvCodes.DataError +=
                DgvCodes_DataError;
        }

        private static void ConfigureButton(
            Button button,
            Color backgroundColor,
            int width,
            int height)
        {
            button.Size =
                new Size(
                    width,
                    height);

            button.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            button.FlatStyle =
                FlatStyle.Flat;

            button.FlatAppearance.BorderSize =
                0;

            button.BackColor =
                backgroundColor;

            button.ForeColor =
                Color.White;

            button.Cursor =
                Cursors.Hand;
        }

        private void LoadCodes(
            IEnumerable<AssemblyCodeSelection>? currentCodes)
        {
            dgvCodes.Rows.Clear();

            if (currentCodes == null)
                return;

            foreach (AssemblyCodeSelection item
                in currentCodes)
            {
                string code =
                    item.Code?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                int copies =
                    item.Copies < 1
                        ? 1
                        : item.Copies;

                dgvCodes.Rows.Add(
                    code,
                    copies);
            }

            NormalizeCodes();
        }

        private void BtnPasteClipboard_Click(
            object? sender,
            EventArgs e)
        {
            if (!Clipboard.ContainsText())
            {
                MessageBox.Show(
                    this,
                    "Negli appunti non è presente alcun testo.",
                    "Configura codici",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            List<string> clipboardCodes =
                ExtractCodesFromClipboard(
                    Clipboard.GetText());

            if (clipboardCodes.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Negli appunti non sono stati trovati codici validi.",
                    "Configura codici",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            bool tableHasValues =
                GetValidCodesCount() > 0;

            PasteMode pasteMode =
                PasteMode.Replace;

            if (tableHasValues)
            {
                pasteMode =
                    ShowPasteModeDialog();

                if (pasteMode ==
                    PasteMode.Cancel)
                {
                    return;
                }
            }

            if (pasteMode ==
                PasteMode.Replace)
            {
                ReplaceWithClipboardCodes(
                    clipboardCodes);
            }
            else
            {
                MergeClipboardCodes(
                    clipboardCodes);
            }

            NormalizeCodes();
            UpdateButtonsState();
        }

        private void ReplaceWithClipboardCodes(
            IEnumerable<string> clipboardCodes)
        {
            dgvCodes.Rows.Clear();

            foreach (string code
                in clipboardCodes)
            {
                dgvCodes.Rows.Add(
                    code,
                    1);
            }
        }

        private void MergeClipboardCodes(
            IEnumerable<string> clipboardCodes)
        {
            HashSet<string> existingCodes =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (DataGridViewRow row
                in dgvCodes.Rows)
            {
                string code =
                    Convert.ToString(
                        row.Cells["Code"].Value)
                    ?.Trim()
                    ?? string.Empty;

                if (!string.IsNullOrWhiteSpace(
                        code))
                {
                    existingCodes.Add(
                        code);
                }
            }

            foreach (string code
                in clipboardCodes)
            {
                if (!existingCodes.Add(
                        code))
                {
                    continue;
                }

                dgvCodes.Rows.Add(
                    code,
                    1);
            }
        }

        private static List<string>
            ExtractCodesFromClipboard(
                string clipboardText)
        {
            List<string> result =
                new List<string>();

            HashSet<string> uniqueCodes =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            string[] lines =
                clipboardText.Split(
                    new[]
                    {
                        "\r\n",
                        "\n",
                        "\r"
                    },
                    StringSplitOptions.None);

            foreach (string line
                in lines)
            {
                string trimmedLine =
                    line.Trim();

                if (string.IsNullOrWhiteSpace(
                        trimmedLine))
                {
                    continue;
                }

                string code =
                    GetFirstColumn(
                        trimmedLine);

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                if (uniqueCodes.Add(
                        code))
                {
                    result.Add(
                        code);
                }
            }

            return result;
        }

        private static string GetFirstColumn(
            string line)
        {
            int tabIndex =
                line.IndexOf('\t');

            int semicolonIndex =
                line.IndexOf(';');

            int separatorIndex =
                -1;

            if (tabIndex >= 0 &&
                semicolonIndex >= 0)
            {
                separatorIndex =
                    Math.Min(
                        tabIndex,
                        semicolonIndex);
            }
            else if (tabIndex >= 0)
            {
                separatorIndex =
                    tabIndex;
            }
            else if (semicolonIndex >= 0)
            {
                separatorIndex =
                    semicolonIndex;
            }

            if (separatorIndex >= 0)
            {
                return line
                    .Substring(
                        0,
                        separatorIndex)
                    .Trim();
            }

            return line.Trim();
        }

        private void BtnAddRow_Click(
            object? sender,
            EventArgs e)
        {
            int rowIndex =
                dgvCodes.Rows.Add(
                    string.Empty,
                    1);

            dgvCodes.ClearSelection();

            DataGridViewRow row =
                dgvCodes.Rows[rowIndex];

            row.Selected =
                true;

            dgvCodes.CurrentCell =
                row.Cells["Code"];

            dgvCodes.BeginEdit(
                true);

            UpdateButtonsState();
        }

        private void BtnDeleteRow_Click(
            object? sender,
            EventArgs e)
        {
            DataGridViewRow? selectedRow =
                GetSelectedRow();

            if (selectedRow == null)
                return;

            DialogResult result =
                MessageBox.Show(
                    this,
                    "Vuoi eliminare questo codice dalla lista?",
                    "Configura codici",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question,
                    MessageBoxDefaultButton.Button2);

            if (result !=
                DialogResult.Yes)
            {
                return;
            }

            dgvCodes.Rows.Remove(
                selectedRow);

            UpdateButtonsState();
        }

        private void BtnOk_Click(
            object? sender,
            EventArgs e)
        {
            dgvCodes.EndEdit();

            NormalizeCodes();

            List<AssemblyCodeSelection>
                result =
                    BuildResult();

            if (result.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Inserisci almeno un codice valido.",
                    "Configura codici",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                UpdateButtonsState();

                return;
            }

            Result =
                result;

            DialogResult =
                DialogResult.OK;

            Close();
        }

        private void BtnCancel_Click(
            object? sender,
            EventArgs e)
        {
            DialogResult =
                DialogResult.Cancel;

            Close();
        }

        private void NormalizeCodes()
        {
            dgvCodes.EndEdit();

            Dictionary<string, int> normalizedCodes =
                new Dictionary<string, int>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (DataGridViewRow row
                in dgvCodes.Rows)
            {
                string code =
                    Convert.ToString(
                        row.Cells["Code"].Value)
                    ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                int copies =
                    ParseCopies(
                        row.Cells["Copies"].Value);

                if (!normalizedCodes.ContainsKey(
                        code))
                {
                    normalizedCodes.Add(
                        code,
                        copies);
                }
            }

            dgvCodes.Rows.Clear();

            foreach (KeyValuePair<string, int> item
                in normalizedCodes)
            {
                dgvCodes.Rows.Add(
                    item.Key,
                    item.Value);
            }

            UpdateButtonsState();
        }

        private List<AssemblyCodeSelection>
            BuildResult()
        {
            List<AssemblyCodeSelection> result =
                new List<AssemblyCodeSelection>();

            HashSet<string> addedCodes =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (DataGridViewRow row
                in dgvCodes.Rows)
            {
                string code =
                    Convert.ToString(
                        row.Cells["Code"].Value)
                    ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                if (!addedCodes.Add(
                        code))
                {
                    continue;
                }

                int copies =
                    ParseCopies(
                        row.Cells["Copies"].Value);

                result.Add(
                    new AssemblyCodeSelection(
                        code,
                        copies));
            }

            return result;
        }

        private static int ParseCopies(
            object? value)
        {
            string text =
                Convert.ToString(
                    value)
                ?.Trim()
                ?? string.Empty;

            if (!int.TryParse(
                    text,
                    out int copies))
            {
                return 1;
            }

            return copies < 1
                ? 1
                : copies;
        }

        private int GetValidCodesCount()
        {
            int count =
                0;

            HashSet<string> uniqueCodes =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (DataGridViewRow row
                in dgvCodes.Rows)
            {
                string code =
                    Convert.ToString(
                        row.Cells["Code"].Value)
                    ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                if (uniqueCodes.Add(
                        code))
                {
                    count++;
                }
            }

            return count;
        }

        private DataGridViewRow?
            GetSelectedRow()
        {
            if (dgvCodes.SelectedRows.Count >
                0)
            {
                return dgvCodes
                    .SelectedRows[0];
            }

            if (dgvCodes.CurrentCell != null)
            {
                return dgvCodes.Rows[
                    dgvCodes.CurrentCell.RowIndex];
            }

            return null;
        }

        private void UpdateButtonsState()
        {
            btnDeleteRow.Enabled =
                GetSelectedRow() != null;

            btnOk.Enabled =
                GetValidCodesCount() > 0;
        }

        private void DgvCodes_SelectionChanged(
            object? sender,
            EventArgs e)
        {
            UpdateButtonsState();
        }

        private void DgvCodes_CellValueChanged(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            UpdateButtonsState();
        }

        private void DgvCodes_CellEndEdit(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0)
                return;

            DataGridViewRow row =
                dgvCodes.Rows[e.RowIndex];

            if (e.ColumnIndex ==
                dgvCodes.Columns["Code"].Index)
            {
                string code =
                    Convert.ToString(
                        row.Cells["Code"].Value)
                    ?.Trim()
                    ?? string.Empty;

                row.Cells["Code"].Value =
                    code;
            }

            if (e.ColumnIndex ==
                dgvCodes.Columns["Copies"].Index)
            {
                row.Cells["Copies"].Value =
                    ParseCopies(
                        row.Cells["Copies"].Value);
            }

            UpdateButtonsState();
        }

        private void DgvCodes_DataError(
            object? sender,
            DataGridViewDataErrorEventArgs e)
        {
            e.ThrowException =
                false;
        }

        private PasteMode ShowPasteModeDialog()
        {
            using PasteModeDialog dialog =
                new PasteModeDialog(
                    _isDarkTheme);

            DialogResult result =
                dialog.ShowDialog(
                    this);

            if (result !=
                DialogResult.OK)
            {
                return PasteMode.Cancel;
            }

            return dialog.SelectedMode;
        }

        private enum PasteMode
        {
            Cancel,
            Replace,
            Merge
        }

        private sealed class PasteModeDialog : Form
        {
            public PasteMode SelectedMode
            {
                get;
                private set;
            } = PasteMode.Cancel;

            public PasteModeDialog(
                bool isDarkTheme)
            {
                Color backgroundColor =
                    isDarkTheme
                        ? Color.FromArgb(
                            32,
                            34,
                            40)
                        : Color.White;

                Color titleColor =
                    isDarkTheme
                        ? Color.White
                        : Color.FromArgb(
                            30,
                            41,
                            59);

                Text =
                    "Incolla da appunti";

                StartPosition =
                    FormStartPosition.CenterParent;

                ClientSize =
                    new Size(
                        560,
                        190);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;

                BackColor =
                    backgroundColor;

                Label message =
                    new Label();

                message.Text =
                    "Valori già presenti in tabella.\n" +
                    "Vuoi sostituirli o unirli a quelli esistenti?";

                message.Font =
                    new Font(
                        "Segoe UI",
                        10,
                        FontStyle.Regular);

                message.ForeColor =
                    titleColor;

                message.Location =
                    new Point(
                        25,
                        25);

                message.Size =
                    new Size(
                        510,
                        55);

                Button btnReplace =
                    CreateDialogButton(
                        "Sostituisci",
                        Color.FromArgb(
                            220,
                            38,
                            38));

                btnReplace.Location =
                    new Point(
                        55,
                        115);

                btnReplace.Click +=
                    delegate
                    {
                        SelectedMode =
                            PasteMode.Replace;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Button btnMerge =
                    CreateDialogButton(
                        "Unisci",
                        Color.FromArgb(
                            37,
                            99,
                            235));

                btnMerge.Location =
                    new Point(
                        215,
                        115);

                btnMerge.Click +=
                    delegate
                    {
                        SelectedMode =
                            PasteMode.Merge;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Button btnCancel =
                    CreateDialogButton(
                        "Annulla",
                        Color.FromArgb(
                            100,
                            116,
                            139));

                btnCancel.Location =
                    new Point(
                        375,
                        115);

                btnCancel.Click +=
                    delegate
                    {
                        SelectedMode =
                            PasteMode.Cancel;

                        DialogResult =
                            DialogResult.Cancel;

                        Close();
                    };

                Controls.Add(
                    message);

                Controls.Add(
                    btnReplace);

                Controls.Add(
                    btnMerge);

                Controls.Add(
                    btnCancel);

                CancelButton =
                    btnCancel;
            }

            private static Button
                CreateDialogButton(
                    string text,
                    Color color)
            {
                Button button =
                    new Button();

                button.Text =
                    text;

                button.Size =
                    new Size(
                        130,
                        38);

                button.Font =
                    new Font(
                        "Segoe UI",
                        9,
                        FontStyle.Bold);

                button.FlatStyle =
                    FlatStyle.Flat;

                button.FlatAppearance.BorderSize =
                    0;

                button.BackColor =
                    color;

                button.ForeColor =
                    Color.White;

                button.Cursor =
                    Cursors.Hand;

                return button;
            }
        }
    }
}