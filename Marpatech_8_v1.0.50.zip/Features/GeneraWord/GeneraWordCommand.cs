﻿using Inventor;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.GeneraWord.Forms;
using Marpatech_8.Features.Mail;
using System;

namespace Marpatech_8.Features.GeneraWord
{
    public static class GeneraWordCommand
    {
        public static void Execute(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            IntPtr inventorHandle =
            InventorService.GetMainFrameHandle(
                inventorApp);

            InventorWindowWrapper owner =
                new InventorWindowWrapper(inventorHandle);

            SingleFormService.ShowSingle(
                "GeneraWord",
                () => new GeneraWordDashboardForm(
                    inventorApp,
                    isDarkTheme),
                owner);
        }
    }
}