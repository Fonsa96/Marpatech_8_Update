﻿using Inventor;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class SelectedAssemblyCodesPrintProcessor
    {
        private readonly Inventor.Application _inventorApp;


        public SelectedAssemblyCodesPrintProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }


        public void Process(
            IWin32Window owner,
            IEnumerable<AssemblyCodeSelection> items,
            string mainAssemblyPrefix,
            StampaCartellineProcessProgress progress)
        {
            if (items == null)
                return;

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }


            string separatorPrefix =
                mainAssemblyPrefix
                    ?.Trim()
                ?? string.Empty;


            foreach (AssemblyCodeSelection item
                in items)
            {
                ProcessSingleItem(
                    item,
                    progress);


                /*
                 * ==================================================
                 * SEPARATORE STL / PREFISSO MAIN
                 * ==================================================
                 *
                 * NON hardcoded.
                 *
                 * Se CODICE inizia con il valore della
                 * textbox singola Metodo 2, il blocco
                 * corrente è concluso.
                 */
                bool isBlockSeparator =
                    !string.IsNullOrWhiteSpace(
                        separatorPrefix) &&
                    !string.IsNullOrWhiteSpace(
                        item.Code) &&
                    item.Code.StartsWith(
                        separatorPrefix,
                        StringComparison.OrdinalIgnoreCase);


                if (isBlockSeparator)
                {
                    MessageBox.Show(
                        owner,
                        "Stampa \"" +
                        item.DrawingName +
                        "\" conclusa." +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        "Quando premerai OK partirà la stampa " +
                        "fino al prossimo " +
                        separatorPrefix +
                        ".",
                        "Stampa Cartelline",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
        }


        private void ProcessSingleItem(
            AssemblyCodeSelection item,
            StampaCartellineProcessProgress progress)
        {
            string drawingName =
                NormalizeDrawingFileName(
                    item.DrawingName);


            /*
             * Stessa logica precedente:
             * se DISEGNO è vuoto, il codice
             * non viene processato.
             *
             * Aggiungiamo solamente il LOG.
             */
            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - Attributo DISEGNO vuoto.");

                return;
            }


            string searchPath =
                item.DrawingSearchPath
                    ?.Trim()
                ?? string.Empty;


            /*
             * Stessa condizione precedente.
             */
            if (string.IsNullOrWhiteSpace(
                    searchPath) ||
                !Directory.Exists(
                    searchPath))
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - Percorso ricerca IDW non disponibile: " +
                    searchPath);

                return;
            }


            string? drawingPath =
                FindDrawingRecursive(
                    searchPath,
                    drawingName);


            /*
             * Stesso comportamento precedente:
             * nessuna tavola trovata = return.
             */
            if (string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - IDW non trovato: " +
                    drawingName);

                return;
            }


            DrawingDocument? drawingDocument =
                null;


            try
            {
                Document? openedDocument =
                    InventorService.OpenDocument(
                        _inventorApp,
                        drawingPath,
                        true);

                if (openedDocument == null)
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        item.Code +
                        " - Impossibile aprire la tavola: " +
                        drawingName);

                    return;
                }


                drawingDocument =
                    openedDocument
                        as DrawingDocument;

                if (drawingDocument == null)
                {
                    InventorService.CloseDocument(
                        openedDocument,
                        true);

                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        item.Code +
                        " - Il file trovato non è un documento IDW valido: " +
                        drawingName);

                    return;
                }


                if (!InventorService.ActivateDrawingDocument(
                        drawingDocument))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare la tavola " +
                        drawingName +
                        ".");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                /*
                 * SOLO LOG.
                 */
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - Tavola " +
                    drawingName +
                    " aperta.");


                int copies =
                    item.Copies < 1
                        ? 1
                        : item.Copies;


                /*
                 * Una sola apertura IDW.
                 *
                 * Il comando viene lanciato N volte
                 * secondo la colonna Quantità.
                 *
                 * LOGICA INVARIATA.
                 */
                for (int copyIndex = 0;
                    copyIndex < copies;
                    copyIndex++)
                {
                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");
                }


                /*
                 * SOLO LOG.
                 *
                 * Viene scritto esclusivamente dopo
                 * che tutti i comandi di stampa
                 * richiesti sono stati eseguiti.
                 */
                progress.AddSuccess(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - Tavola " +
                    drawingName +
                    " stampata. Copie: " +
                    copies);
            }
            catch (Exception exception)
            {
                /*
                 * Registriamo l'errore nel LOG centrale.
                 *
                 * Il singolo elemento termina qui e
                 * il foreach principale può continuare
                 * con il codice successivo.
                 */
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    item.Code +
                    " - Errore durante la stampa di " +
                    drawingName +
                    ": " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                /*
                 * LOGICA DI CHIUSURA INVARIATA.
                 */
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }
            }
        }


        private void ExecuteInventorCommand(
            string commandInternalName)
        {
            bool success =
                InventorService.TryExecuteControlDefinition2(
                    _inventorApp,
                    commandInternalName,
                    true,
                    out string errorMessage);

            if (success)
                return;

            throw new InvalidOperationException(
                "Errore durante l'esecuzione del comando " +
                commandInternalName +
                ": " +
                errorMessage);
        }


        private static string NormalizeDrawingFileName(
            string? drawingName)
        {
            string value =
                drawingName
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }


            try
            {
                value =
                    IOPath.GetFileName(
                        value);
            }
            catch
            {
            }


            string extension =
                IOPath.GetExtension(
                    value);


            if (string.IsNullOrWhiteSpace(
                    extension))
            {
                return value +
                    ".idw";
            }


            if (!string.Equals(
                    extension,
                    ".idw",
                    StringComparison.OrdinalIgnoreCase))
            {
                return IOPath
                           .GetFileNameWithoutExtension(
                               value)
                       + ".idw";
            }


            return value;
        }


        private static string?
            FindDrawingRecursive(
                string searchRoot,
                string expectedFileName)
        {
            try
            {
                foreach (string file
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.TopDirectoryOnly))
                {
                    if (string.Equals(
                            IOPath.GetFileName(
                                file),
                            expectedFileName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return file;
                    }
                }


                foreach (string subDirectory
                    in Directory.EnumerateDirectories(
                        searchRoot))
                {
                    string? result =
                        FindDrawingRecursive(
                            subDirectory,
                            expectedFileName);

                    if (!string.IsNullOrWhiteSpace(
                            result))
                    {
                        return result;
                    }
                }
            }
            catch
            {
            }


            return null;
        }


        private void TryCloseDrawing(
            DrawingDocument drawing)
        {
            string path =
                InventorService
                    .GetDocumentFullFileName(
                        drawing)
                    .Trim();


            /*
             * Primo tentativo.
             */
            InventorService.CloseDrawingDocument(
                drawing,
                true);

            System.Windows.Forms.Application
                .DoEvents();


            /*
             * Secondo tentativo per percorso.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return;
            }


            List<Document> toClose =
                InventorService.FindOpenDrawingDocumentsByPath(
                    _inventorApp,
                    path);

            foreach (Document document
                     in toClose)
            {
                InventorService.CloseDocument(
                    document,
                    true);
            }
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;


            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }


            return realException.Message;
        }
    }
}