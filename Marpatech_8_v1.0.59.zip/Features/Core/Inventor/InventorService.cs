﻿using Inventor;
using Marpatech_8.Features.Mail;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.Core.Inventor
{
    public static class InventorService
    {
        public static Document? GetActiveDocument(
            InventorApp inventorApp)
        {
            try
            {
                if (inventorApp == null)
                    return null;

                return inventorApp.ActiveDocument;
            }
            catch
            {
                return null;
            }
        }

        public static AssemblyDocument? GetActiveAssembly(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as AssemblyDocument;
        }

        public static PartDocument? GetActivePart(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as PartDocument;
        }

        public static DrawingDocument? GetActiveDrawing(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as DrawingDocument;
        }

        public static bool DocumentIsAssembly(Document? document)
        {
            return document is AssemblyDocument;
        }

        public static bool DocumentIsPart(Document? document)
        {
            return document is PartDocument;
        }

        public static bool DocumentIsDrawing(Document? document)
        {
            return document is DrawingDocument;
        }

        public static string GetDocumentTypeName(Document? document)
        {
            if (document == null)
                return "";

            if (DocumentIsAssembly(document))
                return "Assembly";

            if (DocumentIsPart(document))
                return "Part";

            if (DocumentIsDrawing(document))
                return "Drawing";

            return document.DocumentType.ToString();
        }

        public static string ReadProperty(
            Document? document,
            string propertyName)
        {
            return ReadIProperty(document, propertyName);
        }

        public static string ReadIProperty(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return "";

            if (string.IsNullOrWhiteSpace(propertyName))
                return "";

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return property.Value?.ToString() ?? "";
                        }
                    }
                }
            }
            catch
            {
            }

            return "";
        }

        public static bool PropertyExists(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return false;

            if (string.IsNullOrWhiteSpace(propertyName))
                return false;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        public static void WriteProperty(
            Document? document,
            string propertyName,
            string value)
        {
            WriteIProperty(document, propertyName, value);
        }

        public static void WriteIProperty(
            Document? document,
            string propertyName,
            string value)
        {
            if (document == null)
                return;

            if (string.IsNullOrWhiteSpace(propertyName))
                return;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            property.Value = value ?? "";
                            return;
                        }
                    }
                }

                PropertySet userDefinedProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                userDefinedProperties.Add(
                    value ?? "",
                    propertyName);
            }
            catch
            {
            }
        }

        public static Dictionary<string, string> ReadConfiguredProperties(
            Document? document,
            IEnumerable<(string Tag, string IPropertyName)> properties)
        {
            Dictionary<string, string> values =
                new Dictionary<string, string>();

            if (document == null)
                return values;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                values[property.Tag] =
                    ReadIProperty(
                        document,
                        property.IPropertyName);
            }

            return values;
        }

        public static List<string> GetMissingRequiredProperties(
    Document? document,
    IEnumerable<(
        string Tag,
        string IPropertyName,
        bool IsRequired)> properties)
        {
            List<string> missingProperties =
                new List<string>();

            if (document == null)
                return missingProperties;

            if (properties == null)
                return missingProperties;

            foreach ((
                string Tag,
                string IPropertyName,
                bool IsRequired) property in properties)
            {
                if (!property.IsRequired)
                    continue;

                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                if (string.IsNullOrWhiteSpace(property.IPropertyName))
                {
                    missingProperties.Add(property.Tag);
                    continue;
                }

                string value =
                    ReadIProperty(
                        document,
                        property.IPropertyName);

                if (string.IsNullOrWhiteSpace(value))
                {
                    missingProperties.Add(
                        property.Tag);
                }
            }

            return missingProperties;
        }

        public static void WriteConfiguredProperties(
            Document? document,
            Dictionary<string, string> values,
            IEnumerable<(string Tag, string IPropertyName)> properties,
            bool skipEmptyValues = true)
        {
            if (document == null)
                return;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                if (string.IsNullOrWhiteSpace(property.IPropertyName))
                    continue;

                if (!values.ContainsKey(property.Tag))
                    continue;

                string value = values[property.Tag];

                if (skipEmptyValues &&
                    string.IsNullOrWhiteSpace(value))
                    continue;

                WriteIProperty(
                    document,
                    property.IPropertyName,
                    value);
            }
        }

        public static void SaveDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Save();
            }
            catch
            {
            }
        }

        public static void UpdateDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Update();
            }
            catch
            {
            }
        }

        public static InventorWindowWrapper GetInventorOwner(
            InventorApp inventorApp)
        {
            IntPtr inventorHandle =
                new IntPtr(inventorApp.MainFrameHWND);

            return new InventorWindowWrapper(inventorHandle);
        }

        public static string GetDocumentFullFileName(
    Document? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFileName(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetFileName(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFileNameWithoutExtension(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetFileNameWithoutExtension(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFolder(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetDirectoryName(
                    fullFileName) ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentDisplayName(
            Document? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.DisplayName ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static bool DocumentIsSaved(
            Document? document)
        {
            return !string.IsNullOrWhiteSpace(
                GetDocumentFullFileName(document));
        }

        public static string GetDocumentExtension(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetExtension(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static IntPtr GetMainFrameHandle(
            InventorApp inventorApp)
        {
            return new IntPtr(
                inventorApp.MainFrameHWND);
        }
        public static bool SetApplicationVisible(
    InventorApp inventorApp,
    bool visible)
        {
            if (inventorApp == null)
                return false;

            try
            {
                inventorApp.Visible =
                    visible;

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SaveActiveViewAsBitmap(
            InventorApp inventorApp,
            string imagePath,
            int width,
            int height)
        {
            if (inventorApp == null)
                return false;

            if (string.IsNullOrWhiteSpace(
                    imagePath))
            {
                return false;
            }

            try
            {
                inventorApp.ActiveView.SaveAsBitmap(
                    imagePath,
                    width,
                    height);

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool TryExecuteControlDefinition(
    InventorApp inventorApp,
    string controlDefinitionName,
    out bool commandFound,
    out string errorMessage)
        {
            commandFound =
                false;

            errorMessage =
                string.Empty;

            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    controlDefinitionName))
            {
                errorMessage =
                    "Nome comando Inventor non valido.";

                return false;
            }

            try
            {
                ControlDefinition? control =
                    inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            controlDefinitionName]
                        as ControlDefinition;

                if (control == null)
                {
                    return false;
                }

                commandFound =
                    true;

                control.Execute();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool IsDarkTheme(
    InventorApp inventorApp)
        {
            if (inventorApp == null)
                return false;

            try
            {
                string themeName =
                    inventorApp
                        .ThemeManager
                        .ActiveTheme
                        .Name
                        .ToLower();

                return
                    themeName.Contains("dark") ||
                    themeName.Contains("scuro") ||
                    themeName.Contains("nero");
            }
            catch
            {
                return false;
            }
        }

        public static ComponentOccurrences?
    GetAssemblyOccurrences(
        AssemblyDocument? assemblyDocument)
        {
            if (assemblyDocument == null)
                return null;

            try
            {
                return assemblyDocument
                    .ComponentDefinition
                    .Occurrences;
            }
            catch
            {
                return null;
            }
        }


        public static bool IsOccurrenceSuppressed(
            ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return true;

            try
            {
                return occurrence.Suppressed;
            }
            catch
            {
                /*
                 * Manteniamo esattamente la logica
                 * precedente di Stampa Cartelline:
                 * in caso di errore consideriamo
                 * l'occurrence come soppressa.
                 */
                return true;
            }
        }


        public static Document?
            GetOccurrenceDocument(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as Document;
            }
            catch
            {
                return null;
            }
        }


        public static AssemblyDocument?
            GetOccurrenceAssemblyDocument(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as AssemblyDocument;
            }
            catch
            {
                return null;
            }
        }


        public static ComponentOccurrences?
            GetOccurrenceChildOccurrences(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }

            return null;
        }


        public static string ReadUserDefinedProperty(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (string.IsNullOrWhiteSpace(
                    propertyName))
            {
                return string.Empty;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Property property
                         in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static string ReadUserDefinedProperty(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (string.IsNullOrWhiteSpace(
                    propertyName))
            {
                return string.Empty;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Property property
                         in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static Document? OpenDocument(
    InventorApp inventorApp,
    string filePath,
    bool visible)
        {
            if (inventorApp == null)
                return null;

            if (string.IsNullOrWhiteSpace(
                    filePath))
            {
                return null;
            }

            try
            {
                return inventorApp.Documents.Open(
                    filePath,
                    visible);
            }
            catch
            {
                return null;
            }
        }


        public static bool ActivateDocument(
            Document? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool ActivateAssemblyDocument(
            AssemblyDocument? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool ActivateDrawingDocument(
            DrawingDocument? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool CloseDocument(
            Document? document,
            bool skipSave)
        {
            if (document == null)
                return false;

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool CloseDrawingDocument(
            DrawingDocument? document,
            bool skipSave)
        {
            if (document == null)
                return false;

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static DrawingDocument? GetActiveDrawingDocument(
    InventorApp inventorApp)
        {
            try
            {
                if (inventorApp == null)
                    return null;

                return inventorApp.ActiveDocument
                    as DrawingDocument;
            }
            catch
            {
                return null;
            }
        }
        public static BrowserPane? GetActiveBrowserPane(
    AssemblyDocument? assemblyDocument)
        {
            if (assemblyDocument == null)
                return null;

            try
            {
                return assemblyDocument
                    .BrowserPanes
                    .ActivePane;
            }
            catch
            {
                return null;
            }
        }


        public static BrowserNode? GetBrowserTopNode(
            BrowserPane? browserPane)
        {
            if (browserPane == null)
                return null;

            try
            {
                return browserPane.TopNode;
            }
            catch
            {
                return null;
            }
        }


        public static bool SelectBrowserNode(
            BrowserNode? browserNode)
        {
            if (browserNode == null)
                return false;

            try
            {
                browserNode.DoSelect();

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool TryExecuteControlDefinition2(
    InventorApp inventorApp,
    string controlDefinitionName,
    bool synchronous,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    controlDefinitionName))
            {
                errorMessage =
                    "Nome comando Inventor non valido.";

                return false;
            }

            try
            {
                ControlDefinition command =
                    inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            controlDefinitionName];

                command.Execute2(
                    synchronous);

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static List<Document>
    FindOpenDrawingDocumentsByPath(
        InventorApp inventorApp,
        string drawingPath)
        {
            List<Document> result =
                new List<Document>();

            if (inventorApp == null)
                return result;

            if (string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                return result;
            }

            try
            {
                foreach (Document document
                         in inventorApp.Documents)
                {
                    try
                    {
                        if (!DocumentIsDrawing(
                                document))
                        {
                            continue;
                        }

                        string documentPath =
                            GetDocumentFullFileName(
                                document)
                            .Trim();

                        if (string.Equals(
                                documentPath,
                                drawingPath,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            result.Add(
                                document);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return result;
        }
        public static string GetDocumentFullFileName(
            AssemblyDocument? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }


        public static string GetDocumentFileNameWithoutExtension(
            AssemblyDocument? document)
        {
            string fullFileName =
                GetDocumentFullFileName(
                    document);

            if (string.IsNullOrWhiteSpace(
                    fullFileName))
            {
                return "";
            }

            try
            {
                return System.IO.Path
                    .GetFileNameWithoutExtension(
                        fullFileName);
            }
            catch
            {
                return "";
            }
        }
        public static string GetDocumentFullFileName(
    DrawingDocument? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }
        public static string ReadIProperty(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return "";

            if (string.IsNullOrWhiteSpace(propertyName))
                return "";

            try
            {
                foreach (PropertySet propertySet
                    in document.PropertySets)
                {
                    foreach (Property property
                        in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return property.Value
                                       ?.ToString()
                                   ?? "";
                        }
                    }
                }
            }
            catch
            {
            }

            return "";
        }
        public static List<Document> GetOpenDocuments(
    InventorApp inventorApp)
        {
            List<Document> documents =
                new List<Document>();

            if (inventorApp == null)
                return documents;

            try
            {
                foreach (Document document
                         in inventorApp.Documents)
                {
                    documents.Add(
                        document);
                }
            }
            catch
            {
            }

            return documents;
        }
        public static bool TryCloseDocument(
    Document? document,
    bool skipSave,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch (Exception exception)
            {
                Exception realException =
                    exception;

                while (realException.InnerException != null)
                {
                    realException =
                        realException.InnerException;
                }

                errorMessage =
                    realException.Message;

                return false;
            }
        }
        public static bool TryCloseDocument(
    AssemblyDocument? document,
    bool skipSave,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch (Exception exception)
            {
                Exception realException =
                    exception;

                while (realException.InnerException != null)
                {
                    realException =
                        realException.InnerException;
                }

                errorMessage =
                    realException.Message;

                return false;
            }
        }
        public static string ReadIPropertyExactName(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (propertyName == null)
                return string.Empty;

            try
            {
                foreach (PropertySet propertySet
                         in document.PropertySets)
                {
                    foreach (Property property
                             in propertySet)
                    {
                        /*
                         * IMPORTANTE:
                         * confronto volutamente identico
                         * alla logica originale.
                         */
                        if (property.Name == propertyName)
                        {
                            return property.Value
                                       ?.ToString()
                                   ?? string.Empty;
                        }
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static bool WriteIPropertyExactName(
    AssemblyDocument? document,
    string propertyName,
    string value)
        {
            if (document == null)
                return false;

            if (propertyName == null)
                return false;

            try
            {
                foreach (PropertySet propertySet
                         in document.PropertySets)
                {
                    foreach (Property property
                             in propertySet)
                    {
                        /*
                         * Confronto volutamente identico
                         * alla logica originale.
                         */
                        if (property.Name != propertyName)
                            continue;

                        property.Value =
                            value ?? string.Empty;

                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }
        public static ApplicationEvents? GetApplicationEvents(
    InventorApp inventorApp)
        {
            if (inventorApp == null)
                return null;

            try
            {
                return inventorApp.ApplicationEvents;
            }
            catch
            {
                return null;
            }
        }
    }
}