﻿using Marpatech_8.Features.GeneraWord.Translation.Models;
using Marpatech_8.Features.GeneraWord.Translation.Services;
using Marpatech_8.Features.GeneraWord.Translation.WindowSettings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Translation.Forms
{
    public class TranslationManagerForm : Form
    {
        private readonly bool _isDarkTheme;
        private TranslationDatabase _database = new TranslationDatabase();

        private DataGridView grid = null!;
        private CheckBox chkLock = null!;
        private Button btnAdd = null!;
        private Button btnDelete = null!;
        private TextBox txtSearch = null!;

        private readonly TranslationManagerWindowSettings _windowSettings;

        public TranslationManagerForm(bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;
            _windowSettings = TranslationManagerWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();
            LoadData();

            FormClosing += TranslationManagerForm_FormClosing;
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Gestisci Traduzioni";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(1100, 650);
            MinimumSize = new DrawingSize(950, 550);
            BackColor = backgroundColor;

            Label title = new Label();
            title.Text = "Gestisci Traduzioni";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            chkLock = new CheckBox();
            chkLock.Text = "Blocca modifiche";
            chkLock.ForeColor = titleColor;
            chkLock.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            chkLock.AutoSize = true;
            chkLock.Location = new DrawingPoint(40, 82);
            chkLock.CheckedChanged += (s, e) => ApplyLockState();

            txtSearch = new TextBox();
            txtSearch.Location = new DrawingPoint(260, 78);
            txtSearch.Size = new DrawingSize(320, 28);
            txtSearch.Font = new DrawingFont("Segoe UI", 10);
            txtSearch.PlaceholderText = "Cerca traduzione...";
            txtSearch.TextChanged += (s, e) => ApplySearchFilter();

            Controls.Add(txtSearch);
            grid = new DataGridView();
            grid.Location = new DrawingPoint(35, 120);
            grid.Size = new DrawingSize(ClientSize.Width - 70, ClientSize.Height - 210);
            grid.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.AllowUserToOrderColumns = true;

            btnAdd = CreateButton("Aggiungi", DrawingColor.FromArgb(37, 99, 235), 140, 42);
            btnAdd.Location = new DrawingPoint(35, ClientSize.Height - 70);
            btnAdd.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnAdd.Click += BtnAdd_Click;

            btnDelete = CreateButton("Elimina", DrawingColor.FromArgb(220, 38, 38), 140, 42);
            btnDelete.Location = new DrawingPoint(185, ClientSize.Height - 70);
            btnDelete.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnDelete.Click += BtnDelete_Click;

            Button btnCancel = CreateButton("Annulla", DrawingColor.FromArgb(100, 116, 139), 140, 42);
            btnCancel.Location = new DrawingPoint(ClientSize.Width - 330, ClientSize.Height - 70);
            btnCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnCancel.Click += (s, e) => Close();

            Button btnSave = CreateButton("Salva", DrawingColor.FromArgb(22, 163, 74), 140, 42);
            btnSave.Location = new DrawingPoint(ClientSize.Width - 180, ClientSize.Height - 70);
            btnSave.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSave.Click += BtnSave_Click;

            Controls.Add(title);
            Controls.Add(chkLock);
            Controls.Add(grid);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
        }

        private void ApplySearchFilter()
        {
            string search = txtSearch.Text.Trim();

            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                bool visible = string.IsNullOrWhiteSpace(search);

                if (!visible)
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        string value = cell.Value?.ToString() ?? "";

                        if (value.Contains(search, StringComparison.OrdinalIgnoreCase))
                        {
                            visible = true;
                            break;
                        }
                    }
                }

                row.Visible = visible;
            }
        }

        private void LoadData()
        {
            _database = TranslationDatabaseService.Load();

            List<string> languages = _database.Entries
                .SelectMany(x => x.Translations.Keys)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();

            if (!languages.Contains("EN"))
                languages.Add("EN");

            if (!languages.Contains("FR"))
                languages.Add("FR");

            if (!languages.Contains("ES"))
                languages.Add("ES");

            languages = languages
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(x => x)
                .ToList();

            grid.Columns.Clear();

            DataGridViewTextBoxColumn italianColumn = new DataGridViewTextBoxColumn();
            italianColumn.Name = "ItalianText";
            italianColumn.HeaderText = "Italiano";
            italianColumn.Width = 280;
            grid.Columns.Add(italianColumn);

            foreach (string language in languages)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.Name = language.ToUpperInvariant();
                column.HeaderText = language.ToUpperInvariant();
                column.Width = 220;
                grid.Columns.Add(column);
            }

            grid.Rows.Clear();

            foreach (TranslationEntry entry in _database.Entries)
            {
                int rowIndex = grid.Rows.Add();
                DataGridViewRow row = grid.Rows[rowIndex];

                row.Cells["ItalianText"].Value = entry.ItalianText;

                foreach (string language in languages)
                {
                    string lang = language.ToUpperInvariant();

                    if (entry.Translations.ContainsKey(lang))
                        row.Cells[lang].Value = entry.Translations[lang];
                    else
                        row.Cells[lang].Value = "";
                }
            }

            ApplyLockState();
            ApplySearchFilter();
            ApplyColumnOrder();
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            grid.Rows.Add();
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (grid.SelectedRows.Count == 0)
                return;

            grid.Rows.Remove(grid.SelectedRows[0]);
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            TranslationDatabase newDatabase =
                new TranslationDatabase();

            foreach (DataGridViewRow row in grid.Rows)
            {
                string italian =
                    row.Cells["ItalianText"].Value?.ToString()?.Trim() ?? "";

                if (string.IsNullOrWhiteSpace(italian))
                    continue;

                TranslationEntry entry = new TranslationEntry();
                entry.ItalianText = italian;

                foreach (DataGridViewColumn column in grid.Columns)
                {
                    if (column.Name == "ItalianText")
                        continue;

                    string value =
                        row.Cells[column.Name].Value?.ToString()?.Trim() ?? "";

                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        entry.Translations[column.Name.ToUpperInvariant()] = value;
                    }
                }

                newDatabase.Entries.Add(entry);
            }

            TranslationDatabaseService.Save(newDatabase);
            Close();
        }

        private void ApplyLockState()
        {
            bool locked = chkLock.Checked;

            grid.ReadOnly = locked;
            grid.AllowUserToResizeColumns = !locked;
            grid.AllowUserToResizeRows = !locked;

            btnAdd.Enabled = !locked;
            btnDelete.Enabled = !locked;
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }
        private void ApplyWindowSettings()
        {
            Size = new DrawingSize(
                _windowSettings.Width,
                _windowSettings.Height);

            if (_windowSettings.Left >= 0 &&
                _windowSettings.Top >= 0)
            {
                StartPosition = FormStartPosition.Manual;
                Location = new DrawingPoint(
                    _windowSettings.Left,
                    _windowSettings.Top);
            }

            if (_windowSettings.IsMaximized)
                WindowState = FormWindowState.Maximized;
        }
        private void TranslationManagerForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = Width;
                _windowSettings.Height = Height;
                _windowSettings.Left = Left;
                _windowSettings.Top = Top;
                _windowSettings.IsMaximized = false;
            }
            else if (WindowState == FormWindowState.Maximized)
            {
                _windowSettings.IsMaximized = true;
            }

            _windowSettings.ColumnDisplayIndexes.Clear();

            foreach (DataGridViewColumn column in grid.Columns)
            {
                _windowSettings.ColumnDisplayIndexes[column.Name] =
                    column.DisplayIndex;
            }

            TranslationManagerWindowSettingsService.Save(_windowSettings);
        }
        private void ApplyColumnOrder()
        {
            foreach (DataGridViewColumn column in grid.Columns)
            {
                if (_windowSettings.ColumnDisplayIndexes.TryGetValue(
                    column.Name,
                    out int index))
                {
                    if (index >= 0 &&
                        index < grid.Columns.Count)
                    {
                        column.DisplayIndex = index;
                    }
                }
            }
        }
    }
}