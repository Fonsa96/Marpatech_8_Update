﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class DashboardConfigurationManager
    {
        private readonly ComboBox _configurationComboBox;

        private List<PrintFolderConfiguration>
            _configurations =
                new List<PrintFolderConfiguration>();

        public DashboardConfigurationManager(
            ComboBox configurationComboBox)
        {
            _configurationComboBox =
                configurationComboBox
                ?? throw new ArgumentNullException(
                    nameof(configurationComboBox));
        }

        public PrintFolderConfiguration?
            SelectedConfiguration
        {
            get
            {
                return _configurationComboBox
                    .SelectedItem
                    as PrintFolderConfiguration;
            }
        }

        public void Load(
            string? configurationNameToRestore = null)
        {
            PrintFolderConfigurationsFile file =
                StampaCartellineStorage.Load();

            _configurations =
                file.Configurations
                ?? new List<PrintFolderConfiguration>();

            _configurationComboBox
                .BeginUpdate();

            try
            {
                _configurationComboBox
                    .DataSource = null;

                _configurationComboBox
                    .DisplayMember =
                        nameof(
                            PrintFolderConfiguration.Name);

                /*
                 * Aggiungiamo una prima voce vuota
                 * solo alla lista visualizzata.
                 *
                 * Non modifichiamo le configurazioni
                 * originali né il file salvato.
                 */
                List<PrintFolderConfiguration>
                    displayConfigurations =
                        new List<PrintFolderConfiguration>();

                displayConfigurations.Add(
                    new PrintFolderConfiguration
                    {
                        Name = string.Empty
                    });

                displayConfigurations.AddRange(
                    _configurations);

                _configurationComboBox
                    .DataSource =
                        displayConfigurations;

                RestoreSelection(
                    configurationNameToRestore);
            }
            finally
            {
                _configurationComboBox
                    .EndUpdate();
            }
        }

        private void RestoreSelection(
            string? configurationName)
        {
            /*
             * Se viene richiesta esplicitamente
             * una configurazione da ripristinare,
             * manteniamo questa funzionalità.
             */
            if (!string.IsNullOrWhiteSpace(
                    configurationName))
            {
                int index =
                    _configurations.FindIndex(
                        configuration =>
                            string.Equals(
                                configuration.Name,
                                configurationName,
                                StringComparison
                                    .OrdinalIgnoreCase));

                if (index >= 0)
                {
                    /*
                     * +1 perché la prima voce
                     * della ComboBox è vuota.
                     */
                    _configurationComboBox
                        .SelectedIndex =
                            index + 1;

                    return;
                }
            }

            /*
             * All'apertura viene selezionata
             * sempre la prima riga vuota.
             *
             * SelectedConfiguration restituisce
             * null per questa voce.
             */
            _configurationComboBox
                .SelectedIndex = 0;
        }
    }
}
