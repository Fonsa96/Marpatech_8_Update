﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.Core.Inventor;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class DashboardInventorPropertyWriter
    {
        private readonly Inventor.Application _inventorApp;

        public DashboardInventorPropertyWriter(
            Inventor.Application inventorApp)
        {
            _inventorApp = inventorApp;
        }

        public bool WriteProperties(
            IEnumerable<DashboardPropertySession> properties)
        {
            return WriteProperties(
                properties,
                out _);
        }

        public bool WriteProperties(
            IEnumerable<DashboardPropertySession> properties,
            out string errorMessage)
        {
            errorMessage = string.Empty;

            AssemblyDocument? document =
                InventorService.GetActiveAssembly(
                    _inventorApp);

            if (document == null)
            {
                errorMessage =
                    "Impossibile recuperare " +
                    "l'assieme attivo in Inventor.";

                return false;
            }

            foreach (DashboardPropertySession property
                in properties)
            {
                bool written =
                    InventorService.TryWriteIPropertyExactName(
                        document,
                        property.InventorPropertyName,
                        property.Value,
                        out errorMessage);

                if (!written)
                    return false;

                property.OriginalValue =
                    property.Value;
            }

            return true;
        }
    }
}