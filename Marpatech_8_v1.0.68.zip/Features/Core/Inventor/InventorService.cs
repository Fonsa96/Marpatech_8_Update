﻿using Inventor;
using Marpatech_8.Features.Mail;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;
using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.Core.Inventor
{
    public static class InventorService
    {
        public static Document? GetActiveDocument(
            InventorApp inventorApp)
        {
            try
            {
                if (inventorApp == null)
                    return null;

                return inventorApp.ActiveDocument;
            }
            catch
            {
                return null;
            }
        }

        public static AssemblyDocument? GetActiveAssembly(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as AssemblyDocument;
        }

        public static PartDocument? GetActivePart(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as PartDocument;
        }

        public static DrawingDocument? GetActiveDrawing(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as DrawingDocument;
        }

        public static bool DocumentIsAssembly(Document? document)
        {
            return document is AssemblyDocument;
        }

        public static bool DocumentIsPart(Document? document)
        {
            return document is PartDocument;
        }

        public static bool DocumentIsDrawing(Document? document)
        {
            return document is DrawingDocument;
        }

        public static string GetDocumentTypeName(Document? document)
        {
            if (document == null)
                return "";

            if (DocumentIsAssembly(document))
                return "Assembly";

            if (DocumentIsPart(document))
                return "Part";

            if (DocumentIsDrawing(document))
                return "Drawing";

            return document.DocumentType.ToString();
        }

        public static string ReadProperty(
            Document? document,
            string propertyName)
        {
            return ReadIProperty(document, propertyName);
        }

        public static string ReadIProperty(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return "";

            if (string.IsNullOrWhiteSpace(propertyName))
                return "";

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return property.Value?.ToString() ?? "";
                        }
                    }
                }
            }
            catch
            {
            }

            return "";
        }

        public static bool PropertyExists(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return false;

            if (string.IsNullOrWhiteSpace(propertyName))
                return false;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        public static void WriteProperty(
            Document? document,
            string propertyName,
            string value)
        {
            WriteIProperty(document, propertyName, value);
        }

        public static void WriteIProperty(
            Document? document,
            string propertyName,
            string value)
        {
            if (document == null)
                return;

            if (string.IsNullOrWhiteSpace(propertyName))
                return;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            property.Value = value ?? "";
                            return;
                        }
                    }
                }

                PropertySet userDefinedProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                userDefinedProperties.Add(
                    value ?? "",
                    propertyName);
            }
            catch
            {
            }
        }

        public static Dictionary<string, string> ReadConfiguredProperties(
            Document? document,
            IEnumerable<(string Tag, string IPropertyName)> properties)
        {
            Dictionary<string, string> values =
                new Dictionary<string, string>();

            if (document == null)
                return values;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                values[property.Tag] =
                    ReadIProperty(
                        document,
                        property.IPropertyName);
            }

            return values;
        }

        public static List<string> GetMissingRequiredProperties(
    Document? document,
    IEnumerable<(
        string Tag,
        string IPropertyName,
        bool IsRequired)> properties)
        {
            List<string> missingProperties =
                new List<string>();

            if (document == null)
                return missingProperties;

            if (properties == null)
                return missingProperties;

            foreach ((
                string Tag,
                string IPropertyName,
                bool IsRequired) property in properties)
            {
                if (!property.IsRequired)
                    continue;

                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                if (string.IsNullOrWhiteSpace(property.IPropertyName))
                {
                    missingProperties.Add(property.Tag);
                    continue;
                }

                string value =
                    ReadIProperty(
                        document,
                        property.IPropertyName);

                if (string.IsNullOrWhiteSpace(value))
                {
                    missingProperties.Add(
                        property.Tag);
                }
            }

            return missingProperties;
        }

        public static void WriteConfiguredProperties(
            Document? document,
            Dictionary<string, string> values,
            IEnumerable<(string Tag, string IPropertyName)> properties,
            bool skipEmptyValues = true)
        {
            if (document == null)
                return;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                if (string.IsNullOrWhiteSpace(property.IPropertyName))
                    continue;

                if (!values.ContainsKey(property.Tag))
                    continue;

                string value = values[property.Tag];

                if (skipEmptyValues &&
                    string.IsNullOrWhiteSpace(value))
                    continue;

                WriteIProperty(
                    document,
                    property.IPropertyName,
                    value);
            }
        }

        public static void SaveDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Save();
            }
            catch
            {
            }
        }

        public static void UpdateDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Update();
            }
            catch
            {
            }
        }

        public static InventorWindowWrapper GetInventorOwner(
            InventorApp inventorApp)
        {
            IntPtr inventorHandle =
                new IntPtr(inventorApp.MainFrameHWND);

            return new InventorWindowWrapper(inventorHandle);
        }

        public static string GetDocumentFullFileName(
    Document? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFileName(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetFileName(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFileNameWithoutExtension(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetFileNameWithoutExtension(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentFolder(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetDirectoryName(
                    fullFileName) ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static string GetDocumentDisplayName(
            Document? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.DisplayName ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static bool DocumentIsSaved(
            Document? document)
        {
            return !string.IsNullOrWhiteSpace(
                GetDocumentFullFileName(document));
        }

        public static string GetDocumentExtension(
            Document? document)
        {
            string fullFileName =
                GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullFileName))
                return "";

            try
            {
                return System.IO.Path.GetExtension(
                    fullFileName);
            }
            catch
            {
                return "";
            }
        }

        public static IntPtr GetMainFrameHandle(
            InventorApp inventorApp)
        {
            return new IntPtr(
                inventorApp.MainFrameHWND);
        }
        public static bool SetApplicationVisible(
    InventorApp inventorApp,
    bool visible)
        {
            if (inventorApp == null)
                return false;

            try
            {
                inventorApp.Visible =
                    visible;

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SaveActiveViewAsBitmap(
            InventorApp inventorApp,
            string imagePath,
            int width,
            int height)
        {
            if (inventorApp == null)
                return false;

            if (string.IsNullOrWhiteSpace(
                    imagePath))
            {
                return false;
            }

            try
            {
                inventorApp.ActiveView.SaveAsBitmap(
                    imagePath,
                    width,
                    height);

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool TryExecuteControlDefinition(
    InventorApp inventorApp,
    string controlDefinitionName,
    out bool commandFound,
    out string errorMessage)
        {
            commandFound =
                false;

            errorMessage =
                string.Empty;

            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    controlDefinitionName))
            {
                errorMessage =
                    "Nome comando Inventor non valido.";

                return false;
            }

            try
            {
                ControlDefinition? control =
                    inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            controlDefinitionName]
                        as ControlDefinition;

                if (control == null)
                {
                    return false;
                }

                commandFound =
                    true;

                control.Execute();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool IsDarkTheme(
    InventorApp inventorApp)
        {
            if (inventorApp == null)
                return false;

            try
            {
                string themeName =
                    inventorApp
                        .ThemeManager
                        .ActiveTheme
                        .Name
                        .ToLower();

                return
                    themeName.Contains("dark") ||
                    themeName.Contains("scuro") ||
                    themeName.Contains("nero");
            }
            catch
            {
                return false;
            }
        }

        public static ComponentOccurrences?
    GetAssemblyOccurrences(
        AssemblyDocument? assemblyDocument)
        {
            if (assemblyDocument == null)
                return null;

            try
            {
                return assemblyDocument
                    .ComponentDefinition
                    .Occurrences;
            }
            catch
            {
                return null;
            }
        }


        public static bool IsOccurrenceSuppressed(
            ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return true;

            try
            {
                return occurrence.Suppressed;
            }
            catch
            {
                /*
                 * Manteniamo esattamente la logica
                 * precedente di Stampa Cartelline:
                 * in caso di errore consideriamo
                 * l'occurrence come soppressa.
                 */
                return true;
            }
        }


        public static Document?
            GetOccurrenceDocument(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as Document;
            }
            catch
            {
                return null;
            }
        }


        public static AssemblyDocument?
            GetOccurrenceAssemblyDocument(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as AssemblyDocument;
            }
            catch
            {
                return null;
            }
        }


        public static ComponentOccurrences?
            GetOccurrenceChildOccurrences(
                ComponentOccurrence? occurrence)
        {
            if (occurrence == null)
                return null;

            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }

            return null;
        }


        public static string ReadUserDefinedProperty(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (string.IsNullOrWhiteSpace(
                    propertyName))
            {
                return string.Empty;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Property property
                         in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static string ReadUserDefinedProperty(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (string.IsNullOrWhiteSpace(
                    propertyName))
            {
                return string.Empty;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Property property
                         in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static Document? OpenDocument(
    InventorApp inventorApp,
    string filePath,
    bool visible)
        {
            if (inventorApp == null)
                return null;

            if (string.IsNullOrWhiteSpace(
                    filePath))
            {
                return null;
            }

            try
            {
                return inventorApp.Documents.Open(
                    filePath,
                    visible);
            }
            catch
            {
                return null;
            }
        }


        public static bool ActivateDocument(
            Document? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool ActivateAssemblyDocument(
            AssemblyDocument? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool ActivateDrawingDocument(
            DrawingDocument? document)
        {
            if (document == null)
                return false;

            try
            {
                document.Activate();

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool CloseDocument(
            Document? document,
            bool skipSave)
        {
            if (document == null)
                return false;

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch
            {
                return false;
            }
        }


        public static bool CloseDrawingDocument(
            DrawingDocument? document,
            bool skipSave)
        {
            if (document == null)
                return false;

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static DrawingDocument? GetActiveDrawingDocument(
            InventorApp inventorApp)
        {
            return GetActiveDrawing(
                inventorApp);
        }

        public static BrowserPane? GetActiveBrowserPane(
    AssemblyDocument? assemblyDocument)
        {
            if (assemblyDocument == null)
                return null;

            try
            {
                return assemblyDocument
                    .BrowserPanes
                    .ActivePane;
            }
            catch
            {
                return null;
            }
        }


        public static BrowserNode? GetBrowserTopNode(
            BrowserPane? browserPane)
        {
            if (browserPane == null)
                return null;

            try
            {
                return browserPane.TopNode;
            }
            catch
            {
                return null;
            }
        }


        public static bool SelectBrowserNode(
            BrowserNode? browserNode)
        {
            if (browserNode == null)
                return false;

            try
            {
                browserNode.DoSelect();

                return true;
            }
            catch
            {
                return false;
            }
        }
        public static bool TryExecuteControlDefinition2(
    InventorApp inventorApp,
    string controlDefinitionName,
    bool synchronous,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    controlDefinitionName))
            {
                errorMessage =
                    "Nome comando Inventor non valido.";

                return false;
            }

            try
            {
                ControlDefinition command =
                    inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            controlDefinitionName];

                command.Execute2(
                    synchronous);

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static List<Document>
    FindOpenDrawingDocumentsByPath(
        InventorApp inventorApp,
        string drawingPath)
        {
            List<Document> result =
                new List<Document>();

            if (inventorApp == null)
                return result;

            if (string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                return result;
            }

            try
            {
                foreach (Document document
                         in inventorApp.Documents)
                {
                    try
                    {
                        if (!DocumentIsDrawing(
                                document))
                        {
                            continue;
                        }

                        string documentPath =
                            GetDocumentFullFileName(
                                document)
                            .Trim();

                        if (string.Equals(
                                documentPath,
                                drawingPath,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            result.Add(
                                document);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return result;
        }
        public static string GetDocumentFullFileName(
            AssemblyDocument? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }


        public static string GetDocumentFileNameWithoutExtension(
            AssemblyDocument? document)
        {
            string fullFileName =
                GetDocumentFullFileName(
                    document);

            if (string.IsNullOrWhiteSpace(
                    fullFileName))
            {
                return "";
            }

            try
            {
                return System.IO.Path
                    .GetFileNameWithoutExtension(
                        fullFileName);
            }
            catch
            {
                return "";
            }
        }
        public static string GetDocumentFullFileName(
    DrawingDocument? document)
        {
            if (document == null)
                return "";

            try
            {
                return document.FullFileName ?? "";
            }
            catch
            {
                return "";
            }
        }
        public static string ReadIProperty(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return "";

            if (string.IsNullOrWhiteSpace(propertyName))
                return "";

            try
            {
                foreach (PropertySet propertySet
                    in document.PropertySets)
                {
                    foreach (Property property
                        in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return property.Value
                                       ?.ToString()
                                   ?? "";
                        }
                    }
                }
            }
            catch
            {
            }

            return "";
        }
        public static List<Document> GetOpenDocuments(
    InventorApp inventorApp)
        {
            List<Document> documents =
                new List<Document>();

            if (inventorApp == null)
                return documents;

            try
            {
                foreach (Document document
                         in inventorApp.Documents)
                {
                    documents.Add(
                        document);
                }
            }
            catch
            {
            }

            return documents;
        }
        public static bool TryCloseDocument(
    Document? document,
    bool skipSave,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch (Exception exception)
            {
                Exception realException =
                    exception;

                while (realException.InnerException != null)
                {
                    realException =
                        realException.InnerException;
                }

                errorMessage =
                    realException.Message;

                return false;
            }
        }
        public static bool TryCloseDocument(
    AssemblyDocument? document,
    bool skipSave,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Close(
                    skipSave);

                return true;
            }
            catch (Exception exception)
            {
                Exception realException =
                    exception;

                while (realException.InnerException != null)
                {
                    realException =
                        realException.InnerException;
                }

                errorMessage =
                    realException.Message;

                return false;
            }
        }
        public static string ReadIPropertyExactName(
    AssemblyDocument? document,
    string propertyName)
        {
            if (document == null)
                return string.Empty;

            if (propertyName == null)
                return string.Empty;

            try
            {
                foreach (PropertySet propertySet
                         in document.PropertySets)
                {
                    foreach (Property property
                             in propertySet)
                    {
                        /*
                         * IMPORTANTE:
                         * confronto volutamente identico
                         * alla logica originale.
                         */
                        if (property.Name == propertyName)
                        {
                            return property.Value
                                       ?.ToString()
                                   ?? string.Empty;
                        }
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
        public static bool WriteIPropertyExactName(
    AssemblyDocument? document,
    string propertyName,
    string value)
        {
            if (document == null)
                return false;

            if (propertyName == null)
                return false;

            try
            {
                foreach (PropertySet propertySet
                         in document.PropertySets)
                {
                    foreach (Property property
                             in propertySet)
                    {
                        /*
                         * Confronto volutamente identico
                         * alla logica originale.
                         */
                        if (property.Name != propertyName)
                            continue;

                        property.Value =
                            value ?? string.Empty;

                        return true;
                    }
                }
            }
            catch
            {
            }

            return false;
        }
        public static ApplicationEvents? GetApplicationEvents(
    InventorApp inventorApp)
        {
            if (inventorApp == null)
                return null;

            try
            {
                return inventorApp.ApplicationEvents;
            }
            catch
            {
                return null;
            }
        }

        public static List<InventorCustomCodeMatch>
    FindAssembliesByCustomCode(
        global::Inventor.Application inventorApp,
        IEnumerable<string> requestedCodes,
        string searchPropertyName)
        {
            List<InventorCustomCodeMatch> result =
                new List<InventorCustomCodeMatch>();


            if (inventorApp.ActiveDocument == null)
                return result;


            if (inventorApp.ActiveDocument.DocumentType !=
                global::Inventor.DocumentTypeEnum
                    .kAssemblyDocumentObject)
            {
                return result;
            }


            List<string> requestedCodeList =
                requestedCodes
                    .Where(code =>
                        !string.IsNullOrWhiteSpace(code))
                    .Select(code =>
                        code.Trim())
                    .Distinct(
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();


            if (requestedCodeList.Count == 0)
                return result;


            HashSet<string> requestedCodeSet =
                new HashSet<string>(
                    requestedCodeList,
                    StringComparer.OrdinalIgnoreCase);


            global::Inventor.AssemblyDocument rootAssembly =
                (global::Inventor.AssemblyDocument)
                    inventorApp.ActiveDocument;


            /*
             * Un file viene analizzato una sola volta
             * anche se compare più volte nell'albero.
             */
            HashSet<string> processedDocuments =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            ScanOccurrencesRecursive(
                rootAssembly.ComponentDefinition.Occurrences,
                requestedCodeSet,
                searchPropertyName,
                processedDocuments,
                result);


            /*
             * Riportiamo i risultati nello stesso ordine
             * dei codici inseriti nel Form L.
             */
            Dictionary<string, int> requestedOrder =
                requestedCodeList
                    .Select(
                        (code, index) =>
                            new
                            {
                                Code = code,
                                Index = index
                            })
                    .ToDictionary(
                        item => item.Code,
                        item => item.Index,
                        StringComparer.OrdinalIgnoreCase);


            return result
                .OrderBy(match =>
                {
                    if (requestedOrder.TryGetValue(
                        match.Code,
                        out int index))
                    {
                        return index;
                    }

                    return int.MaxValue;
                })
                .ToList();
        }


        private static void ScanOccurrencesRecursive(
            global::Inventor.ComponentOccurrences occurrences,
            HashSet<string> requestedCodes,
            string searchPropertyName,
            HashSet<string> processedDocuments,
            List<InventorCustomCodeMatch> result)
        {
            foreach (
                global::Inventor.ComponentOccurrence occurrence
                in occurrences)
            {
                ProcessOccurrenceRecursive(
                    occurrence,
                    requestedCodes,
                    searchPropertyName,
                    processedDocuments,
                    result);
            }
        }


        private static void ScanOccurrencesRecursive(
            global::Inventor.ComponentOccurrencesEnumerator occurrences,
            HashSet<string> requestedCodes,
            string searchPropertyName,
            HashSet<string> processedDocuments,
            List<InventorCustomCodeMatch> result)
        {
            foreach (
                global::Inventor.ComponentOccurrence occurrence
                in occurrences)
            {
                ProcessOccurrenceRecursive(
                    occurrence,
                    requestedCodes,
                    searchPropertyName,
                    processedDocuments,
                    result);
            }
        }


        private static void ProcessOccurrenceRecursive(
            global::Inventor.ComponentOccurrence occurrence,
            HashSet<string> requestedCodes,
            string searchPropertyName,
            HashSet<string> processedDocuments,
            List<InventorCustomCodeMatch> result)
        {
            try
            {
                if (occurrence.Suppressed)
                    return;


                global::Inventor.Document document =
                    (global::Inventor.Document)
                        occurrence.Definition.Document;


                /*
                 * Gli STL che cerchiamo sono assiemi.
                 */
                if (document.DocumentType ==
                    global::Inventor.DocumentTypeEnum
                        .kAssemblyDocumentObject)
                {
                    string code =
                        GetCustomPropertyValue(
                            document,
                            searchPropertyName)
                        .Trim();


                    if (!string.IsNullOrWhiteSpace(code) &&
                        requestedCodes.Contains(code))
                    {
                        string documentKey =
                            GetDocumentUniqueKey(
                                document);


                        /*
                         * Stesso file ripetuto nell'albero:
                         * lo registriamo una volta sola.
                         */
                        if (processedDocuments.Add(
                            documentKey))
                        {
                            bool isModifiable =
                                false;


                            try
                            {
                                isModifiable =
                                    document.IsModifiable;
                            }
                            catch
                            {
                                isModifiable =
                                    false;
                            }


                            result.Add(
                                new InventorCustomCodeMatch
                                {
                                    Code =
                                        code,

                                    FullFileName =
                                        document.FullFileName,

                                    IsModifiable =
                                        isModifiable,

                                    UpdatedSuccessfully =
                                        false
                                });
                        }
                    }
                }


                /*
                 * Continuiamo sempre la scansione,
                 * anche se l'assieme corrente è
                 * già uno degli STL richiesti.
                 */
                if (occurrence.SubOccurrences.Count > 0)
                {
                    ScanOccurrencesRecursive(
                        occurrence.SubOccurrences,
                        requestedCodes,
                        searchPropertyName,
                        processedDocuments,
                        result);
                }
            }
            catch
            {
                /*
                 * Una singola occorrenza non leggibile
                 * non interrompe la scansione generale.
                 */
            }
        }

        private static string GetCustomPropertyValue(
            global::Inventor.Document document,
            string propertyName)
        {
            try
            {
                global::Inventor.PropertySet customPropertySet =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                global::Inventor.Property property =
                    customPropertySet[propertyName];

                return property.Value?.ToString() ??
                    string.Empty;
            }
            catch
            {
                return string.Empty;
            }
        }


        private static void SetCustomPropertyValue(
            global::Inventor.Document document,
            string propertyName,
            string value)
        {
            global::Inventor.PropertySet customPropertySet =
                document.PropertySets[
                    "Inventor User Defined Properties"];

            try
            {
                global::Inventor.Property existingProperty =
                    customPropertySet[propertyName];

                existingProperty.Value =
                    value;
            }
            catch
            {
                customPropertySet.Add(
                    value,
                    propertyName);
            }
        }


        private static string GetDocumentUniqueKey(
            global::Inventor.Document document)
        {
            if (!string.IsNullOrWhiteSpace(
                document.FullFileName))
            {
                return document.FullFileName;
            }

            return document.InternalName;
        }
        public sealed class InventorCustomCodeMatch
        {
            public string Code { get; set; } =
                string.Empty;

            public string FullFileName { get; set; } =
                string.Empty;

            public bool IsModifiable { get; set; }

            public bool UpdatedSuccessfully { get; set; }

            public string ErrorMessage { get; set; } =
                string.Empty;
        }
        public static bool IsActiveDocumentAssembly(
    global::Inventor.Application inventorApp)
        {
            try
            {
                if (inventorApp.ActiveDocument == null)
                    return false;

                return inventorApp.ActiveDocument.DocumentType ==
                    global::Inventor.DocumentTypeEnum
                        .kAssemblyDocumentObject;
            }
            catch
            {
                return false;
            }
        }
        public static bool WriteCustomPropertyToMatchedDocuments(
    global::Inventor.Application inventorApp,
    IEnumerable<InventorCustomCodeMatch> matches,
    string propertyName,
    string propertyValue,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;


            List<InventorCustomCodeMatch> matchList =
                matches.ToList();


            /*
             * Prima verifica globale.
             *
             * Non tocchiamo nessun file se anche uno
             * solo non è modificabile.
             */
            List<InventorCustomCodeMatch> notModifiable =
                matchList
                    .Where(match =>
                        !match.IsModifiable)
                    .ToList();


            if (notModifiable.Count > 0)
            {
                errorMessage =
                    string.Join(
                        "\r\n",
                        notModifiable.Select(
                            match =>
                                match.Code));

                return false;
            }


            /*
             * Solo dopo aver verificato TUTTI
             * iniziamo realmente la scrittura.
             */
            foreach (InventorCustomCodeMatch match
                in matchList)
            {
                try
                {
                    global::Inventor.Document? document =
                        null;


                    foreach (global::Inventor.Document openDocument
                        in inventorApp.Documents)
                    {
                        if (string.Equals(
                            openDocument.FullFileName,
                            match.FullFileName,
                            StringComparison.OrdinalIgnoreCase))
                        {
                            document =
                                openDocument;

                            break;
                        }
                    }


                    if (document == null)
                    {
                        errorMessage =
                            "Impossibile recuperare il documento:\r\n" +
                            match.Code;

                        return false;
                    }

                    /*
 * Ricontrollo immediatamente prima
 * della modifica.
 */
                    bool stillModifiable =
                        false;

                    try
                    {
                        stillModifiable =
                            document.IsModifiable;
                    }
                    catch
                    {
                        stillModifiable =
                            false;
                    }


                    if (!stillModifiable)
                    {
                        match.IsModifiable =
                            false;

                        errorMessage =
                            "Lo STL \"" +
                            match.Code +
                            "\" risulta in sola lettura.\r\n\r\n" +
                            "Assicurati che il file sia in check-out.";

                        return false;
                    }


                    SetCustomPropertyValue(
                        document,
                        propertyName,
                        propertyValue);


                    document.Save();


                    match.UpdatedSuccessfully =
                        true;
                }
                catch (Exception ex)
                {
                    match.UpdatedSuccessfully =
                        false;

                    match.ErrorMessage =
                        ex.Message;


                    errorMessage =
                        "Errore durante l'aggiornamento di " +
                        match.Code +
                        ":\r\n\r\n" +
                        ex.Message;

                    return false;
                }
            }


            return true;
        }
        public static string ReadActiveAssemblyCustomProperty(
    InventorApp inventorApp,
    string propertyName)
        {
            AssemblyDocument? assembly =
                GetActiveAssembly(
                    inventorApp);

            if (assembly == null)
                return string.Empty;

            return ReadUserDefinedProperty(
                assembly,
                propertyName);
        }
        public static Document? GetSelectedReferencedDocument(
        InventorApp inventorApp)
        {
            if (inventorApp == null)
                return null;

            try
            {
                Document? activeDocument =
                    inventorApp.ActiveDocument;

                if (activeDocument == null)
                    return null;

                if (activeDocument.SelectSet.Count == 0)
                    return null;


                object selectedObject =
                    activeDocument.SelectSet[1];


                /*
                 * ==========================================
                 * SELEZIONE IN ASSIEME
                 * ==========================================
                 */
                if (selectedObject is
                    ComponentOccurrence selectedOccurrence)
                {
                    return GetOccurrenceDocument(
                        selectedOccurrence);
                }


                /*
                 * ==========================================
                 * SELEZIONE DRAWING CURVE SEGMENT
                 * ==========================================
                 */
                if (selectedObject is
                    DrawingCurveSegment curveSegment)
                {
                    try
                    {
                        DrawingCurve drawingCurve =
                            curveSegment.Parent;

                        object? modelGeometry =
                            drawingCurve.ModelGeometry;


                        if (modelGeometry is
                            EdgeProxy edgeProxy)
                        {
                            ComponentOccurrence
                                drawingOccurrence =
                                    edgeProxy
                                        .ContainingOccurrence;

                            return GetOccurrenceDocument(
                                drawingOccurrence);
                        }
                    }
                    catch
                    {
                    }
                }


                /*
                 * ==========================================
                 * SELEZIONE DRAWING CURVE
                 * ==========================================
                 */
                if (selectedObject is
                    DrawingCurve drawingCurveObject)
                {
                    try
                    {
                        object? modelGeometry =
                            drawingCurveObject
                                .ModelGeometry;


                        if (modelGeometry is
                            EdgeProxy edgeProxy)
                        {
                            ComponentOccurrence
                                curveOccurrence =
                                    edgeProxy
                                        .ContainingOccurrence;

                            return GetOccurrenceDocument(
                                curveOccurrence);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }


            return null;
        }
        public static string ReadSelectedDocumentProperty(
    InventorApp inventorApp,
    string propertyName)
        {
            Document? document =
                GetSelectedReferencedDocument(
                    inventorApp);

            if (document == null)
                return string.Empty;

            return ReadIProperty(
                document,
                propertyName);
        }


        public static string ReadSelectedDocumentCustomProperty(
            InventorApp inventorApp,
            string propertyName)
        {
            Document? document =
                GetSelectedReferencedDocument(
                    inventorApp);

            if (document == null)
                return string.Empty;

            return ReadUserDefinedProperty(
                document,
                propertyName);
        }
        public static bool TryWriteUserDefinedProperty(
    Document? document,
    string propertyName,
    string value,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                propertyName))
            {
                errorMessage =
                    "Nome proprietà Inventor non valido.";

                return false;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                Property? existingProperty =
                    null;

                foreach (Property property
                    in customProperties)
                {
                    if (string.Equals(
                        property.Name?.Trim(),
                        propertyName.Trim(),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        existingProperty =
                            property;

                        break;
                    }
                }

                if (existingProperty != null)
                {
                    existingProperty.Value =
                        value ?? string.Empty;
                }
                else
                {
                    customProperties.Add(
                        value ?? string.Empty,
                        propertyName);
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool TrySaveDocument(
    Document? document,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Save();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool TryWriteUserDefinedProperty(
    AssemblyDocument? document,
    string propertyName,
    string value,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                propertyName))
            {
                errorMessage =
                    "Nome proprietà Inventor non valido.";

                return false;
            }

            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                Property? existingProperty =
                    null;

                foreach (Property property
                    in customProperties)
                {
                    if (string.Equals(
                        property.Name?.Trim(),
                        propertyName.Trim(),
                        StringComparison.OrdinalIgnoreCase))
                    {
                        existingProperty =
                            property;

                        break;
                    }
                }

                if (existingProperty != null)
                {
                    existingProperty.Value =
                        value ?? string.Empty;
                }
                else
                {
                    customProperties.Add(
                        value ?? string.Empty,
                        propertyName);
                }

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool TrySaveDocument(
    AssemblyDocument? document,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (document == null)
            {
                errorMessage =
                    "Documento Inventor non disponibile.";

                return false;
            }

            try
            {
                document.Save();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        public static bool OpenOrActivateDocumentByPath(
       InventorApp inventorApp,
       string filePath,
       out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }


            if (string.IsNullOrWhiteSpace(
                filePath))
            {
                errorMessage =
                    "Percorso documento non valido.";

                return false;
            }


            try
            {
                Document? existingDocument =
                    null;


                /*
                 * ==========================================
                 * CERCHIAMO SE IL FILE È GIÀ CARICATO
                 * ==========================================
                 *
                 * Un sottoassieme del MAIN può essere già
                 * presente in inventorApp.Documents anche
                 * senza essere realmente aperto in una
                 * propria finestra.
                 */
                foreach (Document document
                    in inventorApp.Documents)
                {
                    string documentPath =
                        GetDocumentFullFileName(
                            document);


                    if (!string.Equals(
                        documentPath,
                        filePath,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }


                    existingDocument =
                        document;

                    break;
                }


                /*
                 * ==========================================
                 * SE È GIÀ IL DOCUMENTO ATTIVO
                 * ==========================================
                 */
                Document? activeDocument =
                    GetActiveDocument(
                        inventorApp);


                if (activeDocument != null)
                {
                    string activePath =
                        GetDocumentFullFileName(
                            activeDocument);


                    if (string.Equals(
                        activePath,
                        filePath,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }


                /*
                 * ==========================================
                 * PRIMO TENTATIVO: ACTIVATE
                 * ==========================================
                 *
                 * Funziona normalmente per documenti
                 * realmente aperti.
                 */
                if (existingDocument != null)
                {
                    try
                    {
                        existingDocument.Activate();


                        Document? activatedDocument =
                            GetActiveDocument(
                                inventorApp);


                        if (activatedDocument != null)
                        {
                            string activatedPath =
                                GetDocumentFullFileName(
                                    activatedDocument);


                            if (string.Equals(
                                activatedPath,
                                filePath,
                                StringComparison.OrdinalIgnoreCase))
                            {
                                return true;
                            }
                        }
                    }
                    catch
                    {
                        /*
                         * Il documento può essere solamente
                         * caricato come riferimento.
                         *
                         * Proseguiamo con l'apertura esplicita.
                         */
                    }
                }


                /*
                 * ==========================================
                 * APERTURA ESPLICITA VISIBILE
                 * ==========================================
                 *
                 * Questo è il passaggio necessario quando
                 * il file è presente come riferimento del MAIN
                 * ma non ha ancora una propria finestra.
                 */
                Document openedDocument =
                    inventorApp.Documents.Open(
                        filePath,
                        true);


                /*
                 * Normalmente Open(..., true) lo rende già
                 * attivo, ma facciamo comunque Activate.
                 */
                try
                {
                    openedDocument.Activate();
                }
                catch
                {
                    /*
                     * Non consideriamo subito questo catch
                     * come errore: verifichiamo sotto quale
                     * documento è realmente diventato attivo.
                     */
                }


                Document? finalActiveDocument =
                    GetActiveDocument(
                        inventorApp);


                if (finalActiveDocument == null)
                {
                    errorMessage =
                        "Inventor ha aperto il documento ma " +
                        "non risulta presente un documento attivo.";

                    return false;
                }


                string finalActivePath =
                    GetDocumentFullFileName(
                        finalActiveDocument);


                if (!string.Equals(
                    finalActivePath,
                    filePath,
                    StringComparison.OrdinalIgnoreCase))
                {
                    errorMessage =
                        "Inventor non ha reso attivo il documento richiesto.";

                    return false;
                }


                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        
        public static bool CloseDocumentByPath(
    InventorApp inventorApp,
    string filePath,
    bool skipSave,
    out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (inventorApp == null)
            {
                errorMessage =
                    "Applicazione Inventor non disponibile.";

                return false;
            }


            try
            {
                foreach (Document document
                    in inventorApp.Documents)
                {
                    string documentPath =
                        GetDocumentFullFileName(
                            document);


                    if (!string.Equals(
                        documentPath,
                        filePath,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }


                    document.Close(
                        skipSave);

                    return true;
                }


                /*
                 * Se non è più aperto non è un errore.
                 */
                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }
        // =============================================================
        // LETTURA STRUTTURA DOCUMENTI IPT / IAM
        // =============================================================

        public sealed class InventorStructureItem
        {
            public string FullFileName { get; set; } = "";

            public string DisplayName { get; set; } = "";

            public string DocumentType { get; set; } = "";
        }


        public static List<InventorStructureItem> GetActiveDocumentStructure(
            InventorApp inventorApp)
        {
            List<InventorStructureItem> result =
                new List<InventorStructureItem>();

            Document? activeDocument =
                GetActiveDocument(inventorApp);

            if (activeDocument == null)
                return result;

            HashSet<string> visitedDocuments =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            if (!DocumentIsPart(activeDocument) &&
                !DocumentIsAssembly(activeDocument))
            {
                return result;
            }


            AddStructureDocument(
                activeDocument,
                result,
                visitedDocuments);


            if (activeDocument is AssemblyDocument assembly)
            {
                ReadStructureRecursive(
                    GetAssemblyOccurrences(assembly),
                    result,
                    visitedDocuments);
            }

            return result;
        }


        private static void ReadStructureRecursive(
            ComponentOccurrences? occurrences,
            List<InventorStructureItem> result,
            HashSet<string> visitedDocuments)
        {
            if (occurrences == null)
                return;

            foreach (ComponentOccurrence occurrence in occurrences)
            {
                Document? document =
                    GetOccurrenceDocument(occurrence);

                if (document == null)
                    continue;

                if (!DocumentIsPart(document) &&
                    !DocumentIsAssembly(document))
                {
                    continue;
                }

                string uniqueKey =
                    GetStructureDocumentKey(document);

                if (!visitedDocuments.Add(uniqueKey))
                    continue;


                result.Add(
                    CreateStructureItem(document));


                if (document is AssemblyDocument assembly)
                {
                    ReadStructureRecursive(
                        GetAssemblyOccurrences(assembly),
                        result,
                        visitedDocuments);
                }
            }
        }


        private static void AddStructureDocument(
            Document document,
            List<InventorStructureItem> result,
            HashSet<string> visitedDocuments)
        {
            string uniqueKey =
                GetStructureDocumentKey(document);

            if (!visitedDocuments.Add(uniqueKey))
                return;

            result.Add(
                CreateStructureItem(document));
        }


        private static InventorStructureItem CreateStructureItem(
            Document document)
        {
            return new InventorStructureItem
            {
                FullFileName =
                    GetDocumentFullFileName(document),

                DisplayName =
                    GetDocumentDisplayName(document),

                DocumentType =
                    DocumentIsAssembly(document)
                        ? "IAM"
                        : "IPT"
            };
        }


        private static string GetStructureDocumentKey(
            Document document)
        {
            string fullPath =
                GetDocumentFullFileName(document);

            if (!string.IsNullOrWhiteSpace(fullPath))
                return fullPath.Trim();

            return GetDocumentDisplayName(document);
        }
        // =============================================================
        // CONTROLLO TAVOLE - RISULTATO SCANSIONE INVENTOR
        // =============================================================

        public sealed class InventorDrawingScanData
        {
            public bool Success { get; set; }

            public string ErrorMessage { get; set; } = "";

            public int DetachedDimensions { get; set; }

            public int DetachedBalloons { get; set; }

            public int UnresolvedModelViews { get; set; }

            public int ViewsNotUpdated { get; set; }

            public int SheetsWithoutViews { get; set; }

            public int OverlappingViews { get; set; }

            public int ViewsOutsideSheet { get; set; }

            // Geometrie e schizzi con riferimenti persi
            public int DetachedGeometries { get; set; }

            public int RasterViews { get; set; }
        }

        // =============================================================
        // CONTROLLO TAVOLE - OPZIONI CONTROLLI
        // =============================================================

        public sealed class InventorDrawingScanOptions
        {
            public bool CheckDetachedDimensions { get; set; } = true;

            public bool CheckDetachedBalloons { get; set; } = true;

            public bool CheckUnresolvedModelViews { get; set; } = true;

            public bool CheckViewsNotUpdated { get; set; } = true;

            public bool CheckSheetsWithoutViews { get; set; } = true;

            public bool CheckOverlappingViews { get; set; } = true;

            public bool CheckViewsOutsideSheet { get; set; } = true;

            public bool CheckDetachedGeometries { get; set; } = true;

            public bool CheckRasterViews { get; set; } = true;
        }

        // =============================================================
        // CONTROLLO TAVOLE - SCANSIONE COMPLETA
        // =============================================================

        public static InventorDrawingScanData ScanDrawingForControlloTavole(
            InventorApp inventorApp,
            string drawingPath,
            InventorDrawingScanOptions options)
        {
            InventorDrawingScanData result =
                new InventorDrawingScanData();

            if (inventorApp == null)
            {
                result.ErrorMessage = "Inventor non disponibile.";
                return result;
            }

            if (string.IsNullOrWhiteSpace(drawingPath))
            {
                result.ErrorMessage = "Percorso IDW non valido.";
                return result;
            }

            if (!System.IO.File.Exists(drawingPath))
            {
                result.ErrorMessage = "File IDW non trovato.";
                return result;
            }

            if (options == null)
                options = new InventorDrawingScanOptions();

            DrawingDocument? drawingDocument = null;

            bool openedByScanner = false;

            try
            {
                // -----------------------------------------------------
                // CERCA IDW GIÀ APERTO
                // -----------------------------------------------------

                drawingDocument =
                    FindOpenDrawingForControlloTavole(
                        inventorApp,
                        drawingPath);

                // -----------------------------------------------------
                // APERTURA INVISIBILE
                // -----------------------------------------------------

                if (drawingDocument == null)
                {
                    NameValueMap openOptions =
                        inventorApp.TransientObjects.CreateNameValueMap();

                    openOptions.Add(
                        "DeferUpdates",
                        false);

                    openOptions.Add(
                        "FileVersionOption",
                        FileVersionEnum.kOpenOldVersion);

                    Document document =
                        inventorApp.Documents.OpenWithOptions(
                            drawingPath,
                            openOptions,
                            false);

                    drawingDocument =
                        document as DrawingDocument;

                    if (drawingDocument == null)
                    {
                        try
                        {
                            document.Close(true);
                        }
                        catch
                        {
                        }

                        result.ErrorMessage =
                            "Il file aperto non è una tavola Inventor.";

                        return result;
                    }

                    openedByScanner = true;
                }

                // -----------------------------------------------------
                // SCANSIONE FOGLI
                // -----------------------------------------------------

                foreach (Sheet sheet in drawingDocument.Sheets)
                {
                    if (options.CheckDetachedDimensions)
                    {
                        ScanCoreDetachedDimensions(sheet, result);
                    }

                    if (options.CheckDetachedBalloons)
                    {
                        ScanCoreDetachedBalloons(sheet, result);
                    }

                    if (options.CheckUnresolvedModelViews)
                    {
                        ScanCoreUnresolvedModelViews(sheet, result);
                    }

                    if (options.CheckViewsNotUpdated)
                    {
                        ScanCoreViewsNotUpdated(sheet, result);
                    }

                    if (options.CheckSheetsWithoutViews)
                    {
                        ScanCoreSheetsWithoutViews(sheet, result);
                    }

                    if (options.CheckOverlappingViews)
                    {
                        ScanCoreOverlappingViews(
                            sheet,
                            result,
                            inventorApp.TransientGeometry);
                    }

                    if (options.CheckViewsOutsideSheet)
                    {
                        ScanCoreViewsOutsideSheet(sheet, result);
                    }

                    if (options.CheckDetachedGeometries)
                    {
                        ScanCoreDetachedGeometries(sheet, result);
                    }

                    if (options.CheckRasterViews)
                    {
                        ScanCoreRasterViews(sheet, result);
                    }
                }

                result.Success = true;

                return result;
            }
            catch (Exception exception)
            {
                result.Success = false;
                result.ErrorMessage = exception.Message;

                return result;
            }
            finally
            {
                // Chiudiamo SOLO la tavola aperta dallo scanner.
                // Non salviamo mai il documento.

                if (openedByScanner && drawingDocument != null)
                {
                    CloseDrawingDocument(
                        drawingDocument,
                        true);
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - RICERCA DOCUMENTO APERTO
        // =============================================================

        private static DrawingDocument? FindOpenDrawingForControlloTavole(
            InventorApp inventorApp,
            string drawingPath)
        {
            string targetPath =
                NormalizeDrawingPathForControlloTavole(drawingPath);

            foreach (Document document in inventorApp.Documents)
            {
                try
                {
                    if (document.DocumentType !=
                        DocumentTypeEnum.kDrawingDocumentObject)
                    {
                        continue;
                    }

                    string openPath =
                        NormalizeDrawingPathForControlloTavole(
                            document.FullFileName);

                    if (!string.Equals(
                        targetPath,
                        openPath,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    return document as DrawingDocument;
                }
                catch
                {
                    // Documento non interrogabile.
                }
            }

            return null;
        }

        // =============================================================
        // CONTROLLO TAVOLE - NORMALIZZAZIONE PERCORSO
        // =============================================================

        private static string NormalizeDrawingPathForControlloTavole(
            string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return "";

            try
            {
                return System.IO.Path.GetFullPath(path)
                    .TrimEnd(
                        System.IO.Path.DirectorySeparatorChar,
                        System.IO.Path.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - QUOTE SCOLLEGATE
        // =============================================================

        private static void ScanCoreDetachedDimensions(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            foreach (DrawingDimension dimension in sheet.DrawingDimensions)
            {
                try
                {
                    if (!dimension.Attached)
                        result.DetachedDimensions++;
                }
                catch
                {
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - BALLOON SCOLLEGATI
        // =============================================================

        private static void ScanCoreDetachedBalloons(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            foreach (Balloon balloon in sheet.Balloons)
            {
                try
                {
                    if (!balloon.Attached)
                        result.DetachedBalloons++;
                }
                catch
                {
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - RIFERIMENTI NON RISOLTI
        // =============================================================

        private static void ScanCoreUnresolvedModelViews(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            foreach (DrawingView view in sheet.DrawingViews)
            {
                try
                {
                    DocumentDescriptor descriptor =
                        view.ReferencedDocumentDescriptor;

                    if (descriptor.ReferenceMissing)
                        result.UnresolvedModelViews++;
                }
                catch
                {
                    result.UnresolvedModelViews++;
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - VISTE NON AGGIORNATE
        // =============================================================

        private static void ScanCoreViewsNotUpdated(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            foreach (DrawingView view in sheet.DrawingViews)
            {
                try
                {
                    if (!view.IsUpdateComplete)
                        result.ViewsNotUpdated++;
                }
                catch
                {
                    // Non conteggiamo automaticamente l'errore.
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - FOGLI SENZA VISTE
        // =============================================================

        private static void ScanCoreSheetsWithoutViews(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            try
            {
                if (sheet.DrawingViews.Count == 0)
                    result.SheetsWithoutViews++;
            }
            catch
            {
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - VISTE SOVRAPPOSTE
        // =============================================================


        // =============================================================
        // CONTROLLO TAVOLE - VISTE SOVRAPPOSTE
        // GEOMETRIE VISIBILI CON CACHE PER FOGLIO
        // =============================================================

        private sealed class CoreDrawingPoint
        {
            public double X { get; }
            public double Y { get; }

            public CoreDrawingPoint(double x, double y)
            {
                X = x;
                Y = y;
            }
        }

        private sealed class CoreDrawingGeometry
        {
            public List<CoreDrawingPoint> Points { get; } =
                new List<CoreDrawingPoint>();

            public double MinX { get; private set; } = double.MaxValue;
            public double MinY { get; private set; } = double.MaxValue;
            public double MaxX { get; private set; } = double.MinValue;
            public double MaxY { get; private set; } = double.MinValue;

            public void AddPoint(double x, double y)
            {
                Points.Add(new CoreDrawingPoint(x, y));

                MinX = Math.Min(MinX, x);
                MinY = Math.Min(MinY, y);
                MaxX = Math.Max(MaxX, x);
                MaxY = Math.Max(MaxY, y);
            }
        }

        private sealed class CoreDrawingViewGeometry
        {
            public List<CoreDrawingGeometry> Geometries { get; } =
                new List<CoreDrawingGeometry>();

            public double Left { get; set; }
            public double Right { get; set; }
            public double Bottom { get; set; }
            public double Top { get; set; }
        }

        private static void ScanCoreOverlappingViews(
            Sheet sheet,
            InventorDrawingScanData result,
            TransientGeometry transientGeometry)
        {
            try
            {
                List<CoreDrawingViewGeometry> views =
                    new List<CoreDrawingViewGeometry>();

                // Lettura COM una sola volta per ogni vista.
                foreach (DrawingView view in sheet.DrawingViews)
                {
                    views.Add(
                        CoreReadDrawingViewGeometry(
                            view,
                            transientGeometry));
                }

                // Confronto esclusivamente in memoria.
                for (int i = 0; i < views.Count; i++)
                {
                    for (int j = i + 1; j < views.Count; j++)
                    {
                        if (CoreCachedViewsOverlap(
                            views[i],
                            views[j]))
                        {
                            result.OverlappingViews++;
                        }
                    }
                }
            }
            catch
            {
                // Un errore non interrompe gli altri controlli.
            }
        }

        private static CoreDrawingViewGeometry CoreReadDrawingViewGeometry(
            DrawingView view,
            TransientGeometry transientGeometry)
        {
            CoreDrawingViewGeometry data =
                new CoreDrawingViewGeometry();

            Point2d position = view.Position;

            data.Left = position.X - view.Width / 2.0;
            data.Right = position.X + view.Width / 2.0;
            data.Bottom = position.Y - view.Height / 2.0;
            data.Top = position.Y + view.Height / 2.0;

            foreach (DrawingCurve curve in view.DrawingCurves)
            {
                foreach (DrawingCurveSegment segment in curve.Segments)
                {
                    try
                    {
                        if (!segment.Visible)
                            continue;

                        CoreDrawingGeometry geometry =
                            CoreReadDrawingGeometry(segment.Geometry);

                        if (geometry.Points.Count >= 2)
                            data.Geometries.Add(geometry);
                    }
                    catch
                    {
                        // Segmento non leggibile.
                    }
                }
            }

            return data;
        }

        private static CoreDrawingGeometry CoreReadDrawingGeometry(
            object geometry)
        {
            CoreDrawingGeometry result =
                new CoreDrawingGeometry();

            try
            {
                if (geometry is LineSegment2d line)
                {
                    result.AddPoint(
                        line.StartPoint.X,
                        line.StartPoint.Y);

                    result.AddPoint(
                        line.EndPoint.X,
                        line.EndPoint.Y);

                    return result;
                }

                Curve2dEvaluator? evaluator = null;

                if (geometry is Arc2d arc)
                    evaluator = arc.Evaluator;
                else if (geometry is Circle2d circle)
                    evaluator = circle.Evaluator;
                else if (geometry is EllipticalArc2d ellipticalArc)
                    evaluator = ellipticalArc.Evaluator;
                else if (geometry is EllipseFull2d ellipse)
                    evaluator = ellipse.Evaluator;
                else if (geometry is BSplineCurve2d spline)
                    evaluator = spline.Evaluator;

                if (evaluator == null)
                    return result;

                evaluator.GetParamExtents(
                    out double fromParam,
                    out double toParam);

                const double strokeTolerance = 0.001;

                evaluator.GetStrokes(
                    fromParam,
                    toParam,
                    strokeTolerance,
                    out int vertexCount,
                    out double[] coordinates);

                if (coordinates == null)
                    return result;

                for (int i = 0; i < vertexCount; i++)
                {
                    result.AddPoint(
                        coordinates[i * 2],
                        coordinates[i * 2 + 1]);
                }
            }
            catch
            {
                // Non interpretiamo una geometria illeggibile
                // come una sovrapposizione.
            }

            return result;
        }

        private static bool CoreCachedViewsOverlap(
            CoreDrawingViewGeometry first,
            CoreDrawingViewGeometry second)
        {
            const double tolerance = 0.001;

            // Primo filtro: rettangoli delle viste.
            if (!CoreBoundsOverlap(
                first.Left, first.Right,
                first.Bottom, first.Top,
                second.Left, second.Right,
                second.Bottom, second.Top,
                tolerance))
            {
                return false;
            }

            foreach (CoreDrawingGeometry a in first.Geometries)
            {
                foreach (CoreDrawingGeometry b in second.Geometries)
                {
                    // Secondo filtro: rettangoli delle curve.
                    if (!CoreBoundsOverlap(
                        a.MinX, a.MaxX, a.MinY, a.MaxY,
                        b.MinX, b.MaxX, b.MinY, b.MaxY,
                        tolerance))
                    {
                        continue;
                    }

                    for (int i = 0; i < a.Points.Count - 1; i++)
                    {
                        for (int j = 0; j < b.Points.Count - 1; j++)
                        {
                            if (CoreCachedSegmentsIntersect(
                                a.Points[i],
                                a.Points[i + 1],
                                b.Points[j],
                                b.Points[j + 1],
                                tolerance))
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }

        private static bool CoreBoundsOverlap(
            double left1,
            double right1,
            double bottom1,
            double top1,
            double left2,
            double right2,
            double bottom2,
            double top2,
            double tolerance)
        {
            return
                right1 >= left2 - tolerance &&
                right2 >= left1 - tolerance &&
                top1 >= bottom2 - tolerance &&
                top2 >= bottom1 - tolerance;
        }

        private static bool CoreCachedSegmentsIntersect(
            CoreDrawingPoint a,
            CoreDrawingPoint b,
            CoreDrawingPoint c,
            CoreDrawingPoint d,
            double tolerance)
        {
            // Filtro veloce sui singoli segmenti.
            if (!CoreBoundsOverlap(
                Math.Min(a.X, b.X),
                Math.Max(a.X, b.X),
                Math.Min(a.Y, b.Y),
                Math.Max(a.Y, b.Y),
                Math.Min(c.X, d.X),
                Math.Max(c.X, d.X),
                Math.Min(c.Y, d.Y),
                Math.Max(c.Y, d.Y),
                tolerance))
            {
                return false;
            }

            double rx = b.X - a.X;
            double ry = b.Y - a.Y;
            double sx = d.X - c.X;
            double sy = d.Y - c.Y;

            double rr = rx * rx + ry * ry;
            double ss = sx * sx + sy * sy;

            if (rr <= 1e-16 || ss <= 1e-16)
                return false;

            double qpx = c.X - a.X;
            double qpy = c.Y - a.Y;

            double denominator = rx * sy - ry * sx;

            if (Math.Abs(denominator) <= 1e-12)
            {
                // Segmenti paralleli o collineari.
                double cross = qpx * ry - qpy * rx;

                if (Math.Abs(cross) >
                    tolerance * Math.Sqrt(rr))
                {
                    return false;
                }

                double t0 =
                    (qpx * rx + qpy * ry) / rr;

                double t1 =
                    ((d.X - a.X) * rx +
                     (d.Y - a.Y) * ry) / rr;

                return
                    Math.Max(0.0, Math.Min(t0, t1)) <=
                    Math.Min(1.0, Math.Max(t0, t1)) +
                    tolerance / Math.Sqrt(rr);
            }

            double t =
                (qpx * sy - qpy * sx) / denominator;

            double u =
                (qpx * ry - qpy * rx) / denominator;

            double tTolerance = tolerance / Math.Sqrt(rr);
            double uTolerance = tolerance / Math.Sqrt(ss);

            return
                t >= -tTolerance &&
                t <= 1.0 + tTolerance &&
                u >= -uTolerance &&
                u <= 1.0 + uTolerance;
        }





        // =============================================================
        // CONTROLLO TAVOLE - VISTE FUORI FOGLIO
        // =============================================================

        private static void ScanCoreViewsOutsideSheet(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            foreach (DrawingView view in sheet.DrawingViews)
            {
                try
                {
                    Point2d position = view.Position;

                    double left =
                        position.X - view.Width / 2.0;

                    double right =
                        position.X + view.Width / 2.0;

                    double bottom =
                        position.Y - view.Height / 2.0;

                    double top =
                        position.Y + view.Height / 2.0;

                    const double tolerance = 0.01;

                    bool outside =
                        left < -tolerance ||
                        bottom < -tolerance ||
                        right > sheet.Width + tolerance ||
                        top > sheet.Height + tolerance;

                    if (outside)
                        result.ViewsOutsideSheet++;
                }
                catch
                {
                }
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - OTTAVO CONTROLLO
        // GEOMETRIE E SCHIZZI CON RIFERIMENTI PERSI
        // =============================================================
        // =============================================================
        // CONTROLLO TAVOLE - OTTAVO CONTROLLO
        // MARCATORI DI CENTRO E ASSI CON RIFERIMENTI PERSI
        // =============================================================

        private static void ScanCoreDetachedGeometries(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            if (sheet == null || result == null)
                return;

            // ---------------------------------------------------------
            // 1. MARCATORI DI CENTRO
            // ---------------------------------------------------------

            try
            {
                foreach (Centermark centermark in sheet.Centermarks)
                {
                    try
                    {
                        if (!centermark.Attached)
                        {
                            result.DetachedGeometries++;
                        }
                    }
                    catch
                    {
                        // Non conteggiamo errori di lettura come
                        // riferimenti persi.
                    }
                }
            }
            catch
            {
                // Una collezione non leggibile non deve
                // interrompere la scansione.
            }

            // ---------------------------------------------------------
            // 2. ASSI DI MEZZERIA
            // ---------------------------------------------------------

            try
            {
                foreach (Centerline centerline in sheet.Centerlines)
                {
                    try
                    {
                        if (!centerline.Attached)
                        {
                            result.DetachedGeometries++;
                        }
                    }
                    catch
                    {
                        // Non conteggiamo errori di lettura come
                        // riferimenti persi.
                    }
                }
            }
            catch
            {
                // Una collezione non leggibile non deve
                // interrompere la scansione.
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - NONO CONTROLLO
        // VISTE RASTER
        // =============================================================

        private static void ScanCoreRasterViews(
            Sheet sheet,
            InventorDrawingScanData result)
        {
            if (sheet == null || result == null)
                return;

            try
            {
                foreach (DrawingView view in sheet.DrawingViews)
                {
                    try
                    {
                        // Lettura dello stato raster nativo Inventor.
                        // Non modifica la vista.
                        if (view.IsRasterView)
                        {
                            result.RasterViews++;
                        }
                    }
                    catch
                    {
                        // Una vista non leggibile non viene
                        // automaticamente classificata come raster.
                    }
                }
            }
            catch
            {
                // Non interrompiamo la scansione generale.
            }
        }

        // =============================================================
        // CONTROLLO TAVOLE - RECUPERO DOCUMENTO ORIGINALE
        // =============================================================

        public static bool TryActivateOriginalDocument(
            global::Inventor.Application inventorApp,
            string originalDocumentPath,
            out string errorMessage)
        {
            errorMessage = "";

            if (inventorApp == null ||
                string.IsNullOrWhiteSpace(originalDocumentPath))
            {
                errorMessage =
                    "Documento originale non disponibile.";

                return false;
            }

            try
            {
                foreach (global::Inventor.Document document
                         in inventorApp.Documents)
                {
                    string documentPath =
                        GetDocumentFullFileName(document);

                    if (!string.Equals(
                            documentPath,
                            originalDocumentPath,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    document.Activate();

                    return true;
                }

                errorMessage =
                    "Il documento da cui hai avviato Controllo Tavole " +
                    "è stato chiuso. Riaprilo in Inventor per procedere.";

                return false;
            }
            catch (Exception exception)
            {
                errorMessage = exception.Message;

                return false;
            }
        }


        // =============================================================
        // CONTROLLO TAVOLE - RICERCA COMPONENTE NELL'ASSIEME
        // =============================================================

        public static bool TryFindComponentForDrawing(
            global::Inventor.Application inventorApp,
            string componentCode,
            out string componentPath,
            out string errorMessage)
        {
            componentPath = "";
            errorMessage = "";

            if (inventorApp == null ||
                string.IsNullOrWhiteSpace(componentCode))
            {
                errorMessage =
                    "Codice componente non valido.";

                return false;
            }

            try
            {
                global::Inventor.Document activeDocument =
                    inventorApp.ActiveDocument;

                if (activeDocument == null)
                {
                    errorMessage =
                        "Nessun documento attivo.";

                    return false;
                }

                string activePath =
                    GetDocumentFullFileName(activeDocument);

                string activeCode =
                    System.IO.Path.GetFileNameWithoutExtension(activePath);

                // Il codice richiesto corrisponde al documento principale.
                if (string.Equals(
                        activeCode,
                        componentCode,
                        StringComparison.OrdinalIgnoreCase))
                {
                    componentPath = activePath;
                    return true;
                }

                // Se siamo in una parte singola non esiste un albero da esplorare.
                if (activeDocument.DocumentType !=
                    global::Inventor.DocumentTypeEnum.kAssemblyDocumentObject)
                {
                    errorMessage =
                        "Il componente non è presente nel documento originale.";

                    return false;
                }

                global::Inventor.AssemblyDocument assemblyDocument =
                    (global::Inventor.AssemblyDocument)activeDocument;

                return TryFindComponentRecursive(
                    assemblyDocument.ComponentDefinition.Occurrences,
                    componentCode,
                    out componentPath,
                    out errorMessage);
            }
            catch (Exception exception)
            {
                errorMessage = exception.Message;
                return false;
            }
        }


        // =============================================================
        // CONTROLLO TAVOLE - RICERCA RICORSIVA
        // =============================================================

        private static bool TryFindComponentRecursive(
            System.Collections.IEnumerable occurrences,
            string componentCode,
            out string componentPath,
            out string errorMessage)
        {
            componentPath = "";
            errorMessage = "";

            foreach (global::Inventor.ComponentOccurrence occurrence
                     in occurrences)
            {
                try
                {
                    global::Inventor.Document componentDocument =
                        (global::Inventor.Document)occurrence.Definition.Document;

                    string path =
                        GetDocumentFullFileName(componentDocument);

                    string code =
                        System.IO.Path.GetFileNameWithoutExtension(path);

                    if (string.Equals(
                            code,
                            componentCode,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        componentPath = path;
                        return true;
                    }

                    if (occurrence.DefinitionDocumentType ==
                        global::Inventor.DocumentTypeEnum.kAssemblyDocumentObject)
                    {
                        if (TryFindComponentRecursive(
                                occurrence.SubOccurrences,
                                componentCode,
                                out componentPath,
                                out errorMessage))
                        {
                            return true;
                        }
                    }
                }
                catch
                {
                    // Un componente non risolto non deve
                    // interrompere la ricerca degli altri.
                }
            }

            errorMessage =
                "Componente non trovato nell'assieme originale.";

            return false;
        }
        // =============================================================
        // CONTROLLO TAVOLE - APERTURA DISEGNO NATIVO
        // COMPONENTI INTERNI APERTI VISIBILMENTE
        // =============================================================

        public static bool TryOpenDrawingFromOriginalContext(
            global::Inventor.Application inventorApp,
            string originalDocumentPath,
            string componentCode,
            out string errorMessage)
        {
            errorMessage = "";

            const string commandName = "CMxOpenDrawingCmd";

            const string drawingNotFoundMessage =
                "Attenzione tavola non trovata verifica di essere " +
                "sull'assieme da cui hai avviato la funzione prima " +
                "di cliccare APRI IDW";

            // =====================================================
            // 1. RIATTIVAZIONE DOCUMENTO ORIGINALE
            // =====================================================

            if (!TryActivateOriginalDocument(
                    inventorApp,
                    originalDocumentPath,
                    out errorMessage))
            {
                return false;
            }

            // =====================================================
            // 2. RICERCA COMPONENTE
            // =====================================================

            if (!TryFindComponentForDrawing(
                    inventorApp,
                    componentCode,
                    out string componentPath,
                    out errorMessage))
            {
                return false;
            }

            global::Inventor.Document? componentDocument = null;
            global::Inventor.DrawingDocument? openedDrawing = null;

            bool isInternalComponent = false;
            bool componentWasAlreadyOpen = false;
            bool componentOpenedByUs = false;
            bool drawingOpened = false;
            bool operationSucceeded = false;

            try
            {
                global::Inventor.Document? originalDocument =
                    inventorApp.ActiveDocument;

                if (originalDocument == null)
                {
                    errorMessage = "Documento originale non disponibile.";
                    return false;
                }

                string originalPath =
                    GetDocumentFullFileName(originalDocument);

                isInternalComponent =
                    !string.Equals(
                        originalPath,
                        componentPath,
                        StringComparison.OrdinalIgnoreCase);

                // =====================================================
                // CASO 1: DOCUMENTO PRINCIPALE
                // =====================================================

                if (!isInternalComponent)
                {
                    componentDocument = originalDocument;
                }
                else
                {
                    // =================================================
                    // CASO 2: COMPONENTE INTERNO
                    // =================================================

                    // Verifichiamo se il componente possiede già
                    // una propria finestra aperta in Inventor.
                    //
                    // Non basta controllare inventorApp.Documents:
                    // un componente può essere caricato soltanto
                    // come riferimento dell'assieme.

                    foreach (global::Inventor.Document document
                             in inventorApp.Documents)
                    {
                        if (!string.Equals(
                                GetDocumentFullFileName(document),
                                componentPath,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }

                        // Una finestra del documento indica che
                        // il componente era già aperto autonomamente.
                        try
                        {
                            componentWasAlreadyOpen =
                                document.Views.Count > 0;
                        }
                        catch
                        {
                            componentWasAlreadyOpen = false;
                        }

                        break;
                    }

                    // =================================================
                    // APERTURA VISIBILE DEL COMPONENTE
                    // =================================================

                    componentDocument =
                        inventorApp.Documents.Open(
                            componentPath,
                            true);

                    if (componentDocument == null)
                    {
                        errorMessage =
                            "Impossibile aprire il componente.";

                        return false;
                    }

                    // Chiuderemo il documento soltanto se
                    // non aveva già una propria finestra.
                    componentOpenedByUs =
                        !componentWasAlreadyOpen;

                    // Il componente deve diventare attivo
                    // affinché il comando contestuale funzioni.
                    componentDocument.Activate();
                }

                // =====================================================
                // 3. VERIFICA DOCUMENTO ATTIVO
                // =====================================================

                global::Inventor.Document? activeDocument =
                    inventorApp.ActiveDocument;

                if (activeDocument == null ||
                    !string.Equals(
                        GetDocumentFullFileName(activeDocument),
                        componentPath,
                        StringComparison.OrdinalIgnoreCase))
                {
                    errorMessage =
                        "Inventor non ha attivato il componente richiesto.";

                    return false;
                }

                // =====================================================
                // 4. SELEZIONE NODO PRINCIPALE
                // =====================================================

                global::Inventor.BrowserPane browserPane =
                    activeDocument.BrowserPanes.ActivePane;

                if (browserPane == null)
                {
                    errorMessage =
                        "Impossibile recuperare il browser del componente.";

                    return false;
                }

                global::Inventor.BrowserNode topNode =
                    browserPane.TopNode;

                if (topNode == null)
                {
                    errorMessage =
                        "Impossibile recuperare il nodo principale.";

                    return false;
                }

                topNode.DoSelect();

                // =====================================================
                // 5. ESECUZIONE COMANDO APRI DISEGNO
                // =====================================================

                inventorApp.CommandManager
                    .ControlDefinitions[commandName]
                    .Execute2(true);

                // =====================================================
                // 6. VERIFICA APERTURA IDW
                // =====================================================

                global::Inventor.Document? activeAfterCommand =
                    inventorApp.ActiveDocument;

                if (activeAfterCommand != null &&
                    activeAfterCommand.DocumentType ==
                        global::Inventor.DocumentTypeEnum
                            .kDrawingDocumentObject)
                {
                    openedDrawing =
                        activeAfterCommand
                            as global::Inventor.DrawingDocument;

                    drawingOpened =
                        openedDrawing != null;
                }

                if (!drawingOpened)
                {
                    errorMessage = drawingNotFoundMessage;
                    return false;
                }

                operationSucceeded = true;
            }
            catch (Exception exception)
            {
                errorMessage =
                    "Errore durante l'apertura della tavola:\r\n\r\n" +
                    exception.Message;

                return false;
            }
            finally
            {
                // =====================================================
                // 7. CHIUSURA COMPONENTE INTERNO
                // =====================================================

                // Non chiudiamo:
                // - il documento principale;
                // - un componente già aperto dall'utente.
                //
                // Chiudiamo soltanto il componente che
                // abbiamo aperto per questa operazione.

                if (isInternalComponent &&
                    componentOpenedByUs &&
                    componentDocument != null)
                {
                    try
                    {
                        // true = chiudi senza salvare.
                        componentDocument.Close(true);
                    }
                    catch (Exception closeException)
                    {
                        operationSucceeded = false;

                        errorMessage =
                            "La tavola è stata aperta, ma non è stato " +
                            "possibile chiudere il componente temporaneo:\r\n\r\n" +
                            closeException.Message;
                    }
                }

                // =====================================================
                // 8. ATTIVAZIONE TAVOLA
                // =====================================================

                if (drawingOpened && openedDrawing != null)
                {
                    try
                    {
                        openedDrawing.Activate();
                    }
                    catch (Exception activateException)
                    {
                        operationSucceeded = false;

                        errorMessage =
                            "La tavola è stata aperta, ma non è stato " +
                            "possibile renderla attiva:\r\n\r\n" +
                            activateException.Message;
                    }
                }
                else if (isInternalComponent)
                {
                    // Se non è stata aperta una tavola,
                    // torniamo all'assieme originale.

                    try
                    {
                        TryActivateOriginalDocument(
                            inventorApp,
                            originalDocumentPath,
                            out _);
                    }
                    catch
                    {
                    }
                }
            }

            return operationSucceeded;
        }
        // =============================================================
        // CONTROLLO TAVOLE - DIAGNOSTICA GEOMETRIE
        // FASE 4A
        // =============================================================

        public static string DiagnoseDrawingGeometry(
            global::Inventor.Application inventorApp)
        {
            System.Text.StringBuilder report =
                new System.Text.StringBuilder();

            if (inventorApp == null)
                return "Inventor non disponibile.";

            global::Inventor.DrawingDocument? drawingDocument;

            try
            {
                drawingDocument =
                    inventorApp.ActiveDocument
                        as global::Inventor.DrawingDocument;

                if (drawingDocument == null)
                    return "Aprire una tavola IDW prima di eseguire la diagnostica.";
            }
            catch (Exception ex)
            {
                return "Errore accesso documento: " + ex.Message;
            }

            report.AppendLine("DIAGNOSTICA GEOMETRIE TAVOLA");
            report.AppendLine("Documento: " + drawingDocument.DisplayName);
            report.AppendLine();

            foreach (global::Inventor.Sheet sheet in drawingDocument.Sheets)
            {
                report.AppendLine("==================================");
                report.AppendLine("FOGLIO: " + sheet.Name);
                report.AppendLine("==================================");

                // -----------------------------------------------------
                // MARCATORI DI CENTRO
                // -----------------------------------------------------

                try
                {
                    report.AppendLine(
                        "Marcatori di centro: " + sheet.Centermarks.Count);

                    foreach (global::Inventor.Centermark centermark
                             in sheet.Centermarks)
                    {
                        try
                        {
                            report.AppendLine(
                                "  Marcatore di centro rilevato");

                            report.AppendLine(
                                "    Tipo API: " +
                                centermark.Type.ToString());
                        }
                        catch (Exception ex)
                        {
                            report.AppendLine(
                                "  ERRORE marcatore: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    report.AppendLine(
                        "ERRORE collezione marcatori: " + ex.Message);
                }

                // -----------------------------------------------------
                // ASSI DI MEZZERIA
                // -----------------------------------------------------

                try
                {
                    report.AppendLine(
                        "Assi di mezzeria: " + sheet.Centerlines.Count);

                    foreach (global::Inventor.Centerline centerline
                             in sheet.Centerlines)
                    {
                        try
                        {
                            report.AppendLine(
                                "  Asse di mezzeria rilevato");

                            report.AppendLine(
                                "    Tipo API: " +
                                centerline.Type.ToString());
                        }
                        catch (Exception ex)
                        {
                            report.AppendLine(
                                "  ERRORE asse: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    report.AppendLine(
                        "ERRORE collezione assi: " + ex.Message);
                }

                // -----------------------------------------------------
                // SCHIZZI DEL FOGLIO
                // -----------------------------------------------------

                try
                {
                    report.AppendLine(
                        "Schizzi del foglio: " + sheet.Sketches.Count);

                    foreach (global::Inventor.DrawingSketch sketch
                             in sheet.Sketches)
                    {
                        try
                        {
                            report.AppendLine(
                                "  Schizzo: " + sketch.Name);

                            report.AppendLine(
                                "    Tipo API: " +
                                sketch.Type.ToString());

                            report.AppendLine(
                                "    Entità schizzo: " +
                                sketch.SketchEntities.Count);
                        }
                        catch (Exception ex)
                        {
                            report.AppendLine(
                                "  ERRORE schizzo: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    report.AppendLine(
                        "ERRORE collezione schizzi: " + ex.Message);
                }

                report.AppendLine();
            }

            return report.ToString();
        }
    }
}