﻿
using System;
using System.IO;
using Inventor;
using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.Core.Inventor;

using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.ControlloTavole.Services
{
    public static class ControlloTavoleDrawingScannerService
    {
        // =============================================================
        // METODO ORIGINALE - MANTENUTO PER COMPATIBILITÀ
        // =============================================================

        public static ControlloTavoleScanResult Scan(
            InventorApp inventorApp,
            string drawingPath)
        {
            ControlloTavoleSettings settings =
                ControlloTavoleSettingsService.Load();

            return Scan(
                inventorApp,
                drawingPath,
                settings);
        }

        // =============================================================
        // SCANSIONE CON IMPOSTAZIONI CONDIVISE
        // =============================================================

        public static ControlloTavoleScanResult Scan(
            InventorApp inventorApp,
            string drawingPath,
            ControlloTavoleSettings settings)
        {
            ControlloTavoleScanResult result =
                new ControlloTavoleScanResult
                {
                    DrawingPath = drawingPath
                };

            if (inventorApp == null)
            {
                result.ErrorMessage = "Inventor non disponibile.";
                return result;
            }

            if (string.IsNullOrWhiteSpace(drawingPath))
            {
                result.ErrorMessage = "Percorso IDW non valido.";
                return result;
            }

            if (!System.IO.File.Exists(drawingPath))
            {
                result.ErrorMessage = "File IDW non trovato.";
                return result;
            }

            if (settings == null)
            {
                result.ErrorMessage =
                    "Impostazioni Controllo Tavole non disponibili.";

                return result;
            }

            try
            {
                InventorService.InventorDrawingScanOptions options =
                    new InventorService.InventorDrawingScanOptions
                    {
                        CheckDetachedDimensions =
                            settings.CheckDetachedDimensions,

                        CheckDetachedBalloons =
                            settings.CheckDetachedBalloons,

                        CheckUnresolvedModelViews =
                            settings.CheckUnresolvedModelViews,

                        CheckViewsNotUpdated =
                            settings.CheckViewsNotUpdated,

                        CheckSheetsWithoutViews =
                            settings.CheckSheetsWithoutViews,

                        CheckOverlappingViews =
                            settings.CheckOverlappingViews,

                        CheckViewsOutsideSheet =
                            settings.CheckViewsOutsideSheet,

                        CheckDetachedGeometries =
                            settings.CheckDetachedGeometries,

                        // NONO CONTROLLO - VISTE RASTER
                        CheckRasterViews =
                            settings.CheckRasterViews
                    };

                InventorService.InventorDrawingScanData scanData =
                    InventorService.ScanDrawingForControlloTavole(
                        inventorApp,
                        drawingPath,
                        options);

                result.Success = scanData.Success;
                result.ErrorMessage = scanData.ErrorMessage;

                result.DetachedDimensions =
                    scanData.DetachedDimensions;

                result.DetachedBalloons =
                    scanData.DetachedBalloons;

                result.UnresolvedModelViews =
                    scanData.UnresolvedModelViews;

                result.ViewsNotUpdated =
                    scanData.ViewsNotUpdated;

                result.SheetsWithoutViews =
                    scanData.SheetsWithoutViews;

                result.OverlappingViews =
                    scanData.OverlappingViews;

                result.ViewsOutsideSheet =
                    scanData.ViewsOutsideSheet;

                result.DetachedGeometries =
                    scanData.DetachedGeometries;

                // NONO CONTROLLO - RISULTATO VISTE RASTER
                result.RasterViews =
                    scanData.RasterViews;

                if (result.Success)
                {
                    BuildProblemDescriptions(result);
                }

                return result;
            }
            catch (Exception exception)
            {
                result.Success = false;
                result.ErrorMessage = exception.Message;

                return result;
            }
        }

        // =============================================================
        // DESCRIZIONE PROBLEMI
        // =============================================================

        private static void BuildProblemDescriptions(
            ControlloTavoleScanResult result)
        {
            result.Problems.Clear();

            if (result.DetachedDimensions > 0)
            {
                result.Problems.Add(
                    result.DetachedDimensions == 1
                        ? "1 quota scollegata"
                        : result.DetachedDimensions +
                          " quote scollegate");
            }

            if (result.DetachedBalloons > 0)
            {
                result.Problems.Add(
                    result.DetachedBalloons == 1
                        ? "1 balloon scollegato"
                        : result.DetachedBalloons +
                          " balloon scollegati");
            }

            if (result.UnresolvedModelViews > 0)
            {
                result.Problems.Add(
                    result.UnresolvedModelViews == 1
                        ? "1 vista con riferimento modello non risolto"
                        : result.UnresolvedModelViews +
                          " viste con riferimento modello non risolto");
            }

            if (result.ViewsNotUpdated > 0)
            {
                result.Problems.Add(
                    result.ViewsNotUpdated == 1
                        ? "1 vista non aggiornata"
                        : result.ViewsNotUpdated +
                          " viste non aggiornate");
            }

            if (result.SheetsWithoutViews > 0)
            {
                result.Problems.Add(
                    result.SheetsWithoutViews == 1
                        ? "1 foglio senza viste"
                        : result.SheetsWithoutViews +
                          " fogli senza viste");
            }

            if (result.OverlappingViews > 0)
            {
                result.Problems.Add(
                    result.OverlappingViews == 1
                        ? "1 sovrapposizione tra viste"
                        : result.OverlappingViews +
                          " sovrapposizioni tra viste");
            }

            if (result.ViewsOutsideSheet > 0)
            {
                result.Problems.Add(
                    result.ViewsOutsideSheet == 1
                        ? "1 vista fuori dall'area del foglio"
                        : result.ViewsOutsideSheet +
                          " viste fuori dall'area del foglio");
            }

            // =========================================================
            // OTTAVO CONTROLLO - RIFERIMENTI GEOMETRICI PERSI
            // =========================================================

            if (result.DetachedGeometries > 0)
            {
                result.Problems.Add(
                    result.DetachedGeometries == 1
                        ? "1 geometria o schizzo con riferimenti persi"
                        : result.DetachedGeometries +
                          " geometrie o schizzi con riferimenti persi");
            }

            // =========================================================
            // NONO CONTROLLO - VISTE RASTER
            // =========================================================

            if (result.RasterViews > 0)
            {
                result.Problems.Add(
                    result.RasterViews == 1
                        ? "1 vista raster presente"
                        : result.RasterViews +
                          " viste raster presenti");
            }
        }
    }
}
