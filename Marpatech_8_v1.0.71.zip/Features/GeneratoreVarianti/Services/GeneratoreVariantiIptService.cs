﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace Marpatech_8.Features.GeneratoreVarianti.Services
{
    public sealed class RisultatoGenerazioneIpt
    {
        public bool Successo { get; init; }
        public string PercorsoIpt { get; init; } = "";
        public string Messaggio { get; init; } = "";
    }

    public static class GeneratoreVariantiIptService
    {
        public static RisultatoGenerazioneIpt Genera(
            Inventor.Application inventorApp,
            string percorsoOriginale,
            VariantePianificata variante,
            IReadOnlyList<IntervalloVariante> intervalli)
        {
            Inventor.PartDocument? copia = null;
            bool fileCreato = false;
            bool salvato = false;

            try
            {
                if (inventorApp == null)
                    throw new InvalidOperationException(
                        "Inventor non disponibile.");

                if (!File.Exists(percorsoOriginale))
                    throw new FileNotFoundException(
                        "IPT originale non trovato.",
                        percorsoOriginale);

                if (File.Exists(variante.PercorsoIpt))
                    throw new IOException(
                        "Il file IPT della variante esiste già.");

                // Il modello originale rimane intatto.
                File.Copy(
                    percorsoOriginale,
                    variante.PercorsoIpt,
                    false);

                fileCreato = true;

                Inventor.Document documento =
                    inventorApp.Documents.Open(
                        variante.PercorsoIpt,
                        false);

                copia = documento as Inventor.PartDocument
                    ?? throw new InvalidOperationException(
                        "La copia non è un documento IPT valido.");

                Inventor.ModelParameters parametri =
                    copia.ComponentDefinition
                         .Parameters
                         .ModelParameters;

                foreach (IntervalloVariante intervallo
                         in intervalli)
                {
                    if (!variante.Valori.TryGetValue(
                            intervallo.Nome,
                            out decimal valore))
                    {
                        throw new InvalidOperationException(
                            "Valore mancante per il parametro " +
                            intervallo.Nome);
                    }

                    Inventor.ModelParameter? parametro = null;

                    foreach (Inventor.ModelParameter corrente
                             in parametri)
                    {
                        if (string.Equals(
                                corrente.Name,
                                intervallo.Nome,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            parametro = corrente;
                            break;
                        }
                    }

                    if (parametro == null)
                    {
                        throw new InvalidOperationException(
                            "Parametro modello non trovato: " +
                            intervallo.Nome);
                    }

                    string valoreTesto = valore.ToString(
                        "0.############################",
                        CultureInfo.InvariantCulture);

                    // Expression usa le unità esplicite
                    // del parametro originale.
                    string espressione = valoreTesto;

                    if (!string.IsNullOrWhiteSpace(
                            intervallo.Unita))
                    {
                        espressione += " " + intervallo.Unita;
                    }

                    parametro.Expression = espressione;
                }

                // Aggiorna il modello prima del salvataggio.
                copia.Update2(false);

                if (copia.RequiresUpdate)
                {
                    throw new InvalidOperationException(
                        "Il modello richiede ancora un aggiornamento.");
                }

                copia.Save();
                salvato = true;

                return new RisultatoGenerazioneIpt
                {
                    Successo = true,
                    PercorsoIpt = variante.PercorsoIpt,
                    Messaggio = "IPT creato e salvato."
                };
            }
            catch (Exception ex)
            {
                return new RisultatoGenerazioneIpt
                {
                    Successo = false,
                    PercorsoIpt = variante.PercorsoIpt,
                    Messaggio = ex.Message
                };
            }
            finally
            {
                if (copia != null)
                {
                    try
                    {
                        // Chiude senza salvare modifiche
                        // eventualmente rimaste in sospeso.
                        copia.Close(true);
                    }
                    catch
                    {
                        // La chiusura verrà verificata
                        // durante i test.
                    }
                }

                // Se la generazione è fallita, rimuoviamo
                // esclusivamente la copia creata da noi.
                if (fileCreato && !salvato)
                {
                    try
                    {
                        if (File.Exists(variante.PercorsoIpt))
                            File.Delete(variante.PercorsoIpt);
                    }
                    catch
                    {
                        // Non cancelliamo mai l'originale.
                    }
                }
            }
        }
    }
}
