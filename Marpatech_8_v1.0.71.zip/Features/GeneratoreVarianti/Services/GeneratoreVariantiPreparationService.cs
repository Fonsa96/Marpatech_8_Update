﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.GeneratoreVarianti.Services
{
    public sealed class IntervalloVariante
    {
        public string Nome { get; init; } = "";
        public string Unita { get; init; } = "";
        public decimal ValoreOriginale { get; init; }
        public decimal Minimo { get; init; }
        public decimal Massimo { get; init; }
        public decimal Passo { get; init; }
    }

    public sealed class VariantePianificata
    {
        public string NomeBase { get; init; } = "";
        public string PercorsoIpt { get; init; } = "";
        public string PercorsoIdw { get; init; } = "";

        public Dictionary<string, decimal> Valori { get; init; }
            = new Dictionary<string, decimal>();
    }

    public static class GeneratoreVariantiPreparationService
    {
        // Limite di sicurezza per questa prima fase.
        public const int MaxVarianti = 10000;

        public static List<VariantePianificata> Prepara(
            string percorsoIptOriginale,
            IReadOnlyList<IntervalloVariante> intervalli)
        {
            if (string.IsNullOrWhiteSpace(percorsoIptOriginale) ||
                !File.Exists(percorsoIptOriginale))
            {
                throw new InvalidOperationException(
                    "Il modello IPT originale non è disponibile.");
            }

            string percorsoIdwOriginale =
                Path.ChangeExtension(percorsoIptOriginale, ".idw");

            if (!File.Exists(percorsoIdwOriginale))
            {
                throw new InvalidOperationException(
                    "La tavola IDW originale non è disponibile.");
            }

            if (intervalli == null || intervalli.Count == 0)
            {
                throw new InvalidOperationException(
                    "Seleziona almeno un parametro.");
            }

            string cartella =
                Path.GetDirectoryName(percorsoIptOriginale)
                ?? throw new InvalidOperationException(
                    "Cartella del modello non valida.");

            string nomeOriginale =
                Path.GetFileNameWithoutExtension(
                    percorsoIptOriginale);

            var valoriPerParametro =
                new List<(IntervalloVariante Parametro,
                          List<decimal> Valori)>();

            long totaleTeorico = 1;

            foreach (IntervalloVariante parametro in intervalli)
            {
                if (parametro.Passo <= 0 ||
                    parametro.Massimo < parametro.Minimo)
                {
                    throw new InvalidOperationException(
                        $"Intervallo non valido: {parametro.Nome}");
                }

                decimal quantitaDecimale =
                    decimal.Floor(
                        (parametro.Massimo - parametro.Minimo) /
                        parametro.Passo) + 1;

                if (quantitaDecimale > MaxVarianti + 1)
                {
                    throw new InvalidOperationException(
                        "Numero di combinazioni troppo elevato.");
                }

                int quantita = (int)quantitaDecimale;

                if (totaleTeorico > (MaxVarianti + 1L) / quantita)
                {
                    throw new InvalidOperationException(
                        "Superato il limite di varianti.");
                }

                totaleTeorico *= quantita;

                var valori = new List<decimal>();

                for (int i = 0; i < quantita; i++)
                {
                    valori.Add(
                        parametro.Minimo + parametro.Passo * i);
                }

                valoriPerParametro.Add((parametro, valori));
            }

            var risultato = new List<VariantePianificata>();
            var combinazione = new decimal[intervalli.Count];
            var nomiGenerati =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            void Genera(int indice)
            {
                if (indice == intervalli.Count)
                {
                    bool originale = true;

                    for (int i = 0; i < intervalli.Count; i++)
                    {
                        if (combinazione[i] !=
                            intervalli[i].ValoreOriginale)
                        {
                            originale = false;
                            break;
                        }
                    }

                    if (originale)
                        return;

                    var valori = new Dictionary<string, decimal>(
                        StringComparer.OrdinalIgnoreCase);

                    var partiNome = new List<string>();

                    for (int i = 0; i < intervalli.Count; i++)
                    {
                        IntervalloVariante parametro = intervalli[i];
                        decimal valore = combinazione[i];

                        valori.Add(parametro.Nome, valore);

                        string testoValore = valore.ToString(
                            "0.############################",
                            CultureInfo.InvariantCulture);

                        partiNome.Add(
                            parametro.Nome + "-" + testoValore);
                    }

                    string nomeBase = nomeOriginale + "_" +
                        string.Join("_", partiNome);

                    foreach (char carattere in
                             Path.GetInvalidFileNameChars())
                    {
                        if (nomeBase.Contains(carattere))
                        {
                            throw new InvalidOperationException(
                                "Nome variante non valido: " + nomeBase);
                        }
                    }

                    if (!nomiGenerati.Add(nomeBase))
                    {
                        throw new InvalidOperationException(
                            "Nome variante duplicato: " + nomeBase);
                    }

                    string percorsoIpt =
                        Path.Combine(cartella, nomeBase + ".ipt");

                    string percorsoIdw =
                        Path.Combine(cartella, nomeBase + ".idw");

                    if (File.Exists(percorsoIpt) ||
                        File.Exists(percorsoIdw))
                    {
                        throw new InvalidOperationException(
                            "Esiste già un file della variante: " +
                            nomeBase);
                    }

                    risultato.Add(new VariantePianificata
                    {
                        NomeBase = nomeBase,
                        PercorsoIpt = percorsoIpt,
                        PercorsoIdw = percorsoIdw,
                        Valori = valori
                    });

                    return;
                }

                foreach (decimal valore in
                         valoriPerParametro[indice].Valori)
                {
                    combinazione[indice] = valore;
                    Genera(indice + 1);
                }
            }

            Genera(0);

            if (risultato.Count > MaxVarianti)
            {
                throw new InvalidOperationException(
                    "Superato il limite di 10.000 varianti.");
            }

            return risultato;
        }
    }
}
