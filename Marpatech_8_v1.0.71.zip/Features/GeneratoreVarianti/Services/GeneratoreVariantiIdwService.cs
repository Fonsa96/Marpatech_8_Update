﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace Marpatech_8.Features.GeneratoreVarianti.Services
{
    public sealed class RisultatoGenerazioneIdw
    {
        public bool Successo { get; set; }
        public string PercorsoIdw { get; set; } = "";
        public string Messaggio { get; set; } = "";
    }

    // Chiamare dal thread STA dell'add-in; non usare Task.Run.
    public static class GeneratoreVariantiIdwService
    {
        private const double Tol = 0.01; // cm sul foglio = 0,1 mm
        private const int MaxTentativi = 40;
        private static int inEsecuzione;

        private sealed class Stato
        {
            public int Foglio;
            public string Nome = "";
            public double X, Y, W, H, Scala, Rotazione, Gap;
            public Inventor.BreakOrientationEnum Orientamento;
            public Inventor.BreakStyleEnum Stile;
            public int Livello, Simboli;
            public bool SenzaBreak;
            public double FinaleW, FinaleH;
        }

        // Compatibilità con il chiamante del file originale.
        // VariantePianificata rimane il DTO già presente nel progetto Marpatech.
        public static RisultatoGenerazioneIdw Genera(Inventor.Application app,
            string percorsoIptOriginale, VariantePianificata variante)
        {
            if (variante == null) throw new ArgumentNullException(nameof(variante));
            return Genera(app, percorsoIptOriginale, variante.PercorsoIpt, variante.PercorsoIdw);
        }

        public static RisultatoGenerazioneIdw Genera(Inventor.Application app,
            string percorsoIptOriginale, string percorsoIptVariante, string percorsoIdwVariante)
        {
            var risultato = new RisultatoGenerazioneIdw { PercorsoIdw = percorsoIdwVariante };
            if (Interlocked.CompareExchange(ref inEsecuzione, 1, 0) != 0)
            {
                risultato.Messaggio = "Generazione IDW già in corso.";
                return risultato;
            }
            Inventor.DrawingDocument? tavola = null;
            Inventor.Transaction? transazione = null;
            string? backup = null;
            string? destinazione = null;
            bool creata = false, completata = false;
            string fase = "validazione";
            try
            {
                if (app == null) throw new ArgumentNullException(nameof(app));
                if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
                    throw new InvalidOperationException("Chiamare dal thread STA di Inventor.");
                string ipt = Path.GetFullPath(percorsoIptOriginale);
                string nuovoIpt = Path.GetFullPath(percorsoIptVariante);
                string originale = Path.ChangeExtension(ipt, ".idw");
                destinazione = Path.GetFullPath(percorsoIdwVariante);
                risultato.PercorsoIdw = destinazione;
                if (!File.Exists(ipt) || !File.Exists(originale) || !File.Exists(nuovoIpt))
                    throw new FileNotFoundException("Verificare IPT originale, IDW originale e IPT variante.");
                if (!string.Equals(Path.GetExtension(destinazione), ".idw", StringComparison.OrdinalIgnoreCase)
                    || !string.Equals(Path.GetExtension(nuovoIpt), ".ipt", StringComparison.OrdinalIgnoreCase))
                    throw new ArgumentException("Sono richiesti destinazione .idw e modello .ipt.");
                if (Uguali(ipt, nuovoIpt) || Uguali(originale, destinazione))
                    throw new InvalidOperationException("Originale e variante devono avere percorsi diversi.");
                if (File.Exists(destinazione)) throw new IOException("IDW destinazione già esistente: nessuna sovrascrittura.");
                foreach (Inventor.Document d in app.Documents)
                {
                    if (Uguali(d.FullFileName, destinazione))
                        throw new InvalidOperationException("Destinazione già aperta in Inventor.");
                    if ((Uguali(d.FullFileName, originale) || Uguali(d.FullFileName, ipt)
                        || Uguali(d.FullFileName, nuovoIpt)) && d.Dirty)
                        throw new InvalidOperationException("Salvare o annullare prima le modifiche dei documenti di origine/variante aperti.");
                }
                // Non apriamo, aggiorniamo o salviamo l'originale: leggiamo la copia su disco.
                File.Copy(originale, destinazione, false);
                creata = true;
                backup = destinazione + "." + Guid.NewGuid().ToString("N") + ".rollback";
                File.Copy(destinazione, backup, false);
                fase = "acquisizione rettangoli";
                tavola = Apri(app, destinazione);
                var stati = Acquisisci(tavola);
                if (stati.Count == 0) throw new InvalidOperationException("Nessuna vista con una singola interruzione da provare.");
                fase = "ReplaceReference";
                int sostituiti = 0;
                // Iterazione per indice: non conservare enumeratori COM durante la mutazione.
                for (int i = 1; i <= tavola.File.ReferencedFileDescriptors.Count; i++)
                {
                    Inventor.FileDescriptor fd = tavola.File.ReferencedFileDescriptors[i];
                    if (!Uguali(fd.FullFileName, ipt)) continue;
                    fd.ReplaceReference(nuovoIpt);
                    sostituiti++;
                }
                if (sostituiti == 0) throw new InvalidOperationException("Riferimento diretto IPT originale non trovato.");
                Aggiorna(tavola);
                VerificaRiferimenti(tavola, ipt, nuovoIpt);
                tavola.Save();
                Chiudi(ref tavola);
                fase = "riapertura prima del break";
                tavola = Apri(app, destinazione);
                Aggiorna(tavola);
                VerificaRiferimenti(tavola, ipt, nuovoIpt);
                // Checkpoint: su errore ripristiniamo esattamente l'IDW associato,
                // anche se l'errore avviene dopo End/Save o nella verifica su disco.
                File.Copy(destinazione, backup, true);
                fase = "ricreazione e calibrazione";
                transazione = app.TransactionManager.StartTransaction((Inventor._Document)tavola,
                    "Marpatech - calibrazione rettangoli IDW");
                foreach (Stato s in stati) Adatta(app, tavola, s);
                Verifica(app, tavola, stati);
                transazione.End();
                transazione = null;
                tavola.Save();
                Chiudi(ref tavola);
                fase = "verifica dopo salvataggio e riapertura";
                tavola = Apri(app, destinazione);
                Aggiorna(tavola);
                VerificaRiferimenti(tavola, ipt, nuovoIpt);
                Verifica(app, tavola, stati);
                Chiudi(ref tavola);
                completata = true;
                risultato.Successo = true;
                var righe = new List<string>();
                foreach (Stato s in stati)
                    righe.Add(string.Format("Foglio {0}, {1}: {2}; obiettivo {3:F3} x {4:F3} mm, finale {5:F3} x {6:F3} mm.",
                        s.Foglio, s.Nome, s.SenzaBreak ? "vista completa entro il rettangolo" : "break calibrato",
                        s.W * 10, s.H * 10, s.FinaleW * 10, s.FinaleH * 10));
                risultato.Messaggio = "Verifica su IDW riaperto superata. " + string.Join(" ", righe);
            }
            catch (Exception ex)
            {
                risultato.Messaggio = "Errore in " + fase + ": " + ex.Message;
            }
            finally
            {
                bool chiusa = true;
                if (transazione != null)
                    try { transazione.Abort(); }
                    catch (Exception ex) { risultato.Messaggio += " Abort fallito: " + ex.Message; }
                try { Chiudi(ref tavola); }
                catch (Exception ex)
                {
                    chiusa = false;
                    risultato.Successo = false;
                    risultato.Messaggio += " Chiusura fallita: " + ex.Message;
                }
                if (!completata && creata && backup != null && File.Exists(backup))
                {
                    if (chiusa && destinazione != null)
                    {
                        try
                        {
                            File.Copy(backup, destinazione, true);
                            risultato.Messaggio += " Copia ripristinata al checkpoint; NON validata per uso produttivo.";
                        }
                        catch (Exception ex) { risultato.Messaggio += " Ripristino fallito: " + ex.Message; }
                    }
                    risultato.Messaggio += " Backup conservato: " + backup;
                }
                else if (completata && backup != null)
                {
                    try { File.Delete(backup); }
                    catch (Exception ex) { risultato.Messaggio += " Backup non eliminato: " + ex.Message; }
                }
                Interlocked.Exchange(ref inEsecuzione, 0);
            }
            return risultato;
        }

        private static List<Stato> Acquisisci(Inventor.DrawingDocument d)
        {
            var lista = new List<Stato>();
            for (int f = 1; f <= d.Sheets.Count; f++)
            {
                foreach (Inventor.DrawingView v in d.Sheets[f].DrawingViews)
                {
                    if (v.BreakOperations.Count == 0) continue;
                    if (v.BreakOperations.Count != 1) throw new InvalidOperationException(v.Name + ": supportata una sola interruzione.");
                    Inventor.BreakOperation? b = v.BreakOperations[1];
                    Isolata(b);
                    if (!Positivo(v.Width) || !Positivo(v.Height) || !Positivo(v.Scale) || !Positivo(b.Gap))
                        throw new InvalidOperationException(v.Name + ": misure o gap non validi.");
                    if (b.Orientation != Inventor.BreakOrientationEnum.kHorizontalBreakOrientation &&
                        b.Orientation != Inventor.BreakOrientationEnum.kVerticalBreakOrientation)
                        throw new InvalidOperationException("Orientamento non supportato.");
                    lista.Add(new Stato
                    {
                        Foglio = f,
                        Nome = v.Name,
                        X = v.Position.X,
                        Y = v.Position.Y,
                        W = v.Width,
                        H = v.Height,
                        Scala = v.Scale,
                        Rotazione = v.Rotation,
                        Gap = b.Gap,
                        Orientamento = b.Orientation,
                        Stile = b.BreakStyle,
                        Livello = b.DisplayLevel,
                        Simboli = b.NumberOfSymbols
                    });
                }
            }
            return lista;
        }

        private static void Adatta(Inventor.Application app, Inventor.DrawingDocument d, Stato s)
        {
            Inventor.DrawingView v = Vista(d, s);
            if (v.BreakOperations.Count != 1) throw new InvalidOperationException(s.Nome + ": break cambiato dopo riapertura.");
            Inventor.BreakOperation? vecchio = v.BreakOperations[1];
            Isolata(vecchio);
            if (vecchio.Orientation != s.Orientamento) throw new InvalidOperationException("Orientamento cambiato.");
            vecchio.Delete();
            vecchio = null; // Mai riutilizzare un RCW relativo a un break cancellato.
            Aggiorna(d);
            Posiziona(app, d, s);
            v = Vista(d, s);
            double completaW = v.Width, completaH = v.Height;
            if (completaW <= s.W + Tol && completaH <= s.H + Tol)
            {
                s.SenzaBreak = true;
                s.FinaleW = completaW; s.FinaleH = completaH;
                return;
            }
            bool x = s.Orientamento == Inventor.BreakOrientationEnum.kHorizontalBreakOrientation;
            double intera = x ? completaW : completaH;
            double obiettivo = x ? s.W : s.H;
            if (Math.Abs((x ? completaH : completaW) - (x ? s.H : s.W)) > Tol)
                throw new InvalidOperationException(s.Nome + ": dimensione trasversale incompatibile con un solo break a scala invariata.");
            if (intera <= obiettivo + Tol)
                throw new InvalidOperationException(s.Nome + ": rettangolo non raggiungibile lungo l'asse del break.");
            // Mantiene entrambi i tagli all'interno della vista completa.
            double minimo = s.Gap + 0.00001;
            double massimo = intera - Math.Max(0.0001, intera * 0.000001);
            if (massimo <= minimo) throw new InvalidOperationException("Spazio insufficiente per il break.");
            double span = Math.Max(minimo, Math.Min(massimo, intera - obiettivo + s.Gap));
            double precedente = double.PositiveInfinity;
            for (int n = 0; n < MaxTentativi; n++)
            {
                // Ogni tentativo cancella, aggiorna e riparte dalla geometria completa.
                // Non usa StartPoint/EndPoint del break precedente né una derivata obsoleta.
                Ricrea(app, d, s, span);
                v = Vista(d, s);
                double errore = (x ? v.Width : v.Height) - obiettivo;
                if (Math.Abs(v.Width - s.W) <= Tol && Math.Abs(v.Height - s.H) <= Tol)
                {
                    s.FinaleW = v.Width; s.FinaleH = v.Height;
                    return;
                }
                if (Math.Abs((x ? v.Height : v.Width) - (x ? s.H : s.W)) > Tol)
                    throw new InvalidOperationException(s.Nome + ": il break modifica anche la dimensione trasversale.");
                if (errore > 0) minimo = span; else massimo = span;
                double prossimo = (minimo + massimo) / 2;
                if (Math.Abs(prossimo - span) < 1e-9 ||
                    (n > 8 && Math.Abs(errore - precedente) < 1e-10))
                    throw new InvalidOperationException(s.Nome + ": calibrazione senza convergenza.");
                precedente = errore;
                span = prossimo;
            }
            throw new InvalidOperationException(s.Nome + ": superato il limite di calibrazione.");
        }

        private static void Ricrea(Inventor.Application app, Inventor.DrawingDocument d, Stato s, double span)
        {
            Inventor.DrawingView v = Vista(d, s);
            if (v.BreakOperations.Count > 1) throw new InvalidOperationException("Numero break inatteso.");
            if (v.BreakOperations.Count == 1)
            {
                Inventor.BreakOperation? b = v.BreakOperations[1];
                Isolata(b);
                b.Delete();
                b = null;
            }
            Aggiorna(d);
            Posiziona(app, d, s);
            v = Vista(d, s);
            bool x = s.Orientamento == Inventor.BreakOrientationEnum.kHorizontalBreakOrientation;
            double centro = x ? v.Position.X : v.Position.Y;
            var a = app.TransientGeometry.CreatePoint2d(x ? centro - span / 2 : v.Position.X,
                x ? v.Position.Y : centro - span / 2);
            var z = app.TransientGeometry.CreatePoint2d(x ? centro + span / 2 : v.Position.X,
                x ? v.Position.Y : centro + span / 2);
            Inventor.BreakOperation nuovo = v.BreakOperations.Add(s.Orientamento, a, z,
                s.Stile, s.Livello, s.Gap, s.Simboli, false);
            Isolata(nuovo);
            // Il riferimento restituito è quello nuovo; dopo questa chiamata
            // le verifiche riacquisiscono comunque l'operazione dalla collezione.
            Aggiorna(d);
            Posiziona(app, d, s);
        }

        private static void Verifica(Inventor.Application app, Inventor.DrawingDocument d, List<Stato> stati)
        {
            foreach (Stato s in stati)
            {
                Inventor.DrawingView v = Vista(d, s);
                bool dimensioni = s.SenzaBreak
                    ? v.Width <= s.W + Tol && v.Height <= s.H + Tol
                        && Math.Abs(v.Width - s.FinaleW) <= Tol && Math.Abs(v.Height - s.FinaleH) <= Tol
                    : Math.Abs(v.Width - s.W) <= Tol && Math.Abs(v.Height - s.H) <= Tol;
                if (!dimensioni || Math.Abs(v.Scale - s.Scala) > 1e-9 ||
                    Math.Abs(v.Rotation - s.Rotazione) > 1e-9 ||
                    Math.Abs(v.Position.X - s.X) > Tol || Math.Abs(v.Position.Y - s.Y) > Tol)
                    throw new InvalidOperationException(s.Nome + ": verifica rettangolo, posizione, rotazione o scala fallita.");
                if (v.BreakOperations.Count != (s.SenzaBreak ? 0 : 1))
                    throw new InvalidOperationException(s.Nome + ": numero break finale errato.");
                if (!s.SenzaBreak)
                {
                    Inventor.BreakOperation? b = v.BreakOperations[1];
                    Isolata(b);
                    if (Math.Abs(b.Gap - s.Gap) > 0.001 || b.Orientation != s.Orientamento ||
                        b.BreakStyle != s.Stile || b.DisplayLevel != s.Livello ||
                        (s.Stile == Inventor.BreakStyleEnum.kStructuralBreakStyle && b.NumberOfSymbols != s.Simboli))
                        throw new InvalidOperationException(s.Nome + ": proprietà break cambiate.");
                }
                Inventor.Sheet foglio = d.Sheets[s.Foglio];
                if (v.Position.X - v.Width / 2 < -Tol || v.Position.Y - v.Height / 2 < -Tol ||
                    v.Position.X + v.Width / 2 > foglio.Width + Tol || v.Position.Y + v.Height / 2 > foglio.Height + Tol)
                    throw new InvalidOperationException(s.Nome + ": vista fuori dal foglio.");
            }
        }

        private static void Isolata(Inventor.BreakOperation b)
        {
            if (!b.IsSourceBreakOperation || b.AllAffectedViews.Count != 1)
                throw new InvalidOperationException("Test limitato a break singolo non condiviso e non ereditato.");
        }
        private static void Posiziona(Inventor.Application app, Inventor.DrawingDocument d, Stato s)
        {
            Vista(d, s).Position = app.TransientGeometry.CreatePoint2d(s.X, s.Y);
            Aggiorna(d);
        }
        private static Inventor.DrawingView Vista(Inventor.DrawingDocument d, Stato s)
        {
            foreach (Inventor.DrawingView v in d.Sheets[s.Foglio].DrawingViews)
                if (string.Equals(v.Name, s.Nome, StringComparison.Ordinal)) return v;
            throw new InvalidOperationException("Vista non trovata: " + s.Nome);
        }
        private static Inventor.DrawingDocument Apri(Inventor.Application app, string path)
        {
            return app.Documents.Open(path, false) as Inventor.DrawingDocument
                ?? throw new InvalidOperationException("Impossibile aprire l'IDW: " + path);
        }
        private static void Chiudi(ref Inventor.DrawingDocument? d)
        {
            if (d == null) return;
            d.Close(true); // SkipSave=true: non salvare modifiche implicite/di errore.
            d = null; // Non usare RCW appartenenti al documento chiuso.
        }
        private static void Aggiorna(Inventor.DrawingDocument d)
        {
            if (!d.Update2(false) || d.RequiresUpdate)
                throw new InvalidOperationException("Aggiornamento IDW non riuscito.");
        }
        private static void VerificaRiferimenti(Inventor.DrawingDocument d, string vecchio, string nuovo)
        {
            bool trovato = false;
            foreach (Inventor.FileDescriptor f in d.File.ReferencedFileDescriptors)
            {
                if (Uguali(f.FullFileName, vecchio)) throw new InvalidOperationException("Riferimento originale ancora presente.");
                if (Uguali(f.FullFileName, nuovo)) trovato = true;
            }
            if (!trovato) throw new InvalidOperationException("Riferimento variante assente.");
        }
        private static bool Uguali(string? a, string? b)
        {
            return !string.IsNullOrWhiteSpace(a) && !string.IsNullOrWhiteSpace(b)
                && string.Equals(Path.GetFullPath(a), Path.GetFullPath(b), StringComparison.OrdinalIgnoreCase);
        }
        private static bool Positivo(double n) { return !double.IsNaN(n) && !double.IsInfinity(n) && n > 0; }
    }
}

