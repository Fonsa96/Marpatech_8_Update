﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneratoreVarianti.Forms
{
    public sealed class VarianteLogEntry
    {
        public string Variante { get; set; } = "";
        public string Stato { get; set; } = "";
        public string Dettagli { get; set; } = "";
    }

    public sealed class GeneratoreVariantiLogForm : Form
    {
        private readonly BindingSource _source;
        private readonly bool _isDarkTheme;

        public GeneratoreVariantiLogForm(
            BindingSource source,
            bool isDarkTheme)
        {
            _source = source;
            _isDarkTheme = isDarkTheme;

            InitializeComponent();
        }

        private void InitializeComponent()
        {
            Text = "Registro Varianti - Marpatech.8";
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(1000, 650);
            MinimumSize = new Size(750, 450);

            Color background = _isDarkTheme
                ? Color.FromArgb(18, 18, 22)
                : Color.FromArgb(245, 247, 250);

            Color foreground = _isDarkTheme
                ? Color.White
                : Color.FromArgb(30, 41, 59);

            Color surface = _isDarkTheme
                ? Color.FromArgb(32, 34, 40)
                : Color.White;

            BackColor = background;

            Label title = new Label
            {
                Text = "Registro delle varianti",
                Font = new Font(
                    "Segoe UI", 20, FontStyle.Bold),
                ForeColor = foreground,
                AutoSize = true,
                Location = new Point(25, 20)
            };

            Controls.Add(title);

            Label subtitle = new Label
            {
                Text = "Risultati delle coppie IPT + IDW",
                Font = new Font("Segoe UI", 10),
                ForeColor = _isDarkTheme
                    ? Color.LightGray
                    : Color.DimGray,
                AutoSize = true,
                Location = new Point(28, 65)
            };

            Controls.Add(subtitle);

            DataGridView grid = new DataGridView
            {
                Location = new Point(25, 105),
                Size = new Size(
                    ClientSize.Width - 50,
                    ClientSize.Height - 175),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Bottom |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                BackgroundColor = surface,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                MultiSelect = false,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                EnableHeadersVisualStyles = false
            };

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                surface;

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                foreground;

            grid.DefaultCellStyle.BackColor = surface;
            grid.DefaultCellStyle.ForeColor = foreground;

            grid.DefaultCellStyle.SelectionBackColor =
                _isDarkTheme
                    ? Color.FromArgb(55, 60, 70)
                    : Color.FromArgb(226, 232, 240);

            grid.DefaultCellStyle.SelectionForeColor =
                foreground;

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    HeaderText = "Variante",
                    DataPropertyName = "Variante",
                    Width = 310
                });

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    HeaderText = "Stato",
                    DataPropertyName = "Stato",
                    Width = 180
                });

            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    HeaderText = "Dettagli",
                    DataPropertyName = "Dettagli",
                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill
                });

            grid.DataSource = _source;

            Controls.Add(grid);

            Button closeButton = new Button
            {
                Text = "CHIUDI",
                Size = new Size(140, 38),
                Location = new Point(
                    ClientSize.Width - 165,
                    ClientSize.Height - 55),
                Anchor = AnchorStyles.Bottom |
                         AnchorStyles.Right,
                BackColor = Color.FromArgb(71, 85, 105),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            closeButton.FlatAppearance.BorderSize = 0;
            closeButton.Click += (s, e) => Close();

            Controls.Add(closeButton);
        }
    }
}
