﻿
using Marpatech_8.Features.Core.Settings;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.GeneratoreVarianti.Services;


namespace Marpatech_8.Features.GeneratoreVarianti.Forms
{
    public class GeneratoreVariantiForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly WindowSettings _windowSettings;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryColor;
        private Color _inputColor;
        private Color _lineColor;

        private Label lblModel = null!;
        private Label lblModelPath = null!;
        private Label lblDrawing = null!;
        private Label lblCount = null!;
        private Label lblProgress = null!;
        private Label lblPercentage = null!;

        private DataGridView parametersGrid = null!;
        private ProgressBar progressBar = null!;
        private Button btnStart = null!;

        private Button btnRegistroVarianti = null!;
        private GeneratoreVariantiLogForm? _registroForm;
        private readonly BindingList<VarianteLogEntry>
    _registroEntries = new();

        private readonly BindingSource _registroSource =
            new BindingSource();

        private string _modelPath = "";
        private bool _loading;

        public GeneratoreVariantiForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "GeneratoreVarianti",
                1150,
                800);

            InitializeTheme();
            InitializeComponent();

            _registroSource.DataSource = _registroEntries;

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            Shown += (s, e) => LoadCurrentModel();

            FormClosing += (s, e) =>
                WindowSettingsService.Save(
                    this,
                    "GeneratoreVarianti");
        }

        private void InitializeTheme()
        {
            _backgroundColor = _isDarkTheme
                ? Color.FromArgb(18, 18, 22)
                : Color.FromArgb(245, 247, 250);

            _cardColor = _isDarkTheme
                ? Color.FromArgb(32, 34, 40)
                : Color.White;

            _titleColor = _isDarkTheme
                ? Color.White
                : Color.FromArgb(30, 41, 59);

            _secondaryColor = _isDarkTheme
                ? Color.FromArgb(170, 178, 190)
                : Color.FromArgb(100, 116, 139);

            _inputColor = _isDarkTheme
                ? Color.FromArgb(43, 46, 55)
                : Color.White;

            _lineColor = _isDarkTheme
                ? Color.FromArgb(70, 75, 85)
                : Color.FromArgb(203, 213, 225);
        }



        private void InitializeComponent()
        {
            Text = "Generatore Varianti Parametriche";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 800);
            MinimumSize = new Size(950, 650);
            BackColor = _backgroundColor;

            Label title = new Label
            {
                Text = "Generatore Varianti Parametriche",
                Font = new Font(
                    "Segoe UI", 24, FontStyle.Bold),
                ForeColor = _titleColor,
                AutoSize = true,
                Location = new Point(35, 18)
            };

            Controls.Add(title);


            btnRegistroVarianti = CreateButton(
                "REGISTRO VARIANTI",
                Color.FromArgb(71, 85, 105));

            btnRegistroVarianti.Size = new Size(205, 42);

            btnRegistroVarianti.Location = new Point(
                ClientSize.Width - btnRegistroVarianti.Width - 35,
                22);

            btnRegistroVarianti.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            btnRegistroVarianti.Visible = false;
            btnRegistroVarianti.Enabled = false;

            btnRegistroVarianti.Click +=
                BtnRegistroVarianti_Click;

            Controls.Add(btnRegistroVarianti);
            btnRegistroVarianti.BringToFront();



            TableLayoutPanel layout = new TableLayoutPanel
            {
                Location = new Point(35, 90),
                Size = new Size(
                    ClientSize.Width - 70,
                    ClientSize.Height - 120),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Bottom |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = _backgroundColor
            };

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 175));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 145));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));


            Panel modelCard = CreateCard();
            Panel parametersCard = CreateCard();
            Panel executionCard = CreateCard();

            layout.Controls.Add(executionCard, 0, 0);
            layout.Controls.Add(modelCard, 0, 1);
            layout.Controls.Add(parametersCard, 0, 2);

            Controls.Add(layout);

            BuildModelCard(modelCard);
            BuildParametersCard(parametersCard);
            BuildExecutionCard(executionCard);

        }

        private Panel CreateCard()
        {
            return new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = _cardColor,
                Margin = new Padding(0, 0, 0, 12)
            };
        }

        private Label CreateLabel(
            string text,
            int size = 9,
            bool bold = false)
        {
            return new Label
            {
                Text = text,
                Font = new Font(
                    "Segoe UI",
                    size,
                    bold ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = bold
                    ? _titleColor
                    : _secondaryColor,
                AutoSize = true
            };
        }

        private Button CreateButton(
            string text,
            Color color)
        {
            Button button = new Button
            {
                Text = text,
                Font = new Font(
                    "Segoe UI", 9, FontStyle.Bold),
                BackColor = color,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private void BuildModelCard(Panel card)
        {
            Label heading = CreateLabel(
                "Modello di origine", 14, true);

            heading.Location = new Point(22, 15);
            card.Controls.Add(heading);

            lblModel = CreateLabel(
                "Nessun modello rilevato", 12, true);
            lblModel.Location = new Point(22, 50);
            card.Controls.Add(lblModel);

            lblModelPath = CreateLabel("");
            lblModelPath.Location = new Point(22, 80);
            card.Controls.Add(lblModelPath);

            lblDrawing = CreateLabel(
                "Tavola IDW: non verificata");
            lblDrawing.Location = new Point(22, 103);
            card.Controls.Add(lblDrawing);

            Button refresh = CreateButton(
                "AGGIORNA MODELLO",
                Color.FromArgb(124, 58, 237));

            refresh.Size = new Size(185, 44);
            refresh.Location = new Point(
                card.Width - 207, 48);

            refresh.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            refresh.Click += (s, e) => LoadCurrentModel();

            card.Controls.Add(refresh);
        }

        private void BuildParametersCard(Panel card)
        {
            Label heading = CreateLabel(
                "Parametri del modello", 14, true);
            heading.Location = new Point(22, 14);
            card.Controls.Add(heading);

            Label subtitle = CreateLabel(
                "Seleziona i parametri e imposta minimo, massimo e passo.");
            subtitle.Location = new Point(23, 46);
            card.Controls.Add(subtitle);

            parametersGrid = CreateGrid();
            parametersGrid.Location = new Point(22, 75);
            parametersGrid.Size = new Size(
                card.Width - 44,
                card.Height - 95);

            // Impedisce all'utente di ridimensionare le colonne.
parametersGrid.AllowUserToResizeColumns = false;

// Impedisce di modificare la larghezza delle intestazioni.
parametersGrid.ColumnHeadersHeightSizeMode =
    DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            parametersGrid.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            parametersGrid.Columns.Add(
                new DataGridViewCheckBoxColumn
                {
                    Name = "Selected",
                    HeaderText = "Usa",
                    Width = 55
                });

            AddColumn(parametersGrid, "Name", "Parametro", 125);
            AddColumn(parametersGrid, "Current", "Equazione", 180);
            AddColumn(parametersGrid, "Unit", "Unità", 80);
            AddColumn(parametersGrid, "Min", "Minimo", 110);
            AddColumn(parametersGrid, "Max", "Massimo", 110);
            AddColumn(parametersGrid, "Step", "Passo", 110);

            parametersGrid.Columns["Name"]!.ReadOnly = true;
            parametersGrid.Columns["Current"]!.ReadOnly = true;
            parametersGrid.Columns["Unit"]!.ReadOnly = true;

            parametersGrid.Columns["Current"]!.ToolTipText =
             "Equazione originale del parametro modello Inventor.";

            parametersGrid.Columns["Current"]!.DefaultCellStyle.WrapMode =
                DataGridViewTriState.False;

            parametersGrid.CellEndEdit += (s, e) =>
                UpdateCombinationCount();


            parametersGrid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            parametersGrid.Columns["Selected"]!.FillWeight = 6;
            parametersGrid.Columns["Name"]!.FillWeight = 26;
            parametersGrid.Columns["Current"]!.FillWeight = 19;
            parametersGrid.Columns["Unit"]!.FillWeight = 8;
            parametersGrid.Columns["Min"]!.FillWeight = 14;
            parametersGrid.Columns["Max"]!.FillWeight = 14;
            parametersGrid.Columns["Step"]!.FillWeight = 13;

            parametersGrid.Columns["Selected"]!.MinimumWidth = 50;
            parametersGrid.Columns["Name"]!.MinimumWidth = 180;
            parametersGrid.Columns["Current"]!.MinimumWidth = 125;
            parametersGrid.Columns["Unit"]!.MinimumWidth = 65;
            parametersGrid.Columns["Min"]!.MinimumWidth = 90;
            parametersGrid.Columns["Max"]!.MinimumWidth = 90;
            parametersGrid.Columns["Step"]!.MinimumWidth = 90;

            // Ripristina tutte le linee standard della tabella.
            parametersGrid.CellBorderStyle =
                DataGridViewCellBorderStyle.Single;

            // Disegna un unico separatore tra i dati Inventor
            // e i valori impostati dall'utente.
            parametersGrid.CellPainting += ParametersGrid_CellPainting;

            parametersGrid.CurrentCellDirtyStateChanged +=
                (s, e) =>
                {
                    if (parametersGrid.IsCurrentCellDirty)
                        parametersGrid.CommitEdit(
                            DataGridViewDataErrorContexts.Commit);
                };

            parametersGrid.CellValueChanged +=
                (s, e) => UpdateCombinationCount();

            parametersGrid.DataError +=
                (s, e) => { e.ThrowException = false; };

            card.Controls.Add(parametersGrid);
        }

        private void BuildExecutionCard(Panel card)
        {
            lblCount = CreateLabel(
                "Combinazioni previste: 0", 11, true);
            lblCount.Location = new Point(22, 14);
            card.Controls.Add(lblCount);

            btnStart = CreateButton(
                "AVVIA GENERAZIONE",
                Color.FromArgb(22, 163, 74));

            btnStart.Location = new Point(22, 43);
            btnStart.Size = new Size(
                card.Width - 44, 42);

            btnStart.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            // Prima fase: preparazione delle combinazioni.
            // Non crea e non modifica file Inventor.
            btnStart.Enabled = true;
            btnStart.Click += BtnStart_Click;

            card.Controls.Add(btnStart);

            progressBar = new ProgressBar
            {
                Location = new Point(22, 94),
                Size = new Size(card.Width - 115, 20),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                Minimum = 0,
                Maximum = 100,
                Value = 0
            };

            card.Controls.Add(progressBar);

            lblPercentage = CreateLabel("0%", 9, true);
            lblPercentage.Location = new Point(
                card.Width - 80, 94);

            lblPercentage.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            card.Controls.Add(lblPercentage);

            lblProgress = CreateLabel(
                "In attesa del motore di generazione");
            lblProgress.Location = new Point(22, 125);
            card.Controls.Add(lblProgress);
        }

        private DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView
            {
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = false,
                BackgroundColor = _inputColor,
                GridColor = _lineColor,
                BorderStyle = BorderStyle.None,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 40,
                ColumnHeadersHeightSizeMode =
                    DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.FromArgb(241, 245, 249);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                _titleColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 9, FontStyle.Bold);

            grid.DefaultCellStyle.BackColor = _inputColor;
            grid.DefaultCellStyle.ForeColor = _titleColor;
            grid.DefaultCellStyle.SelectionBackColor = _inputColor;
            grid.DefaultCellStyle.SelectionForeColor = _titleColor;
            grid.DefaultCellStyle.Font =
                new Font("Segoe UI", 9);

            grid.DefaultCellStyle.Padding =
                new Padding(6, 2, 6, 2);

            grid.RowTemplate.Height = 38;

            return grid;
        }

        private static void AddColumn(
            DataGridView grid,
            string name,
            string header,
            int width)
        {
            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = name,
                    HeaderText = header,
                    Width = width,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });
        }


        private sealed class ParametroInfo
        {
            public string Nome { get; init; } = "";
            public string Equazione { get; init; } = "";
            public string Unita { get; init; } = "";
            public decimal ValoreOriginale { get; init; }
            public bool Numerico { get; init; }
        }

        private static bool TryParseEquazioneNumerica(
            string expression,
            out decimal value,
            out string unit)
        {
            value = 0;
            unit = "";

            if (string.IsNullOrWhiteSpace(expression))
                return false;

            var match = System.Text.RegularExpressions.Regex.Match(
                expression.Trim(),
                @"^([+-]?(?:\d+(?:[.,]\d+)?|[.,]\d+)(?:[eE][+-]?\d+)?)\s*(.*)$");

            if (!match.Success)
                return false;

            string number = match.Groups[1].Value;
            string suffix = match.Groups[2].Value.Trim();

            // Accettiamo solo un'unità semplice.
            // Formule, riferimenti e operazioni sono esclusi
            // da questa prima versione.
            if (suffix.Length > 0 &&
                !System.Text.RegularExpressions.Regex.IsMatch(
                    suffix,
                    @"^[\p{L}°%][\p{L}\d°%²³^/*-]*$"))
            {
                return false;
            }

            string normalized = number.Replace(',', '.');

            if (!decimal.TryParse(
                normalized,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value))
            {
                return false;
            }

            unit = suffix;
            return true;
        }





        private void ParametersGrid_CellPainting(
            object? sender,
            DataGridViewCellPaintingEventArgs e)
        {
            if (e.Graphics == null)
                return;

            if (e.ColumnIndex < 0)
                return;

            DataGridViewColumn? unitColumn =
                parametersGrid.Columns["Unit"];

            if (unitColumn == null)
                return;

            int unitIndex = unitColumn.Index;

            if (e.ColumnIndex != unitIndex)
                return;

            // Disegna normalmente intestazione e celle,
            // escludendo soltanto il bordo standard.
            e.Paint(
                e.CellBounds,
                DataGridViewPaintParts.All &
                ~DataGridViewPaintParts.Border);

            // Ripristina i bordi standard superiore,
            // inferiore e sinistro.
            using (Pen normalPen = new Pen(_lineColor, 1f))
            {
                int left = e.CellBounds.Left;
                int right = e.CellBounds.Right - 1;
                int top = e.CellBounds.Top;
                int bottom = e.CellBounds.Bottom - 1;

                e.Graphics.DrawLine(
                    normalPen, left, top, right, top);

                e.Graphics.DrawLine(
                    normalPen, left, bottom, right, bottom);

                e.Graphics.DrawLine(
                    normalPen, left, top, left, bottom);
            }

            // Un solo separatore più spesso sul bordo
            // destro della colonna Unità.
            using (Pen separatorPen = new Pen(
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(65, 75, 90),
                4f))
            {
                int x = e.CellBounds.Right - 2;

                e.Graphics.DrawLine(
                    separatorPen,
                    x,
                    e.CellBounds.Top,
                    x,
                    e.CellBounds.Bottom);
            }

            e.Handled = true;
        }





        private void LoadCurrentModel()
        {
            if (_loading)
                return;

            _loading = true;

            try
            {
                parametersGrid.Rows.Clear();
                _modelPath = "";

                Inventor.Document document =
                    _inventorApp.ActiveDocument;

                if (document is not Inventor.PartDocument part)
                {
                    lblModel.Text = "Nessun IPT attivo";
                    lblModelPath.Text =
                        "Apri un file IPT in Inventor.";
                    lblDrawing.Text = "Tavola IDW: non verificata";
                    UpdateCombinationCount();
                    return;
                }

                _modelPath = part.FullFileName;

                lblModel.Text = string.IsNullOrWhiteSpace(
                    _modelPath)
                    ? part.DisplayName
                    : Path.GetFileName(_modelPath);

                lblModelPath.Text = _modelPath;

                string drawingPath =
                    Path.ChangeExtension(_modelPath, ".idw");

                lblDrawing.Text =
                    !string.IsNullOrWhiteSpace(_modelPath) &&
                    File.Exists(drawingPath)
                        ? "Tavola IDW: " +
                          Path.GetFileName(drawingPath)
                        : "Tavola IDW: non trovata nella cartella del modello";

                Inventor.ModelParameters modelParameters =
                    part.ComponentDefinition.Parameters.ModelParameters;


                foreach (Inventor.ModelParameter parameter
                         in modelParameters)
                {
                    string expression = parameter.Expression;
                    string name = parameter.Name;

                    bool numeric = TryParseEquazioneNumerica(
                        expression,
                        out decimal originalValue,
                        out string unit);


                    int index = parametersGrid.Rows.Add(
                        false,
                        name,
                        expression,
                        unit,
                        "",
                        "",
                        "");

                    DataGridViewRow row = parametersGrid.Rows[index];

                    row.Tag = new ParametroInfo
                    {
                        Nome = name,
                        Equazione = expression,
                        Unita = unit,
                        ValoreOriginale = originalValue,
                        Numerico = numeric
                    };

                    if (!numeric)
                    {
                        row.Cells["Selected"].ReadOnly = true;
                        row.Cells["Min"].ReadOnly = true;
                        row.Cells["Max"].ReadOnly = true;
                        row.Cells["Step"].ReadOnly = true;

                        row.Cells["Selected"].ToolTipText =
                            "Parametro con formula: gestione prevista in futuro.";

                        row.DefaultCellStyle.ForeColor =
                            _secondaryColor;
                    }
                }


                UpdateCombinationCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Errore durante la lettura del modello:" +
                    Environment.NewLine + ex.Message,
                    "Generatore Varianti",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                _loading = false;
                UpdateCombinationCount();
            }
        }


        private List<IntervalloVariante> LeggiIntervalliSelezionati()
        {
            parametersGrid.EndEdit();

            var intervalli = new List<IntervalloVariante>();

            foreach (DataGridViewRow row in parametersGrid.Rows)
            {
                bool selezionato = Convert.ToBoolean(
                    row.Cells["Selected"].Value ?? false);

                if (!selezionato)
                    continue;

                if (row.Tag is not ParametroInfo info ||
                    !info.Numerico)
                {
                    throw new InvalidOperationException(
                        "È stato selezionato un parametro non numerico.");
                }

                if (!TryReadNumber(row, "Min", out decimal minimo) ||
                    !TryReadNumber(row, "Max", out decimal massimo) ||
                    !TryReadNumber(row, "Step", out decimal passo))
                {
                    throw new InvalidOperationException(
                        "Compila Minimo, Massimo e Passo per " +
                        info.Nome);
                }

                if (passo <= 0 || massimo < minimo)
                {
                    throw new InvalidOperationException(
                        "Intervallo non valido per " + info.Nome);
                }

                intervalli.Add(new IntervalloVariante
                {
                    Nome = info.Nome,
                    Unita = info.Unita,
                    ValoreOriginale = info.ValoreOriginale,
                    Minimo = minimo,
                    Massimo = massimo,
                    Passo = passo
                });
            }

            if (intervalli.Count == 0)
            {
                throw new InvalidOperationException(
                    "Seleziona almeno un parametro.");
            }

            return intervalli;
        }


        private void UpdateCombinationCount()
        {
            if (parametersGrid == null ||
                lblCount == null ||
                _loading)
                return;

            long combinations = 1;
            int selectedCount = 0;
            bool valid = true;
            bool originalIncluded = true;

            foreach (DataGridViewRow row in parametersGrid.Rows)
            {
                bool selected = Convert.ToBoolean(
                    row.Cells["Selected"].Value ?? false);

                if (!selected)
                    continue;

                selectedCount++;

                if (row.Tag is not ParametroInfo info ||
                    !info.Numerico)
                {
                    valid = false;
                    break;
                }

                bool minValid =
                    TryReadNumber(row, "Min", out decimal min);

                bool maxValid =
                    TryReadNumber(row, "Max", out decimal max);

                bool stepValid =
                    TryReadNumber(row, "Step", out decimal step);

                if (!minValid || !maxValid || !stepValid ||
                    step <= 0 || max < min)
                {
                    valid = false;
                    break;
                }

                try
                {
                    decimal intervals =
                        decimal.Floor((max - min) / step);

                    long count = checked((long)intervals + 1);

                    combinations = checked(combinations * count);

                    decimal original = info.ValoreOriginale;

                    if (original < min || original > max)
                    {
                        originalIncluded = false;
                    }
                    else
                    {
                        decimal position = (original - min) / step;

                        if (position != decimal.Truncate(position))
                            originalIncluded = false;
                    }
                }
                catch (OverflowException)
                {
                    valid = false;
                    break;
                }
            }

            if (!valid)
            {
                lblCount.Text =
                    "Intervalli non validi o troppe combinazioni";
                return;
            }

            if (selectedCount == 0)
            {
                lblCount.Text = "Combinazioni previste: 0";
                return;
            }

            long total = combinations -
                (originalIncluded ? 1 : 0);

            lblCount.Text =
                "Combinazioni previste: " +
                total.ToString("N0", CultureInfo.CurrentCulture);
        }



        private static bool TryReadNumber(
            DataGridViewRow row,
            string column,
            out decimal value)
        {
            string text = Convert.ToString(
                row.Cells[column].Value)?.Trim() ?? "";

            value = 0;

            if (string.IsNullOrWhiteSpace(text))
                return false;

            // Supporta sia 6,5 sia 6.5.
            string normalized = text.Replace(',', '.');

            return decimal.TryParse(
                normalized,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value);
        }





        private void BtnStart_Click(object? sender, EventArgs e)
        {
            btnStart.Enabled = false;

            try
            {
                List<IntervalloVariante> intervalli =
                    LeggiIntervalliSelezionati();

                List<VariantePianificata> varianti =
                    GeneratoreVariantiPreparationService.Prepara(
                        _modelPath,
                        intervalli);

                if (varianti.Count == 0)
                {
                    MessageBox.Show(
                        this,
                        "Nessuna nuova variante da generare.",
                        "Generatore Varianti",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return;
                }

                DialogResult conferma = MessageBox.Show(
                    this,
                    "Verranno generate " + varianti.Count +
                    " coppie IPT + IDW." +
                    Environment.NewLine +
                    "I file originali non verranno modificati." +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Vuoi procedere?",
                    "Conferma generazione",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (conferma != DialogResult.Yes)
                    return;

                _registroEntries.Clear();

                progressBar.Value = 0;
                lblPercentage.Text = "0%";

                OnGenerazioneAvviata();

                int completate = 0;
                int errori = 0;
                int elaborate = 0;

                foreach (VariantePianificata variante in varianti)
                {
                    lblProgress.Text =
                        "Generazione IPT: " + variante.NomeBase;

                    lblProgress.Refresh();

                    RisultatoGenerazioneIpt risultatoIpt =
                        GeneratoreVariantiIptService.Genera(
                            _inventorApp,
                            _modelPath,
                            variante,
                            intervalli);

                    if (!risultatoIpt.Successo)
                    {
                        errori++;

                        AggiungiEsitoVariante(
                            variante.NomeBase,
                            "Errore IPT",
                            risultatoIpt.Messaggio);
                    }
                    else
                    {
                        lblProgress.Text =
                            "Generazione IDW: " + variante.NomeBase;

                        lblProgress.Refresh();

                        RisultatoGenerazioneIdw risultatoIdw =
                            GeneratoreVariantiIdwService.Genera(
                                _inventorApp,
                                _modelPath,
                                variante);


                        if (risultatoIdw.Successo)
                        {
                            completate++;

                            bool richiedeControllo =
                                !string.IsNullOrWhiteSpace(risultatoIdw.Messaggio);

                            AggiungiEsitoVariante(
                                variante.NomeBase,
                                richiedeControllo ? "Da controllare" : "OK",
                                richiedeControllo ? risultatoIdw.Messaggio : "");
                        }


                        else
                        {
                            errori++;

                            AggiungiEsitoVariante(
                                variante.NomeBase,
                                "Errore IDW",
                                "IPT creato. " +
                                risultatoIdw.Messaggio);
                        }
                    }

                    elaborate++;

                    int percentuale = (int)(
                        (long)elaborate * 100 / varianti.Count);

                    progressBar.Value = percentuale;
                    lblPercentage.Text = percentuale + "%";

                    // Permette l'aggiornamento visivo
                    // durante l'elaborazione COM di Inventor.
                    Application.DoEvents();
                }

                lblProgress.Text =
                    "Coppie collegate: " + completate +
                    " | Errori: " + errori;

                MessageBox.Show(
                    this,
                    "Generazione terminata." +
                    Environment.NewLine +
                    "Coppie IPT + IDW collegate: " + completate +
                    Environment.NewLine +
                    "Errori: " + errori +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Il controllo geometrico delle tavole " +
                    "non è ancora stato eseguito.",
                    "Generatore Varianti",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                lblProgress.Text = "Generazione interrotta.";

                MessageBox.Show(
                    this,
                    ex.Message,
                    "Generatore Varianti",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                btnStart.Enabled = true;
            }
        }



        private void BtnRegistroVarianti_Click(
            object? sender,
            EventArgs e)
        {
            if (!btnRegistroVarianti.Enabled)
                return;

            if (_registroForm != null &&
                !_registroForm.IsDisposed)
            {
                _registroForm.Show();
                _registroForm.BringToFront();
                _registroForm.Activate();
                return;
            }

            _registroForm = new GeneratoreVariantiLogForm(
                _registroSource,
                _isDarkTheme);

            _registroForm.FormClosed += (s, args) =>
                _registroForm = null;

            _registroForm.Show(this);
        }

        /// <summary>
        /// Da richiamare esclusivamente quando
        /// il motore di generazione è partito.
        /// </summary>

        private void OnGenerazioneAvviata()
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(OnGenerazioneAvviata));
                return;
            }

            btnRegistroVarianti.Enabled = true;
            btnRegistroVarianti.Visible = true;
            btnRegistroVarianti.BringToFront();
        }


        /// <summary>
        /// Registra l'esito di una variante.
        /// Sarà chiamato dal motore IPT/IDW.
        /// </summary>
        private void AggiungiEsitoVariante(
            string variante,
            string stato,
            string dettagli)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() =>
                    AggiungiEsitoVariante(
                        variante, stato, dettagli)));
                return;
            }

            _registroEntries.Add(
                new VarianteLogEntry
                {
                    Variante = variante,
                    Stato = stato,
                    Dettagli = dettagli
                });
        }

    }
}
