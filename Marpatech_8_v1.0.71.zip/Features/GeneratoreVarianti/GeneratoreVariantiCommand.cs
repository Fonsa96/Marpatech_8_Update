﻿
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.GeneratoreVarianti.Forms;
using Marpatech_8.Features.Mail;

using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.GeneratoreVarianti
{
    public static class GeneratoreVariantiCommand
    {
        public static void Execute(
            InventorApp inventorApp,
            FeatureOpenContext context)
        {
            if (context.MainDashboard != null &&
                !context.MainDashboard.IsDisposed)
            {
                FeatureNavigationService.OpenFeature(
                    context,
                    "GeneratoreVarianti",
                    () => new GeneratoreVariantiForm(
                        inventorApp,
                        context.IsDarkTheme));

                return;
            }

            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(inventorApp);

            SingleFormService.ShowSingle(
                "GeneratoreVarianti",
                () => new GeneratoreVariantiForm(
                    inventorApp,
                    context.IsDarkTheme),
                owner);
        }

        public static void Execute(
            InventorApp inventorApp,
            bool isDarkTheme)
        {
            Execute(
                inventorApp,
                FeatureOpenContext.FromInventor(isDarkTheme));
        }
    }
}
