﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.ControlloTavole.Models;
using Marpatech_8.Features.ControlloTavole.Services;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marpatech_8.Features.ControlloTavole.Forms
{
    public class ControlloTavoleDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;

        // Documento IAM/IPT da cui è stata caricata la struttura.
        private string _originalDocumentPath = "";
        private readonly bool _isDarkTheme;
        private readonly WindowSettings _windowSettings;

        private Label? lblAssemblyName;
        private Label? lblAssemblyPath;

        private Button? btnStartCheck;
        private Button? btnReadCurrentAssembly;
        private Button? btnSettings;


        private Panel? progressCard;
        private ProgressBar? progressBar;
        private Label? lblProgress;
        private Label? lblProgressPercentage;

        private DataGridView? drawingsGrid;

        private bool _isLoadingDrawings;

        private bool _isScanningDrawings;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryTextColor;
        private Color _inputColor;
        private Color _lineColor;

        public ControlloTavoleDashboardForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "ControlloTavoleDashboard",
                1100,
                720);

            InitializeTheme();
            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            Shown += ControlloTavoleDashboardForm_Shown;
        }

        private void InitializeTheme()
        {
            _backgroundColor = _isDarkTheme
                ? Color.FromArgb(18, 18, 22)
                : Color.FromArgb(245, 247, 250);

            _cardColor = _isDarkTheme
                ? Color.FromArgb(32, 34, 40)
                : Color.White;

            _titleColor = _isDarkTheme
                ? Color.White
                : Color.FromArgb(30, 41, 59);

            _secondaryTextColor = _isDarkTheme
                ? Color.FromArgb(170, 178, 190)
                : Color.FromArgb(100, 116, 139);

            _inputColor = _isDarkTheme
                ? Color.FromArgb(43, 46, 55)
                : Color.White;

            _lineColor = _isDarkTheme
                ? Color.FromArgb(70, 75, 85)
                : Color.FromArgb(203, 213, 225);
        }

        private void InitializeComponent()
        {
            Text = "Controllo Tavole";

            StartPosition = FormStartPosition.CenterScreen;

            Size = new Size(
                1100,
                720);

            MinimumSize = new Size(
                1100,
                600);

            BackColor = _backgroundColor;

            FormClosing +=
                ControlloTavoleDashboardForm_FormClosing;


            // =========================================================
            // TITOLO
            // =========================================================

            Label title = new Label();

            title.Text =
                "Controllo Tavole";

            title.Font =
                new Font(
                    "Segoe UI",
                    26,
                    FontStyle.Bold);

            title.ForeColor =
                _titleColor;

            title.AutoSize =
                true;

            title.Location =
                new Point(
                    35,
                    18);


            // =========================================================
            // IMPOSTAZIONI
            // =========================================================

            btnSettings =
                CreateButton(
                    "⚙",
                    Color.FromArgb(
                        37,
                        99,
                        235),
                    50,
                    42);

            btnSettings.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            btnSettings.Location =
                new Point(
                    ClientSize.Width - 85,
                    30);

            btnSettings.Click +=
                BtnSettings_Click;


            // =========================================================
            // CONTENITORE PRINCIPALE
            // =========================================================

            Panel contentPanel =
                new Panel();

            contentPanel.Location =
                new Point(
                    35,
                    90);

            contentPanel.Size =
                new Size(
                    ClientSize.Width - 70,
                    ClientSize.Height - 120);

            contentPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            contentPanel.BackColor =
                _backgroundColor;


            // =========================================================
            // ASSIEME RILEVATO
            // =========================================================

            Panel assemblyCard =
                new Panel();

            assemblyCard.Location =
                new Point(
                    0,
                    0);

            assemblyCard.Size =
                new Size(
                    contentPanel.Width,
                    130);

            assemblyCard.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            assemblyCard.BackColor =
                _cardColor;

            assemblyCard.Padding =
                new Padding(22);


            Label lblAssemblyTitle =
                CreateSectionTitle(
                    "Codice Rilevato");

            lblAssemblyTitle.Location =
                new Point(
                    22,
                    18);


            lblAssemblyName =
                new Label();

            lblAssemblyName.Text =
                "Nessun documento aperto a schermo";

            lblAssemblyName.Font =
                new Font(
                    "Segoe UI",
                    12,
                    FontStyle.Bold);

            lblAssemblyName.ForeColor =
                _titleColor;

            lblAssemblyName.AutoEllipsis =
                true;

            lblAssemblyName.Location =
                new Point(
                    22,
                    53);

            lblAssemblyName.Size =
                new Size(
                    300,
                    25);

            lblAssemblyName.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left;


            lblAssemblyPath =
                new Label();

            lblAssemblyPath.Text =
                "";

            lblAssemblyPath.Font =
                new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Regular);

            lblAssemblyPath.ForeColor =
                _secondaryTextColor;

            lblAssemblyPath.AutoEllipsis =
                true;

            lblAssemblyPath.Location =
                new Point(
                    22,
                    82);

            lblAssemblyPath.Size =
                new Size(
                    300,
                    22);

            lblAssemblyPath.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left;

            btnReadCurrentAssembly =
                CreateButton(
                    "LEGGI ASSIEME CORRENTE",
                    Color.FromArgb(
                        124,
                        58,
                        237),
                    220,
                    52);

                        btnReadCurrentAssembly.Font =
                            new Font(
                                "Segoe UI",
                                9,
                                FontStyle.Bold);

                        btnReadCurrentAssembly.Location =
                            new Point(
                                assemblyCard.Width - 830,
                                39);

                        btnReadCurrentAssembly.Anchor =
                            AnchorStyles.Top |
                            AnchorStyles.Right;

                        btnReadCurrentAssembly.Click +=
                            BtnReadCurrentAssembly_Click;


            btnStartCheck =
                CreateButton(
                    "AVVIA CONTROLLO",
                    Color.FromArgb(
                        22,
                        163,
                        74),
                    560,
                    52);

            btnStartCheck.Font =
                new Font(
                    "Segoe UI",
                    12,
                    FontStyle.Bold);

            btnStartCheck.Location =
                new Point(
                    assemblyCard.Width - 585,
                    39);

            btnStartCheck.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;

            assemblyCard.Resize +=
            (s, e) =>
            {
                UpdateAssemblyInfoWidth(
                    assemblyCard);
            };

            btnStartCheck.Click +=
                BtnStartCheck_Click;


            assemblyCard.Controls.Add(
                lblAssemblyTitle);

            assemblyCard.Controls.Add(
                lblAssemblyName);

            assemblyCard.Controls.Add(
                lblAssemblyPath);

            assemblyCard.Controls.Add(
                btnReadCurrentAssembly);

            assemblyCard.Controls.Add(
                btnStartCheck);
            UpdateAssemblyInfoWidth(
                assemblyCard);


            // =========================================================
            // AVANZAMENTO
            // inizialmente nascosto
            // =========================================================

            progressCard =
                new Panel();

            progressCard.Location =
                new Point(
                    0,
                    145);

            progressCard.Size =
                new Size(
                    contentPanel.Width,
                    105);

            progressCard.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            progressCard.BackColor =
                _cardColor;

            progressCard.Visible =
                false;


            Label lblProgressTitle =
                CreateSectionTitle(
                    "Avanzamento controllo");

            lblProgressTitle.Location =
                new Point(
                    22,
                    14);


            progressBar =
                new ProgressBar();

            progressBar.Location =
                new Point(
                    22,
                    49);

            progressBar.Size =
                new Size(
                    progressCard.Width - 115,
                    22);

            progressBar.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            progressBar.Minimum =
                0;

            progressBar.Maximum =
                100;

            progressBar.Value =
                0;


            lblProgressPercentage =
                new Label();

            lblProgressPercentage.Text =
                "0%";

            lblProgressPercentage.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            lblProgressPercentage.ForeColor =
                _titleColor;

            lblProgressPercentage.TextAlign =
                ContentAlignment.MiddleRight;

            lblProgressPercentage.Location =
                new Point(
                    progressCard.Width - 82,
                    48);

            lblProgressPercentage.Size =
                new Size(
                    55,
                    24);

            lblProgressPercentage.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;


            lblProgress =
                new Label();

            lblProgress.Text =
                "Preparazione controllo...";

            lblProgress.Font =
                new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Regular);

            lblProgress.ForeColor =
                _secondaryTextColor;

            lblProgress.AutoEllipsis =
                true;

            lblProgress.Location =
                new Point(
                    22,
                    77);

            lblProgress.Size =
                new Size(
                    progressCard.Width - 44,
                    20);

            lblProgress.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;


            progressCard.Controls.Add(
                lblProgressTitle);

            progressCard.Controls.Add(
                progressBar);

            progressCard.Controls.Add(
                lblProgressPercentage);

            progressCard.Controls.Add(
                lblProgress);


            // =========================================================
            // SEZIONE TAVOLE
            // =========================================================

            Panel drawingsCard =
                new Panel();

            drawingsCard.Location =
                new Point(
                    0,
                    145);

            drawingsCard.Size =
                new Size(
                    contentPanel.Width,
                    contentPanel.Height - 145);

            drawingsCard.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            drawingsCard.BackColor =
                _cardColor;


            Label lblDrawingsTitle =
                CreateSectionTitle(
                    "Tavole");

            lblDrawingsTitle.Location =
                new Point(
                    22,
                    16);


            Label lblDrawingsSubtitle =
                new Label();

            lblDrawingsSubtitle.Text =
                "Tavole rilevate dal documento corrente";

            lblDrawingsSubtitle.Font =
                new Font(
                    "Segoe UI",
                    8,
                    FontStyle.Regular);

            lblDrawingsSubtitle.ForeColor =
                _secondaryTextColor;

            lblDrawingsSubtitle.AutoSize =
                true;

            lblDrawingsSubtitle.Location =
                new Point(
                    23,
                    46);


            drawingsGrid =
                new DataGridView();

            ConfigureDrawingsGrid();

            drawingsGrid.Location =
                new Point(
                    22,
                    75);

            drawingsGrid.Size =
                new Size(
                    drawingsCard.Width - 44,
                    drawingsCard.Height - 97);

            drawingsGrid.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;


            drawingsCard.Controls.Add(
                lblDrawingsTitle);

            drawingsCard.Controls.Add(
                lblDrawingsSubtitle);

            drawingsCard.Controls.Add(
                drawingsGrid);


            // =========================================================
            // CONTROLLI
            // =========================================================

            contentPanel.Controls.Add(
                assemblyCard);

            contentPanel.Controls.Add(
                progressCard);

            contentPanel.Controls.Add(
                drawingsCard);


            Controls.Add(
                title);

            Controls.Add(
                btnSettings);

            Controls.Add(
                contentPanel);


            /*
             * Conserviamo il riferimento alla card delle tavole
             * nel Tag del progressCard.
             *
             * Serve soltanto alla gestione del layout quando
             * compare / scompare l'avanzamento.
             */
            progressCard.Tag =
                drawingsCard;
        }

        private void UpdateAssemblyInfoWidth(
            Panel assemblyCard)
        {
            if (lblAssemblyName == null ||
                lblAssemblyPath == null ||
                btnReadCurrentAssembly == null)
            {
                return;
            }

            const int leftMargin = 22;
            const int gapBeforeButton = 25;

            int availableWidth =
                btnReadCurrentAssembly.Left -
                leftMargin -
                gapBeforeButton;

            availableWidth =
                Math.Max(
                    100,
                    availableWidth);

            lblAssemblyName.Width =
                availableWidth;

            lblAssemblyPath.Width =
                availableWidth;
        }



        // =============================================================
        // GRIGLIA
        // =============================================================

        private void ConfigureDrawingsGrid()
        {
            if (drawingsGrid == null)
                return;

            drawingsGrid.AllowUserToAddRows =
                false;

            drawingsGrid.AllowUserToDeleteRows =
                false;

            drawingsGrid.AllowUserToResizeRows =
                false;

            drawingsGrid.AllowUserToOrderColumns =
                false;

            drawingsGrid.ReadOnly =
                true;

            drawingsGrid.MultiSelect =
                false;

            drawingsGrid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            drawingsGrid.AutoGenerateColumns =
                false;

            drawingsGrid.RowHeadersVisible =
                false;

            drawingsGrid.BackgroundColor =
                _inputColor;

            drawingsGrid.BorderStyle =
                BorderStyle.None;

            drawingsGrid.GridColor =
                _lineColor;

            drawingsGrid.EnableHeadersVisualStyles =
                false;

            drawingsGrid.ColumnHeadersBorderStyle =
                DataGridViewHeaderBorderStyle.None;

            drawingsGrid.ColumnHeadersHeight =
                40;

            drawingsGrid.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            drawingsGrid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        43,
                        46,
                        55)
                    : Color.FromArgb(
                        241,
                        245,
                        249);

            drawingsGrid.ColumnHeadersDefaultCellStyle.ForeColor =
                _titleColor;

            drawingsGrid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            drawingsGrid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                drawingsGrid.ColumnHeadersDefaultCellStyle.BackColor;

            drawingsGrid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                _titleColor;

            drawingsGrid.DefaultCellStyle.BackColor =
                _inputColor;

            drawingsGrid.DefaultCellStyle.ForeColor =
                _titleColor;

            drawingsGrid.DefaultCellStyle.SelectionBackColor =
                _inputColor;

            drawingsGrid.DefaultCellStyle.SelectionForeColor =
                _titleColor;

            drawingsGrid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            drawingsGrid.DefaultCellStyle.Padding =
                new Padding(
                    6,
                    2,
                    6,
                    2);

            drawingsGrid.RowTemplate.Height =
                38;

            drawingsGrid.CellClick +=
                DrawingsGrid_CellClick;


            // STATO

            DataGridViewTextBoxColumn statusColumn =
                new DataGridViewTextBoxColumn();

            statusColumn.Name =
                "Status";

            statusColumn.HeaderText =
                "Stato";

            statusColumn.Width =
                80;

            statusColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            statusColumn.DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;


            // CODICE

            DataGridViewTextBoxColumn codeColumn =
                new DataGridViewTextBoxColumn();

            codeColumn.Name =
                "Code";

            codeColumn.HeaderText =
                "Codice";

            codeColumn.Width =
                230;

            codeColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.None;

            codeColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;


            // TAVOLA

            // PRESENZA TAVOLA

            DataGridViewTextBoxColumn drawingColumn =
                new DataGridViewTextBoxColumn();

            drawingColumn.Name =
                "Drawing";

            drawingColumn.HeaderText =
                "Presenza Tavola";

            drawingColumn.Width =
                120;

            drawingColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.None;

            drawingColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            drawingColumn.DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;

            drawingColumn.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    12,
                    FontStyle.Bold);


            // ESITO

            DataGridViewTextBoxColumn resultColumn =
                new DataGridViewTextBoxColumn();

            resultColumn.Name =
                "Result";

            resultColumn.HeaderText =
                "Esito / Problemi";

            resultColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            resultColumn.FillWeight =
                100;

            resultColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            // =============================================================
            // SCEGLI IDW MANUALMENTE
            //
            // La colonna parte nascosta.
            // Viene mostrata soltanto se, a ricerca terminata,
            // esiste almeno una tavola mancante con fallback disabilitato.
            // =============================================================

            DataGridViewButtonColumn manualColumn =
                new DataGridViewButtonColumn();

            manualColumn.Name =
                "SelectManual";

            manualColumn.HeaderText =
                "";

            manualColumn.Text =
                "Scegli IDW";

            manualColumn.UseColumnTextForButtonValue =
                true;

            manualColumn.Width =
                120;

            manualColumn.FlatStyle =
                FlatStyle.Flat;

            manualColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            manualColumn.Visible =
                false;


            // APRI IDW

            DataGridViewButtonColumn openColumn =
                new DataGridViewButtonColumn();

            openColumn.Name =
                "Open";

            openColumn.HeaderText =
                "";

            openColumn.Text =
                "Apri IDW";

            openColumn.UseColumnTextForButtonValue =
                true;

            openColumn.Width =
                110;

            openColumn.FlatStyle =
                FlatStyle.Flat;

            openColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;


            // =============================================================
            // APRI IPT / IAM
            // =============================================================

            DataGridViewButtonColumn openModelColumn =
                new DataGridViewButtonColumn();

            openModelColumn.Name =
                "OpenModel";

            openModelColumn.HeaderText =
                "";

            openModelColumn.Text =
                "Apri Ipt/Iam";

            openModelColumn.UseColumnTextForButtonValue =
                true;

            openModelColumn.Width =
                125;

            openModelColumn.FlatStyle =
                FlatStyle.Flat;

            openModelColumn.SortMode =
                DataGridViewColumnSortMode.NotSortable;

            openModelColumn.Visible =
                true;


            // Percorso IDW nascosto.

            DataGridViewTextBoxColumn pathColumn =
                new DataGridViewTextBoxColumn();

            pathColumn.Name =
                "DrawingPath";

            pathColumn.Visible =
                false;


            drawingsGrid.Columns.Add(
                statusColumn);

            drawingsGrid.Columns.Add(
                codeColumn);

            drawingsGrid.Columns.Add(
                drawingColumn);

            drawingsGrid.Columns.Add(
                resultColumn);

            drawingsGrid.Columns.Add(
                manualColumn);

            drawingsGrid.Columns.Add(
                openColumn);

            drawingsGrid.Columns.Add(
                openModelColumn);

            drawingsGrid.Columns.Add(
                pathColumn);
        }


        // =============================================================
        // CARICAMENTO DOCUMENTO / STRUTTURA
        // =============================================================

private async void ControlloTavoleDashboardForm_Shown(
    object? sender,
    EventArgs e)
{
    CaptureOriginalDocument();

    RefreshDetectedDocument();


    if (_isLoadingDrawings)
        return;


    _isLoadingDrawings =
        true;


    try
    {
                ControlloTavoleLoadResult loadResult =
                    await ControlloTavoleLoadService.LoadAsync(
                        _inventorApp);


                /*
                 * Durante la ricerca server l'utente potrebbe
                 * aver chiuso Controllo Tavole.
                 *
                 * In quel caso NON dobbiamo più toccare il Form.
                 */
                if (IsDisposed ||
                    Disposing)
                {
                    return;
                }


                ApplyLoadResult(
                    loadResult);
            }
            catch (Exception exception)
            {
                if (IsDisposed ||
                    Disposing)
                {
                    return;
                }

                MessageBox.Show(
                    this,
                    "Errore durante la ricerca delle tavole:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
         {
        _isLoadingDrawings =
            false;
        }
}

        // =============================================================
        // MEMORIZZAZIONE DOCUMENTO ORIGINALE
        // =============================================================

        private void CaptureOriginalDocument()
        {
            Inventor.Document? document =
                InventorService.GetActiveDocument(_inventorApp);

            if (document == null)
                return;

            string fullPath =
                InventorService.GetDocumentFullFileName(document);

            if (string.IsNullOrWhiteSpace(fullPath))
                return;

            string extension =
                Path.GetExtension(fullPath);

            if (!string.Equals(
                    extension,
                    ".iam",
                    StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(
                    extension,
                    ".ipt",
                    StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            _originalDocumentPath = fullPath;
        }

        private void RefreshDetectedDocument()
        {
            Inventor.Document? document =
                InventorService.GetActiveDocument(
                    _inventorApp);

            if (document == null)
            {
                if (lblAssemblyName != null)
                {
                    lblAssemblyName.Text =
                        "Nessun documento aperto a schermo";
                }

                if (lblAssemblyPath != null)
                {
                    lblAssemblyPath.Text =
                        "Per utilizzare questa funzione apri un documento in Inventor";
                }

                if (btnStartCheck != null)
                {
                    btnStartCheck.Enabled =
                        false;
                }

                return;
            }

            // =========================================================
            // LETTURA DATI DOCUMENTO TRAMITE CORE
            // =========================================================

            string fullPath =
                InventorService.GetDocumentFullFileName(
                    document);

            string fileName =
                string.IsNullOrWhiteSpace(fullPath)
                    ? InventorService.GetDocumentDisplayName(
                        document)
                    : Path.GetFileName(fullPath);

            // =========================================================
            // AGGIORNAMENTO INTERFACCIA
            // =========================================================

            if (lblAssemblyName != null)
            {
                lblAssemblyName.Text =
                    fileName;
            }

            if (lblAssemblyPath != null)
            {
                lblAssemblyPath.Text =
                    fullPath;
            }

            if (btnStartCheck != null)
            {
                btnStartCheck.Enabled =
                    true;
            }
        }


        private void ApplyLoadResult(
            ControlloTavoleLoadResult loadResult)
        {
            if (drawingsGrid == null)
                return;


            // Solo ORA sostituiamo il contenuto precedente.
            drawingsGrid.SuspendLayout();

            try
            {
                drawingsGrid.Rows.Clear();


                foreach (ControlloTavoleItem item
                         in loadResult.Items)
                {
                    loadResult.Drawings.TryGetValue(
                        item.Code,
                        out ControlloTavoleDrawingResult? drawingResult);


                    bool drawingExists =
                        drawingResult != null &&
                        drawingResult.Found &&
                        !string.IsNullOrWhiteSpace(
                            drawingResult.DrawingPath);


                    string drawingPath =
                        drawingResult?.DrawingPath ?? "";



                    int rowIndex =
                        drawingsGrid.Rows.Add(
                            "●",
                            item.Code,
                            drawingExists ? "✓" : "✕",
                            "Da controllare",
                            "",
                            "Apri IDW",
                            "Apri IPT/IAM",
                            drawingPath);



                    DataGridViewRow row =
                        drawingsGrid.Rows[rowIndex];

                    row.Cells["DrawingPath"].Value =
                     drawingPath;

                    row.Cells["Open"].Value =
                        "Apri IDW";


                    row.Tag =
                        new DrawingRowData
                        {
                            Item = item,
                            DrawingResult =
                                drawingResult
                        };


                    SetRowPending(
                        row);


                    ApplyDrawingPresenceColor(
                        row,
                        drawingExists);
                }
            }
            finally
            {
                drawingsGrid.ResumeLayout();
            }
            UpdateManualDrawingColumnVisibility();
        }

        private void ApplyDrawingPresenceColor(
    DataGridViewRow row,
    bool drawingExists)
        {
            DataGridViewCell drawingCell =
                row.Cells["Drawing"];


            Color color =
                drawingExists
                    ? Color.FromArgb(
                        34,
                        197,
                        94)
                    : Color.FromArgb(
                        239,
                        68,
                        68);


            drawingCell.Style.ForeColor =
                color;

            drawingCell.Style.SelectionForeColor =
                color;
        }

        private void UpdateManualDrawingColumnVisibility()
        {
            if (drawingsGrid == null)
                return;


            DataGridViewColumn? manualColumn =
                drawingsGrid.Columns["SelectManual"];

            if (manualColumn == null)
                return;


            bool showColumn =
                false;


            foreach (DataGridViewRow row
                     in drawingsGrid.Rows)
            {
                bool canSelectManually =
                    CanSelectDrawingManually(
                        row);


                DataGridViewCell cell =
                    row.Cells["SelectManual"];


                if (canSelectManually)
                {
                    cell.Value =
                        "Scegli IDW";

                    showColumn =
                        true;
                }
                else
                {
                    /*
                     * La colonna DataGridView non permette di nascondere
                     * una singola cella.
                     *
                     * Per le righe non interessate lasciamo quindi la cella
                     * senza testo e la rendiamo non utilizzabile logicamente.
                     */
                    cell.Value =
                        "";
                }
            }


            manualColumn.Visible =
                showColumn;
        }


        private static bool CanSelectDrawingManually(
            DataGridViewRow row)
        {
            if (row.Tag is not DrawingRowData rowData)
                return false;


            ControlloTavoleDrawingResult? result =
                rowData.DrawingResult;


            if (result == null)
                return false;


            /*
             * Se una tavola è stata trovata, automaticamente
             * oppure manualmente, non serve più il pulsante.
             */
            if (result.Found)
                return false;


            /*
             * REGOLA DEFINITIVA:
             *
             * fallback TRUE  -> MAI selezione manuale
             * fallback FALSE -> selezione manuale consentita
             */
            if (result.FallbackEnabled)
                return false;


            /*
             * Deve esistere un nome IDW atteso.
             *
             * Questo evita di offrire la selezione manuale a codici
             * per i quali non è stata trovata alcuna regola valida.
             */
            if (string.IsNullOrWhiteSpace(
                    result.ExpectedFileName))
            {
                return false;
            }


            return true;
        }

        private sealed class DrawingRowData
        {
            public ControlloTavoleItem Item { get; set; } =
                new ControlloTavoleItem();

            public ControlloTavoleDrawingResult? DrawingResult
            { get; set; }
        }


        // =============================================================
        // AVVIO CONTROLLO
        // =============================================================

        private async void BtnReadCurrentAssembly_Click(
            object? sender,
            EventArgs e)
        {
            if (_isLoadingDrawings)
                return;


            _isLoadingDrawings =
                true;


            if (btnReadCurrentAssembly != null)
                btnReadCurrentAssembly.Enabled = false;


            try
            {
                /*
                 * Aggiorniamo subito le informazioni del documento,
                 * ma NON tocchiamo ancora la vecchia griglia.
                 */
                CaptureOriginalDocument();

                RefreshDetectedDocument();

                ControlloTavoleLoadResult loadResult =
                    await ControlloTavoleLoadService.LoadAsync(
                        _inventorApp);


                if (IsDisposed ||
                    Disposing)
                {
                    return;
                }


                ApplyLoadResult(
                    loadResult);


                // I risultati del vecchio controllo non sono più validi.

                if (progressCard != null)
                {
                    progressCard.Visible =
                        false;
                }


                SetProgress(
                    0,
                    "Preparazione controllo...");


                ResetDrawingsCardPosition();
            }
            catch (Exception exception)
            {
                if (IsDisposed ||
                 Disposing)
                {
                    return;
                }

                MessageBox.Show(
                    this,
                    "Errore durante la lettura del documento:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                _isLoadingDrawings =
                    false;


                if (!IsDisposed &&
                    !Disposing)
                {
                    if (btnReadCurrentAssembly != null)
                        btnReadCurrentAssembly.Enabled = true;
                }
            }
        }

        private async void BtnStartCheck_Click(
            object? sender,
            EventArgs e)
        {
            if (_isScanningDrawings)
                return;

            if (drawingsGrid == null)
                return;


            RefreshDetectedDocument();


            Inventor.Document? document =
                InventorService.GetActiveDocument(
                    _inventorApp);


            if (document == null)
            {
                MessageBox.Show(
                    this,
                    "Per utilizzare questa funzione apri un documento in Inventor.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            /*
             * Costruiamo prima l'elenco delle sole righe
             * che hanno realmente una tavola da controllare.
             */
            List<DataGridViewRow> rowsToScan =
                new List<DataGridViewRow>();


            foreach (DataGridViewRow row
                     in drawingsGrid.Rows)
            {
                string drawingPath =
                    Convert.ToString(
                        row.Cells["DrawingPath"].Value) ?? "";


                if (!string.IsNullOrWhiteSpace(
                        drawingPath))
                {
                    rowsToScan.Add(
                        row);
                }
            }


            if (rowsToScan.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Non ci sono tavole IDW disponibili da controllare.",
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }


            _isScanningDrawings =
                true;


            if (btnStartCheck != null)
                btnStartCheck.Enabled = false;

            if (btnReadCurrentAssembly != null)
                btnReadCurrentAssembly.Enabled = false;

            if (btnSettings != null)
                btnSettings.Enabled = false;


            try
            {
                ShowProgressSection();

                SetProgress(
                    0,
                    "Preparazione controllo...");


                int total =
                    rowsToScan.Count;

                int completed =
                    0;

                ControlloTavoleSettings scanSettings =
                 ControlloTavoleSettingsService.Load();


                foreach (DataGridViewRow row
                         in rowsToScan)
                {
                    string code =
                        Convert.ToString(
                            row.Cells["Code"].Value) ?? "";

                    string drawingPath =
                        Convert.ToString(
                            row.Cells["DrawingPath"].Value) ?? "";


                    int startPercentage =
                        (int)Math.Round(
                            completed * 100.0 / total);


                    SetProgress(
                        startPercentage,
                        "Controllo " + code + "...");


                    /*
                     * Permettiamo a WinForms di ridisegnare
                     * progress bar e testo prima di entrare
                     * nella scansione Inventor.
                     */
                    await Task.Yield();

                    if (IsDisposed ||
                        Disposing)
                    {
                        return;
                    }


                    ControlloTavoleScanResult scanResult =
                        ControlloTavoleDrawingScannerService.Scan(
                            _inventorApp,
                            drawingPath,
                            scanSettings);


                    ApplyScanResult(
                        row,
                        scanResult,
                        scanSettings);


                    completed++;


                    int percentage =
                        (int)Math.Round(
                            completed * 100.0 / total);


                    SetProgress(
                        percentage,
                        "Controllate " +
                        completed +
                        " di " +
                        total +
                        " tavole");


                    await Task.Yield();

                    if (IsDisposed ||
                         Disposing)
                    {
                        return;
                    }
                }


                SetProgress(
                    100,
                    "Controllo completato");


                SortRowsAfterScan();
            }
            catch (Exception exception)
            {
                if (IsDisposed ||
                     Disposing)
                {
                    return;
                }
                MessageBox.Show(
                    this,
                    "Errore durante il controllo delle tavole:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                _isScanningDrawings =
                    false;


                if (!IsDisposed &&
                    !Disposing)
                {
                    if (btnStartCheck != null)
                        btnStartCheck.Enabled = true;

                    if (btnReadCurrentAssembly != null)
                        btnReadCurrentAssembly.Enabled = true;

                    if (btnSettings != null)
                        btnSettings.Enabled = true;
                }
            }
        }

        // =============================================================
        // CALCOLO GRAVITÀ COMPLESSIVA DELLA TAVOLA
        // =============================================================

        private static ControlloTavoleSeverity? GetScanSeverity(
            ControlloTavoleScanResult result,
            ControlloTavoleSettings settings)
        {
            bool hasRed = false;
            bool hasOrange = false;

            void CheckSeverity(
                int problemCount,
                ControlloTavoleSeverity severity)
            {
                if (problemCount <= 0)
                    return;

                if (severity == ControlloTavoleSeverity.Red)
                {
                    hasRed = true;
                }
                else
                {
                    hasOrange = true;
                }
            }

            if (settings.CheckDetachedDimensions)
            {
                CheckSeverity(
                    result.DetachedDimensions,
                    settings.DetachedDimensionsSeverity);
            }

            if (settings.CheckDetachedBalloons)
            {
                CheckSeverity(
                    result.DetachedBalloons,
                    settings.DetachedBalloonsSeverity);
            }

            if (settings.CheckUnresolvedModelViews)
            {
                CheckSeverity(
                    result.UnresolvedModelViews,
                    settings.UnresolvedModelViewsSeverity);
            }

            if (settings.CheckViewsNotUpdated)
            {
                CheckSeverity(
                    result.ViewsNotUpdated,
                    settings.ViewsNotUpdatedSeverity);
            }

            if (settings.CheckSheetsWithoutViews)
            {
                CheckSeverity(
                    result.SheetsWithoutViews,
                    settings.SheetsWithoutViewsSeverity);
            }

            if (settings.CheckOverlappingViews)
            {
                CheckSeverity(
                    result.OverlappingViews,
                    settings.OverlappingViewsSeverity);
            }

            if (settings.CheckViewsOutsideSheet)
            {
                CheckSeverity(
                    result.ViewsOutsideSheet,
                    settings.ViewsOutsideSheetSeverity);
            }

            if (settings.CheckDetachedGeometries)
            {
                CheckSeverity(
                    result.DetachedGeometries,
                    settings.DetachedGeometriesSeverity);
            }

            // =============================================================
            // NONO CONTROLLO - VISTE RASTER
            // =============================================================

            if (settings.CheckRasterViews)
            {
                CheckSeverity(
                    result.RasterViews,
                    settings.RasterViewsSeverity);
            }

            if (hasRed)
                return ControlloTavoleSeverity.Red;

            if (hasOrange)
                return ControlloTavoleSeverity.Orange;

            return null;
        }

        // =============================================================
        // APPLICAZIONE RISULTATO CONTROLLO
        // =============================================================

        private void ApplyScanResult(
            DataGridViewRow row,
            ControlloTavoleScanResult result,
            ControlloTavoleSettings settings)
        {
            // =========================================================
            // ERRORE DURANTE LA SCANSIONE
            // =========================================================

            if (!result.Success)
            {
                string errorMessage =
                    string.IsNullOrWhiteSpace(result.ErrorMessage)
                        ? "Errore durante il controllo"
                        : "Errore: " + result.ErrorMessage;

                SetRowError(
                    row,
                    errorMessage);

                return;
            }


            // =========================================================
            // CALCOLO GRAVITÀ
            // =========================================================

            ControlloTavoleSeverity? severity =
                GetScanSeverity(
                    result,
                    settings);

            // =========================================================
            // DESCRIZIONE PROBLEMI
            // =========================================================

            string message =
                result.Problems.Count > 0
                    ? string.Join(
                        " - ",
                        result.Problems)
                    : result.TotalProblems +
                      " problemi rilevati";

            // =========================================================
            // ROSSO
            // =========================================================

            if (severity == ControlloTavoleSeverity.Red)
            {
                SetRowError(
                    row,
                    message);

                return;
            }

            // =========================================================
            // ARANCIONE
            // =========================================================

            if (severity == ControlloTavoleSeverity.Orange)
            {
                SetRowWarning(
                    row,
                    message);

                return;
            }

            // =========================================================
            // VERDE
            // =========================================================

            SetRowSuccess(
                row);
        }

        private void SortRowsAfterScan()
        {
            if (drawingsGrid == null)
                return;


            List<DataGridViewRow> rows =
                drawingsGrid.Rows
                    .Cast<DataGridViewRow>()
                    .ToList();


            rows =
                rows
                    .OrderBy(
                        GetRowStatusOrder)
                    .ThenBy(
                        GetCodeTypeOrder)
                    .ThenBy(
                        row =>
                            Convert.ToString(
                                row.Cells["Code"].Value) ?? "",
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();


            /*
             * Manteniamo gli stessi oggetti Row:
             * quindi Tag, DrawingResult, percorso IDW
             * e associazioni manuali rimangono intatti.
             */
            drawingsGrid.SuspendLayout();

            try
            {
                drawingsGrid.Rows.Clear();

                foreach (DataGridViewRow row
                         in rows)
                {
                    drawingsGrid.Rows.Add(
                        row);
                }
            }
            finally
            {
                drawingsGrid.ResumeLayout();
            }


            UpdateManualDrawingColumnVisibility();
        }

        // =============================================================
        // ORDINAMENTO PER GRAVITÀ
        // =============================================================

        private static int GetRowStatusOrder(
            DataGridViewRow row)
        {
            string status =
                Convert.ToString(
                    row.Cells["Status"].Value) ?? "";

            // ROSSO
            if (status == "✕")
                return 0;

            // ARANCIONE
            if (status == "!")
                return 1;

            // VERDE
            if (status == "✓")
                return 2;

            // NON CONTROLLATO
            if (status == "●")
                return 3;

            return 3;
        }


        private static int GetCodeTypeOrder(
            DataGridViewRow row)
        {
            string code =
                Convert.ToString(
                    row.Cells["Code"].Value) ?? "";


            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return 2;
            }


            char firstCharacter =
                code.Trim()[0];


            if (char.IsLetter(
                    firstCharacter))
            {
                return 0;
            }


            if (char.IsDigit(
                    firstCharacter))
            {
                return 1;
            }


            return 2;
        }



        private void ShowProgressSection()
        {
            if (progressCard == null)
                return;

            progressCard.Visible =
                true;

            if (progressCard.Tag is not Panel drawingsCard)
                return;

            drawingsCard.Top =
                progressCard.Bottom + 15;

            if (drawingsCard.Parent != null)
            {
                drawingsCard.Height =
                    drawingsCard.Parent.ClientSize.Height -
                    drawingsCard.Top;
            }
        }

        private void SetProgress(
            int percentage,
            string message)
        {
            percentage =
                Math.Max(
                    0,
                    Math.Min(
                        100,
                        percentage));

            if (progressBar != null)
            {
                progressBar.Value =
                    percentage;
            }

            if (lblProgressPercentage != null)
            {
                lblProgressPercentage.Text =
                    percentage + "%";
            }

            if (lblProgress != null)
            {
                lblProgress.Text =
                    message;
            }
        }


        // =============================================================
        // COLORAZIONE RIGHE
        // Questi metodi saranno richiamati dallo scanner.
        // =============================================================

        private void SetRowPending(
            DataGridViewRow row)
        {
            Color background =
                _isDarkTheme
                    ? Color.FromArgb(
                        43,
                        46,
                        55)
                    : Color.FromArgb(
                        248,
                        250,
                        252);

            ApplyRowColor(
                row,
                background,
                _titleColor);

            row.Cells["Status"].Value =
                "●";

            row.Cells["Result"].Value =
                "Da controllare";
        }

        private void SetRowSuccess(
            DataGridViewRow row)
        {
            Color background =
                _isDarkTheme
                    ? Color.FromArgb(
                        24,
                        74,
                        48)
                    : Color.FromArgb(
                        220,
                        252,
                        231);

            Color foreground =
                _isDarkTheme
                    ? Color.FromArgb(
                        220,
                        252,
                        231)
                    : Color.FromArgb(
                        20,
                        83,
                        45);

            ApplyRowColor(
                row,
                background,
                foreground);

            row.Cells["Status"].Value =
                "✓";

            row.Cells["Result"].Value =
                "Nessun problema";
        }

        // =============================================================
        // RIGA ARANCIONE - PROBLEMI NON GRAVI
        // =============================================================

        private void SetRowWarning(
            DataGridViewRow row,
            string result)
        {
            Color background =
                _isDarkTheme
                    ? Color.FromArgb(
                        100,
                        60,
                        20)
                    : Color.FromArgb(
                        255,
                        237,
                        213);

            Color foreground =
                _isDarkTheme
                    ? Color.FromArgb(
                        255,
                        237,
                        213)
                    : Color.FromArgb(
                        154,
                        52,
                        18);

            ApplyRowColor(
                row,
                background,
                foreground);

            row.Cells["Status"].Value =
                "!";

            row.Cells["Result"].Value =
                result;
        }

        private void SetRowError(
            DataGridViewRow row,
            string result)
        {
            Color background =
                _isDarkTheme
                    ? Color.FromArgb(
                        92,
                        35,
                        35)
                    : Color.FromArgb(
                        254,
                        226,
                        226);

            Color foreground =
                _isDarkTheme
                    ? Color.FromArgb(
                        254,
                        226,
                        226)
                    : Color.FromArgb(
                        153,
                        27,
                        27);

            ApplyRowColor(
                row,
                background,
                foreground);

            row.Cells["Status"].Value =
                "✕";

            row.Cells["Result"].Value =
                result;
        }

        private static void ApplyRowColor(
            DataGridViewRow row,
            Color background,
            Color foreground)
        {
            row.DefaultCellStyle.BackColor =
                background;

            row.DefaultCellStyle.ForeColor =
                foreground;

            row.DefaultCellStyle.SelectionBackColor =
                background;

            row.DefaultCellStyle.SelectionForeColor =
                foreground;
        }

        private void SelectDrawingManually(
    DataGridViewRow row,
    DrawingRowData rowData)
        {
            ControlloTavoleDrawingResult? result =
                rowData.DrawingResult;


            if (result == null)
                return;


            if (result.FallbackEnabled)
                return;


            if (result.Found)
                return;


            if (string.IsNullOrWhiteSpace(
                    result.ExpectedFileName))
            {
                return;
            }


            using OpenFileDialog dialog =
                new OpenFileDialog
                {
                    Title =
                        "Seleziona la tavola IDW",

                    Filter =
                        "Tavole Autodesk Inventor (*.idw)|*.idw",

                    CheckFileExists =
                        true,

                    CheckPathExists =
                        true,

                    Multiselect =
                        false,

                    FileName =
                        result.ExpectedFileName
                };


            if (dialog.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }


            string selectedPath =
                dialog.FileName;


            string selectedFileName =
                Path.GetFileName(
                    selectedPath);


            bool expectedName =
                string.Equals(
                    selectedFileName,
                    result.ExpectedFileName,
                    StringComparison.OrdinalIgnoreCase);


            // =============================================================
            // NOME DIFFERENTE DA QUELLO PREVISTO
            // =============================================================

            if (!expectedName)
            {
                DialogResult answer =
                    MessageBox.Show(
                        this,

                        "La tavola selezionata non corrisponde " +
                        "al codice atteso." +
                        Environment.NewLine +
                        Environment.NewLine +

                        "Tavola prevista:" +
                        Environment.NewLine +
                        result.ExpectedFileName +
                        Environment.NewLine +
                        Environment.NewLine +

                        "Tavola selezionata:" +
                        Environment.NewLine +
                        selectedFileName +
                        Environment.NewLine +
                        Environment.NewLine +

                        "Associare comunque?" +
                        Environment.NewLine +
                        Environment.NewLine +

                        "Attenzione: utilizzare una tavola diversa " +
                        "da quella prevista potrebbe compromettere " +
                        "il risultato della funzione.",

                        "Controllo Tavole",

                        MessageBoxButtons.YesNo,

                        MessageBoxIcon.Warning);


                if (answer !=
                    DialogResult.Yes)
                {
                    return;
                }
            }


            // =============================================================
            // ASSOCIAZIONE SOLO PER LA SESSIONE CORRENTE
            // =============================================================

            result.DrawingPath =
                selectedPath;

            result.Found =
                true;

            /*
             * Non è stata trovata dal fallback.
             * È un'associazione manuale.
             */
            result.FoundByFallback =
                false;


            row.Cells["DrawingPath"].Value =
                selectedPath;


            row.Cells["Drawing"].Value =
                "✓";


            ApplyDrawingPresenceColor(
                row,
                true);


            /*
             * La riga non necessita più del pulsante.
             */
            row.Cells["SelectManual"].Value =
                "";


            /*
             * Se questa era l'ultima tavola mancante
             * selezionabile manualmente, sparisce
             * automaticamente l'intera colonna.
             */
            UpdateManualDrawingColumnVisibility();
        }


        // =============================================================
        // APERTURA IDW
        // =============================================================

        private void DrawingsGrid_CellClick(
            object? sender,
            DataGridViewCellEventArgs e)
        {
            if (drawingsGrid == null)
                return;

            if (e.RowIndex < 0 ||
                e.ColumnIndex < 0)
            {
                return;
            }


            DataGridViewColumn clickedColumn =
                drawingsGrid.Columns[e.ColumnIndex];

            DataGridViewRow row =
                drawingsGrid.Rows[e.RowIndex];


            if (row.Tag is not DrawingRowData rowData)
                return;


            /*
             * SCELTA MANUALE IDW
             */
            if (clickedColumn.Name == "SelectManual")
            {
                if (!CanSelectDrawingManually(row))
                    return;


                SelectDrawingManually(
                    row,
                    rowData);

                return;
            }


            // =============================================================
            // APRI MODELLO 3D IPT / IAM
            // =============================================================

            if (clickedColumn.Name == "OpenModel")
            {
                OpenSourceModel(rowData.Item);
                return;
            }


            /*
             * APRI IDW
             */
            if (clickedColumn.Name != "Open")
                return;


            ControlloTavoleItem item =
                rowData.Item;


            try
            {
                string drawingPath =
                    Convert.ToString(
                        row.Cells["DrawingPath"].Value) ?? ""; 


                if (string.IsNullOrWhiteSpace(drawingPath))
                {
                    MessageBox.Show(
                        this,
                        "Nessuna tavola IDW trovata per:" +
                        Environment.NewLine +
                        Environment.NewLine +
                        item.Code,
                        "Controllo Tavole",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return;
                }


                bool opened =
                    InventorService.TryOpenDrawingFromOriginalContext(
                        _inventorApp,
                        _originalDocumentPath,
                        rowData.Item.Code,
                        out string errorMessage);

                if (!opened)
                {
                    MessageBox.Show(
                        errorMessage,
                        "Controllo Tavole",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }


                if (!opened)
                {
                    MessageBox.Show(
                        this,
                        "Impossibile aprire la tavola:" +
                        Environment.NewLine +
                        Environment.NewLine +
                        drawingPath,
                        "Controllo Tavole",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    "Errore durante l'apertura della tavola:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }


        // =============================================================
        // APERTURA MODELLO 3D ORIGINALE IPT / IAM
        // =============================================================

        private void OpenSourceModel(ControlloTavoleItem item)
        {
            if (item == null)
                return;

            try
            {
                string modelPath =
                    item.SourceDocumentPath?.Trim() ?? "";

                if (string.IsNullOrWhiteSpace(modelPath))
                {
                    MessageBox.Show(
                        this,
                        "Percorso del modello 3D non disponibile per:" +
                        Environment.NewLine +
                        Environment.NewLine +
                        item.Code,
                        "Controllo Tavole",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                string extension =
                    Path.GetExtension(modelPath);

                bool isPart =
                    string.Equals(
                        extension,
                        ".ipt",
                        StringComparison.OrdinalIgnoreCase);

                bool isAssembly =
                    string.Equals(
                        extension,
                        ".iam",
                        StringComparison.OrdinalIgnoreCase);

                if (!isPart && !isAssembly)
                {
                    MessageBox.Show(
                        this,
                        "Il documento associato non è un IPT o IAM:" +
                        Environment.NewLine +
                        Environment.NewLine +
                        modelPath,
                        "Controllo Tavole",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                // Se il file è già aperto, lo attiviamo.
                foreach (Inventor.Document document
                         in _inventorApp.Documents)
                {
                    string openedPath =
                        InventorService.GetDocumentFullFileName(
                            document);

                    if (string.Equals(
                        openedPath,
                        modelPath,
                        StringComparison.OrdinalIgnoreCase))
                    {
                        document.Activate();
                        return;
                    }
                }

                // Apertura visibile del documento originale.
                Inventor.Document openedDocument =
                    _inventorApp.Documents.Open(
                        modelPath,
                        true);

                openedDocument.Activate();
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    "Impossibile aprire il modello 3D:" +
                    Environment.NewLine +
                    Environment.NewLine +
                    item.Code +
                    Environment.NewLine +
                    Environment.NewLine +
                    exception.Message,
                    "Controllo Tavole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }



        // =============================================================
        // IMPOSTAZIONI
        // =============================================================

        private void BtnSettings_Click(
            object? sender,
            EventArgs e)
        {
            ControlloTavoleSettingsForm settingsForm =
                new ControlloTavoleSettingsForm(
                    _isDarkTheme);

            settingsForm.ShowDialog(
                this);
        }


        // =============================================================
        // HELPERS UI
        // =============================================================

        private Label CreateSectionTitle(
            string text)
        {
            Label label =
                new Label();

            label.Text =
                text;

            label.Font =
                new Font(
                    "Segoe UI",
                    14,
                    FontStyle.Bold);

            label.ForeColor =
                _titleColor;

            label.AutoSize =
                true;

            return label;
        }

        private static Button CreateButton(
            string text,
            Color color,
            int width,
            int height)
        {
            Button button =
                new Button();

            button.Text =
                text;

            button.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            button.Size =
                new Size(
                    width,
                    height);

            button.FlatStyle =
                FlatStyle.Flat;

            button.FlatAppearance.BorderSize =
                0;

            button.BackColor =
                color;

            button.ForeColor =
                Color.White;

            button.Cursor =
                Cursors.Hand;

            return button;
        }


        // =============================================================
        // CHIUSURA
        // =============================================================

        private void ControlloTavoleDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "ControlloTavoleDashboard");
        }

        private void ResetDrawingsCardPosition()
        {
            if (progressCard == null)
                return;

            if (progressCard.Tag is not Panel drawingsCard)
                return;

            drawingsCard.Top = 145;

            if (drawingsCard.Parent != null)
            {
                drawingsCard.Height =
                    drawingsCard.Parent.ClientSize.Height -
                    drawingsCard.Top;
            }
        }
    }
}