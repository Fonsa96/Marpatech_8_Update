﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Updater.Services
{
    public static class UpdateFileService
    {
        public static bool FileExists(string path)
        {
            return FileSystemCompatibilityService.FileExists(path);
        }
    }
}