﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Marpatech_8.Features.Updater.Services;

namespace Marpatech_8.Features.Updater
{
    public static class UpdateCommand
    {
        public static async Task ExecuteAsync()
        {
            UpdateSettings settings = new UpdateSettings();

            UpdateService service = new UpdateService(settings);

            UpdateInfo? updateInfo = await service.CheckForUpdateAsync();

            if (updateInfo == null)
            {
                UpdateDialogService.Info(
                    "Nessun aggiornamento disponibile.",
                    "Aggiorna versione");

                return;
            }

            bool downloaded = await service.DownloadUpdateAsync(updateInfo);

            if (!downloaded)
            {
                UpdateDialogService.Warning(
                    "Aggiornamento trovato, ma download non riuscito.",
                    "Aggiorna versione");

                return;
            }

            bool pending = service.MarkUpdateAsPending();

            if (!pending)
            {
                UpdateDialogService.Warning(
                    "Aggiornamento scaricato, ma non è stato possibile marcarlo come pendente.",
                    "Aggiorna versione");

                return;
            }

            TryStartUpdaterSilent(settings);

            UpdateDialogService.Info(
                "Aggiornamento scaricato correttamente.\n\n" +
                "Verrà installato automaticamente dopo la chiusura di Inventor.",
                "Aggiorna versione");
        }

        private static void TryStartUpdaterSilent(UpdateSettings settings)
        {
            try
            {
                string updaterExe = settings.LocalUpdaterFile;

                if (!UpdateFileService.FileExists(updaterExe))
                    return;

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = updaterExe;
                psi.Arguments = "--silent --wait-inventor-close";
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;

                Process.Start(psi);
            }
            catch
            {
                // Update silenzioso: non blocchiamo Inventor.
            }
        }
    }
}