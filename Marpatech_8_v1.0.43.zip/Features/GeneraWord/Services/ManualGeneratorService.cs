﻿using Inventor;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.Core.Temporary;
using Marpatech_8.Features.Core.Windows;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public class ManualGeneratorService
    {
        private readonly Inventor.Application _inventorApp;
        private readonly ManualSettings _settings;
        private readonly bool _isDarkTheme;
        private readonly WordPlaceholderSettings _placeholderSettings;

        ManualGenerationResult result =
    new ManualGenerationResult();

        public ManualGeneratorService(
            Inventor.Application inventorApp,
            ManualSettings settings,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _settings = settings;
            _isDarkTheme = isDarkTheme;
            _placeholderSettings = WordPlaceholderSettingsService.Load();
        }

        public async Task<ManualGenerationResult> GenerateAsync(
            ManualGenerationRequest request,
            IWin32Window? owner,
            IProgress<ManualGenerationProgress>? progress)
        {
            try
            {
                Inventor.Document? document =
                    InventorService.GetActiveDocument(_inventorApp);

                if (document == null)
                {
                    ManualDialogService.Warning(
                        "Nessun documento Inventor aperto.",
                        "Genera Word Manuali",
                        owner);

                    return result;
                }

                ValidateRequest(request);

                SaveEditedProperties(
                    document,
                    request.PropertyValues);

                ValidateRequiredProperties(
                    request.PropertyValues);

                string inventorImagePath =
                    await ManualImageService.PrepareAndSaveCurrentViewAsync(
                    _inventorApp,
                    _isDarkTheme,
                    owner);

                ManualFileService.EnsureDirectory(
                    _settings.OutputFolderPath);

                string generationFolder =
                    CreateGenerationFolder(request);

                result.GenerationFolder = generationFolder;

                CopySelectedLanguages(
                    request,
                    generationFolder);

                ApplyTelaFilter(
                   request,
                   generationFolder);

                AddMotorPropertiesToRequest(
                    document,
                    request);

                ManualWordService wordService = new ManualWordService();

                List<ManualGenerationError> errors =
                    await wordService.ProcessWordFilesAsync(
                        generationFolder,
                        request.PropertyValues,
                        inventorImagePath,
                        request.ExportPdf,
                        request.ExportOnlyDichiarazionePdf,
                        progress);

                result.Errors.AddRange(errors);

                return result;

            }

            catch (OperationCanceledException)
            {
                return new ManualGenerationResult();
            }

            catch (Exception ex)
            {
                ManualDialogService.Error(
                    ex.Message,
                    "Errore Genera Word Manuali",
                    owner);

                return new ManualGenerationResult();
            }
            finally
            {
                CleanupTemporaryFiles();
                try
                {
                    NativeWindowHelper.RemoveTopMost(
                        new IntPtr(_inventorApp.MainFrameHWND));
                }
                catch
                {
                }
            }
        }

        private void ValidateRequest(
            ManualGenerationRequest request)
        {
            if (string.IsNullOrWhiteSpace(_settings.BaseTemplatePath))
                throw new Exception("Percorso base template manuali non configurato.");

            if (string.IsNullOrWhiteSpace(_settings.OutputFolderPath))
                throw new Exception("Cartella output manuali non configurata.");

            if (string.IsNullOrWhiteSpace(request.PersonalizzazioneManuale))
                throw new Exception("Selezionare una Personalizzazione Manuale.");

            if (string.IsNullOrWhiteSpace(request.TipologiaManuale))
                throw new Exception("Selezionare una Tipologia Manuale.");

            if (request.Lingue.Count == 0)
                throw new Exception("Selezionare almeno una lingua.");

            string templatePath =
                IOPath.Combine(
                    _settings.BaseTemplatePath,
                    request.PersonalizzazioneManuale,
                    request.TipologiaManuale);

            if (!ManualFileService.DirectoryExists(templatePath))
            {
                throw new Exception(
                    "Percorso template manuale non trovato:\n\n" +
                    templatePath);
            }

            foreach (string lingua in request.Lingue)
            {
                string linguaPath =
                    IOPath.Combine(
                        templatePath,
                        lingua);

                if (!ManualFileService.DirectoryExists(linguaPath))
                {
                    throw new Exception(
                        "Cartella lingua non trovata:\n\n" +
                        linguaPath);
                }
            }
        }

        private void SaveEditedProperties(
            Inventor.Document document,
            Dictionary<string, string> propertyValues)
        {
            foreach (ManualPropertyConfig property in _settings.Properties)
            {
                if (!propertyValues.ContainsKey(property.Tag))
                    continue;

                InventorService.WriteIProperty(
                    document,
                    property.IPropertyName,
                    propertyValues[property.Tag]);
            }
        }

        private void ValidateRequiredProperties(
            Dictionary<string, string> propertyValues)
        {
            foreach (ManualPropertyConfig property in _settings.Properties)
            {
                if (!property.Required)
                    continue;

                if (!propertyValues.ContainsKey(property.Tag) ||
                    string.IsNullOrWhiteSpace(propertyValues[property.Tag]))
                {
                    throw new Exception(
                        "La proprietà obbligatoria è vuota:\n\n" +
                        property.Tag +
                        "\n\nProprietà Inventor: " +
                        property.IPropertyName);
                }
            }
        }

        private string CreateGenerationFolder(
            ManualGenerationRequest request)
        {
            string folderSource =
                _placeholderSettings.ManualFolderProperty;

            if (string.IsNullOrWhiteSpace(folderSource))
                throw new Exception("Proprietà Cartella Manuale non configurata.");

            string folderValue =
                ResolveSourceValue(
                    folderSource,
                    request.PropertyValues);

            if (string.IsNullOrWhiteSpace(folderValue))
                throw new Exception(
                    "Impossibile creare la cartella manuale.\n\n" +
                    "La proprietà scelta per la cartella è vuota:\n" +
                    folderSource);

            string folderName =
                "MANUALE " + CleanFolderName(folderValue);

            string baseFolder =
                IOPath.Combine(
                    _settings.OutputFolderPath,
                    folderName);

            string finalFolder =
                GetUniqueDestinationFolder(baseFolder);

            ManualFileService.EnsureDirectory(finalFolder);

            return finalFolder;
        }

        private void CopySelectedLanguages(
            ManualGenerationRequest request,
            string generationFolder)
        {
            string sourceBaseFolder =
                IOPath.Combine(
                    _settings.BaseTemplatePath,
                    request.PersonalizzazioneManuale,
                    request.TipologiaManuale);

            foreach (string language in request.Lingue)
            {
                string sourceLanguageFolder =
                    IOPath.Combine(
                        sourceBaseFolder,
                        language);

                string destinationLanguageFolder =
                    IOPath.Combine(
                        generationFolder,
                        language);

                CopyDirectory(
                    sourceLanguageFolder,
                    destinationLanguageFolder);
            }
        }

        private void CopyDirectory(
            string sourceDir,
            string destinationDir)
        {
            ManualFileService.EnsureDirectory(destinationDir);

            foreach (string file in ManualFileService.GetFiles(
                sourceDir,
                "*",
                SearchOption.TopDirectoryOnly))
            {
                string fileName =
                    IOPath.GetFileName(file);

                ManualFileService.CopyFileSafe(
                    file,
                    IOPath.Combine(destinationDir, fileName),
                    true);
            }

            foreach (string directory in ManualFileService.GetDirectories(
                sourceDir,
                "*",
                SearchOption.TopDirectoryOnly))
            {
                string dirName =
                    IOPath.GetFileName(directory);

                CopyDirectory(
                    directory,
                    IOPath.Combine(destinationDir, dirName));
            }
        }

        private string GetUniqueDestinationFolder(
            string destinationPath)
        {
            if (!ManualFileService.DirectoryExists(destinationPath))
                return destinationPath;

            string basePath = destinationPath;
            string newPath = basePath + " (Copia)";
            int index = 2;

            while (ManualFileService.DirectoryExists(newPath))
            {
                newPath = basePath + " (Copia " + index + ")";
                index++;
            }

            return newPath;
        }

        private string CleanFolderName(
            string folderName)
        {
            foreach (char invalidChar in IOPath.GetInvalidFileNameChars())
            {
                folderName = folderName.Replace(invalidChar.ToString(), "");
            }

            return folderName.Trim();
        }
        private void ApplyTelaFilter(
            ManualGenerationRequest request,
            string generationFolder)
        {
            if (request.IncludeCentraggioTela)
                return;

            if (!ManualFileService.DirectoryExists(generationFolder))
                return;

            foreach (string file in ManualFileService.GetFiles(
                generationFolder,
                "*",
                SearchOption.AllDirectories))
            {
                string fileName =
                    IOPath.GetFileName(file);

                if (fileName.Contains(
                    "Tela",
                    StringComparison.OrdinalIgnoreCase))
                {
                    try
                    {
                        ManualFileService.DeleteFileSafe(file);
                    }
                    catch
                    {
                    }
                }
            }
        }
        private string ResolveSourceValue(
                 string source,
              Dictionary<string, string> propertyValues)
        {
            if (string.IsNullOrWhiteSpace(source))
                return "";

            if (source == "SPAZIO VUOTO")
                return "";

            if (source == "DATA")
                return DateTime.Today.ToString("dd/MM/yyyy");

            if (source == "EDIZIONE")
                return DateTime.Today.ToString("MM/yyyy");

            if (source == "ANNO DI PRODUZIONE")
                return DateTime.Today.ToString("yyyy");

            if (propertyValues.ContainsKey(source))
                return propertyValues[source];

            return "";
        }
        private void AddMotorPropertiesToRequest(
    Inventor.Document document,
    ManualGenerationRequest request)
        {
            for (int i = 0; i <= 5; i++)
            {
                AddPropertyValueIfExists(
                    document,
                    request,
                    "Potenza Motore " + i);

                AddPropertyValueIfExists(
                    document,
                    request,
                    "IP " + i);

                AddPropertyValueIfExists(
                    document,
                    request,
                    "Tensione " + i);

                AddPropertyValueIfExists(
                    document,
                    request,
                    "Frequenza " + i);

                AddPropertyValueIfExists(
                    document,
                    request,
                    "Lub " + i);
            }
        }

        private void AddPropertyValueIfExists(
            Inventor.Document document,
            ManualGenerationRequest request,
            string propertyName)
        {
            string value =
                 InventorService.ReadIProperty(
                    document,
                    propertyName);

            request.PropertyValues[propertyName] =
                value ?? "";
        }
        private void CleanupTemporaryFiles()
        {
            TempFileService.ClearTempFolder(
                "GeneraWord");
        }
    }


    public class ManualGenerationRequest
    {
        public Dictionary<string, string> PropertyValues { get; set; } = new();

        public string PersonalizzazioneManuale { get; set; } = "";
        public string TipologiaManuale { get; set; } = "";
        public List<string> Lingue { get; set; } = new();

        public bool IncludeCentraggioTela { get; set; } = false;
        public bool ExportPdf { get; set; } = true;
        public bool ExportOnlyDichiarazionePdf { get; set; } = false;
    }

}