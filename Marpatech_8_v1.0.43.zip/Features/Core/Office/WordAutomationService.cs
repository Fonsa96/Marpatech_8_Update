﻿using System;
using Word = Microsoft.Office.Interop.Word;

namespace Marpatech_8.Features.Core.Office
{
    public static class WordAutomationService
    {
        public static Word.Application? CreateApplication(
            bool visible,
            bool displayAlerts)
        {
            try
            {
                Word.Application wordApp = new Word.Application();
                wordApp.Visible = visible;
                wordApp.DisplayAlerts = displayAlerts
                    ? Word.WdAlertLevel.wdAlertsAll
                    : Word.WdAlertLevel.wdAlertsNone;

                return wordApp;
            }
            catch
            {
                return null;
            }
        }

        public static Word.Document? OpenDocument(
            Word.Application wordApp,
            string filePath,
            bool readOnly = false)
        {
            try
            {
                return wordApp.Documents.Open(
                    FileName: filePath,
                    ReadOnly: readOnly,
                    AddToRecentFiles: false);
            }
            catch
            {
                return null;
            }
        }

        public static void ReplaceText(
            Word.Document document,
            string findText,
            string replaceText)
        {
            try
            {
                Word.Find find = document.Content.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = findText;
                find.Replacement.Text = replaceText ?? "";
                find.Forward = true;
                find.Wrap = Word.WdFindWrap.wdFindContinue;
                find.Format = false;
                find.MatchCase = false;
                find.MatchWholeWord = false;
                find.MatchWildcards = false;

                find.Execute(
                    Replace: Word.WdReplace.wdReplaceAll);
            }
            catch
            {
            }
        }

        public static bool PrintDocument(
            Word.Document document)
        {
            try
            {
                document.PrintOut(
                    Background: false);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void CloseDocument(
            Word.Document? document,
            bool saveChanges)
        {
            try
            {
                if (document == null)
                    return;

                object save =
                    saveChanges
                        ? Word.WdSaveOptions.wdSaveChanges
                        : Word.WdSaveOptions.wdDoNotSaveChanges;

                document.Close(
                    SaveChanges: ref save);
            }
            catch
            {
            }
        }

        public static void QuitApplication(
            Word.Application? wordApp)
        {
            try
            {
                if (wordApp == null)
                    return;

                wordApp.Quit(false);
            }
            catch
            {
            }
        }
    }
}