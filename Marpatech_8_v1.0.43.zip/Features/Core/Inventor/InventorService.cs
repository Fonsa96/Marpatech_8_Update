﻿using Inventor;
using Marpatech_8.Features.Mail;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
using InventorApp = Inventor.Application;

namespace Marpatech_8.Features.Core.Inventor
{
    public static class InventorService
    {
        public static Document? GetActiveDocument(
            InventorApp inventorApp)
        {
            try
            {
                if (inventorApp == null)
                    return null;

                return inventorApp.ActiveDocument;
            }
            catch
            {
                return null;
            }
        }

        public static AssemblyDocument? GetActiveAssembly(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as AssemblyDocument;
        }

        public static PartDocument? GetActivePart(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as PartDocument;
        }

        public static DrawingDocument? GetActiveDrawing(
            InventorApp inventorApp)
        {
            return GetActiveDocument(inventorApp) as DrawingDocument;
        }

        public static bool DocumentIsAssembly(Document? document)
        {
            return document is AssemblyDocument;
        }

        public static bool DocumentIsPart(Document? document)
        {
            return document is PartDocument;
        }

        public static bool DocumentIsDrawing(Document? document)
        {
            return document is DrawingDocument;
        }

        public static string GetDocumentTypeName(Document? document)
        {
            if (document == null)
                return "";

            if (DocumentIsAssembly(document))
                return "Assembly";

            if (DocumentIsPart(document))
                return "Part";

            if (DocumentIsDrawing(document))
                return "Drawing";

            return document.DocumentType.ToString();
        }

        public static string ReadProperty(
            Document? document,
            string propertyName)
        {
            return ReadIProperty(document, propertyName);
        }

        public static string ReadIProperty(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return "";

            if (string.IsNullOrWhiteSpace(propertyName))
                return "";

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return property.Value?.ToString() ?? "";
                        }
                    }
                }
            }
            catch
            {
            }

            return "";
        }

        public static bool PropertyExists(
            Document? document,
            string propertyName)
        {
            if (document == null)
                return false;

            if (string.IsNullOrWhiteSpace(propertyName))
                return false;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
            }
            catch
            {
            }

            return false;
        }

        public static void WriteProperty(
            Document? document,
            string propertyName,
            string value)
        {
            WriteIProperty(document, propertyName, value);
        }

        public static void WriteIProperty(
            Document? document,
            string propertyName,
            string value)
        {
            if (document == null)
                return;

            if (string.IsNullOrWhiteSpace(propertyName))
                return;

            try
            {
                foreach (PropertySet propertySet in document.PropertySets)
                {
                    foreach (Property property in propertySet)
                    {
                        if (string.Equals(
                            property.Name?.Trim(),
                            propertyName.Trim(),
                            StringComparison.OrdinalIgnoreCase))
                        {
                            property.Value = value ?? "";
                            return;
                        }
                    }
                }

                PropertySet userDefinedProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                userDefinedProperties.Add(
                    value ?? "",
                    propertyName);
            }
            catch
            {
            }
        }

        public static Dictionary<string, string> ReadConfiguredProperties(
            Document? document,
            IEnumerable<(string Tag, string IPropertyName)> properties)
        {
            Dictionary<string, string> values =
                new Dictionary<string, string>();

            if (document == null)
                return values;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                values[property.Tag] =
                    ReadIProperty(
                        document,
                        property.IPropertyName);
            }

            return values;
        }

        public static void WriteConfiguredProperties(
            Document? document,
            Dictionary<string, string> values,
            IEnumerable<(string Tag, string IPropertyName)> properties,
            bool skipEmptyValues = true)
        {
            if (document == null)
                return;

            foreach ((string Tag, string IPropertyName) property in properties)
            {
                if (string.IsNullOrWhiteSpace(property.Tag))
                    continue;

                if (string.IsNullOrWhiteSpace(property.IPropertyName))
                    continue;

                if (!values.ContainsKey(property.Tag))
                    continue;

                string value = values[property.Tag];

                if (skipEmptyValues &&
                    string.IsNullOrWhiteSpace(value))
                    continue;

                WriteIProperty(
                    document,
                    property.IPropertyName,
                    value);
            }
        }

        public static void SaveDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Save();
            }
            catch
            {
            }
        }

        public static void UpdateDocument(Document? document)
        {
            if (document == null)
                return;

            try
            {
                document.Update();
            }
            catch
            {
            }
        }

        public static InventorWindowWrapper GetInventorOwner(
            InventorApp inventorApp)
        {
            IntPtr inventorHandle =
                new IntPtr(inventorApp.MainFrameHWND);

            return new InventorWindowWrapper(inventorHandle);
        }
    }
}