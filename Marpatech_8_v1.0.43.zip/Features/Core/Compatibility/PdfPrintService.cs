﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class PdfPrintService
    {
        [DllImport("shell32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr ShellExecute(
            IntPtr hwnd,
            string lpOperation,
            string lpFile,
            string lpParameters,
            string lpDirectory,
            int nShowCmd);

        public static bool PrintPdf(
            string pdfPath)
        {
            if (string.IsNullOrWhiteSpace(pdfPath))
                return false;

            if (!FileSystemCompatibilityService.FileExists(pdfPath))
                return false;

            try
            {
                IntPtr result =
                    ShellExecute(
                        IntPtr.Zero,
                        "print",
                        pdfPath,
                        "",
                        "",
                        0);

                return result.ToInt64() > 32;
            }
            catch
            {
                return false;
            }
        }

        public static void CloseAcrobat()
        {
            KillProcessSafe("AcroRd32");
            KillProcessSafe("Acrobat");
        }

        private static void KillProcessSafe(
            string processName)
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName(processName))
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit(3000);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }
    }
}