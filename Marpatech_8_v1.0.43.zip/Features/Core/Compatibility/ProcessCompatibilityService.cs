﻿using System.Diagnostics;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class ProcessCompatibilityService
    {
        public static bool StartFile(string path)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = path,
                    UseShellExecute = true
                });

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool StartHiddenCommand(
            string fileName,
            string arguments)
        {
            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    CreateNoWindow = true,
                    UseShellExecute = false
                });

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void KillProcessSafe(string processName)
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName(processName))
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit(3000);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }
    }
}