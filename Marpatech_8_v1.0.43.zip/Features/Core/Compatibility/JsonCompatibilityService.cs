﻿using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class JsonCompatibilityService
    {
        private static readonly JsonSerializerOptions Options =
            new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNameCaseInsensitive = true
            };

        public static T? Deserialize<T>(string json)
        {
            return JsonSerializer.Deserialize<T>(
                json,
                Options);
        }

        public static string Serialize<T>(T value)
        {
            return JsonSerializer.Serialize(
                value,
                Options);
        }

        public static T? LoadFromFile<T>(string path)
        {
            if (!File.Exists(path))
                return default;

            string json = File.ReadAllText(path);

            return Deserialize<T>(json);
        }

        public static void SaveToFile<T>(
            string path,
            T value)
        {
            string? folder =
                Path.GetDirectoryName(path);

            if (!string.IsNullOrWhiteSpace(folder))
                Directory.CreateDirectory(folder);

            File.WriteAllText(
                path,
                Serialize(value));
        }
    }
}