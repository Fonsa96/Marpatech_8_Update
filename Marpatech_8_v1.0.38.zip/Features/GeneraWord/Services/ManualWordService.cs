﻿using Inventor;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using Marpatech_8.Features.GeneraWord.Translation.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using FormsApplication = System.Windows.Forms.Application;
using IOFile = System.IO.File;
using IOPath = System.IO.Path;
using Word = Microsoft.Office.Interop.Word;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public class ManualWordService
    {
        public async Task<List<ManualGenerationError>> ProcessWordFilesAsync(
                            string generationFolder,
            Dictionary<string, string> propertyValues,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf,
            IProgress<ManualGenerationProgress>? progress)
        {
            List<string> wordFiles = Directory
                .GetFiles(generationFolder, "*.*", SearchOption.AllDirectories)
                .Where(file =>
                    file.EndsWith(".doc", StringComparison.OrdinalIgnoreCase) ||
                    file.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                .Where(file => !IOPath.GetFileName(file).StartsWith("~$"))
                .ToList();

            List<ManualGenerationError> errors = new List<ManualGenerationError>();

            Word.Application? wordApp = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                wordApp.DisplayAlerts = Word.WdAlertLevel.wdAlertsNone;

                int current = 0;
                int total = wordFiles.Count;

                foreach (string wordFile in wordFiles)
                {
                    current++;

                    string currentWordFile = wordFile;

                    try
                    {
                        string languageCode =
                            GetLanguageCodeFromFile(
                                generationFolder,
                                wordFile);


                        currentWordFile =
                            RenameWordFileIfNeeded(
                                wordFile,
                                propertyValues);

                        progress?.Report(new ManualGenerationProgress
                        {
                            Current = current,
                            Total = total,
                            CurrentFile = languageCode + "\\" + IOPath.GetFileName(currentWordFile),
                            Percentage = total == 0 ? 100 : (int)((double)current / total * 100)
                        });

                        FormsApplication.DoEvents();

                        Dictionary<string, string> placeholderMap =
                            await BuildPlaceholderMapAsync(
                                propertyValues,
                                languageCode);

                        ProcessSingleDocument(
                            wordApp,
                            currentWordFile,
                            placeholderMap,
                            inventorImagePath,
                            exportPdf,
                            exportOnlyDichiarazionePdf);
                    }
                    catch (Exception ex)
                    {
                        errors.Add(new ManualGenerationError
                        {
                            FileName = IOPath.GetFileName(currentWordFile),
                            ErrorMessage = ex.ToString()
                        });
                    }
                }
            }
            finally
            {
                if (wordApp != null)
                {
                    wordApp.Quit(false);

                    Marshal.ReleaseComObject(wordApp);

                    wordApp = null;
                }
            }
            return errors;
        }
        private string RenameWordFileIfNeeded(
            string wordFile,
            Dictionary<string, string> propertyValues)
        {
            WordPlaceholderSettings settings =
                WordPlaceholderSettingsService.Load();

            string replacementValue =
                ResolveSourceValue(
                    settings.ManualFolderProperty,
                    propertyValues);

            if (string.IsNullOrWhiteSpace(replacementValue))
                return wordFile;

            string fileName = IOPath.GetFileName(wordFile);

            if (!fileName.Contains("NCOM", StringComparison.OrdinalIgnoreCase))
                return wordFile;

            string directory = IOPath.GetDirectoryName(wordFile) ?? "";

            string newFileName = fileName.Replace(
                "NCOM",
                replacementValue,
                StringComparison.OrdinalIgnoreCase);

            string newPath = IOPath.Combine(directory, newFileName);

            if (IOFile.Exists(newPath))
                IOFile.Delete(newPath);

            IOFile.Move(wordFile, newPath);

            return newPath;
        }
        private async Task<Dictionary<string, string>> BuildPlaceholderMapAsync(
            Dictionary<string, string> propertyValues,
            string languageCode)
        {
            WordPlaceholderSettings placeholderSettings =
                WordPlaceholderSettingsService.Load();

            TranslationService translationService =
                new TranslationService();

            Dictionary<string, string> map = new Dictionary<string, string>();

            foreach (WordPlaceholderConfig config in placeholderSettings.Placeholders)
            {
                if (string.IsNullOrWhiteSpace(config.Placeholder))
                    continue;

                string value =
                    ResolveSourceValue(
                        config.Source,
                        propertyValues);

                value =
                    await translationService.TranslateOrOriginalAsync(
                        value,
                        languageCode,
                        config.IncludeInTranslation);

                map[config.Placeholder] = value;
            }

            return map;
        }

         private string GetValue(
            Dictionary<string, string> values,
            string key)
           {
                 if (values.ContainsKey(key))
                     return values[key];

                     return "";
                }
        private void ProcessSingleDocument(
            Word.Application wordApp,
            string wordFile,
            Dictionary<string, string> placeholderMap,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf)
        {
            Word.Document? document = null;

            try
            {
                document = wordApp.Documents.Open(
                    wordFile,
                    ReadOnly: false,
                    Visible: false);

                ReplaceInRange(
                    document.Content,
                    placeholderMap);

                foreach (Word.Section section in document.Sections)
                {
                    foreach (Word.HeaderFooter footer in section.Footers)
                    {
                        ReplaceInRange(
                            footer.Range,
                            placeholderMap);
                    }
                }

                try
                {
                    InsertInventorImage(
                        wordApp,
                        document,
                        inventorImagePath);
                }
                catch
                {
                    // L'immagine non deve mai bloccare placeholder, salvataggio o PDF.
                }

                document.Save();

                ExportPdfIfNeeded(
                    document,
                    wordFile,
                    exportPdf,
                    exportOnlyDichiarazionePdf);
            }
            finally
            {
                if (document != null)
                {
                    document.Close(false);

                    Marshal.ReleaseComObject(document);

                    document = null;
                }
            }
        }
        private void ReplaceInRange(
              Word.Range range,
              Dictionary<string, string> placeholderMap)
             {
            foreach (KeyValuePair<string, string> item in placeholderMap)
            {
                Word.Find find = range.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = item.Key;
                find.Replacement.Text =
                    string.IsNullOrWhiteSpace(item.Value)
                        ? " "
                        : item.Value;

                object replaceAll =
                    Word.WdReplace.wdReplaceAll;

                find.Execute(
                    Replace: ref replaceAll);
            }
        }
        private void InsertInventorImage(
            Word.Application wordApp,
            Word.Document document,
            string inventorImagePath)
        {
            DebugImage("1) Entrato in InsertInventorImage");

            if (wordApp == null)
            {
                DebugImage("STOP: wordApp è null");
                return;
            }

            if (document == null)
            {
                DebugImage("STOP: document è null");
                return;
            }

            DebugImage("2) Percorso immagine ricevuto:\n" + inventorImagePath);

            if (string.IsNullOrWhiteSpace(inventorImagePath))
            {
                DebugImage("STOP: inventorImagePath vuoto");
                return;
            }

            if (!IOFile.Exists(inventorImagePath))
            {
                DebugImage("STOP: file immagine NON trovato:\n" + inventorImagePath);
                return;
            }

            FileInfo info = new FileInfo(inventorImagePath);

            DebugImage(
                "3) File immagine trovato.\n" +
                "Dimensione: " + info.Length + " byte");

            bool bookmarkExists = false;

            try
            {
                bookmarkExists =
                    document.Bookmarks.Exists("ImgInventor");
            }
            catch (Exception ex)
            {
                DebugImage("STOP: errore controllo bookmark:\n" + ex.Message);
                return;
            }

            DebugImage("4) Bookmark ImgInventor esiste: " + bookmarkExists);

            if (!bookmarkExists)
                return;

            try
            {
                document.Activate();
                DebugImage("5) Documento attivato");
            }
            catch (Exception ex)
            {
                DebugImage("STOP: document.Activate fallito:\n" + ex.Message);
                return;
            }

            try
            {
                object what = Word.WdGoToItem.wdGoToBookmark;
                object name = "ImgInventor";

                wordApp.Selection.GoTo(
                    What: ref what,
                    Name: ref name);

                DebugImage(
                    "6) GoTo ImgInventor eseguito.\n" +
                    "Selection Type: " + wordApp.Selection.Type.ToString() + "\n" +
                    "Selection Text: [" + wordApp.Selection.Text + "]");
            }
            catch (Exception ex)
            {
                DebugImage("STOP: GoTo bookmark fallito:\n" + ex.Message);
                return;
            }

            try
            {
                int shapeCount = 0;

                try
                {
                    shapeCount = wordApp.Selection.ShapeRange.Count;
                }
                catch
                {
                    shapeCount = -1;
                }

                int inlineCount = 0;

                try
                {
                    inlineCount = wordApp.Selection.InlineShapes.Count;
                }
                catch
                {
                    inlineCount = -1;
                }

                DebugImage(
                    "7) Oggetti nella selezione:\n" +
                    "ShapeRange.Count = " + shapeCount + "\n" +
                    "InlineShapes.Count = " + inlineCount);

                if (shapeCount > 0)
                {
                    DebugImage("8) Trovata Shape selezionata. Tento sostituzione Shape.");

                    Word.Shape oldShape =
                        wordApp.Selection.ShapeRange[1];

                    DebugImage(
                        "9) Shape vecchia:\n" +
                        "Width=" + oldShape.Width + "\n" +
                        "Height=" + oldShape.Height + "\n" +
                        "Left=" + oldShape.Left + "\n" +
                        "Top=" + oldShape.Top);

                    ReplaceSelectedShape(
                        document,
                        oldShape,
                        inventorImagePath);

                    DebugImage("10) ReplaceSelectedShape completato.");
                    return;
                }

                if (inlineCount > 0)
                {
                    DebugImage("8) Trovata InlineShape selezionata. Tento sostituzione Inline.");

                    Word.InlineShape oldInlineShape =
                        wordApp.Selection.InlineShapes[1];

                    DebugImage(
                        "9) Inline vecchia:\n" +
                        "Width=" + oldInlineShape.Width + "\n" +
                        "Height=" + oldInlineShape.Height);

                    ReplaceSelectedInlineShape(
                        wordApp,
                        oldInlineShape,
                        inventorImagePath);

                    DebugImage("10) ReplaceSelectedInlineShape completato.");
                    return;
                }

                DebugImage("STOP: GoTo trova il bookmark, ma non seleziona nessuna immagine.");
            }
            catch (Exception ex)
            {
                DebugImage(
                    "STOP: errore durante analisi/sostituzione immagine:\n" +
                    ex.ToString());
            }
        }

        private void DebugImage(string message)
        {
            MessageBox.Show(
                message,
                "DEBUG ImgInventor",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void ReplaceSelectedShape(
    Word.Document document,
    Word.Shape oldShape,
    string imagePath)
        {
            float width = oldShape.Width;
            float height = oldShape.Height;
            float left = oldShape.Left;
            float top = oldShape.Top;

            Word.WdWrapType wrapType = oldShape.WrapFormat.Type;
            Word.WdRelativeHorizontalPosition relativeHorizontal =
                oldShape.RelativeHorizontalPosition;
            Word.WdRelativeVerticalPosition relativeVertical =
                oldShape.RelativeVerticalPosition;

            Word.Range anchorRange =
                oldShape.Anchor.Duplicate;

            Word.Shape newShape =
                document.Shapes.AddPicture(
                    FileName: imagePath,
                    LinkToFile: false,
                    SaveWithDocument: true,
                    Left: left,
                    Top: top,
                    Width: width,
                    Height: height,
                    Anchor: anchorRange);

            newShape.WrapFormat.Type = wrapType;
            newShape.RelativeHorizontalPosition = relativeHorizontal;
            newShape.RelativeVerticalPosition = relativeVertical;

            oldShape.Delete();
        }

        private void ReplaceSelectedInlineShape(
            Word.Application wordApp,
            Word.InlineShape oldInlineShape,
            string imagePath)
        {
            if (wordApp == null || oldInlineShape == null)
                return;

            if (!IOFile.Exists(imagePath))
                return;

            float width = oldInlineShape.Width;
            float height = oldInlineShape.Height;

            oldInlineShape.Select();

            int start = wordApp.Selection.Start;

            wordApp.Selection.Delete();

            Word.Range insertRange =
                wordApp.ActiveDocument.Range(
                    Start: start,
                    End: start);

            Word.InlineShape newShape =
                insertRange.InlineShapes.AddPicture(
                    FileName: imagePath,
                    LinkToFile: false,
                    SaveWithDocument: true);

            if (newShape == null)
                return;

            newShape.Width = width;
            newShape.Height = height;
        }

        private void ExportPdfIfNeeded(
             Word.Document document,
             string wordFile,
              bool exportPdf,
              bool exportOnlyDichiarazionePdf)
        {
            if (!exportPdf && !exportOnlyDichiarazionePdf)
                return;

            string fileNameWithoutExtension =
                IOPath.GetFileNameWithoutExtension(wordFile);

            if (exportOnlyDichiarazionePdf && !exportPdf)
            {
                if (!fileNameWithoutExtension.StartsWith(
                    "DICHIARAZIONE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            string directory =
                IOPath.GetDirectoryName(wordFile) ?? "";

            string pdfPath =
                IOPath.Combine(
                    directory,
                    fileNameWithoutExtension + ".pdf");

            if (IOFile.Exists(pdfPath))
                return;

            document.ExportAsFixedFormat(
                pdfPath,
                Word.WdExportFormat.wdExportFormatPDF);
        }

            private string ResolveSourceValue(
            string source,
            Dictionary<string, string> propertyValues)
            {
                if (string.IsNullOrWhiteSpace(source))
                    return "";

                if (source == "SPAZIO VUOTO")
                    return "";

                if (source == "DATA")
                    return DateTime.Today.ToString("dd/MM/yyyy");

                if (source == "EDIZIONE")
                    return DateTime.Today.ToString("MM/yyyy");

                if (source == "ANNO DI PRODUZIONE")
                    return DateTime.Today.ToString("yyyy");

                if (propertyValues.ContainsKey(source))
                    return propertyValues[source];

                return "";
            }

        private string GetLanguageCodeFromFile(
              string generationFolder,
              string wordFile)
              {
            string relativePath =
                IOPath.GetRelativePath(
                    generationFolder,
                    wordFile);

            string[] parts =
                relativePath.Split(
                    IOPath.DirectorySeparatorChar,
                    IOPath.AltDirectorySeparatorChar);

            if (parts.Length == 0)
                return "IT";

            return parts[0].Trim().ToUpperInvariant();
        }

    }
}