﻿
using Marpatech_8.Features.Core.Settings;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;


namespace Marpatech_8.Features.GeneratoreVarianti.Forms
{
    public class GeneratoreVariantiForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly WindowSettings _windowSettings;

        private Color _backgroundColor;
        private Color _cardColor;
        private Color _titleColor;
        private Color _secondaryColor;
        private Color _inputColor;
        private Color _lineColor;

        private Label lblModel = null!;
        private Label lblModelPath = null!;
        private Label lblDrawing = null!;
        private Label lblCount = null!;
        private Label lblProgress = null!;
        private Label lblPercentage = null!;

        private DataGridView parametersGrid = null!;
        private ProgressBar progressBar = null!;
        private Button btnStart = null!;

        private Button btnRegistroVarianti = null!;
        private GeneratoreVariantiLogForm? _registroForm;
        private readonly BindingList<VarianteLogEntry>
    _registroEntries = new();

        private readonly BindingSource _registroSource =
            new BindingSource();

        private string _modelPath = "";
        private bool _loading;

        public GeneratoreVariantiForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "GeneratoreVarianti",
                1150,
                800);

            InitializeTheme();
            InitializeComponent();

            _registroSource.DataSource = _registroEntries;

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            Shown += (s, e) => LoadCurrentModel();

            FormClosing += (s, e) =>
                WindowSettingsService.Save(
                    this,
                    "GeneratoreVarianti");
        }

        private void InitializeTheme()
        {
            _backgroundColor = _isDarkTheme
                ? Color.FromArgb(18, 18, 22)
                : Color.FromArgb(245, 247, 250);

            _cardColor = _isDarkTheme
                ? Color.FromArgb(32, 34, 40)
                : Color.White;

            _titleColor = _isDarkTheme
                ? Color.White
                : Color.FromArgb(30, 41, 59);

            _secondaryColor = _isDarkTheme
                ? Color.FromArgb(170, 178, 190)
                : Color.FromArgb(100, 116, 139);

            _inputColor = _isDarkTheme
                ? Color.FromArgb(43, 46, 55)
                : Color.White;

            _lineColor = _isDarkTheme
                ? Color.FromArgb(70, 75, 85)
                : Color.FromArgb(203, 213, 225);
        }



        private void InitializeComponent()
        {
            Text = "Generatore Varianti Parametriche";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1150, 800);
            MinimumSize = new Size(950, 650);
            BackColor = _backgroundColor;

            Label title = new Label
            {
                Text = "Generatore Varianti Parametriche",
                Font = new Font(
                    "Segoe UI", 24, FontStyle.Bold),
                ForeColor = _titleColor,
                AutoSize = true,
                Location = new Point(35, 18)
            };

            Controls.Add(title);


            btnRegistroVarianti = CreateButton(
                "REGISTRO VARIANTI",
                Color.FromArgb(71, 85, 105));

            btnRegistroVarianti.Size = new Size(205, 42);

            btnRegistroVarianti.Location = new Point(
                ClientSize.Width - btnRegistroVarianti.Width - 35,
                22);

            btnRegistroVarianti.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            btnRegistroVarianti.Visible = false;
            btnRegistroVarianti.Enabled = false;

            btnRegistroVarianti.Click +=
                BtnRegistroVarianti_Click;

            Controls.Add(btnRegistroVarianti);
            btnRegistroVarianti.BringToFront();



            TableLayoutPanel layout = new TableLayoutPanel
            {
                Location = new Point(35, 90),
                Size = new Size(
                    ClientSize.Width - 70,
                    ClientSize.Height - 120),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Bottom |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = _backgroundColor
            };

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 175));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Absolute, 145));

            layout.RowStyles.Add(
                new RowStyle(SizeType.Percent, 100));


            Panel modelCard = CreateCard();
            Panel parametersCard = CreateCard();
            Panel executionCard = CreateCard();

            layout.Controls.Add(executionCard, 0, 0);
            layout.Controls.Add(modelCard, 0, 1);
            layout.Controls.Add(parametersCard, 0, 2);

            Controls.Add(layout);

            BuildModelCard(modelCard);
            BuildParametersCard(parametersCard);
            BuildExecutionCard(executionCard);

        }

        private Panel CreateCard()
        {
            return new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = _cardColor,
                Margin = new Padding(0, 0, 0, 12)
            };
        }

        private Label CreateLabel(
            string text,
            int size = 9,
            bool bold = false)
        {
            return new Label
            {
                Text = text,
                Font = new Font(
                    "Segoe UI",
                    size,
                    bold ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = bold
                    ? _titleColor
                    : _secondaryColor,
                AutoSize = true
            };
        }

        private Button CreateButton(
            string text,
            Color color)
        {
            Button button = new Button
            {
                Text = text,
                Font = new Font(
                    "Segoe UI", 9, FontStyle.Bold),
                BackColor = color,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };

            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private void BuildModelCard(Panel card)
        {
            Label heading = CreateLabel(
                "Modello di origine", 14, true);

            heading.Location = new Point(22, 15);
            card.Controls.Add(heading);

            lblModel = CreateLabel(
                "Nessun modello rilevato", 12, true);
            lblModel.Location = new Point(22, 50);
            card.Controls.Add(lblModel);

            lblModelPath = CreateLabel("");
            lblModelPath.Location = new Point(22, 80);
            card.Controls.Add(lblModelPath);

            lblDrawing = CreateLabel(
                "Tavola IDW: non verificata");
            lblDrawing.Location = new Point(22, 103);
            card.Controls.Add(lblDrawing);

            Button refresh = CreateButton(
                "AGGIORNA MODELLO",
                Color.FromArgb(124, 58, 237));

            refresh.Size = new Size(185, 44);
            refresh.Location = new Point(
                card.Width - 207, 48);

            refresh.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            refresh.Click += (s, e) => LoadCurrentModel();

            card.Controls.Add(refresh);
        }

        private void BuildParametersCard(Panel card)
        {
            Label heading = CreateLabel(
                "Parametri del modello", 14, true);
            heading.Location = new Point(22, 14);
            card.Controls.Add(heading);

            Label subtitle = CreateLabel(
                "Seleziona i parametri e imposta minimo, massimo e passo.");
            subtitle.Location = new Point(23, 46);
            card.Controls.Add(subtitle);

            parametersGrid = CreateGrid();
            parametersGrid.Location = new Point(22, 75);
            parametersGrid.Size = new Size(
                card.Width - 44,
                card.Height - 95);

            parametersGrid.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            parametersGrid.Columns.Add(
                new DataGridViewCheckBoxColumn
                {
                    Name = "Selected",
                    HeaderText = "Usa",
                    Width = 55
                });

            AddColumn(parametersGrid, "Name", "Parametro", 125);
            AddColumn(parametersGrid, "Current", "Attuale", 115);
            AddColumn(parametersGrid, "Unit", "Unità", 80);
            AddColumn(parametersGrid, "Min", "Minimo", 110);
            AddColumn(parametersGrid, "Max", "Massimo", 110);
            AddColumn(parametersGrid, "Step", "Passo", 110);

            parametersGrid.Columns["Name"]!.ReadOnly = true;
            parametersGrid.Columns["Current"]!.ReadOnly = true;
            parametersGrid.Columns["Unit"]!.ReadOnly = true;

            parametersGrid.Columns["Step"]!.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            parametersGrid.CurrentCellDirtyStateChanged +=
                (s, e) =>
                {
                    if (parametersGrid.IsCurrentCellDirty)
                        parametersGrid.CommitEdit(
                            DataGridViewDataErrorContexts.Commit);
                };

            parametersGrid.CellValueChanged +=
                (s, e) => UpdateCombinationCount();

            parametersGrid.DataError +=
                (s, e) => { e.ThrowException = false; };

            card.Controls.Add(parametersGrid);
        }

        private void BuildExecutionCard(Panel card)
        {
            lblCount = CreateLabel(
                "Combinazioni previste: 0", 11, true);
            lblCount.Location = new Point(22, 14);
            card.Controls.Add(lblCount);

            btnStart = CreateButton(
                "AVVIA GENERAZIONE",
                Color.FromArgb(22, 163, 74));

            btnStart.Location = new Point(22, 43);
            btnStart.Size = new Size(
                card.Width - 44, 42);

            btnStart.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;

            // Il motore IPT/IDW verrà collegato nella fase 3.
            btnStart.Enabled = false;
            card.Controls.Add(btnStart);

            progressBar = new ProgressBar
            {
                Location = new Point(22, 94),
                Size = new Size(card.Width - 115, 20),
                Anchor = AnchorStyles.Top |
                         AnchorStyles.Left |
                         AnchorStyles.Right,
                Minimum = 0,
                Maximum = 100,
                Value = 0
            };

            card.Controls.Add(progressBar);

            lblPercentage = CreateLabel("0%", 9, true);
            lblPercentage.Location = new Point(
                card.Width - 80, 94);

            lblPercentage.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            card.Controls.Add(lblPercentage);

            lblProgress = CreateLabel(
                "In attesa del motore di generazione");
            lblProgress.Location = new Point(22, 125);
            card.Controls.Add(lblProgress);
        }

        private DataGridView CreateGrid()
        {
            DataGridView grid = new DataGridView
            {
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = false,
                BackgroundColor = _inputColor,
                GridColor = _lineColor,
                BorderStyle = BorderStyle.None,
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 40,
                ColumnHeadersHeightSizeMode =
                    DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                SelectionMode =
                    DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false
            };

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(43, 46, 55)
                    : Color.FromArgb(241, 245, 249);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                _titleColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font("Segoe UI", 9, FontStyle.Bold);

            grid.DefaultCellStyle.BackColor = _inputColor;
            grid.DefaultCellStyle.ForeColor = _titleColor;
            grid.DefaultCellStyle.SelectionBackColor = _inputColor;
            grid.DefaultCellStyle.SelectionForeColor = _titleColor;
            grid.DefaultCellStyle.Font =
                new Font("Segoe UI", 9);

            grid.DefaultCellStyle.Padding =
                new Padding(6, 2, 6, 2);

            grid.RowTemplate.Height = 38;

            return grid;
        }

        private static void AddColumn(
            DataGridView grid,
            string name,
            string header,
            int width)
        {
            grid.Columns.Add(
                new DataGridViewTextBoxColumn
                {
                    Name = name,
                    HeaderText = header,
                    Width = width,
                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                });
        }

        private void LoadCurrentModel()
        {
            if (_loading)
                return;

            _loading = true;

            try
            {
                parametersGrid.Rows.Clear();
                _modelPath = "";

                Inventor.Document document =
                    _inventorApp.ActiveDocument;

                if (document is not Inventor.PartDocument part)
                {
                    lblModel.Text = "Nessun IPT attivo";
                    lblModelPath.Text =
                        "Apri un file IPT in Inventor.";
                    lblDrawing.Text = "Tavola IDW: non verificata";
                    UpdateCombinationCount();
                    return;
                }

                _modelPath = part.FullFileName;

                lblModel.Text = string.IsNullOrWhiteSpace(
                    _modelPath)
                    ? part.DisplayName
                    : Path.GetFileName(_modelPath);

                lblModelPath.Text = _modelPath;

                string drawingPath =
                    Path.ChangeExtension(_modelPath, ".idw");

                lblDrawing.Text =
                    !string.IsNullOrWhiteSpace(_modelPath) &&
                    File.Exists(drawingPath)
                        ? "Tavola IDW: " +
                          Path.GetFileName(drawingPath)
                        : "Tavola IDW: non trovata nella cartella del modello";

                Inventor.ModelParameters modelParameters =
                    part.ComponentDefinition.Parameters.ModelParameters;

                foreach (Inventor.ModelParameter parameter
                         in modelParameters)
                {
                    // Expression mantiene l'unità visualizzata
                    // dal parametro di Inventor.
                    string expression = parameter.Expression;

                    int index = parametersGrid.Rows.Add(
                        false,
                        parameter.Name,
                        expression,
                        "",
                        expression,
                        expression,
                        "");

                    parametersGrid.Rows[index].Tag =
                        parameter.Name;
                }

                UpdateCombinationCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Errore durante la lettura del modello:" +
                    Environment.NewLine + ex.Message,
                    "Generatore Varianti",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                _loading = false;
            }
        }

        private void UpdateCombinationCount()
        {
            if (parametersGrid == null ||
                lblCount == null ||
                _loading)
                return;

            long combinations = 1;
            int selectedCount = 0;
            bool valid = true;

            foreach (DataGridViewRow row in parametersGrid.Rows)
            {
                bool selected =
                    Convert.ToBoolean(
                        row.Cells["Selected"].Value ?? false);

                if (!selected)
                    continue;

                selectedCount++;

                decimal min = 0;
                decimal max = 0;
                decimal step = 0;

                bool minValid = TryReadNumber(row, "Min", out min);
                bool maxValid = TryReadNumber(row, "Max", out max);
                bool stepValid = TryReadNumber(row, "Step", out step);

                bool parsed = minValid && maxValid && stepValid;

                if (!parsed || step <= 0 || max < min)
                {
                    valid = false;
                    break;
                }

                try
                {
                    long count = checked(
                        (long)decimal.Floor(
                            (max - min) / step) + 1);

                    combinations = checked(combinations * count);
                }
                catch (OverflowException)
                {
                    valid = false;
                    break;
                }
            }

            if (!valid)
            {
                lblCount.Text =
                    "Intervalli non validi o numero di combinazioni eccessivo";
                return;
            }

            lblCount.Text = selectedCount == 0
                ? "Combinazioni previste: 0"
                : "Combinazioni teoriche: " +
                  combinations.ToString("N0", CultureInfo.CurrentCulture);
        }

        private static bool TryReadNumber(
            DataGridViewRow row,
            string column,
            out decimal value)
        {
            string text = Convert.ToString(
                row.Cells[column].Value)?.Trim() ?? "";

            // In questa prima UI si accettano valori numerici.
            // La gestione delle unità Inventor arriverà
            // con il servizio dedicato.
            return decimal.TryParse(
                text,
                NumberStyles.Number,
                CultureInfo.CurrentCulture,
                out value);
        }

        private void BtnRegistroVarianti_Click(
            object? sender,
            EventArgs e)
        {
            if (!btnRegistroVarianti.Enabled)
                return;

            if (_registroForm != null &&
                !_registroForm.IsDisposed)
            {
                _registroForm.Show();
                _registroForm.BringToFront();
                _registroForm.Activate();
                return;
            }

            _registroForm = new GeneratoreVariantiLogForm(
                _registroSource,
                _isDarkTheme);

            _registroForm.FormClosed += (s, args) =>
                _registroForm = null;

            _registroForm.Show(this);
        }

        /// <summary>
        /// Da richiamare esclusivamente quando
        /// il motore di generazione è partito.
        /// </summary>

        private void OnGenerazioneAvviata()
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(OnGenerazioneAvviata));
                return;
            }

            btnRegistroVarianti.Enabled = true;
            btnRegistroVarianti.Visible = true;
            btnRegistroVarianti.BringToFront();
        }


        /// <summary>
        /// Registra l'esito di una variante.
        /// Sarà chiamato dal motore IPT/IDW.
        /// </summary>
        private void AggiungiEsitoVariante(
            string variante,
            string stato,
            string dettagli)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action(() =>
                    AggiungiEsitoVariante(
                        variante, stato, dettagli)));
                return;
            }

            _registroEntries.Add(
                new VarianteLogEntry
                {
                    Variante = variante,
                    Stato = stato,
                    Dettagli = dettagli
                });
        }

    }
}
