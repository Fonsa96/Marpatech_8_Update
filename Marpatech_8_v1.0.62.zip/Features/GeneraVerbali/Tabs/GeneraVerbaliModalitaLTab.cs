﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Tabs
{
    public sealed class GeneraVerbaliModalitaLTab : UserControl
    {
        private readonly bool
            _isDarkTheme;

        private DataGridView
            _columnsGrid = null!;


        public GeneraVerbaliModalitaLTab(
            bool isDarkTheme)
        {
            _isDarkTheme =
                isDarkTheme;

            InitializeComponent();
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Color secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(180, 185, 195)
                    : Color.FromArgb(100, 116, 139);


            Dock =
                DockStyle.Fill;

            BackColor =
                backgroundColor;


            Label titleLabel =
                new Label
                {
                    Text =
                        "Configurazione colonne",

                    Font =
                        new Font(
                            "Segoe UI",
                            12F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            20)
                };


            Label descriptionLabel =
                new Label
                {
                    Text =
                        "Definisci il nome e l'ordine delle colonne che verranno mostrate nella Modalità L.",

                    Font =
                        new Font(
                            "Segoe UI",
                            9F),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            52)
                };


            /*
             * ==========================================
             * TABELLA COMPATTA
             * ==========================================
             */
            _columnsGrid =
                new DataGridView
                {
                    Location =
                        new Point(
                            20,
                            85),

                    Size =
                        new Size(
                            ClientSize.Width - 40,
                            190),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                        false,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    SelectionMode =
                        DataGridViewSelectionMode.FullRowSelect,

                    MultiSelect =
                        false,

                    BackgroundColor =
                        _isDarkTheme
                            ? Color.FromArgb(42, 44, 50)
                            : Color.White,

                    BorderStyle =
                        BorderStyle.FixedSingle
                };

            _columnsGrid.EnableHeadersVisualStyles =
    false;

            _columnsGrid.DefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(42, 44, 50)
                    : Color.White;

            _columnsGrid.DefaultCellStyle.ForeColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            _columnsGrid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(37, 99, 235);

            _columnsGrid.DefaultCellStyle.SelectionForeColor =
                Color.White;


            _columnsGrid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(55, 58, 66)
                    : Color.FromArgb(226, 232, 240);

            _columnsGrid.ColumnHeadersDefaultCellStyle.ForeColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            _columnsGrid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                _isDarkTheme
                    ? Color.FromArgb(55, 58, 66)
                    : Color.FromArgb(226, 232, 240);

            _columnsGrid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);


            DataGridViewTextBoxColumn orderColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "Order",

                    HeaderText =
                        "Ordine",

                    Width =
                        75,

                    ReadOnly =
                        true,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            DataGridViewTextBoxColumn nameColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "Name",

                    HeaderText =
                        "Nome colonna",

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            _columnsGrid.Columns.Add(
                orderColumn);

            _columnsGrid.Columns.Add(
                nameColumn);


            /*
             * ==========================================
             * PULSANTI
             * ==========================================
             */
            Button addButton =
                CreateButton(
                    "Aggiungi colonna",
                    20,
                    292,
                    135);

            addButton.Click +=
                AddButton_Click;


            Button removeButton =
                CreateButton(
                    "Rimuovi",
                    165,
                    292,
                    95);

            removeButton.Click +=
                RemoveButton_Click;


            Button moveUpButton =
                CreateButton(
                    "▲",
                    270,
                    292,
                    45);

            moveUpButton.Click +=
                MoveUpButton_Click;


            Button moveDownButton =
                CreateButton(
                    "▼",
                    325,
                    292,
                    45);

            moveDownButton.Click +=
                MoveDownButton_Click;


            Controls.Add(
                titleLabel);

            Controls.Add(
                descriptionLabel);

            Controls.Add(
                _columnsGrid);

            Controls.Add(
                addButton);

            Controls.Add(
                removeButton);

            Controls.Add(
                moveUpButton);

            Controls.Add(
                moveDownButton);
        }


        private Button CreateButton(
            string text,
            int x,
            int y,
            int width)
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(241, 245, 249);

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);


            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            button.FlatAppearance.BorderColor =
                _isDarkTheme
                    ? Color.FromArgb(85, 90, 100)
                    : Color.FromArgb(203, 213, 225);

            return button;
        }


        public void SetColumns(
            IEnumerable<string>? columns)
        {
            _columnsGrid.Rows.Clear();

            if (columns == null)
            {
                RefreshColumnOrder();
                return;
            }


            foreach (string columnName in columns)
            {
                int rowIndex =
                    _columnsGrid.Rows.Add();

                _columnsGrid.Rows[rowIndex]
                    .Cells["Name"].Value =
                    columnName;
            }

            RefreshColumnOrder();
        }


        public List<string> GetColumns()
        {
            _columnsGrid.EndEdit();

            List<string> result =
                new List<string>();


            foreach (DataGridViewRow row in
                _columnsGrid.Rows)
            {
                string columnName =
                    Convert.ToString(
                        row.Cells["Name"].Value)
                    ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                    columnName))
                {
                    continue;
                }

                result.Add(
                    columnName);
            }


            return result;
        }


        private void AddButton_Click(
            object? sender,
            EventArgs e)
        {
            int rowIndex =
                _columnsGrid.Rows.Add();

            RefreshColumnOrder();

            _columnsGrid.ClearSelection();

            DataGridViewRow row =
                _columnsGrid.Rows[rowIndex];

            row.Selected =
                true;

            _columnsGrid.CurrentCell =
                row.Cells["Name"];

            _columnsGrid.BeginEdit(
                true);
        }


        private void RemoveButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_columnsGrid.CurrentRow == null)
                return;

            int rowIndex =
                _columnsGrid.CurrentRow.Index;

            if (rowIndex < 0 ||
                rowIndex >= _columnsGrid.Rows.Count)
            {
                return;
            }

            _columnsGrid.Rows.RemoveAt(
                rowIndex);

            RefreshColumnOrder();
        }


        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_columnsGrid.CurrentRow == null)
                return;

            int currentIndex =
                _columnsGrid.CurrentRow.Index;

            if (currentIndex <= 0)
                return;

            SwapRows(
                currentIndex,
                currentIndex - 1);
        }


        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_columnsGrid.CurrentRow == null)
                return;

            int currentIndex =
                _columnsGrid.CurrentRow.Index;

            if (currentIndex < 0 ||
                currentIndex >=
                _columnsGrid.Rows.Count - 1)
            {
                return;
            }

            SwapRows(
                currentIndex,
                currentIndex + 1);
        }


        private void SwapRows(
            int sourceIndex,
            int destinationIndex)
        {
            string sourceName =
                Convert.ToString(
                    _columnsGrid.Rows[sourceIndex]
                        .Cells["Name"].Value)
                ?? string.Empty;

            string destinationName =
                Convert.ToString(
                    _columnsGrid.Rows[destinationIndex]
                        .Cells["Name"].Value)
                ?? string.Empty;


            _columnsGrid.Rows[destinationIndex]
                .Cells["Name"].Value =
                sourceName;

            _columnsGrid.Rows[sourceIndex]
                .Cells["Name"].Value =
                destinationName;


            RefreshColumnOrder();

            _columnsGrid.ClearSelection();

            _columnsGrid.Rows[destinationIndex]
                .Selected =
                true;

            _columnsGrid.CurrentCell =
                _columnsGrid.Rows[destinationIndex]
                    .Cells["Name"];
        }


        private void RefreshColumnOrder()
        {
            for (int i = 0;
                 i < _columnsGrid.Rows.Count;
                 i++)
            {
                _columnsGrid.Rows[i]
                    .Cells["Order"].Value =
                    i + 1;
            }
        }
    }
}