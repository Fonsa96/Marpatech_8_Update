﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.GeneraVerbali.Models;
using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraVerbali.Tabs
{
    public sealed class GeneraVerbaliModalitaStlTab : UserControl
    {
        private readonly bool
            _isDarkTheme;


        private TextBox
            _outputStartPathTextBox = null!;

        private TextBox
            _determiningAttributeTextBox = null!;

        private TextBox
            _outputEndPathTextBox = null!;


        private DataGridView
            _propertiesGrid = null!;

        private DataGridView
            _formColumnsGrid = null!;


        public GeneraVerbaliModalitaStlTab(
            bool isDarkTheme)
        {
            _isDarkTheme =
                isDarkTheme;

            InitializeComponent();
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryTextColor =
                _isDarkTheme
                    ? Color.FromArgb(185, 190, 200)
                    : Color.FromArgb(100, 116, 139);

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(42, 44, 50)
                    : Color.White;

            Color buttonColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(241, 245, 249);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Dock =
                DockStyle.Fill;

            BackColor =
                backgroundColor;

            AutoScroll =
                true;

            AutoScrollMinSize =
                new Size(
                    0,
                    900);


            /*
             * ==========================================
             * OUTPUT
             * ==========================================
             */
            Label outputTitleLabel =
                CreateSectionTitle(
                    "Output",
                    20,
                    20,
                    textColor);


            Label outputDescriptionLabel =
                new Label
                {
                    Text =
                        "Configura come verrà determinato automaticamente il percorso di destinazione dei file.",

                    Font =
                        new Font(
                            "Segoe UI",
                            9F),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            52)
                };


            /*
             * PERCORSO INIZIALE
             */
            Label startPathLabel =
                CreateFieldLabel(
                    "Percorso iniziale",
                    20,
                    88,
                    textColor);


            Panel startPathPanel =
                new Panel
                {
                    Location =
                        new Point(
                            20,
                            113),

                    Size =
                        new Size(
                            Width - 50,
                            31),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        backgroundColor
                };


            _outputStartPathTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            0,
                            0),

                    Size =
                        new Size(
                            startPathPanel.Width - 55,
                            30),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        inputColor,

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Font =
                        new Font(
                            "Segoe UI",
                            9.5F)
                };


            Button browseStartPathButton =
                new Button
                {
                    Text =
                        "...",

                    Location =
                        new Point(
                            startPathPanel.Width - 45,
                            0),

                    Size =
                        new Size(
                            45,
                            30),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        buttonColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            browseStartPathButton.FlatAppearance.BorderColor =
                borderColor;

            browseStartPathButton.Click +=
                BrowseStartPathButton_Click;

            startPathPanel.Controls.Add(
           _outputStartPathTextBox);

            startPathPanel.Controls.Add(
                browseStartPathButton);



            /*
             * ATTRIBUTO DETERMINANTE
             */
            Label attributeLabel =
                CreateFieldLabel(
                    "Attributo determinante",
                    20,
                    157,
                    textColor);


            _determiningAttributeTextBox =
                CreateTextBox(
                    20,
                    182,
                    Width - 50,
                    inputColor,
                    textColor);

            _determiningAttributeTextBox.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;


            Label attributeDescriptionLabel =
                new Label
                {
                    Text =
                        "Nome della proprietà dell'assieme Inventor utilizzata per individuare la cartella corrispondente.",

                    Font =
                        new Font(
                            "Segoe UI",
                            8.5F),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            216)
                };


            /*
             * PARTE FINALE
             */
            Label endPathLabel =
                CreateFieldLabel(
                    "Parte finale del percorso",
                    20,
                    250,
                    textColor);


            _outputEndPathTextBox =
                CreateTextBox(
                    20,
                    275,
                    Width - 50,
                    inputColor,
                    textColor);

            _outputEndPathTextBox.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;


            /*
             * ==========================================
             * SEPARATORE 1
             * ==========================================
             */
            Panel separator1 =
                CreateSeparator(
                    20,
                    330,
                    borderColor);


            /*
             * ==========================================
             * PROPRIETÀ
             * ==========================================
             */
            Label propertiesTitleLabel =
                CreateSectionTitle(
                    "Proprietà",
                    20,
                    355,
                    textColor);


            Label propertiesDescriptionLabel =
                new Label
                {
                    Text =
                        "Configura le TextBox del Form STL e la relativa destinazione nel file Excel.",

                    Font =
                        new Font(
                            "Segoe UI",
                            9F),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            387)
                };


            _propertiesGrid =
                CreateModernGrid(
                    20,
                    420,
                    Width - 50,
                    190,
                    backgroundColor,
                    inputColor,
                    textColor,
                    borderColor);

            _propertiesGrid.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;


            /*
             * COLONNA 1
             */
            DataGridViewTextBoxColumn propertyNameColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "TextBoxName",

                    HeaderText =
                        "Nome TextBox",

                    FillWeight =
                        25F,

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            /*
             * COLONNA 2
             */
            DataGridViewTextBoxColumn propertyTextColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "TextBoxText",

                    HeaderText =
                        "Testo TextBox",

                    FillWeight =
                        35F,

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            /*
             * COLONNA 3
             *
             * Può contenere sia:
             * B12
             *
             * sia eventualmente:
             * B12:D12
             *
             * La gestione effettiva delle celle unite
             * verrà fatta nella logica Excel.
             */
            DataGridViewTextBoxColumn excelCellColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "ExcelCell",

                    HeaderText =
                        "Cella Excel",

                    FillWeight =
                        20F,

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            /*
             * COLONNA 4
             */
            DataGridViewCheckBoxColumn inventorPropertyColumn =
                new DataGridViewCheckBoxColumn
                {
                    Name =
                        "IsInventorProperty",

                    HeaderText =
                        "Proprietà Inventor?",

                    FillWeight =
                        20F,

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable,

                    TrueValue =
                        true,

                    FalseValue =
                        false
                };


            _propertiesGrid.Columns.Add(
                propertyNameColumn);

            _propertiesGrid.Columns.Add(
                propertyTextColumn);

            _propertiesGrid.Columns.Add(
                excelCellColumn);

            _propertiesGrid.Columns.Add(
                inventorPropertyColumn);


            /*
             * PULSANTI PROPRIETÀ
             */
            Button addPropertyButton =
                CreateSecondaryButton(
                    "Aggiungi riga",
                    20,
                    625,
                    125,
                    buttonColor,
                    textColor,
                    borderColor);

            addPropertyButton.Click +=
                AddPropertyButton_Click;


            Button removePropertyButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    155,
                    625,
                    95,
                    buttonColor,
                    textColor,
                    borderColor);

            removePropertyButton.Click +=
                RemovePropertyButton_Click;


            Button movePropertyUpButton =
                CreateSecondaryButton(
                    "▲",
                    260,
                    625,
                    45,
                    buttonColor,
                    textColor,
                    borderColor);

            movePropertyUpButton.Click +=
                MovePropertyUpButton_Click;


            Button movePropertyDownButton =
                CreateSecondaryButton(
                    "▼",
                    315,
                    625,
                    45,
                    buttonColor,
                    textColor,
                    borderColor);

            movePropertyDownButton.Click +=
                MovePropertyDownButton_Click;


            /*
             * ==========================================
             * SEPARATORE 2
             * ==========================================
             */
            Panel separator2 =
                CreateSeparator(
                    20,
                    685,
                    borderColor);


            /*
             * ==========================================
             * COLONNE FORM STL
             * ==========================================
             */
            Label formColumnsTitleLabel =
                CreateSectionTitle(
                    "Colonne Form STL",
                    20,
                    710,
                    textColor);


            Label formColumnsDescriptionLabel =
                new Label
                {
                    Text =
                        "Definisci le colonne della tabella del Form STL e la cella Excel di partenza associata a ciascuna colonna.",

                    Font =
                        new Font(
                            "Segoe UI",
                            9F),

                    ForeColor =
                        secondaryTextColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            20,
                            742)
                };


            _formColumnsGrid =
                CreateModernGrid(
                    20,
                    775,
                    Width - 50,
                    180,
                    backgroundColor,
                    inputColor,
                    textColor,
                    borderColor);

            _formColumnsGrid.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;


            DataGridViewTextBoxColumn orderColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "Order",

                    HeaderText =
                        "Ordine",

                    Width =
                        70,

                    ReadOnly =
                        true,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            DataGridViewTextBoxColumn columnNameColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "Name",

                    HeaderText =
                        "Nome colonna",

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    FillWeight =
                        70F,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            DataGridViewTextBoxColumn columnExcelCellColumn =
                new DataGridViewTextBoxColumn
                {
                    Name =
                        "ExcelCell",

                    HeaderText =
                        "Cella Excel",

                    AutoSizeMode =
                        DataGridViewAutoSizeColumnMode.Fill,

                    FillWeight =
                        30F,

                    SortMode =
                        DataGridViewColumnSortMode.NotSortable
                };


            _formColumnsGrid.Columns.Add(
                orderColumn);

            _formColumnsGrid.Columns.Add(
                columnNameColumn);

            _formColumnsGrid.Columns.Add(
                columnExcelCellColumn);


            /*
             * PULSANTI COLONNE FORM
             */
            Button addFormColumnButton =
                CreateSecondaryButton(
                    "Aggiungi colonna",
                    20,
                    970,
                    135,
                    buttonColor,
                    textColor,
                    borderColor);

            addFormColumnButton.Click +=
                AddFormColumnButton_Click;


            Button removeFormColumnButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    165,
                    970,
                    95,
                    buttonColor,
                    textColor,
                    borderColor);

            removeFormColumnButton.Click +=
                RemoveFormColumnButton_Click;


            Button moveFormColumnUpButton =
                CreateSecondaryButton(
                    "▲",
                    270,
                    970,
                    45,
                    buttonColor,
                    textColor,
                    borderColor);

            moveFormColumnUpButton.Click +=
                MoveFormColumnUpButton_Click;


            Button moveFormColumnDownButton =
                CreateSecondaryButton(
                    "▼",
                    325,
                    970,
                    45,
                    buttonColor,
                    textColor,
                    borderColor);

            moveFormColumnDownButton.Click +=
                MoveFormColumnDownButton_Click;


            /*
             * ==========================================
             * CONTROLS
             * ==========================================
             */
            Controls.Add(
                outputTitleLabel);

            Controls.Add(
                outputDescriptionLabel);

            Controls.Add(
                startPathLabel);

            Controls.Add(
                startPathPanel);

            Controls.Add(
                attributeLabel);

            Controls.Add(
                _determiningAttributeTextBox);

            Controls.Add(
                attributeDescriptionLabel);

            Controls.Add(
                endPathLabel);

            Controls.Add(
                _outputEndPathTextBox);

            Controls.Add(
                separator1);

            Controls.Add(
                propertiesTitleLabel);

            Controls.Add(
                propertiesDescriptionLabel);

            Controls.Add(
                _propertiesGrid);

            Controls.Add(
                addPropertyButton);

            Controls.Add(
                removePropertyButton);

            Controls.Add(
                movePropertyUpButton);

            Controls.Add(
                movePropertyDownButton);

            Controls.Add(
                separator2);

            Controls.Add(
                formColumnsTitleLabel);

            Controls.Add(
                formColumnsDescriptionLabel);

            Controls.Add(
                _formColumnsGrid);

            Controls.Add(
                addFormColumnButton);

            Controls.Add(
                removeFormColumnButton);

            Controls.Add(
                moveFormColumnUpButton);

            Controls.Add(
                moveFormColumnDownButton);
        }


        /*
         * ==========================================
         * CREAZIONE CONTROLLI
         * ==========================================
         */
        private Label CreateSectionTitle(
            string text,
            int x,
            int y,
            Color textColor)
        {
            return new Label
            {
                Text =
                    text,

                Font =
                    new Font(
                        "Segoe UI",
                        12F,
                        FontStyle.Bold),

                ForeColor =
                    textColor,

                AutoSize =
                    true,

                Location =
                    new Point(
                        x,
                        y)
            };
        }


        private Label CreateFieldLabel(
            string text,
            int x,
            int y,
            Color textColor)
        {
            return new Label
            {
                Text =
                    text,

                Font =
                    new Font(
                        "Segoe UI",
                        9.5F,
                        FontStyle.Bold),

                ForeColor =
                    textColor,

                AutoSize =
                    true,

                Location =
                    new Point(
                        x,
                        y)
            };
        }


        private TextBox CreateTextBox(
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor)
        {
            return new TextBox
            {
                Location =
                    new Point(
                        x,
                        y),

                Size =
                    new Size(
                        Math.Max(
                            100,
                            width),
                        30),

                BackColor =
                    backgroundColor,

                ForeColor =
                    textColor,

                BorderStyle =
                    BorderStyle.FixedSingle,

                Font =
                    new Font(
                        "Segoe UI",
                        9.5F)
            };
        }


        private Panel CreateSeparator(
            int x,
            int y,
            Color borderColor)
        {
            return new Panel
            {
                Location =
                    new Point(
                        x,
                        y),

                Size =
                    new Size(
                        Width - 50,
                        1),

                Anchor =
                    AnchorStyles.Top |
                    AnchorStyles.Left |
                    AnchorStyles.Right,

                BackColor =
                    borderColor
            };
        }


        private DataGridView CreateModernGrid(
            int x,
            int y,
            int width,
            int height,
            Color backgroundColor,
            Color cellColor,
            Color textColor,
            Color borderColor)
        {
            DataGridView grid =
                new DataGridView
                {
                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            Math.Max(
                                200,
                                width),
                            height),

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                        false,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    MultiSelect =
                        false,

                    SelectionMode =
                        DataGridViewSelectionMode.FullRowSelect,

                    BackgroundColor =
                        backgroundColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    GridColor =
                        borderColor,

                    EnableHeadersVisualStyles =
                        false,

                    EditMode =
                        DataGridViewEditMode.EditOnKeystrokeOrF2
                };


            grid.DefaultCellStyle.BackColor =
                cellColor;

            grid.DefaultCellStyle.ForeColor =
                textColor;

            grid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            grid.DefaultCellStyle.SelectionForeColor =
                Color.White;

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9F);

            grid.DefaultCellStyle.Padding =
                new Padding(
                    3);


            grid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                grid.ColumnHeadersDefaultCellStyle.BackColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9F,
                    FontStyle.Bold);

            grid.ColumnHeadersHeight =
                36;

            grid.RowTemplate.Height =
                32;


            return grid;
        }


        private Button CreateSecondaryButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor,
            Color borderColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };


            button.FlatAppearance.BorderColor =
                borderColor;


            return button;
        }


        /*
         * ==========================================
         * OUTPUT
         * ==========================================
         */
        private void BrowseStartPathButton_Click(
            object? sender,
            EventArgs e)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog
                {
                    Description =
                        "Seleziona il percorso iniziale di output",

                    UseDescriptionForTitle =
                        true,

                    ShowNewFolderButton =
                        true
                };


            string currentPath =
                _outputStartPathTextBox.Text.Trim();


            if (!string.IsNullOrWhiteSpace(
                    currentPath) &&
                Directory.Exists(
                    currentPath))
            {
                dialog.SelectedPath =
                    currentPath;
            }


            if (dialog.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }


            _outputStartPathTextBox.Text =
                dialog.SelectedPath;
        }


        /*
         * ==========================================
         * PROPRIETÀ
         * ==========================================
         */
        private void AddPropertyButton_Click(
            object? sender,
            EventArgs e)
        {
            int rowIndex =
                _propertiesGrid.Rows.Add();


            _propertiesGrid.Rows[rowIndex]
                .Cells["IsInventorProperty"]
                .Value =
                false;


            SelectGridRow(
                _propertiesGrid,
                rowIndex,
                "TextBoxName");
        }


        private void RemovePropertyButton_Click(
            object? sender,
            EventArgs e)
        {
            RemoveCurrentRow(
                _propertiesGrid);
        }


        private void MovePropertyUpButton_Click(
            object? sender,
            EventArgs e)
        {
            MoveCurrentRow(
                _propertiesGrid,
                -1);
        }


        private void MovePropertyDownButton_Click(
            object? sender,
            EventArgs e)
        {
            MoveCurrentRow(
                _propertiesGrid,
                1);
        }


        /*
         * ==========================================
         * COLONNE FORM STL
         * ==========================================
         */
        private void AddFormColumnButton_Click(
            object? sender,
            EventArgs e)
        {
            int rowIndex =
                _formColumnsGrid.Rows.Add();

            RefreshFormColumnOrder();


            SelectGridRow(
                _formColumnsGrid,
                rowIndex,
                "Name");
        }


        private void RemoveFormColumnButton_Click(
            object? sender,
            EventArgs e)
        {
            RemoveCurrentRow(
                _formColumnsGrid);

            RefreshFormColumnOrder();
        }


        private void MoveFormColumnUpButton_Click(
            object? sender,
            EventArgs e)
        {
            MoveCurrentRow(
                _formColumnsGrid,
                -1);

            RefreshFormColumnOrder();
        }


        private void MoveFormColumnDownButton_Click(
            object? sender,
            EventArgs e)
        {
            MoveCurrentRow(
                _formColumnsGrid,
                1);

            RefreshFormColumnOrder();
        }


        /*
         * ==========================================
         * GESTIONE RIGHE GENERICA
         * ==========================================
         */
        private void RemoveCurrentRow(
            DataGridView grid)
        {
            if (grid.CurrentRow == null)
                return;


            int index =
                grid.CurrentRow.Index;


            if (index < 0 ||
                index >= grid.Rows.Count)
            {
                return;
            }


            grid.Rows.RemoveAt(
                index);
        }


        private void MoveCurrentRow(
            DataGridView grid,
            int direction)
        {
            if (grid.CurrentRow == null)
                return;


            grid.EndEdit();


            int sourceIndex =
                grid.CurrentRow.Index;

            int destinationIndex =
                sourceIndex +
                direction;


            if (sourceIndex < 0 ||
                destinationIndex < 0 ||
                destinationIndex >=
                grid.Rows.Count)
            {
                return;
            }


            object?[] sourceValues =
                new object?[grid.Columns.Count];

            object?[] destinationValues =
                new object?[grid.Columns.Count];


            for (int columnIndex = 0;
                 columnIndex < grid.Columns.Count;
                 columnIndex++)
            {
                sourceValues[columnIndex] =
                    grid.Rows[sourceIndex]
                        .Cells[columnIndex]
                        .Value;

                destinationValues[columnIndex] =
                    grid.Rows[destinationIndex]
                        .Cells[columnIndex]
                        .Value;
            }


            for (int columnIndex = 0;
                 columnIndex < grid.Columns.Count;
                 columnIndex++)
            {
                grid.Rows[destinationIndex]
                    .Cells[columnIndex]
                    .Value =
                    sourceValues[columnIndex];

                grid.Rows[sourceIndex]
                    .Cells[columnIndex]
                    .Value =
                    destinationValues[columnIndex];
            }


            grid.ClearSelection();

            grid.Rows[destinationIndex]
                .Selected =
                true;

            grid.CurrentCell =
                grid.Rows[destinationIndex]
                    .Cells[0];
        }


        private void SelectGridRow(
            DataGridView grid,
            int rowIndex,
            string cellName)
        {
            grid.ClearSelection();

            grid.Rows[rowIndex]
                .Selected =
                true;

            grid.CurrentCell =
                grid.Rows[rowIndex]
                    .Cells[cellName];

            grid.BeginEdit(
                true);
        }


        private void RefreshFormColumnOrder()
        {
            for (int i = 0;
                 i < _formColumnsGrid.Rows.Count;
                 i++)
            {
                _formColumnsGrid.Rows[i]
                    .Cells["Order"].Value =
                    i + 1;
            }
        }
        public void SetSettings(
    GeneraVerbaliModalitaStlSettings? settings)
        {
            if (settings == null)
                settings =
                    new GeneraVerbaliModalitaStlSettings();


            _outputStartPathTextBox.Text =
                settings.OutputStartPath
                ?? string.Empty;

            _determiningAttributeTextBox.Text =
                settings.DeterminingAttribute
                ?? string.Empty;

            _outputEndPathTextBox.Text =
                settings.OutputEndPath
                ?? string.Empty;


            /*
             * ==========================================
             * PROPRIETÀ
             * ==========================================
             */
            _propertiesGrid.Rows.Clear();


            if (settings.Properties != null)
            {
                foreach (GeneraVerbaliStlPropertySetting property in
                    settings.Properties)
                {
                    int rowIndex =
                        _propertiesGrid.Rows.Add();

                    DataGridViewRow row =
                        _propertiesGrid.Rows[rowIndex];


                    row.Cells["TextBoxName"].Value =
                        property.TextBoxName;

                    row.Cells["TextBoxText"].Value =
                        property.TextBoxText;

                    row.Cells["ExcelCell"].Value =
                        property.ExcelCell;

                    row.Cells["IsInventorProperty"].Value =
                        property.IsInventorProperty;
                }
            }


            /*
             * ==========================================
             * COLONNE FORM STL
             * ==========================================
             */
            _formColumnsGrid.Rows.Clear();


            if (settings.FormColumns != null)
            {
                foreach (GeneraVerbaliStlFormColumnSetting column in
                    settings.FormColumns)
                {
                    int rowIndex =
                        _formColumnsGrid.Rows.Add();

                    DataGridViewRow row =
                        _formColumnsGrid.Rows[rowIndex];


                    row.Cells["Name"].Value =
                        column.Name;

                    row.Cells["ExcelCell"].Value =
                        column.ExcelCell;
                }
            }


            RefreshFormColumnOrder();
        }
        public GeneraVerbaliModalitaStlSettings GetSettings()
        {
            _propertiesGrid.EndEdit();
            _formColumnsGrid.EndEdit();


            GeneraVerbaliModalitaStlSettings settings =
                new GeneraVerbaliModalitaStlSettings
                {
                    OutputStartPath =
                        _outputStartPathTextBox.Text.Trim(),

                    DeterminingAttribute =
                        _determiningAttributeTextBox.Text.Trim(),

                    OutputEndPath =
                        _outputEndPathTextBox.Text.Trim()
                };


            /*
             * ==========================================
             * PROPRIETÀ
             * ==========================================
             */
            foreach (DataGridViewRow row in
                _propertiesGrid.Rows)
            {
                string textBoxName =
                    Convert.ToString(
                        row.Cells["TextBoxName"].Value)
                    ?.Trim()
                    ?? string.Empty;

                string textBoxText =
                    Convert.ToString(
                        row.Cells["TextBoxText"].Value)
                    ?.Trim()
                    ?? string.Empty;

                string excelCell =
                    Convert.ToString(
                        row.Cells["ExcelCell"].Value)
                    ?.Trim()
                    ?? string.Empty;


                bool isInventorProperty =
                    Convert.ToBoolean(
                        row.Cells["IsInventorProperty"].Value
                        ?? false);


                /*
                 * Una riga completamente vuota
                 * non viene salvata.
                 */
                if (string.IsNullOrWhiteSpace(textBoxName) &&
                    string.IsNullOrWhiteSpace(textBoxText) &&
                    string.IsNullOrWhiteSpace(excelCell) &&
                    !isInventorProperty)
                {
                    continue;
                }


                settings.Properties.Add(
                    new GeneraVerbaliStlPropertySetting
                    {
                        TextBoxName =
                            textBoxName,

                        TextBoxText =
                            textBoxText,

                        ExcelCell =
                            excelCell,

                        IsInventorProperty =
                            isInventorProperty
                    });
            }


            /*
             * ==========================================
             * COLONNE FORM STL
             * ==========================================
             */
            foreach (DataGridViewRow row in
                _formColumnsGrid.Rows)
            {
                string columnName =
                    Convert.ToString(
                        row.Cells["Name"].Value)
                    ?.Trim()
                    ?? string.Empty;

                string excelCell =
                    Convert.ToString(
                        row.Cells["ExcelCell"].Value)
                    ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(columnName) &&
                    string.IsNullOrWhiteSpace(excelCell))
                {
                    continue;
                }


                settings.FormColumns.Add(
                    new GeneraVerbaliStlFormColumnSetting
                    {
                        Name =
                            columnName,

                        ExcelCell =
                            excelCell
                    });
            }


            return settings;
        }
    }
}