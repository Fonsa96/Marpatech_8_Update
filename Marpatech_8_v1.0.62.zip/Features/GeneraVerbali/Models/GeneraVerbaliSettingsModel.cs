﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraVerbali.Models
{
    public sealed class GeneraVerbaliSettingsModel
    {
        public string TemplatePath { get; set; } =
            string.Empty;

        public GeneraVerbaliModalitaLSettings ModalitaL { get; set; } =
            new GeneraVerbaliModalitaLSettings();

        public GeneraVerbaliModalitaStlSettings ModalitaSTL { get; set; } =
            new GeneraVerbaliModalitaStlSettings();
    }


    public sealed class GeneraVerbaliModalitaLSettings
    {
        public List<string> Columns { get; set; } =
            new List<string>();
    }


    public sealed class GeneraVerbaliModalitaStlSettings
    {
        public string OutputStartPath { get; set; } =
            string.Empty;

        public string DeterminingAttribute { get; set; } =
            string.Empty;

        public string OutputEndPath { get; set; } =
            string.Empty;


        public List<GeneraVerbaliStlPropertySetting> Properties { get; set; } =
            new List<GeneraVerbaliStlPropertySetting>();


        public List<GeneraVerbaliStlFormColumnSetting> FormColumns { get; set; } =
            new List<GeneraVerbaliStlFormColumnSetting>();
    }


    public sealed class GeneraVerbaliStlPropertySetting
    {
        public string TextBoxName { get; set; } =
            string.Empty;

        public string TextBoxText { get; set; } =
            string.Empty;

        public string ExcelCell { get; set; } =
            string.Empty;

        public bool IsInventorProperty { get; set; }
    }


    public sealed class GeneraVerbaliStlFormColumnSetting
    {
        public string Name { get; set; } =
            string.Empty;

        public string ExcelCell { get; set; } =
            string.Empty;
    }
}