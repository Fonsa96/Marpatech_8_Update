﻿using Marpatech_8.Features.Core.Inventor;
using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public sealed class GeneraVerbaliModalitaLSession
    {
        /*
         * Percorso del MAIN dal quale è partita
         * la Modalità L.
         *
         * Serve SOLO per riattivarlo.
         *
         * MAIN NON viene modificato.
         * MAIN NON viene salvato.
         */
        public string MainAssemblyPath { get; set; } =
            string.Empty;


        /*
         * STL trovati nel MAIN,
         * mantenuti nello stesso ordine
         * inserito dall'utente nel Form L.
         */
        public List<InventorService.InventorCustomCodeMatch>
            StlItems
        { get; set; } =
                new();


        /*
         * Indice dello STL attualmente
         * in elaborazione.
         */
        public int CurrentIndex { get; set; }


        /*
         * DATI_COLLAUDO_PRODOTTI costruito
         * UNA SOLA VOLTA dal Form L.
         *
         * Rimane in memoria durante tutta
         * la sequenza e viene scritto nello
         * STL solamente quando quello specifico
         * STL viene aperto.
         */
        public string ProductsData { get; set; } =
            string.Empty;


        /*
         * Unica istanza Excel condivisa
         * durante tutta la Modalità L.
         */
        public GeneraVerbaliExcelSession ExcelSession { get; set; } =
            null!;


        public bool HasCurrentItem =>
            CurrentIndex >= 0 &&
            CurrentIndex < StlItems.Count;


        public InventorService.InventorCustomCodeMatch?
            CurrentItem =>
                HasCurrentItem
                    ? StlItems[CurrentIndex]
                    : null;


        public bool IsLastItem =>
            HasCurrentItem &&
            CurrentIndex ==
                StlItems.Count - 1;
    }
}