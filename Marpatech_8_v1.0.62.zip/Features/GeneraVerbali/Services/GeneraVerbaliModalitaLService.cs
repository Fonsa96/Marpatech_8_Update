﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public static class GeneraVerbaliModalitaLService
    {
        public static List<string> ParseStlCodes(
            string? text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return new List<string>();
            }

            return text
                .Split(
                    ',',
                    StringSplitOptions.RemoveEmptyEntries)
                .Select(code =>
                    code.Trim())
                .Where(code =>
                    !string.IsNullOrWhiteSpace(code))
                .Distinct(
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }


        public static string BuildProductsData(
            DataGridView grid)
        {
            List<string> values =
                new List<string>();

            foreach (DataGridViewRow row
                in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                bool rowContainsValue =
                    false;

                for (int columnIndex = 0;
                    columnIndex < grid.Columns.Count;
                    columnIndex++)
                {
                    object? cellValue =
                        row.Cells[columnIndex].Value;

                    string value =
                        cellValue?.ToString() ??
                        string.Empty;

                    if (!string.IsNullOrWhiteSpace(
                        value))
                    {
                        rowContainsValue =
                            true;

                        break;
                    }
                }

                /*
                 * Riga completamente vuota:
                 * non viene salvata.
                 */
                if (!rowContainsValue)
                    continue;

                /*
                 * Riga utilizzata:
                 * vengono salvate tutte le celle,
                 * comprese quelle vuote.
                 */
                for (int columnIndex = 0;
                    columnIndex < grid.Columns.Count;
                    columnIndex++)
                {
                    object? cellValue =
                        row.Cells[columnIndex].Value;

                    string value =
                        cellValue?.ToString() ??
                        string.Empty;

                    values.Add(
                        value);
                }
            }

            return string.Join(
                "|",
                values);
        }
        public static List<string> ParseProductsData(
    string? data)
        {
            if (string.IsNullOrEmpty(data))
            {
                return new List<string>();
            }

            /*
             * IMPORTANTISSIMO:
             *
             * StringSplitOptions.None mantiene anche
             * le celle vuote.
             *
             * Esempio:
             *
             * A||2
             *
             * diventa:
             *
             * [A]
             * []
             * [2]
             */
            return data
                .Split(
                    '|',
                    StringSplitOptions.None)
                .ToList();
        }
    }
}