﻿using Marpatech_8.Features.GeneraVerbali.Models;
using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public static class GeneraVerbaliSettingsService
    {

        public static GeneraVerbaliSettingsModel Load()
        {
            try
            {
                string path =
                    GetSettingsFilePath();

                if (!File.Exists(path))
                {
                    return CreateDefault();
                }


                string json =
                    File.ReadAllText(
                        path);


                GeneraVerbaliSettingsModel? settings =
                    JsonSerializer.Deserialize<GeneraVerbaliSettingsModel>(
                        json);


                if (settings == null)
                {
                    return CreateDefault();
                }


                settings.ModalitaL ??=
                    new GeneraVerbaliModalitaLSettings();

                settings.ModalitaL.Columns ??=
                    new();

                settings.ModalitaSTL ??=
    new GeneraVerbaliModalitaStlSettings();

                settings.ModalitaSTL.Properties ??=
                    new();

                settings.ModalitaSTL.FormColumns ??=
                    new();


                return settings;
            }
            catch
            {
                return CreateDefault();
            }
        }


        public static void Save(
            GeneraVerbaliSettingsModel settings)
        {
            if (settings == null)
                return;


            string path =
                GetSettingsFilePath();


            string? folder =
                Path.GetDirectoryName(
                    path);


            if (!string.IsNullOrWhiteSpace(
                folder))
            {
                Directory.CreateDirectory(
                    folder);
            }


            JsonSerializerOptions options =
                new JsonSerializerOptions
                {
                    WriteIndented =
                        true
                };


            string json =
                JsonSerializer.Serialize(
                    settings,
                    options);


            File.WriteAllText(
                path,
                json);
        }


        public static string GetSettingsFilePath()
        {
            string appDataRoaming =
                Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

            string settingsFolder =
                Path.Combine(
                    appDataRoaming,
                    "Marpatech",
                    "Settings");

            return Path.Combine(
                settingsFolder,
                "GeneraVerbali.json");
        }


        private static GeneraVerbaliSettingsModel CreateDefault()
        {
            return new GeneraVerbaliSettingsModel();
        }
    }
}