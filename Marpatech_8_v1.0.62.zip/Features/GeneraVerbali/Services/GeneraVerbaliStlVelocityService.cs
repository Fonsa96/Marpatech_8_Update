﻿using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public static class GeneraVerbaliStlVelocityService
    {
        public const double MotorRpm =
    1415.0;


        /*
         * ==========================================
         * PROPRIETÀ INVENTOR SELEZIONI
         * ==========================================
         *
         * Modificare SOLO questi nomi quando
         * avremo conferma delle iProperties reali.
         */
        public const string MotorReductionPropertyName =
            "RAPPORTO DI RID";

        public const string PrimitiveDiameterPropertyName =
            "D PRIMITIVO_S";


        /*
         * Proprietà dell'assieme STL corrente.
         */
        public const string BeltSpeedPropertyName =
            "VELOCITA  MT_MIN";


        public static bool TryExtractReductionRatio(
            string? description,
            out string value)
        {
            value =
                string.Empty;

            if (string.IsNullOrWhiteSpace(
                description))
            {
                return false;
            }


            /*
             * Accetta ad esempio:
             *
             * i=25
             * I=25
             * i = 25
             * i=25,5
             * i=25.5
             */
            Match match =
                Regex.Match(
                    description,
                    @"(?i)\bi\s*=\s*(\d+(?:[.,]\d+)?)");


            if (!match.Success)
                return false;


            value =
                match.Groups[1]
                    .Value
                    .Trim();


            return !string.IsNullOrWhiteSpace(
                value);
        }


        public static bool TryExtractPrimitiveDiameter(
            string? propertyValue,
            out string value)
        {
            value =
                string.Empty;

            if (string.IsNullOrWhiteSpace(
                propertyValue))
            {
                return false;
            }


            string rawValue =
                propertyValue.Trim();


            /*
             * Esempio:
             *
             * 250_80
             *
             * interessa solamente:
             *
             * 250
             */
            int separatorIndex =
                rawValue.IndexOf(
                    '_');


            if (separatorIndex >= 0)
            {
                rawValue =
                    rawValue.Substring(
                        0,
                        separatorIndex)
                    .Trim();
            }


            /*
             * Verifichiamo che la parte ottenuta
             * sia realmente numerica.
             */
            string normalized =
                rawValue.Replace(
                    ',',
                    '.');


            if (!double.TryParse(
                normalized,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out _))
            {
                return false;
            }


            value =
                rawValue;

            return true;
        }


        public static bool TryParseNumber(
            string? text,
            out double value)
        {
            value =
                0;


            if (string.IsNullOrWhiteSpace(
                text))
            {
                return false;
            }


            string normalized =
                text
                    .Trim()
                    .Replace(
                        ',',
                        '.');


            return double.TryParse(
                normalized,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value);
        }
        public static bool TryCalculateBeltSpeed(
    double reductionRatio,
    double primitiveDiameterMm,
    out double beltSpeed)
        {
            beltSpeed =
                0;


            if (reductionRatio <= 0)
                return false;

            if (primitiveDiameterMm <= 0)
                return false;


            double outputRpm =
                MotorRpm /
                reductionRatio;


            double circumferenceMeters =
                Math.PI *
                primitiveDiameterMm /
                1000.0;


            beltSpeed =
                outputRpm *
                circumferenceMeters;


            return true;
        }
    }
}