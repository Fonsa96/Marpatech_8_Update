﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public static class GeneraVerbaliGridLayoutService
    {
        private sealed class GridLayoutModel
        {
            public Dictionary<string, List<int>>
                RowHeights
            { get; set; } =
                    new();
        }


        private static string GetSettingsPath()
        {
            string folder =
                Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.ApplicationData),
                    "Marpatech",
                    "Settings");


            Directory.CreateDirectory(
                folder);


            return Path.Combine(
                folder,
                "GeneraVerbaliGridLayout.json");
        }


        public static void SaveRowHeights(
            string key,
            DataGridView grid)
        {
            if (string.IsNullOrWhiteSpace(key) ||
                grid == null)
            {
                return;
            }


            try
            {
                GridLayoutModel model =
                    LoadModel();


                List<int> heights =
                    new();


                foreach (DataGridViewRow row
                    in grid.Rows)
                {
                    if (row.IsNewRow)
                        continue;


                    heights.Add(
                        row.Height);
                }


                model.RowHeights[key] =
                    heights;


                string json =
                    JsonSerializer.Serialize(
                        model,
                        new JsonSerializerOptions
                        {
                            WriteIndented =
                                true
                        });


                File.WriteAllText(
                    GetSettingsPath(),
                    json);
            }
            catch
            {
            }
        }


        public static void ApplyRowHeights(
            string key,
            DataGridView grid)
        {
            if (string.IsNullOrWhiteSpace(key) ||
                grid == null)
            {
                return;
            }


            try
            {
                GridLayoutModel model =
                    LoadModel();


                if (!model.RowHeights.TryGetValue(
                    key,
                    out List<int>? heights))
                {
                    return;
                }


                int count =
                    Math.Min(
                        heights.Count,
                        grid.Rows.Count);


                for (int i = 0;
                     i < count;
                     i++)
                {
                    if (heights[i] <= 0)
                        continue;


                    grid.Rows[i].Height =
                        heights[i];
                }
            }
            catch
            {
            }
        }


        private static GridLayoutModel LoadModel()
        {
            try
            {
                string path =
                    GetSettingsPath();


                if (!File.Exists(path))
                {
                    return new GridLayoutModel();
                }


                string json =
                    File.ReadAllText(
                        path);


                return JsonSerializer.Deserialize<GridLayoutModel>(
                           json)
                       ?? new GridLayoutModel();
            }
            catch
            {
                return new GridLayoutModel();
            }
        }
    }
}