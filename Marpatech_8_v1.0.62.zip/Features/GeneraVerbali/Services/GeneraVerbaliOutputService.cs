﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public static class GeneraVerbaliOutputService
    {
        public static bool TryResolveOutputFolder(
            string startPath,
            string determiningValue,
            string endPath,
            out string outputFolder,
            out string errorMessage)
        {
            outputFolder =
                string.Empty;

            errorMessage =
                string.Empty;


            if (string.IsNullOrWhiteSpace(
                startPath))
            {
                errorMessage =
                    "Il percorso iniziale OUTPUT non è configurato.";

                return false;
            }


            if (!Directory.Exists(
                startPath))
            {
                errorMessage =
                    "Il percorso iniziale OUTPUT non esiste:\r\n\r\n" +
                    startPath;

                return false;
            }


            if (string.IsNullOrWhiteSpace(
                determiningValue))
            {
                errorMessage =
                    "L'attributo determinante non contiene alcun valore.";

                return false;
            }


            string? matchingFolder =
                Directory
                    .EnumerateDirectories(
                        startPath)
                    .FirstOrDefault(folder =>
                    {
                        string folderName =
                            Path.GetFileName(
                                folder);

                        return folderName.Contains(
                            determiningValue,
                            StringComparison.OrdinalIgnoreCase);
                    });


            if (matchingFolder == null)
            {
                errorMessage =
                    "Non è stata trovata nel percorso iniziale " +
                    "una cartella contenente:\r\n\r\n" +
                    determiningValue;

                return false;
            }


            outputFolder =
                string.IsNullOrWhiteSpace(
                    endPath)
                    ? matchingFolder
                    : Path.Combine(
                        matchingFolder,
                        endPath.Trim()
                            .TrimStart(
                                '\\',
                                '/'));


            if (!Directory.Exists(
                outputFolder))
            {
                errorMessage =
                    "La cartella finale OUTPUT non esiste:\r\n\r\n" +
                    outputFolder;

                return false;
            }


            return true;
        }


        public static bool TryCopyTemplate(
           string templatePath,
           string outputFolder,
           string finalFileNameWithoutExtension,
           bool overwriteExisting,
           out string generatedFilePath,
           out string errorMessage)
        {
            generatedFilePath =
                string.Empty;

            errorMessage =
                string.Empty;


            if (string.IsNullOrWhiteSpace(
                templatePath))
            {
                errorMessage =
                    "Percorso template non valido.";

                return false;
            }


            if (!File.Exists(
                templatePath))
            {
                errorMessage =
                    "Il template configurato non esiste:\r\n\r\n" +
                    templatePath;

                return false;
            }


            if (string.IsNullOrWhiteSpace(
                outputFolder))
            {
                errorMessage =
                    "Cartella di output non valida.";

                return false;
            }


            if (!Directory.Exists(
                outputFolder))
            {
                errorMessage =
                    "La cartella di output non esiste:\r\n\r\n" +
                    outputFolder;

                return false;
            }


            if (string.IsNullOrWhiteSpace(
                finalFileNameWithoutExtension))
            {
                errorMessage =
                    "Nome del verbale non valido.";

                return false;
            }


            try
            {
                string extension =
                    Path.GetExtension(
                        templatePath);


                generatedFilePath =
                    Path.Combine(
                        outputFolder,
                        finalFileNameWithoutExtension +
                        extension);


                /*
                 * ==========================================
                 * FILE GIÀ ESISTENTE
                 * ==========================================
                 */
                if (File.Exists(
                    generatedFilePath))
                {
                    if (!overwriteExisting)
                    {
                        errorMessage =
                            "FILE_ALREADY_EXISTS";

                        return false;
                    }


                    /*
                     * Prima della cancellazione togliamo
                     * eventualmente la sola lettura.
                     */
                    RemoveReadOnlyAttribute(
                        generatedFilePath);


                    File.Delete(
                        generatedFilePath);
                }


                /*
                 * ==========================================
                 * COPIA TEMPLATE
                 * ==========================================
                 */
                File.Copy(
                    templatePath,
                    generatedFilePath,
                    false);


                /*
                 * ==========================================
                 * REGOLA FONDAMENTALE
                 * ==========================================
                 *
                 * Il file generato NON deve mai rimanere
                 * in sola lettura, anche se il template
                 * originale aveva quell'attributo.
                 */
                RemoveReadOnlyAttribute(
                    generatedFilePath);


                /*
                 * Verifica finale.
                 */
                FileAttributes finalAttributes =
                    File.GetAttributes(
                        generatedFilePath);


                if ((finalAttributes &
                    FileAttributes.ReadOnly) != 0)
                {
                    errorMessage =
                        "Il verbale è stato copiato, ma non è stato " +
                        "possibile rimuovere l'attributo di sola lettura:\r\n\r\n" +
                        generatedFilePath;

                    return false;
                }


                return true;
            }
            catch (UnauthorizedAccessException)
            {
                errorMessage =
                    "Accesso negato durante la creazione del verbale:\r\n\r\n" +
                    generatedFilePath +
                    "\r\n\r\n" +
                    "Verifica i permessi di modifica sulla cartella.";

                return false;
            }
            catch (IOException)
            {
                errorMessage =
                    "Non è possibile creare o sostituire il verbale:\r\n\r\n" +
                    generatedFilePath +
                    "\r\n\r\n" +
                    "Il file potrebbe essere aperto o utilizzato da un altro programma.";

                return false;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Errore durante la creazione del verbale:\r\n\r\n" +
                    ex.Message;

                return false;
            }
        }

        private static void RemoveReadOnlyAttribute(
    string filePath)
        {
            if (string.IsNullOrWhiteSpace(
                filePath))
            {
                return;
            }


            if (!File.Exists(
                filePath))
            {
                return;
            }


            FileAttributes attributes =
                File.GetAttributes(
                    filePath);


            if ((attributes &
                FileAttributes.ReadOnly) == 0)
            {
                return;
            }


            File.SetAttributes(
                filePath,
                attributes &
                ~FileAttributes.ReadOnly);
        }




        public static bool TryOpenFolder(
            string folderPath)
        {
            try
            {
                if (!Directory.Exists(
                    folderPath))
                {
                    return false;
                }


                Process.Start(
                    new ProcessStartInfo
                    {
                        FileName =
                            "explorer.exe",

                        Arguments =
                            "\"" +
                            folderPath +
                            "\"",

                        UseShellExecute =
                            true
                    });


                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}