﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public sealed class GeneraVerbaliExcelSession :
        IDisposable
    {
        private dynamic? _excel;
        private dynamic? _workbook;
        private dynamic? _worksheet;


        public bool IsStarted =>
            _excel != null;


        public bool HasWorkbook =>
            _workbook != null;


        public bool Start(
            out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_excel != null)
                return true;


            try
            {
                Type? excelType =
                    Type.GetTypeFromProgID(
                        "Excel.Application");


                if (excelType == null)
                {
                    errorMessage =
                        "Microsoft Excel non è disponibile.";

                    return false;
                }


                _excel =
                    Activator.CreateInstance(
                        excelType);


                if (_excel == null)
                {
                    errorMessage =
                        "Impossibile avviare Microsoft Excel.";

                    return false;
                }


                _excel.Visible =
                    false;

                _excel.DisplayAlerts =
                    false;


                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }


        public bool OpenWorkbook(
          string filePath,
          out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_excel == null)
            {
                errorMessage =
                    "Excel non è stato avviato.";

                return false;
            }


            if (string.IsNullOrWhiteSpace(
                filePath))
            {
                errorMessage =
                    "Percorso del verbale Excel non valido.";

                return false;
            }


            if (!File.Exists(
                filePath))
            {
                errorMessage =
                    "Il verbale Excel non esiste:\r\n\r\n" +
                    filePath;

                return false;
            }


            try
            {
                CloseCurrentWorkbook(
                    false);


                /*
                 * ==========================================
                 * RIMOZIONE SOLA LETTURA PRIMA DELL'APERTURA
                 * ==========================================
                 */
                FileAttributes attributes =
                    File.GetAttributes(
                        filePath);


                if ((attributes &
                    FileAttributes.ReadOnly) != 0)
                {
                    File.SetAttributes(
                        filePath,
                        attributes &
                        ~FileAttributes.ReadOnly);
                }


                /*
                 * Verifica effettiva.
                 */
                FileAttributes finalAttributes =
                    File.GetAttributes(
                        filePath);


                if ((finalAttributes &
                    FileAttributes.ReadOnly) != 0)
                {
                    errorMessage =
                        "Il verbale risulta ancora in sola lettura:\r\n\r\n" +
                        filePath;

                    return false;
                }


                /*
                 * ==========================================
                 * APERTURA ESPLICITAMENTE NON READ-ONLY
                 * ==========================================
                 *
                 * Workbooks.Open:
                 * 1 = Filename
                 * 2 = UpdateLinks
                 * 3 = ReadOnly
                 */
                _workbook =
                    _excel.Workbooks.Open(
                        filePath,
                        0,
                        false);


                /*
                 * Ulteriore controllo lato Excel.
                 */
                bool workbookReadOnly =
                    false;

                try
                {
                    workbookReadOnly =
                        _workbook.ReadOnly;
                }
                catch
                {
                }


                if (workbookReadOnly)
                {
                    _workbook.Close(
                        false);

                    ReleaseComObject(
                        _workbook);

                    _workbook =
                        null;


                    errorMessage =
                        "Excel ha aperto il verbale in sola lettura:\r\n\r\n" +
                        filePath +
                        "\r\n\r\n" +
                        "Verifica che il file non sia già aperto " +
                        "da un altro utente o da un'altra istanza di Excel.";

                    return false;
                }


                _worksheet =
                    _workbook.Worksheets[1];


                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Impossibile aprire il verbale Excel:\r\n\r\n" +
                    ex.Message;

                return false;
            }
        }


        public bool WriteValue(
            string configuredCell,
            string value,
            out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_worksheet == null)
            {
                errorMessage =
                    "Foglio Excel non disponibile.";

                return false;
            }


            if (!GeneraVerbaliExcelCellService
                .TryParse(
                    configuredCell,
                    out GeneraVerbaliExcelCellReference reference))
            {
                errorMessage =
                    "Riferimento Excel non valido: " +
                    configuredCell;

                return false;
            }


            return WriteExcelAddress(
                reference.ToExcelAddress(),
                value,
                out errorMessage);
        }


        public bool WriteTableValue(
            string configuredCell,
            int tableRowIndex,
            string value,
            out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_worksheet == null)
            {
                errorMessage =
                    "Foglio Excel non disponibile.";

                return false;
            }


            if (!GeneraVerbaliExcelCellService
                .TryParse(
                    configuredCell,
                    out GeneraVerbaliExcelCellReference reference))
            {
                errorMessage =
                    "Riferimento Excel non valido: " +
                    configuredCell;

                return false;
            }


            string address =
                reference
                    .ToExcelAddressForTableRow(
                        tableRowIndex);


            return WriteExcelAddress(
                address,
                value,
                out errorMessage);
        }


        private bool WriteExcelAddress(
      string address,
      string value,
      out string errorMessage)
        {
            errorMessage =
                string.Empty;

            dynamic? range =
                null;


            /*
             * Copiamo il riferimento in una variabile
             * locale dopo il controllo null.
             *
             * In questo modo evitiamo anche il warning
             * nullable CS8602.
             */
            dynamic? worksheet =
                _worksheet;


            if (worksheet == null)
            {
                errorMessage =
                    "Foglio Excel non disponibile.";

                return false;
            }


            try
            {
                range =
                    worksheet.Range[
                        address];


                /*
                 * Anche per una cella unita scriviamo
                 * nella prima cella dell'area.
                 */
                range.Cells[1, 1].Value2 =
                    value ?? string.Empty;


                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Errore scrittura Excel in " +
                    address +
                    ":\r\n\r\n" +
                    ex.Message;

                return false;
            }
            finally
            {
                ReleaseComObject(
                    range);
            }
        }

        public void ShowExcel()
        {
            if (_excel == null)
                return;

            try
            {
                _excel.Visible =
                    true;

                _excel.UserControl =
                    true;
            }
            catch
            {
            }
        }


        public void HideExcel()
        {
            if (_excel == null)
                return;

            try
            {
                _excel.Visible =
                    false;
            }
            catch
            {
            }
        }


        public bool PrintCurrentWorkbook(
            out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_workbook == null)
            {
                errorMessage =
                    "Nessun verbale Excel aperto.";

                return false;
            }


            try
            {
                _workbook.PrintOut();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }


        public bool SaveCurrentWorkbook(
            out string errorMessage)
        {
            errorMessage =
                string.Empty;


            if (_workbook == null)
            {
                errorMessage =
                    "Nessun verbale Excel aperto.";

                return false;
            }


            try
            {
                _workbook.Save();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage =
                    ex.Message;

                return false;
            }
        }


        public void CloseCurrentWorkbook(
            bool saveChanges)
        {
            if (_workbook == null)
                return;


            try
            {
                _workbook.Close(
                    saveChanges);
            }
            catch
            {
            }


            ReleaseComObject(
                _worksheet);

            _worksheet =
                null;


            ReleaseComObject(
                _workbook);

            _workbook =
                null;
        }


        public void QuitExcel()
        {
            CloseCurrentWorkbook(
                false);


            if (_excel == null)
                return;


            try
            {
                _excel.Quit();
            }
            catch
            {
            }


            ReleaseComObject(
                _excel);

            _excel =
                null;


            GC.Collect();

            GC.WaitForPendingFinalizers();

            GC.Collect();

            GC.WaitForPendingFinalizers();
        }


        private static void ReleaseComObject(
            object? value)
        {
            if (value == null)
                return;


            try
            {
                if (Marshal.IsComObject(
                    value))
                {
                    Marshal.FinalReleaseComObject(
                        value);
                }
            }
            catch
            {
            }
        }


        public void Dispose()
        {
            QuitExcel();
        }
    }
}