﻿using System;
using System.Text.RegularExpressions;

namespace Marpatech_8.Features.GeneraVerbali.Services
{
    public sealed class GeneraVerbaliExcelCellReference
    {
        public string StartColumn { get; set; } =
            string.Empty;

        public string EndColumn { get; set; } =
            string.Empty;

        public int StartRow { get; set; }

        public int EndRow { get; set; }

        public int RowHeight =>
            EndRow - StartRow + 1;


        public string ToExcelAddress()
        {
            string start =
                StartColumn +
                StartRow;

            string end =
                EndColumn +
                EndRow;

            if (string.Equals(
                start,
                end,
                StringComparison.OrdinalIgnoreCase))
            {
                return start;
            }

            return start +
                ":" +
                end;
        }


        public string ToExcelAddressForTableRow(
            int tableRowIndex)
        {
            int offset =
                tableRowIndex *
                RowHeight;

            int startRow =
                StartRow +
                offset;

            int endRow =
                EndRow +
                offset;

            string start =
                StartColumn +
                startRow;

            string end =
                EndColumn +
                endRow;

            if (string.Equals(
                start,
                end,
                StringComparison.OrdinalIgnoreCase))
            {
                return start;
            }

            return start +
                ":" +
                end;
        }
    }


    public static class GeneraVerbaliExcelCellService
    {
        public static bool TryParse(
            string? text,
            out GeneraVerbaliExcelCellReference reference)
        {
            reference =
                new GeneraVerbaliExcelCellReference();


            if (string.IsNullOrWhiteSpace(
                text))
            {
                return false;
            }


            string normalized =
                text
                    .Trim()
                    .ToUpperInvariant()
                    .Replace(" ", "");


            Match match =
                Regex.Match(
                    normalized,
                    @"^([A-Z]+)(?:/([A-Z]+))?-(\d+)(?:/(\d+))?$");


            if (!match.Success)
                return false;


            string startColumn =
                match.Groups[1]
                    .Value;

            string endColumn =
                match.Groups[2].Success
                    ? match.Groups[2].Value
                    : startColumn;


            if (!int.TryParse(
                match.Groups[3].Value,
                out int startRow))
            {
                return false;
            }


            int endRow =
                startRow;


            if (match.Groups[4].Success &&
                !int.TryParse(
                    match.Groups[4].Value,
                    out endRow))
            {
                return false;
            }


            if (startRow <= 0 ||
                endRow < startRow)
            {
                return false;
            }


            reference =
                new GeneraVerbaliExcelCellReference
                {
                    StartColumn =
                        startColumn,

                    EndColumn =
                        endColumn,

                    StartRow =
                        startRow,

                    EndRow =
                        endRow
                };


            return true;
        }
    }
}