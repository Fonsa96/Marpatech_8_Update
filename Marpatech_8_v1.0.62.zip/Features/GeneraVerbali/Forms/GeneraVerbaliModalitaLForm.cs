﻿using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.GeneraVerbali.Services;
using Marpatech_8.Features.Mail;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using InventorApplication = global::Inventor.Application;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliModalitaLForm : Form
    {
        private readonly InventorApplication
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        private TextBox
            _stlTextBox = null!;

        private DataGridView
            _dataGrid = null!;

        private GeneraVerbaliCheckoutPromptForm?
    _checkoutPromptForm;

        private bool
            _modalitaLProcessing;

        private GeneraVerbaliModalitaLSession?
    _modalitaLSession;


        public GeneraVerbaliModalitaLForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliModalitaL",
                    1000,
                    700);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            BuildConfiguredColumns();

            CreateInitialRows();

            GeneraVerbaliGridLayoutService
            .ApplyRowHeights(
                "ModalitaL",
                _dataGrid);
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(241, 245, 249);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Text =
                "Genera Verbali - Modalità L";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    850,
                    600);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliModalitaLForm_FormClosing;

            Label stlTitleLabel =
    new Label
    {
        Text =
            "Gestione STL",

        Font =
            new Font(
                "Segoe UI",
                11F,
                FontStyle.Bold),

        ForeColor =
            textColor,

        AutoSize =
            true,

        Location =
            new Point(
                30,
                25)
    };


            /*
             * ==========================================
             * TEXTBOX STL
             * ==========================================
             */
            _stlTextBox =
                new TextBox
                {
                    PlaceholderText =
                        "Scrivi qui gli STL da gestire separandoli con una virgola",

                    Location =
                        new Point(
                            30,
                            50),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            34),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F),

                    TabIndex =
                         0,

                };


            /*
             * ==========================================
             * SEPARATORE SUPERIORE
             * ==========================================
             */
            Panel separatorTop =
                new Panel
                {
                    Location =
                        new Point(
                            30,
                            105),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            1),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        borderColor
                };

            Label tableTitleLabel =
    new Label
    {
        Text =
            "Tabella prodotti in Comune",

        Font =
            new Font(
                "Segoe UI",
                11F,
                FontStyle.Bold),

        ForeColor =
            textColor,

        AutoSize =
            true,

        Location =
            new Point(
                30,
                125)
    };


            /*
             * ==========================================
             * TABELLA
             * ==========================================
             */
            _dataGrid =
                new DataGridView
                {
                    Location =
                        new Point(
                            30,
                            158),

                                        Size =
                        new Size(
                            ClientSize.Width - 60,
                            ClientSize.Height - 328),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    AllowUserToAddRows =
                        false,

                    AllowUserToDeleteRows =
                        false,

                    AllowUserToResizeRows =
                         true,

                    RowHeadersVisible =
                        false,

                    AutoGenerateColumns =
                        false,

                    SelectionMode =
                        DataGridViewSelectionMode.FullRowSelect,

                    MultiSelect =
                        false,

                    BackgroundColor =
                        panelColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    GridColor =
                        borderColor,

                    EnableHeadersVisualStyles =
                        false,

                    EditMode =
                        DataGridViewEditMode.EditOnKeystrokeOrF2,

                        TabIndex =
                      1,

                    StandardTab =
                    false,
                };


            /*
             * ==========================================
             * STILE CELLE
             * ==========================================
             */
            _dataGrid.DefaultCellStyle.BackColor =
                panelColor;

            _dataGrid.DefaultCellStyle.ForeColor =
                textColor;

            _dataGrid.DefaultCellStyle.SelectionBackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            _dataGrid.DefaultCellStyle.SelectionForeColor =
                Color.White;

            _dataGrid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F);

            _dataGrid.DefaultCellStyle.Padding =
                new Padding(
                    4);


            _dataGrid.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            _dataGrid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                _dataGrid.ColumnHeadersDefaultCellStyle.BackColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            _dataGrid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold);

            _dataGrid.ColumnHeadersHeight =
                38;

            _dataGrid.RowTemplate.Height =
                34;


            /*
             * ==========================================
             * PULSANTI GESTIONE RIGHE
             * ==========================================
             */
            Button addRowButton =
                CreateSecondaryButton(
                    "Aggiungi riga",
                    30,
                    ClientSize.Height - 150,
                    125,
                    secondaryColor,
                    textColor,
                    borderColor);

            addRowButton.TabStop =
                false;

            addRowButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            addRowButton.Click +=
                AddRowButton_Click;


            Button removeRowButton =
                CreateSecondaryButton(
                    "Rimuovi",
                    165,
                    ClientSize.Height - 150,
                    95,
                    secondaryColor,
                    textColor,
                    borderColor);

            removeRowButton.TabStop =
                false;


            removeRowButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            removeRowButton.Click +=
                RemoveRowButton_Click;


            Button moveUpButton =
                CreateSecondaryButton(
                    "▲",
                    270,
                    ClientSize.Height - 150,
                    45,
                    secondaryColor,
                    textColor,
                    borderColor);

            moveUpButton.TabStop =
                 false;

            moveUpButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            moveUpButton.Click +=
                MoveUpButton_Click;


            Button moveDownButton =
                CreateSecondaryButton(
                    "▼",
                    325,
                    ClientSize.Height - 150,
                    45,
                    secondaryColor,
                    textColor,
                    borderColor);

            moveDownButton.TabStop =
                false;

            moveDownButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left;

            moveDownButton.Click +=
                MoveDownButton_Click;


            /*
             * ==========================================
             * SEPARATORE INFERIORE
             * ==========================================
             */
            Panel separatorBottom =
                new Panel
                {
                    Location =
                        new Point(
                            30,
                            ClientSize.Height - 100),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            1),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        borderColor
                };


            /*
             * ==========================================
             * AVVIA FUNZIONE
             * ==========================================
             */
            Button startButton =
                new Button
                {
                    Text =
                        "Avvia Funzione",

                    Location =
                        new Point(
                            30,
                            ClientSize.Height - 76),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            46),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            22,
                            163,
                            74),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            startButton.TabStop =
             false;

            startButton.FlatAppearance.BorderSize =
                0;

            startButton.Click +=
                StartButton_Click;


            Controls.Add(
                stlTitleLabel);

            Controls.Add(
                _stlTextBox);

            Controls.Add(
                separatorTop);

            Controls.Add(
                tableTitleLabel);

            Controls.Add(
                _dataGrid);

            Controls.Add(
                addRowButton);

            Controls.Add(
                removeRowButton);

            Controls.Add(
                moveUpButton);

            Controls.Add(
                moveDownButton);

            Controls.Add(
                separatorBottom);

            Controls.Add(
                startButton);
        }


        private Button CreateSecondaryButton(
            string text,
            int x,
            int y,
            int width,
            Color backgroundColor,
            Color textColor,
            Color borderColor)
        {
            Button button =
                new Button
                {
                    Text =
                        text,

                    Location =
                        new Point(
                            x,
                            y),

                    Size =
                        new Size(
                            width,
                            34),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        backgroundColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            button.FlatAppearance.BorderColor =
                borderColor;

            return button;
        }


        /*
         * ==========================================
         * COLONNE DA IMPOSTAZIONI
         * ==========================================
         */
        private void BuildConfiguredColumns()
        {
            _dataGrid.Columns.Clear();


            var settings =
                GeneraVerbaliSettingsService.Load();


            List<string> columns =
                settings.ModalitaL?.Columns
                ?? new List<string>();


            foreach (string columnName in columns)
            {
                if (string.IsNullOrWhiteSpace(
                    columnName))
                {
                    continue;
                }


                DataGridViewTextBoxColumn column =
                    new DataGridViewTextBoxColumn
                    {
                        HeaderText =
                            columnName,

                        Name =
                            Guid.NewGuid().ToString(),

                        SortMode =
                            DataGridViewColumnSortMode.NotSortable,

                        AutoSizeMode =
                            DataGridViewAutoSizeColumnMode.Fill
                    };


                _dataGrid.Columns.Add(
                    column);
            }
        }


        /*
         * ==========================================
         * 5 RIGHE INIZIALI
         * ==========================================
         */
        private void CreateInitialRows()
        {
            if (_dataGrid.Columns.Count == 0)
                return;


            for (int i = 0;
                 i < 5;
                 i++)
            {
                _dataGrid.Rows.Add();
            }
        }


        /*
         * ==========================================
         * AGGIUNGI
         * ==========================================
         */
        private void AddRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.Columns.Count == 0)
                return;


            int rowIndex =
                _dataGrid.Rows.Add();


            _dataGrid.ClearSelection();

            _dataGrid.Rows[rowIndex]
                .Selected =
                true;


            if (_dataGrid.Columns.Count > 0)
            {
                _dataGrid.CurrentCell =
                    _dataGrid.Rows[rowIndex]
                        .Cells[0];

                _dataGrid.BeginEdit(
                    true);
            }
        }


        /*
         * ==========================================
         * RIMUOVI
         * ==========================================
         */
        private void RemoveRowButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int index =
                _dataGrid.CurrentRow.Index;


            if (index < 0 ||
                index >= _dataGrid.Rows.Count)
            {
                return;
            }


            _dataGrid.Rows.RemoveAt(
                index);
        }


        /*
         * ==========================================
         * SPOSTA SU
         * ==========================================
         */
        private void MoveUpButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int currentIndex =
                _dataGrid.CurrentRow.Index;


            if (currentIndex <= 0)
                return;


            SwapRows(
                currentIndex,
                currentIndex - 1);
        }


        /*
         * ==========================================
         * SPOSTA GIÙ
         * ==========================================
         */
        private void MoveDownButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_dataGrid.CurrentRow == null)
                return;


            int currentIndex =
                _dataGrid.CurrentRow.Index;


            if (currentIndex < 0 ||
                currentIndex >=
                _dataGrid.Rows.Count - 1)
            {
                return;
            }


            SwapRows(
                currentIndex,
                currentIndex + 1);
        }


        /*
         * ==========================================
         * SCAMBIA CONTENUTO RIGHE
         * ==========================================
         */
        private void SwapRows(
            int sourceIndex,
            int destinationIndex)
        {
            _dataGrid.EndEdit();


            object?[] sourceValues =
                new object?[
                    _dataGrid.Columns.Count];


            object?[] destinationValues =
                new object?[
                    _dataGrid.Columns.Count];


            for (int columnIndex = 0;
                 columnIndex < _dataGrid.Columns.Count;
                 columnIndex++)
            {
                sourceValues[columnIndex] =
                    _dataGrid.Rows[sourceIndex]
                        .Cells[columnIndex]
                        .Value;

                destinationValues[columnIndex] =
                    _dataGrid.Rows[destinationIndex]
                        .Cells[columnIndex]
                        .Value;
            }


            for (int columnIndex = 0;
                 columnIndex < _dataGrid.Columns.Count;
                 columnIndex++)
            {
                _dataGrid.Rows[destinationIndex]
                    .Cells[columnIndex]
                    .Value =
                    sourceValues[columnIndex];

                _dataGrid.Rows[sourceIndex]
                    .Cells[columnIndex]
                    .Value =
                    destinationValues[columnIndex];
            }


            _dataGrid.ClearSelection();

            _dataGrid.Rows[destinationIndex]
                .Selected =
                true;

            _dataGrid.CurrentCell =
                _dataGrid.Rows[destinationIndex]
                    .Cells[0];
        }


        /*
         * ==========================================
         * AVVIA FUNZIONE
         * ==========================================
         */
        private void StartButton_Click(
            object? sender,
            EventArgs e)
        {
            if (_modalitaLProcessing)
                return;


            /*
             * Evitiamo più popup contemporaneamente.
             */
            if (_checkoutPromptForm != null &&
                !_checkoutPromptForm.IsDisposed)
            {
                _checkoutPromptForm.Show();

                _checkoutPromptForm.BringToFront();

                _checkoutPromptForm.Activate();

                return;
            }


            _checkoutPromptForm =
                new GeneraVerbaliCheckoutPromptForm(
                    _isDarkTheme);


            _checkoutPromptForm.Confirmed +=
                CheckoutPromptForm_Confirmed;


            _checkoutPromptForm.FormClosed +=
                (_, _) =>
                {
                    _checkoutPromptForm =
                        null;
                };


            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);


            /*
             * Show, NON ShowDialog.
             *
             * Inventor rimane completamente utilizzabile.
             */
            _checkoutPromptForm.Show(
                owner);
        }


        /*
         * ==========================================
         * WINDOW SETTINGS
         * ==========================================
         */
        private void GeneraVerbaliModalitaLForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            GeneraVerbaliGridLayoutService
                .SaveRowHeights(
                    "ModalitaL",
                    _dataGrid);

            WindowSettingsService.Save(
                this,
                "GeneraVerbaliModalitaL");
        }
        private void CheckoutPromptForm_Confirmed(
           object? sender,
           EventArgs e)
        {
            if (_modalitaLProcessing)
                return;

            if (_checkoutPromptForm != null &&
    !_checkoutPromptForm.IsDisposed)
            {
                _checkoutPromptForm.Close();

                _checkoutPromptForm =
                    null;
            }

            /*
             * Prima di tutto deve esserci
             * un assieme MAIN aperto in Inventor.
             */
            if (!InventorService.IsActiveDocumentAssembly(
                _inventorApp))
            {
                MessageBox.Show(
                    this,
                    "Apri un assieme in Inventor prima di avviare la funzione.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Leggiamo la lista STL richiesta.
             */
            List<string> requestedCodes =
                GeneraVerbaliModalitaLService.ParseStlCodes(
                    _stlTextBox.Text);


            if (requestedCodes.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Inserisci almeno un codice STL nella prima casella.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            /*
             * Costruiamo UNA SOLA VOLTA i dati
             * dei prodotti comuni.
             *
             * Questi dati vengono mantenuti in memoria
             * durante tutta la sessione L.
             *
             * NON vengono ancora scritti in nessun STL.
             */
            string productsData =
                GeneraVerbaliModalitaLService.BuildProductsData(
                    _dataGrid);


            try
            {
                _modalitaLProcessing =
                    true;


                /*
                 * Cerchiamo tutti gli STL richiesti
                 * all'interno del MAIN.
                 *
                 * Questa fase è solamente di ricerca.
                 * NON modifica nessun documento.
                 */
                List<InventorService.InventorCustomCodeMatch>
                    foundAssemblies =
                        InventorService
                            .FindAssembliesByCustomCode(
                                _inventorApp,
                                requestedCodes,
                                "CODICE");


                HashSet<string> foundCodes =
                    foundAssemblies
                        .Select(item =>
                            item.Code)
                        .ToHashSet(
                            StringComparer.OrdinalIgnoreCase);


                List<string> missingCodes =
                    requestedCodes
                        .Where(code =>
                            !foundCodes.Contains(code))
                        .ToList();


                /*
                 * Se manca anche un solo STL,
                 * la Modalità L non parte.
                 *
                 * Nessun file è stato modificato.
                 */
                if (missingCodes.Count > 0)
                {
                    string missingText =
                        string.Join(
                            "\r\n",
                            missingCodes.Select(
                                code =>
                                    "• " + code));


                    MessageBox.Show(
                        this,
                        "La Modalità L non può essere avviata perché " +
                        "i seguenti STL non sono stati trovati " +
                        "nell'assieme aperto:\r\n\r\n" +
                        missingText +
                        "\r\n\r\n" +
                        "Nessun STL è stato modificato.",
                        "Genera Verbali - Modalità L",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                /*
                 * IMPORTANTE:
                 *
                 * NON controlliamo più qui IsModifiable.
                 *
                 * NON scriviamo più qui
                 * DATI_COLLAUDO_PRODOTTI.
                 *
                 * Ogni STL verrà realmente aperto,
                 * controllato e modificato solamente
                 * quando arriverà il suo turno.
                 */


                /*
                 * Avviamo la sequenza conservando
                 * in memoria anche i prodotti comuni.
                 */
                StartModalitaLSequence(
                    foundAssemblies,
                    productsData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Si è verificato un errore durante " +
                    "la scansione dell'assieme.\r\n\r\n" +
                    ex.Message,
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                /*
                 * Questo flag protegge solamente
                 * l'avvio iniziale.
                 *
                 * La sessione vera e propria viene
                 * mantenuta da _modalitaLSession.
                 */
                _modalitaLProcessing =
                    false;
            }
        }
        private void StartModalitaLSequence(
            List<InventorService.InventorCustomCodeMatch>
                foundAssemblies,
            string productsData)
        {
            if (foundAssemblies.Count == 0)
                return;


            /*
             * Memorizziamo il MAIN prima
             * di aprire qualsiasi STL.
             */
            string mainAssemblyPath =
                InventorService
                    .GetDocumentFullFileName(
                        InventorService
                            .GetActiveAssembly(
                                _inventorApp));


            if (string.IsNullOrWhiteSpace(
                mainAssemblyPath))
            {
                MessageBox.Show(
                    this,
                    "Impossibile determinare il percorso dell'assieme MAIN.",
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }


            /*
             * Una sola istanza Excel per tutta
             * la sessione Modalità L.
             */
            GeneraVerbaliExcelSession excelSession =
                new GeneraVerbaliExcelSession();


            if (!excelSession.Start(
                out string excelError))
            {
                MessageBox.Show(
                    this,
                    "Impossibile avviare Excel.\r\n\r\n" +
                    excelError,
                    "Genera Verbali - Modalità L",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }


            excelSession.HideExcel();


            /*
             * Creiamo la sessione.
             *
             * ProductsData rimane solamente in memoria.
             */
            _modalitaLSession =
                new GeneraVerbaliModalitaLSession
                {
                    MainAssemblyPath =
                        mainAssemblyPath,

                    StlItems =
                        foundAssemblies,

                    CurrentIndex =
                        0,

                    ProductsData =
                        productsData,

                    ExcelSession =
                        excelSession
                };


            /*
             * MAIN:
             * - rimane aperto;
             * - non viene modificato;
             * - non viene salvato.
             *
             * Nascondiamo solamente il Form L.
             */
            Hide();


            OpenCurrentModalitaLStl();
        }
        private void OpenCurrentModalitaLStl()
        {
            if (_modalitaLSession == null)
                return;


            InventorService.InventorCustomCodeMatch?
                currentItem =
                    _modalitaLSession.CurrentItem;


            if (currentItem == null)
            {
                FinishModalitaLSequence();

                return;
            }


            /*
             * ==========================================
             * 1. RIATTIVAZIONE MAIN
             * ==========================================
             *
             * Prima di iniziare ogni STL torniamo
             * sempre al MAIN.
             *
             * MAIN non viene modificato né salvato.
             */
            if (!InventorService
                .OpenOrActivateDocumentByPath(
                    _inventorApp,
                    _modalitaLSession.MainAssemblyPath,
                    out string mainError))
            {
                AbortModalitaLSequence(
                    "Impossibile riattivare l'assieme MAIN.\r\n\r\n" +
                    mainError);

                return;
            }


            /*
             * ==========================================
             * 2. APERTURA STL CORRENTE
             * ==========================================
             */
            if (!InventorService
                .OpenOrActivateDocumentByPath(
                    _inventorApp,
                    currentItem.FullFileName,
                    out string stlError))
            {
                AbortModalitaLSequence(
                    "Impossibile aprire lo STL \"" +
                    currentItem.Code +
                    "\".\r\n\r\n" +
                    stlError);

                return;
            }


            /*
             * ==========================================
             * 3. RECUPERIAMO LO STL APPENA APERTO
             * ==========================================
             */
            global::Inventor.AssemblyDocument?
                currentStlAssembly =
                    InventorService.GetActiveAssembly(
                        _inventorApp);


            if (currentStlAssembly == null)
            {
                AbortModalitaLSequence(
                    "Lo STL \"" +
                    currentItem.Code +
                    "\" è stato aperto, ma non risulta " +
                    "l'assieme attivo in Inventor.");

                return;
            }


            /*
             * Controllo di sicurezza:
             * l'assieme attivo deve essere proprio
             * quello previsto.
             */
            string activeStlPath =
                InventorService
                    .GetDocumentFullFileName(
                        currentStlAssembly);


            if (!string.Equals(
                activeStlPath,
                currentItem.FullFileName,
                StringComparison.OrdinalIgnoreCase))
            {
                AbortModalitaLSequence(
                    "L'assieme attivo in Inventor non corrisponde " +
                    "allo STL previsto \"" +
                    currentItem.Code +
                    "\".");

                return;
            }


            /*
             * ==========================================
             * 4. SCRITTURA DATI_COLLAUDO_PRODOTTI
             * ==========================================
             *
             * Questa è la PRIMA volta in cui
             * modifichiamo questo STL.
             *
             * La proprietà viene scritta solamente
             * nello STL attualmente aperto.
             */
            if (!InventorService
                .TryWriteUserDefinedProperty(
                    currentStlAssembly,
                    "DATI_COLLAUDO_PRODOTTI",
                    _modalitaLSession.ProductsData,
                    out string productsWriteError))
            {
                AbortModalitaLSequence(
                    "Impossibile scrivere DATI_COLLAUDO_PRODOTTI " +
                    "nello STL \"" +
                    currentItem.Code +
                    "\".\r\n\r\n" +
                    productsWriteError);

                return;
            }


            /*
             * ==========================================
             * 5. SALVATAGGIO DEL SOLO STL
             * ==========================================
             *
             * MAIN non viene salvato.
             */
            if (!InventorService
                .TrySaveDocument(
                    currentStlAssembly,
                    out string productsSaveError))
            {
                AbortModalitaLSequence(
                    "Impossibile salvare lo STL \"" +
                    currentItem.Code +
                    "\" dopo la scrittura dei dati prodotti.\r\n\r\n" +
                    productsSaveError);

                return;
            }


            /*
             * ==========================================
             * 6. APERTURA FORM STL
             * ==========================================
             *
             * A questo punto DATI_COLLAUDO_PRODOTTI
             * è già fisicamente salvato nello STL.
             *
             * Il costruttore del Form STL lo rileggerà
             * normalmente e popolerà la tabella.
             */
            GeneraVerbaliModalitaStlForm stlForm =
                new GeneraVerbaliModalitaStlForm(
                    _inventorApp,
                    _openContext,
                    _modalitaLSession);


            stlForm.FormClosed +=
                (_, _) =>
                {
                    HandleModalitaLStlClosed(
                        stlForm);
                };


            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    _inventorApp);


            stlForm.Show(
                owner);
        }
        private void HandleModalitaLStlClosed(
    GeneraVerbaliModalitaStlForm stlForm)
        {
            if (_modalitaLSession == null)
                return;


            InventorService.InventorCustomCodeMatch?
                currentItem =
                    _modalitaLSession.CurrentItem;


            /*
             * Se il Form STL è stato chiuso manualmente
             * SENZA completare il verbale,
             * interrompiamo tutta la sequenza.
             */
            if (!stlForm.ModalitaLStepCompleted)
            {
                AbortModalitaLSequence(
                    "La sequenza Modalità L è stata interrotta.");

                return;
            }


            /*
             * Chiudiamo lo STL appena elaborato.
             *
             * Le proprietà che dovevano essere salvate
             * sono già state salvate dalla Modalità STL.
             */
            if (currentItem != null)
            {
                InventorService.CloseDocumentByPath(
                    _inventorApp,
                    currentItem.FullFileName,
                    true,
                    out _);
            }


            /*
             * Torniamo al MAIN.
             *
             * SOLO attivazione.
             * NESSUN SAVE.
             */
            if (!InventorService
                .OpenOrActivateDocumentByPath(
                    _inventorApp,
                    _modalitaLSession.MainAssemblyPath,
                    out string mainError))
            {
                AbortModalitaLSequence(
                    "Impossibile riattivare l'assieme MAIN.\r\n\r\n" +
                    mainError);

                return;
            }


            /*
             * Era l'ultimo STL?
             */
            if (_modalitaLSession.IsLastItem)
            {
                FinishModalitaLSequence();

                return;
            }


            /*
             * Prossimo STL.
             */
            _modalitaLSession.CurrentIndex++;


            OpenCurrentModalitaLStl();
        }
        private void FinishModalitaLSequence()
        {
            if (_modalitaLSession == null)
                return;


            /*
             * Chiudiamo definitivamente l'unica
             * istanza Excel della sessione L.
             */
            _modalitaLSession
                .ExcelSession
                .QuitExcel();


            /*
             * Riattiviamo MAIN.
             *
             * Nessuna modifica.
             * Nessun salvataggio.
             */
            InventorService
                .OpenOrActivateDocumentByPath(
                    _inventorApp,
                    _modalitaLSession.MainAssemblyPath,
                    out _);


            /*
             * ==========================================
             * RILASCIO DATI SESSIONE L
             * ==========================================
             */
            _modalitaLSession.ProductsData =
                string.Empty;

            _modalitaLSession.StlItems.Clear();

            _modalitaLSession.CurrentIndex =
                0;


            _modalitaLSession =
                null;


            _modalitaLProcessing =
                false;


            /*
             * La Modalità L torna disponibile.
             * I dati inseriti dall'utente restano
             * esattamente nel Form.
             */
            Show();

            BringToFront();

            Activate();


            MessageBox.Show(
                this,
                "Tutti i verbali della Modalità L sono stati completati.",
                "Genera Verbali - Modalità L",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        private void AbortModalitaLSequence(
    string message)
        {
            if (_modalitaLSession != null)
            {
                try
                {
                    /*
                     * Chiudiamo eventuale workbook aperto
                     * senza chiudere Excel prima di aver
                     * fatto la pulizia.
                     */
                    _modalitaLSession
                        .ExcelSession
                        .CloseCurrentWorkbook(
                            false);


                    _modalitaLSession
                        .ExcelSession
                        .QuitExcel();
                }
                catch
                {
                }


                /*
                 * Torniamo sempre al MAIN.
                 *
                 * MAIN non viene mai salvato.
                 */
                InventorService
                    .OpenOrActivateDocumentByPath(
                        _inventorApp,
                        _modalitaLSession.MainAssemblyPath,
                        out _);
            }


            if (_modalitaLSession != null)
            {
                _modalitaLSession.ProductsData =
                    string.Empty;

                _modalitaLSession.StlItems.Clear();

                _modalitaLSession.CurrentIndex =
                    0;
            }

            _modalitaLProcessing =
                false;


            Show();

            BringToFront();

            Activate();


            MessageBox.Show(
                this,
                message,
                "Genera Verbali - Modalità L",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}