﻿using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.GeneraVerbali.Models;
using Marpatech_8.Features.GeneraVerbali.Services;
using Marpatech_8.Features.GeneraVerbali.Tabs;
using System.Collections.Generic;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

using InventorApplication = global::Inventor.Application;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public class GeneraVerbaliSettingsForm : Form
    {
        private readonly InventorApplication
            _inventorApp;

        private readonly FeatureOpenContext
            _openContext;

        private readonly bool
            _isDarkTheme;

        private readonly WindowSettings
            _windowSettings;


        private TextBox
            _templatePathTextBox = null!;

        private GeneraVerbaliModalitaLTab
            _modalitaLTabControl = null!;

        private GeneraVerbaliModalitaStlTab
            _modalitaStlTabControl = null!;

        private GeneraVerbaliSettingsModel
            _settings = new GeneraVerbaliSettingsModel();


        public GeneraVerbaliSettingsForm(
            InventorApplication inventorApp,
            FeatureOpenContext openContext)
        {
            _inventorApp =
                inventorApp;

            _openContext =
                openContext;

            _isDarkTheme =
                openContext.IsDarkTheme;

            _windowSettings =
                WindowSettingsService.Load(
                    "GeneraVerbaliSettings",
                    850,
                    570);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            LoadSettings();
        }


        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);


            Text =
                "Impostazioni Genera Verbali";

            StartPosition =
                FormStartPosition.CenterScreen;

            MinimumSize =
                new Size(
                    850,
                    570);

            BackColor =
                backgroundColor;

            FormClosing +=
                GeneraVerbaliSettingsForm_FormClosing;


            /*
             * ==========================================
             * TITOLO
             * ==========================================
             */
            Label titleLabel =
                new Label
                {
                    Text =
                        "Impostazioni Genera Verbali",

                    Font =
                        new Font(
                            "Segoe UI",
                            22F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            30,
                            25)
                };


            /*
             * ==========================================
             * IMPORT / EXPORT
             * ==========================================
             */
            Button exportButton =
                new Button
                {
                    Text =
                        "Esporta configurazione",

                    Size =
                        new Size(
                            160,
                            36),

                    Location =
                        new Point(
                            ClientSize.Width - 350,
                            28),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            22,
                            163,
                            74),

                    ForeColor =
                        Color.White,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            exportButton.FlatAppearance.BorderSize =
                0;

            exportButton.Click +=
                ExportButton_Click;


            Button importButton =
                new Button
                {
                    Text =
                        "Importa configurazione",

                    Size =
                        new Size(
                            160,
                            36),

                    Location =
                        new Point(
                            ClientSize.Width - 180,
                            28),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            234,
                            88,
                            12),

                    ForeColor =
                        Color.White,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            importButton.FlatAppearance.BorderSize =
                0;

            importButton.Click +=
                ImportButton_Click;


            /*
             * ==========================================
             * TEMPLATE
             * ==========================================
             */
            Label templateLabel =
                new Label
                {
                    Text =
                        "Template",

                    Font =
                        new Font(
                            "Segoe UI",
                            11F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            30,
                            95)
                };


            _templatePathTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            30,
                            125),

                    Size =
                        new Size(
                            ClientSize.Width - 115,
                            30),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        _isDarkTheme
                            ? Color.FromArgb(42, 44, 50)
                            : Color.White,

                    ForeColor =
                        _isDarkTheme
                            ? Color.White
                            : Color.FromArgb(15, 23, 42)
                };


            Button browseTemplateButton =
                new Button
                {
                    Text =
                        "...",

                    Size =
                        new Size(
                            45,
                            30),

                    Location =
                        new Point(
                            ClientSize.Width - 72,
                            124),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            browseTemplateButton.Click +=
                BrowseTemplateButton_Click;


            /*
             * ==========================================
             * SEPARATORE
             * ==========================================
             */
            Panel separator =
                new Panel
                {
                    Location =
                        new Point(
                            30,
                            178),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            1),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    BackColor =
                        _isDarkTheme
                            ? Color.FromArgb(70, 75, 85)
                            : Color.FromArgb(203, 213, 225)
                };


            /*
             * ==========================================
             * TAB CONTROL
             * ==========================================
             */
            TabControl tabControl =
                new TabControl
                {
                    Location =
                        new Point(
                            30,
                            200),

                    Size =
                        new Size(
                            ClientSize.Width - 60,
                            ClientSize.Height - 275),

                    Anchor =
                        AnchorStyles.Top |
                        AnchorStyles.Bottom |
                        AnchorStyles.Left |
                        AnchorStyles.Right,

                    DrawMode =
                        TabDrawMode.OwnerDrawFixed,

                    SizeMode =
                        TabSizeMode.Fixed,

                    ItemSize =
                        new Size(
                            180,
                            34)
                };

            tabControl.DrawItem +=
                TabControl_DrawItem;

            TabPage modalitaLPage =
                new TabPage
                {
                    Text =
                        "Modalità L",

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor
                };


            TabPage modalitaStlPage =
                new TabPage
                {
                    Text =
                        "Modalità STL",

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor
                };


            _modalitaLTabControl =
                new GeneraVerbaliModalitaLTab(
                    _isDarkTheme);


            _modalitaStlTabControl =
                new GeneraVerbaliModalitaStlTab(
                    _isDarkTheme);


            modalitaLPage.Controls.Add(
                _modalitaLTabControl);

            modalitaStlPage.Controls.Add(
                _modalitaStlTabControl);


            tabControl.TabPages.Add(
                modalitaLPage);

            tabControl.TabPages.Add(
                modalitaStlPage);


            /*
             * ==========================================
             * SALVA / ANNULLA
             * ==========================================
             */
            Button saveButton =
                new Button
                {
                    Text =
                        "Salva",

                    Size =
                        new Size(
                            100,
                            36),

                    Location =
                        new Point(
                            ClientSize.Width - 140,
                            ClientSize.Height - 52),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        Color.White,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            saveButton.FlatAppearance.BorderSize =
                0;

            saveButton.Click +=
                SaveButton_Click;


            Button cancelButton =
                new Button
                {
                    Text =
                        "Annulla",

                    Size =
                        new Size(
                            100,
                            36),

                    Location =
                        new Point(
                            ClientSize.Width - 250,
                            ClientSize.Height - 52),

                    Anchor =
                        AnchorStyles.Bottom |
                        AnchorStyles.Right,

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor,

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            cancelButton.Click +=
                CancelButton_Click;


            Controls.Add(
                titleLabel);

            Controls.Add(
                exportButton);

            Controls.Add(
                importButton);

            Controls.Add(
                templateLabel);

            Controls.Add(
                _templatePathTextBox);

            Controls.Add(
                browseTemplateButton);

            Controls.Add(
                separator);

            Controls.Add(
                tabControl);

            Controls.Add(
                cancelButton);

            Controls.Add(
                saveButton);
        }


        private void LoadSettings()
        {
            _settings =
                GeneraVerbaliSettingsService.Load();


            _templatePathTextBox.Text =
                _settings.TemplatePath
                ?? string.Empty;


            _modalitaLTabControl.SetColumns(
                _settings.ModalitaL?.Columns);


            _modalitaStlTabControl.SetSettings(
                _settings.ModalitaSTL);
        }


        private void SaveButton_Click(
            object? sender,
            EventArgs e)
        {
            GeneraVerbaliSettingsModel settings =
                new GeneraVerbaliSettingsModel
                {
                    TemplatePath =
                        _templatePathTextBox.Text.Trim()
                };


            /*
             * ==========================================
             * MODALITÀ L
             * ==========================================
             */
            foreach (string columnName in
                _modalitaLTabControl.GetColumns())
            {
                settings.ModalitaL.Columns.Add(
                    columnName);
            }


            /*
             * ==========================================
             * MODALITÀ STL
             * ==========================================
             */
            settings.ModalitaSTL =
                _modalitaStlTabControl.GetSettings();


            /*
             * ==========================================
             * SALVATAGGIO
             * ==========================================
             */
            GeneraVerbaliSettingsService.Save(
                settings);


            _settings =
                settings;


            MessageBox.Show(
                this,
                "Impostazioni salvate correttamente.",
                "Genera Verbali",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }


        private void BrowseTemplateButton_Click(
            object? sender,
            EventArgs e)
        {
            using OpenFileDialog dialog =
                new OpenFileDialog
                {
                    Title =
                        "Seleziona il file Template",

                    Filter =
                        "File Excel (*.xlsx;*.xlsm;*.xls)|*.xlsx;*.xlsm;*.xls|Tutti i file (*.*)|*.*",

                    CheckFileExists =
                        true,

                    Multiselect =
                        false
                };


            string currentPath =
                _templatePathTextBox.Text.Trim();


            if (!string.IsNullOrWhiteSpace(
                currentPath))
            {
                try
                {
                    string? folder =
                        Path.GetDirectoryName(
                            currentPath);

                    if (!string.IsNullOrWhiteSpace(folder) &&
                        Directory.Exists(folder))
                    {
                        dialog.InitialDirectory =
                            folder;
                    }
                }
                catch
                {
                }
            }


            if (dialog.ShowDialog(this) !=
                DialogResult.OK)
            {
                return;
            }


            _templatePathTextBox.Text =
                dialog.FileName;
        }


        private void ExportButton_Click(
            object? sender,
            EventArgs e)
        {
            try
            {
                string sourcePath =
                    GeneraVerbaliSettingsService.GetSettingsFilePath();

                if (!File.Exists(sourcePath))
                {
                    MessageBox.Show(
                        this,
                        "Non esiste ancora una configurazione da esportare.\n\nSalva prima le impostazioni.",
                        "Genera Verbali",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return;
                }


                using SaveFileDialog dialog =
                    new SaveFileDialog
                    {
                        Title =
                            "Esporta configurazione Genera Verbali",

                        Filter =
                            "File JSON (*.json)|*.json",

                        FileName =
                            "GeneraVerbali.json",

                        DefaultExt =
                            "json",

                        AddExtension =
                            true,

                        OverwritePrompt =
                            true
                    };


                if (dialog.ShowDialog(this) !=
                    DialogResult.OK)
                {
                    return;
                }


                File.Copy(
                    sourcePath,
                    dialog.FileName,
                    true);


                MessageBox.Show(
                    this,
                    "Configurazione esportata correttamente.",
                    "Genera Verbali",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Errore durante l'esportazione della configurazione:\n\n" +
                    ex.Message,
                    "Genera Verbali",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        private void ImportButton_Click(
            object? sender,
            EventArgs e)
        {
            try
            {
                using OpenFileDialog dialog =
                    new OpenFileDialog
                    {
                        Title =
                            "Importa configurazione Genera Verbali",

                        Filter =
                            "File JSON (*.json)|*.json",

                        CheckFileExists =
                            true,

                        Multiselect =
                            false
                    };


                if (dialog.ShowDialog(this) !=
                    DialogResult.OK)
                {
                    return;
                }


                string importedJson =
                    File.ReadAllText(
                        dialog.FileName);


                GeneraVerbaliSettingsModel? importedSettings =
                    System.Text.Json.JsonSerializer.Deserialize
                        <GeneraVerbaliSettingsModel>(
                            importedJson);


                if (importedSettings == null)
                {
                    MessageBox.Show(
                        this,
                        "Il file selezionato non contiene una configurazione valida di Genera Verbali.",
                        "Genera Verbali",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                importedSettings.ModalitaL ??=
                    new GeneraVerbaliModalitaLSettings();

                importedSettings.ModalitaL.Columns ??=
                    new List<string>();


                DialogResult confirmResult =
                    MessageBox.Show(
                        this,
                        "Importando questa configurazione verranno sostituite le impostazioni attuali di Genera Verbali.\n\nVuoi continuare?",
                        "Importa configurazione",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question);


                if (confirmResult !=
                    DialogResult.Yes)
                {
                    return;
                }


                GeneraVerbaliSettingsService.Save(
                    importedSettings);


                LoadSettings();


                MessageBox.Show(
                    this,
                    "Configurazione importata correttamente.",
                    "Genera Verbali",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (System.Text.Json.JsonException)
            {
                MessageBox.Show(
                    this,
                    "Il file selezionato non è un JSON valido oppure non appartiene alla configurazione Genera Verbali.",
                    "Genera Verbali",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Errore durante l'importazione della configurazione:\n\n" +
                    ex.Message,
                    "Genera Verbali",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }


        private void CancelButton_Click(
            object? sender,
            EventArgs e)
        {
            Close();
        }


        private void GeneraVerbaliSettingsForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "GeneraVerbaliSettings");
        }
        private void TabControl_DrawItem(
    object? sender,
    DrawItemEventArgs e)
        {
            if (sender is not TabControl tabControl)
                return;

            bool isSelected =
                e.Index == tabControl.SelectedIndex;

            Rectangle tabBounds =
                tabControl.GetTabRect(
                    e.Index);

            Color backColor;
            Color textColor;


            if (e.Index == 0)
            {
                backColor =
                    isSelected
                        ? Color.FromArgb(37, 99, 235)
                        : Color.FromArgb(30, 64, 175);
            }
            else
                {
                    backColor =
                        isSelected
                            ? Color.FromArgb(234, 179, 8)
                            : Color.FromArgb(202, 138, 4);
                }


            textColor =
                Color.White;


            using SolidBrush backgroundBrush =
                new SolidBrush(
                    backColor);

            e.Graphics.FillRectangle(
                backgroundBrush,
                tabBounds);


            string text =
                tabControl.TabPages[e.Index].Text;


            TextRenderer.DrawText(
                e.Graphics,
                text,
                new Font(
                    "Segoe UI",
                    9.5F,
                    FontStyle.Bold),
                tabBounds,
                textColor,
                TextFormatFlags.HorizontalCenter |
                TextFormatFlags.VerticalCenter);
        }
    }
}