﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliCheckoutPromptForm : Form
    {
        public event EventHandler? Confirmed;


        public GeneraVerbaliCheckoutPromptForm(
            bool isDarkTheme)
        {
            InitializeComponent(
                isDarkTheme);
        }


        private void InitializeComponent(
            bool isDarkTheme)
        {
            Color backgroundColor =
                isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);


            Text =
                "Genera Verbali";

            StartPosition =
                FormStartPosition.CenterScreen;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    560,
                    190);

            BackColor =
                backgroundColor;


            Label messageLabel =
                new Label
                {
                    Text =
                        "Prima di cliccare OK assicurati di avere " +
                        "gli STL interessati in check-out",

                    Location =
                        new Point(
                            30,
                            25),

                    Size =
                        new Size(
                            500,
                            65),

                    ForeColor =
                        textColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10.5F,
                            FontStyle.Bold),

                    TextAlign =
                        ContentAlignment.MiddleCenter
                };


            Label infoLabel =
                new Label
                {
                    Text =
                        "Puoi continuare a utilizzare Inventor " +
                        "mentre questa finestra è aperta.",

                    Location =
                        new Point(
                            30,
                            87),

                    Size =
                        new Size(
                            500,
                            24),

                    ForeColor =
                        isDarkTheme
                            ? Color.FromArgb(180, 190, 205)
                            : Color.FromArgb(71, 85, 105),

                    Font =
                        new Font(
                            "Segoe UI",
                            9F),

                    TextAlign =
                        ContentAlignment.MiddleCenter
                };


            Button okButton =
                new Button
                {
                    Text =
                        "OK",

                    Location =
                        new Point(
                            190,
                            130),

                    Size =
                        new Size(
                            180,
                            42),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            okButton.FlatAppearance.BorderSize =
                0;

            okButton.Click +=
                OkButton_Click;


            Controls.Add(
                messageLabel);

            Controls.Add(
                infoLabel);

            Controls.Add(
                okButton);
        }


        private void OkButton_Click(
            object? sender,
            EventArgs e)
        {
            Confirmed?.Invoke(
                this,
                EventArgs.Empty);

            Close();
        }
    }
}