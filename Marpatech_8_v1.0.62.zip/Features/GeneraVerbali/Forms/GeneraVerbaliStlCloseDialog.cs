﻿using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraVerbali.Forms
{
    public sealed class GeneraVerbaliStlCloseDialog : Form
    {
        public bool CloseWholeFeature { get; private set; }


        public GeneraVerbaliStlCloseDialog(
            bool isDarkTheme)
        {
            InitializeComponent(
                isDarkTheme);
        }


        private void InitializeComponent(
            bool isDarkTheme)
        {
            Color backgroundColor =
                isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            Color secondaryButtonColor =
                isDarkTheme
                    ? Color.FromArgb(48, 50, 58)
                    : Color.FromArgb(226, 232, 240);

            Color borderColor =
                isDarkTheme
                    ? Color.FromArgb(75, 80, 90)
                    : Color.FromArgb(203, 213, 225);


            Text =
                "Genera Verbali";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    540,
                    175);

            BackColor =
                backgroundColor;


            Label messageLabel =
                new Label
                {
                    Text =
                        "Vuoi tornare alla dashboard di funzione " +
                        "o chiudere direttamente la funzione?",

                    Location =
                        new Point(
                            25,
                            25),

                    Size =
                        new Size(
                            490,
                            45),

                    ForeColor =
                        textColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F),

                    TextAlign =
                        ContentAlignment.MiddleCenter
                };


            Button returnButton =
                new Button
                {
                    Text =
                        "Ritorna alla funzione",

                    Location =
                        new Point(
                            70,
                            100),

                    Size =
                        new Size(
                            185,
                            42),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        Color.FromArgb(
                            37,
                            99,
                            235),

                    ForeColor =
                        Color.White,

                    Font =
                        new Font(
                            "Segoe UI",
                            9.5F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            returnButton.FlatAppearance.BorderSize =
                0;

            returnButton.Click +=
                (_, _) =>
                {
                    CloseWholeFeature =
                        false;

                    DialogResult =
                        DialogResult.OK;

                    Close();
                };


            Button closeButton =
                new Button
                {
                    Text =
                        "Chiudi",

                    Location =
                        new Point(
                            285,
                            100),

                    Size =
                        new Size(
                            185,
                            42),

                    FlatStyle =
                        FlatStyle.Flat,

                    BackColor =
                        secondaryButtonColor,

                    ForeColor =
                        textColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            9.5F,
                            FontStyle.Bold),

                    Cursor =
                        Cursors.Hand,

                    UseVisualStyleBackColor =
                        false
                };

            closeButton.FlatAppearance.BorderColor =
                borderColor;

            closeButton.Click +=
                (_, _) =>
                {
                    CloseWholeFeature =
                        true;

                    DialogResult =
                        DialogResult.OK;

                    Close();
                };


            Controls.Add(
                messageLabel);

            Controls.Add(
                returnButton);

            Controls.Add(
                closeButton);
        }
    }
}