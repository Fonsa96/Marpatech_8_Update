﻿using Inventor;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.GeneraVerbali.Forms;
using Marpatech_8.Features.Mail;

namespace Marpatech_8.Features.GeneraVerbali
{
    public static class GeneraVerbaliCommand
    {
        public static void Execute(
            Inventor.Application inventorApp,
            FeatureOpenContext context)
        {
            /*
             * ==========================================
             * APERTURA DALLA MAIN DASHBOARD
             * ==========================================
             *
             * La Main Dashboard viene nascosta.
             * Alla chiusura completa della funzione
             * viene ripristinata.
             */
            if (context.MainDashboard != null &&
                !context.MainDashboard.IsDisposed)
            {
                FeatureNavigationService.OpenFeature(
                    context,
                    "GeneraVerbali",
                    () => new GeneraVerbaliDashboardForm(
                        inventorApp,
                        context));

                return;
            }

            /*
             * ==========================================
             * APERTURA DIRETTA DAL RIBBON INVENTOR
             * ==========================================
             */
            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    inventorApp);

            SingleFormService.ShowSingle(
                "GeneraVerbali",
                () => new GeneraVerbaliDashboardForm(
                    inventorApp,
                    context),
                owner);
        }

        /*
         * Compatibilità con eventuali chiamate
         * che dispongono soltanto del tema.
         */
        public static void Execute(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            Execute(
                inventorApp,
                FeatureOpenContext.FromInventor(
                    isDarkTheme));
        }
    }
}