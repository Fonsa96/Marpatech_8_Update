﻿using Marpatech_8.Features.Core.Inventor;
using InventorApp = Inventor.Application;
using Marpatech_8.Features.Core.Forms;

namespace Marpatech_8.Features.MainDashboard
{
    public static class MainDashboardCommand
    {
        public static void Execute(
            InventorApp inventorApp)
        {
            bool isDarkTheme =
                InventorService.IsDarkTheme(
                    inventorApp);

            SingleFormService.ShowSingle(
                "MainDashboard",
                () => new MainDashboardForm(
                    inventorApp,
                    isDarkTheme),
                showIfAlreadyOpenButHidden: false);
        }
    }
}