﻿using Marpatech_8.Features.RegoleProgettazione.Models;
using Marpatech_8.Features.RegoleProgettazione.Services;
using Marpatech_8.Features.RegoleProgettazione.UI;
using Marpatech_8.Features.Core.Settings;

using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.Forms
{
    public class RegoleProgettazioneSettingsForm : Form
    {
        private readonly RuleSettingsService
            _settingsService;

        private readonly RuleSettings
            _settings;

        private readonly bool
            _isDarkTheme;

        private readonly bool
            _forcePathEditing;

        private TextBox
            rootPathTextBox = null!;

        private Button
            browseButton = null!;

        private CheckBox
            readOnlyCheckBox = null!;

        private ListBox
    exportPathsListBox = null!;

        private Button
            addExportPathButton = null!;

        private Button
            removeExportPathButton = null!;

        private Button
            exportRulesButton = null!;

        public bool SettingsChanged
        {
            get;
            private set;
        }

        public RegoleProgettazioneSettingsForm(
            RuleSettingsService settingsService,
            bool isDarkTheme,
            bool forcePathEditing = false)
        {
            _settingsService =
                settingsService;

            _settings =
                _settingsService.Load();

            _isDarkTheme =
                isDarkTheme;

            _forcePathEditing =
                forcePathEditing;

            InitializeComponent();

            LoadSettings();

        }

        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Color secondaryColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            Text =
                "Impostazioni - Regole di progettazione";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    650,
                    545);

            BackColor =
                backgroundColor;

            Font =
                new Font(
                    "Segoe UI",
                    9F);

            Label titleLabel =
                new Label
                {
                    Text =
                        "Impostazioni",

                    Font =
                        new Font(
                            "Segoe UI",
                            18F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            24,
                            20)
                };

            Label pathLabel =
                new Label
                {
                    Text =
                        "Cartella Regole di progettazione",

                    ForeColor =
                        textColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold),

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            26,
                            72)
                };

            rootPathTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            26,
                            98),

                    Size =
                        new Size(
                            535,
                            30),

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor
                };

            browseButton =
                new Button
                {
                    Text =
                        "...",

                    Location =
                        new Point(
                            570,
                            97),

                    Size =
                        new Size(
                            48,
                            30)
                };

            RuleButtonStyle.ApplyPrimary(
             browseButton);

            browseButton.Click +=
                BrowseButton_Click;

            Label noteLabel =
                new Label
                {
                    Text =
                        "Può essere una cartella locale, di rete o su server.",

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            28,
                            134),

                    AutoSize =
                        true
                };

            readOnlyCheckBox =
                new CheckBox
                {
                    Text =
                        "Sola Lettura",

                    ForeColor =
                        textColor,

                    BackColor =
                        backgroundColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Bold),

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            28,
                            178)
                };

            readOnlyCheckBox.CheckedChanged +=
                (_, _) =>
                {
                    UpdateReadOnlyState();
                };

            Label readOnlyDescription =
                new Label
                {
                    Text =
                        "Nasconde tutte le funzioni di modifica nell'addin. " +
                        "La cartella Windows rimane comunque modificabile secondo i normali permessi del sistema.",

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            48,
                            207),

                    Size =
                        new Size(
                            550,
                            40)
                };

            Button cancelButton =
                new Button
                {
                    Text =
                        "Annulla",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            408,
                            252),

                    DialogResult =
                        DialogResult.Cancel
                };

            RuleButtonStyle.ApplySecondary(
                cancelButton);

            Button saveButton =
                new Button
                {
                    Text =
                        "Salva",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            518,
                            252)
                };

            RuleButtonStyle.ApplySave(
               saveButton);

            saveButton.Click +=
                SaveButton_Click;

            /*
 * ==========================================
 * ESPORTAZIONE REGOLE
 * ==========================================
 */

            Panel exportSeparator =
                new Panel
                {
                    Location =
                        new Point(
                            26,
                            305),

                    Size =
                        new Size(
                            592,
                            1),

                    BackColor =
                        _isDarkTheme
                            ? Color.FromArgb(70, 75, 85)
                            : Color.FromArgb(203, 213, 225)
                };


            Label exportTitleLabel =
                new Label
                {
                    Text =
                        "Esportazione Regole",

                    Font =
                        new Font(
                            "Segoe UI",
                            13F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            26,
                            322)
                };


            Label exportDescriptionLabel =
                new Label
                {
                    Text =
                        "Seleziona una destinazione. L'esportazione sostituirà completamente il contenuto della cartella selezionata.",

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            28,
                            352),

                    Size =
                        new Size(
                            590,
                            34)
                };


            exportPathsListBox =
                new ListBox
                {
                    Location =
                        new Point(
                            26,
                            389),

                    Size =
                        new Size(
                            425,
                            92),

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor,

                    BorderStyle =
                        BorderStyle.FixedSingle,

                    IntegralHeight =
                        false
                };

            exportPathsListBox.SelectedIndexChanged +=
                    (_, _) =>
                    {
                        UpdateExportButtonsState();
                    };


            exportRulesButton =
                new Button
                {
                    Text =
                        "Esporta Regole",

                    Location =
                        new Point(
                            466,
                            389),

                    Size =
                        new Size(
                            152,
                            38)
                };

            RuleButtonStyle.ApplyPrimary(
                exportRulesButton);

            exportRulesButton.Click +=
                ExportRulesButton_Click;


            addExportPathButton =
                new Button
                {
                    Text =
                        "Aggiungi percorso",

                    Location =
                        new Point(
                            26,
                            490),

                    Size =
                        new Size(
                            140,
                            34)
                };

            RuleButtonStyle.ApplyPrimary(
                addExportPathButton);

            addExportPathButton.Click +=
                AddExportPathButton_Click;


            removeExportPathButton =
                new Button
                {
                    Text =
                        "Rimuovi",

                    Location =
                        new Point(
                            176,
                            490),

                    Size =
                        new Size(
                            100,
                            34)
                };

            RuleButtonStyle.ApplySecondary(
                removeExportPathButton);

            removeExportPathButton.Click +=
                RemoveExportPathButton_Click;

            Controls.Add(
                titleLabel);

            Controls.Add(
                pathLabel);

            Controls.Add(
                rootPathTextBox);

            Controls.Add(
                browseButton);

            Controls.Add(
                noteLabel);

            Controls.Add(
                readOnlyCheckBox);

            Controls.Add(
                readOnlyDescription);

            Controls.Add(
                cancelButton);

            Controls.Add(
                saveButton);

            AcceptButton =
                saveButton;

            Controls.Add(
    exportSeparator);

            Controls.Add(
                exportTitleLabel);

            Controls.Add(
                exportDescriptionLabel);

            Controls.Add(
                exportPathsListBox);

            Controls.Add(
                exportRulesButton);

            Controls.Add(
                addExportPathButton);

            Controls.Add(
                removeExportPathButton);

            CancelButton =
                cancelButton;
        }

        private void LoadSettings()
        {
            rootPathTextBox.Text =
                _settings.RootPath;

            readOnlyCheckBox.Checked =
                _settings.IsReadOnly;


            exportPathsListBox.Items.Clear();

            if (_settings.ExportPaths != null)
            {
                foreach (string path
                         in _settings.ExportPaths)
                {
                    if (string.IsNullOrWhiteSpace(
                            path))
                    {
                        continue;
                    }

                    exportPathsListBox.Items.Add(
                        path);
                }
            }


            UpdateReadOnlyState();

            UpdateExportButtonsState();
        }

        private void UpdateReadOnlyState()
        {
            bool lockPath =
                readOnlyCheckBox.Checked &&
                !_forcePathEditing;

            rootPathTextBox.ReadOnly =
                lockPath;

            browseButton.Enabled =
                !lockPath;
        }

        private void UpdateExportButtonsState()
        {
            bool hasSelection =
                exportPathsListBox.SelectedIndex >= 0;

            removeExportPathButton.Enabled =
                hasSelection;

            exportRulesButton.Enabled =
                hasSelection;
        }

        private void BrowseButton_Click(
            object? sender,
            EventArgs e)
        {
            if (rootPathTextBox.ReadOnly)
                return;

            using FolderBrowserDialog dialog =
                new FolderBrowserDialog
                {
                    Description =
                        "Seleziona la cartella principale delle Regole di progettazione",

                    UseDescriptionForTitle =
                        true
                };

            if (!string.IsNullOrWhiteSpace(
                    rootPathTextBox.Text) &&
                Directory.Exists(
                    rootPathTextBox.Text))
            {
                dialog.SelectedPath =
                    rootPathTextBox.Text;
            }

            if (dialog.ShowDialog(
                    this) !=
                DialogResult.OK)
            {
                return;
            }

            rootPathTextBox.Text =
                dialog.SelectedPath;
        }

        private void SaveButton_Click(
            object? sender,
            EventArgs e)
        {
            string rootPath =
                rootPathTextBox
                    .Text
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                    rootPath))
            {
                MessageBox.Show(
                    this,
                    "Imposta la cartella principale delle Regole di progettazione.",
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            /*
             * IMPORTANTE:
             * cartella VUOTA è perfettamente valida.
             *
             * Deve semplicemente esistere.
             */
            if (!Directory.Exists(
                    rootPath))
            {
                MessageBox.Show(
                    this,
                    "La cartella indicata non esiste:\r\n\r\n" +
                    rootPath,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            try
            {
                _settings.RootPath =
                    rootPath;

                _settings.IsReadOnly =
                    readOnlyCheckBox.Checked;

                _settings.ExportPaths.Clear();

                foreach (object item
                         in exportPathsListBox.Items)
                {
                    string path =
                        item
                            ?.ToString()
                            ?.Trim()
                        ?? string.Empty;

                    if (string.IsNullOrWhiteSpace(
                            path))
                    {
                        continue;
                    }

                    _settings.ExportPaths.Add(
                        path);
                }

                _settingsService.Save(
                    _settings);

                if (!_settings.IsReadOnly)
                {
                    RuleExternalChangesService.EnsureRequestFile(
                        rootPath);
                }

                SettingsChanged =
                    true;

                DialogResult =
                    DialogResult.OK;

                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    ex.Message,
                    "Errore salvataggio impostazioni",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        private void AddExportPathButton_Click(
    object? sender,
    EventArgs e)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog
                {
                    Description =
                        "Seleziona la cartella di destinazione per l'esportazione delle Regole di progettazione",

                    UseDescriptionForTitle =
                        true
                };


            if (dialog.ShowDialog(
                    this) !=
                DialogResult.OK)
            {
                return;
            }


            string selectedPath =
                dialog.SelectedPath
                    .Trim();


            if (string.IsNullOrWhiteSpace(
                    selectedPath))
            {
                return;
            }


            /*
             * Evitiamo duplicati nella lista.
             */
            foreach (object item
                     in exportPathsListBox.Items)
            {
                string existingPath =
                    item
                        ?.ToString()
                        ?.Trim()
                    ?? string.Empty;

                if (string.Equals(
                        existingPath,
                        selectedPath,
                        StringComparison.OrdinalIgnoreCase))
                {
                    exportPathsListBox.SelectedItem =
                        item;

                    return;
                }
            }


            exportPathsListBox.Items.Add(
                selectedPath);

            exportPathsListBox.SelectedItem =
                selectedPath;

            /*
             * La lista fa parte delle impostazioni.
             *
             * Verrà fisicamente salvata quando
             * l'utente preme "Salva".
             */
        }
        private void RemoveExportPathButton_Click(
    object? sender,
    EventArgs e)
        {
            int selectedIndex =
                exportPathsListBox.SelectedIndex;

            if (selectedIndex < 0)
                return;


            exportPathsListBox.Items.RemoveAt(
                selectedIndex);


            if (exportPathsListBox.Items.Count > 0)
            {
                int newIndex =
                    Math.Min(
                        selectedIndex,
                        exportPathsListBox.Items.Count - 1);

                exportPathsListBox.SelectedIndex =
                    newIndex;
            }


            UpdateExportButtonsState();
        }
        private void ExportRulesButton_Click(
    object? sender,
    EventArgs e)
        {
            if (exportPathsListBox.SelectedItem == null)
            {
                MessageBox.Show(
                    this,
                    "Seleziona una cartella di esportazione.",
                    "Esportazione Regole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            string sourcePath =
                rootPathTextBox
                    .Text
                    .Trim();

            string destinationPath =
                exportPathsListBox
                    .SelectedItem
                    ?.ToString()
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    sourcePath))
            {
                MessageBox.Show(
                    this,
                    "La cartella principale delle Regole di progettazione non è impostata.",
                    "Esportazione Regole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            if (string.IsNullOrWhiteSpace(
                    destinationPath))
            {
                MessageBox.Show(
                    this,
                    "Il percorso di esportazione selezionato non è valido.",
                    "Esportazione Regole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }


            DialogResult answer =
                MessageBox.Show(
                    this,
                    "La cartella di destinazione verrà COMPLETAMENTE SVUOTATA e sostituita con una copia delle Regole di progettazione." +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Destinazione:" +
                    Environment.NewLine +
                    destinationPath +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Continuare?",
                    "Conferma esportazione Regole",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);


            if (answer !=
                DialogResult.Yes)
            {
                return;
            }


            try
            {
                UseWaitCursor =
                    true;

                exportRulesButton.Enabled =
                    false;


                RuleExportService.ExportMirror(
                    sourcePath,
                    destinationPath);


                MessageBox.Show(
                    this,
                    "Esportazione completata correttamente." +
                    Environment.NewLine +
                    Environment.NewLine +
                    destinationPath,
                    "Esportazione Regole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    "Esportazione non completata." +
                    Environment.NewLine +
                    Environment.NewLine +
                    ex.Message,
                    "Errore esportazione Regole",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            finally
            {
                UseWaitCursor =
                    false;

                UpdateExportButtonsState();
            }
        }
    }
}