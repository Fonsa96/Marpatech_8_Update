﻿using System;
using System.IO;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class RuleExportService
    {
        public static void ExportMirror(
            string sourcePath,
            string destinationPath)
        {
            string source =
                NormalizePath(
                    sourcePath);

            string destination =
                NormalizePath(
                    destinationPath);

            ValidatePaths(
                source,
                destination);

            /*
             * Prima verifichiamo che la sorgente
             * sia realmente accessibile.
             *
             * In questo modo non svuotiamo la
             * destinazione se la sorgente non
             * è disponibile.
             */
            EnsureSourceAccessible(
                source);

            /*
             * MIRROR:
             *
             * la destinazione viene completamente
             * svuotata e poi ricostruita copiando
             * il contenuto della sorgente.
             */
            ResetDestination(
                destination);

            CopyDirectoryRecursive(
                source,
                destination);
        }


        private static void ValidatePaths(
            string source,
            string destination)
        {
            if (string.IsNullOrWhiteSpace(
                    source))
            {
                throw new InvalidOperationException(
                    "La cartella principale delle Regole di progettazione non è impostata.");
            }

            if (string.IsNullOrWhiteSpace(
                    destination))
            {
                throw new InvalidOperationException(
                    "Il percorso di esportazione non è valido.");
            }

            if (!Directory.Exists(
                    source))
            {
                throw new DirectoryNotFoundException(
                    "La cartella principale delle Regole di progettazione non esiste:\r\n\r\n" +
                    source);
            }

            /*
             * Impediamo:
             *
             * sorgente == destinazione
             */
            if (PathsAreEqual(
                    source,
                    destination))
            {
                throw new InvalidOperationException(
                    "La cartella di esportazione non può coincidere con la cartella principale delle Regole di progettazione.");
            }

            /*
             * Impediamo che la destinazione
             * sia contenuta nella sorgente.
             *
             * Evita copie ricorsive e cancellazioni
             * pericolose.
             */
            if (IsSubPath(
                    destination,
                    source))
            {
                throw new InvalidOperationException(
                    "La cartella di esportazione non può trovarsi all'interno della cartella principale delle Regole di progettazione.");
            }

            /*
             * Impediamo anche il caso contrario:
             *
             * la sorgente dentro la destinazione.
             *
             * Dato che la destinazione viene
             * completamente svuotata, questo
             * cancellerebbe anche la sorgente.
             */
            if (IsSubPath(
                    source,
                    destination))
            {
                throw new InvalidOperationException(
                    "La cartella principale delle Regole di progettazione non può trovarsi all'interno della cartella di esportazione.");
            }
        }


        private static void EnsureSourceAccessible(
            string source)
        {
            try
            {
                /*
                 * Forziamo almeno una lettura
                 * del contenuto della directory.
                 */
                Directory.GetFileSystemEntries(
                    source);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Non è possibile accedere alla cartella principale delle Regole di progettazione.\r\n\r\n" +
                    ex.Message,
                    ex);
            }
        }


        private static void ResetDestination(
            string destination)
        {
            try
            {
                if (Directory.Exists(
                        destination))
                {
                    Directory.Delete(
                        destination,
                        true);
                }

                Directory.CreateDirectory(
                    destination);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(
                    "Non è stato possibile svuotare e ricreare la cartella di esportazione.\r\n\r\n" +
                    destination +
                    "\r\n\r\n" +
                    ex.Message,
                    ex);
            }
        }


        private static void CopyDirectoryRecursive(
            string source,
            string destination)
        {
            Directory.CreateDirectory(
                destination);

            foreach (string file
                     in Directory.GetFiles(
                         source))
            {
                string destinationFile =
                    Path.Combine(
                        destination,
                        Path.GetFileName(
                            file));

                File.Copy(
                    file,
                    destinationFile,
                    true);
            }

            foreach (string directory
                     in Directory.GetDirectories(
                         source))
            {
                string destinationDirectory =
                    Path.Combine(
                        destination,
                        Path.GetFileName(
                            directory));

                CopyDirectoryRecursive(
                    directory,
                    destinationDirectory);
            }
        }


        private static string NormalizePath(
            string? path)
        {
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return string.Empty;
            }

            try
            {
                return Path
                    .GetFullPath(
                        path.Trim())
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar);
            }
            catch
            {
                return path
                    .Trim()
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar);
            }
        }


        private static bool PathsAreEqual(
            string firstPath,
            string secondPath)
        {
            return string.Equals(
                firstPath,
                secondPath,
                StringComparison.OrdinalIgnoreCase);
        }


        private static bool IsSubPath(
            string possibleChild,
            string possibleParent)
        {
            if (string.IsNullOrWhiteSpace(
                    possibleChild) ||
                string.IsNullOrWhiteSpace(
                    possibleParent))
            {
                return false;
            }

            string child =
                possibleChild
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar)
                + Path.DirectorySeparatorChar;

            string parent =
                possibleParent
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar)
                + Path.DirectorySeparatorChar;

            return child.StartsWith(
                parent,
                StringComparison.OrdinalIgnoreCase);
        }
    }
}