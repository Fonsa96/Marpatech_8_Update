﻿using System.Collections.Generic;

namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class RuleSettings
    {
        public string RootPath { get; set; } =
            string.Empty;

        public bool IsReadOnly { get; set; }

        /*
         * Percorsi utilizzabili come destinazione
         * per l'esportazione delle Regole di progettazione.
         *
         * Non imponiamo alcun limite al numero
         * di destinazioni configurabili.
         */
        public List<string> ExportPaths { get; set; } =
            new List<string>();
    }
}