﻿using InventorApp = Inventor.Application;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Temporary;
using Marpatech_8.Features.Core.Windows;
using Marpatech_8.Features.GeneraWord.Forms;
using System;
using System.IO;
using System.Threading.Tasks;
using IOPath = System.IO.Path;
using DrawingImage = System.Drawing.Image;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualImageService
    {
        private static string TempFolder
        {
            get
            {
                return TempFileService.GetTempFolder(
                    "GeneraWord");
            }
        }

        public static async Task<string> PrepareAndSaveCurrentViewAsync(
    InventorApp inventorApp,
    bool isDarkTheme,
    IWin32Window? owner)
        {

            CleanTempFolder();

            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            PositionImageForm form = new PositionImageForm(isDarkTheme);

            form.FormClosed += (s, e) =>
            {
                tcs.TrySetResult(form.ImageCaptured);
            };

            form.Show(owner);
            form.Activate();

            bool captured = await tcs.Task;

            form.Dispose();
            UiCompatibilityService.DoEventsSafe();

            if (!captured)
                throw new OperationCanceledException(
                    "Generazione manuale annullata dall'utente.");

            string imagePath = IOPath.Combine(
                TempFolder,
                "InventorView.png");

            try
            {
                InventorService.SetApplicationVisible(
                    inventorApp,
                    true);

                NativeWindowHelper.BringWindowMaximizedTopMost(
                    InventorService.GetMainFrameHandle(
                        inventorApp));

                UiCompatibilityService.DoEventsSafe();

                await UiCompatibilityService.DelayAsync(
                    500);
            }
            catch
            {
            }


            bool imageSaved =
                await SaveInventorImageWithRetryAsync(
                    inventorApp,
                    imagePath);

            if (!imageSaved)
            {
                throw new Exception(
                    "Impossibile acquisire correttamente l'immagine Inventor." +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    imagePath);
            }

            return imagePath;
        }

        private static async Task<bool> SaveInventorImageWithRetryAsync(
    InventorApp inventorApp,
    string imagePath)
        {
            const int maxAttempts = 4;

            for (int attempt = 1;
                 attempt <= maxAttempts;
                 attempt++)
            {
                try
                {
                    if (ManualFileService.FileExists(imagePath))
                    {
                        ManualFileService.DeleteFileSafe(
                            imagePath);
                    }

                    InventorService.SetApplicationVisible(
                        inventorApp,
                        true);

                    NativeWindowHelper.BringWindowMaximizedTopMost(
                        InventorService.GetMainFrameHandle(
                            inventorApp));

                    UiCompatibilityService.DoEventsSafe();

                    await UiCompatibilityService.DelayAsync(
                        350);

                    bool bitmapSaved =
                        InventorService.SaveActiveViewAsBitmap(
                            inventorApp,
                            imagePath,
                            1920,
                            1080);

                    if (!bitmapSaved)
                    {
                        throw new InvalidOperationException(
                            "Inventor non ha potuto salvare la vista corrente.");
                    }

                    UiCompatibilityService.DoEventsSafe();

                    await UiCompatibilityService.DelayAsync(
                        250);

                    if (IsValidImageFile(imagePath))
                        return true;
                }
                catch
                {
                }

                if (attempt < maxAttempts)
                {
                    UiCompatibilityService.DoEventsSafe();

                    await UiCompatibilityService.DelayAsync(
                        400);
                }
            }

            return false;
        }

        private static bool IsValidImageFile(
    string imagePath)
        {
            try
            {
                if (!ManualFileService.FileExists(imagePath))
                    return false;

                FileInfo imageInfo =
                    new FileInfo(imagePath);

                if (imageInfo.Length <= 0)
                    return false;

                using DrawingImage image =
                    DrawingImage.FromFile(imagePath);

                if (image.Width <= 0 ||
                    image.Height <= 0)
                {
                    return false;
                }

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void CleanTempFolder()
        {
            if (!ManualFileService.DirectoryExists(TempFolder))
                return;

            foreach (string file in ManualFileService.GetFiles(
                TempFolder,
                "*",
                SearchOption.TopDirectoryOnly))
            {
                ManualFileService.DeleteFile(file);
            }
        }
    }
}