﻿using Marpatech_8.Features.Core.Inventor;

using InventorAssemblyDocument =
    Inventor.AssemblyDocument;

using InventorComponentOccurrence =
    Inventor.ComponentOccurrence;

using InventorComponentOccurrences =
    Inventor.ComponentOccurrences;

using InventorDocument =
    Inventor.Document;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod1TreeCollector
    {
        public List<AssemblyGroupMethod1TreeNode> Collect(
            InventorAssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            if (rules == null)
            {
                return new List<AssemblyGroupMethod1TreeNode>();
            }


            List<AssemblyGroupSearchRule> validRules=
                rules
                    .Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList();


            if (validRules.Count == 0)
            {
                return new List<AssemblyGroupMethod1TreeNode>();
            }


            /*
             * Nodi STL di primo livello rispetto
             * all'assieme MAIN.
             */
            List<AssemblyGroupMethod1TreeNode> roots =
                new List<AssemblyGroupMethod1TreeNode>();


            InventorComponentOccurrences?
                rootOccurrences =
                    InventorService.GetAssemblyOccurrences(
                        mainAssembly);

            if (rootOccurrences == null)
            {
                return roots;
            }

            CollectLevel(
                rootOccurrences,
                validRules,
                roots,
                null); 


            return roots;
        }


        /*
         * ==================================================
         * SCANSIONE DEL SINGOLO LIVELLO
         * ==================================================
         *
         * Questa funzione implementa una regola fondamentale:
         *
         * lo stesso STL ripetuto nello STESSO contenitore
         * viene considerato una sola volta.
         *
         * La deduplicazione NON viene passata ai livelli
         * successivi.
         *
         * Di conseguenza:
         *
         * STL100
         * ├── STL500
         * └── STL500
         *
         * produce un solo STL500.
         *
         * Ma:
         *
         * STL100
         * └── STL500
         *
         * STL200
         * └── STL500
         *
         * produce correttamente DUE nodi STL500.
         */
        private static void CollectLevel(
            InventorComponentOccurrences occurrences,
                    IReadOnlyList<AssemblyGroupSearchRule> rules,
            ICollection<AssemblyGroupMethod1TreeNode> targetNodes,
            AssemblyGroupMethod1TreeNode? parent)
        {
            /*
             * Deduplicazione esclusivamente
             * all'interno di QUESTO contenitore.
             */
            HashSet<string> stlAlreadyAddedAtThisLevel =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (InventorComponentOccurrence occurrence
                in occurrences)
            {
                /*
                 * ==================================================
                 * SOPPRESSI
                 * ==================================================
                 *
                 * Se l'occorrenza è soppressa:
                 *
                 * - non viene aggiunta;
                 * - non viene attraversata;
                 * - tutto quel ramo viene ignorato.
                 */
                if (InventorService.IsOccurrenceSuppressed(
                        occurrence))
                {
                    continue;
                }


                InventorDocument? referencedDocument =
                    InventorService.GetOccurrenceDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }


                if (!InventorService.DocumentIsAssembly(
                        referencedDocument))
                {
                    continue;
                }


                string code =
                    InventorService.ReadUserDefinedProperty(
                        referencedDocument,
                        "CODICE");


                AssemblyGroupSearchRule? matchingRule =
           FindMatchingRule(
               code,
               rules);


                /*
                 * ==================================================
                 * QUESTO ASSIEME È UNO STL VALIDO
                 * ==================================================
                 */
                if (matchingRule != null)
                {
                    string assemblyPath =
                        InventorService
                            .GetDocumentFullFileName(
                                referencedDocument)
                            .Trim();


                    /*
                     * Per la deduplicazione dello stesso
                     * livello usiamo preferibilmente il
                     * percorso IAM.
                     *
                     * Se per qualche motivo non è disponibile,
                     * ripieghiamo sul CODICE.
                     */
                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();


                    /*
                     * Se lo stesso IAM è già comparso
                     * nello stesso contenitore,
                     * questa seconda occorrenza viene ignorata.
                     */
                    if (!stlAlreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }


                    AssemblyGroupMethod1TreeNode node =
                        new AssemblyGroupMethod1TreeNode
                        {
                            Code =
                                code,

                            DrawingName =
                                InventorService.ReadUserDefinedProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            AssemblyPath =
                                assemblyPath,

                            DrawingSearchPath =
                                matchingRule
                                    .DrawingSearchPath
                                    ?.Trim()
                                ?? string.Empty,

                            Parent =
                                parent,

                            SelectionState =
                                AssemblyGroupMethod1SelectionState.DrawingOnly
                        };


                    targetNodes.Add(
                        node);


                    InventorComponentOccurrences?
                        childOccurrences =
                            InventorService.GetOccurrenceChildOccurrences(
                                occurrence);


                    if (childOccurrences != null)
                    {
                        CollectLevel(
                            childOccurrences,
                            rules,
                            node.Children,
                            node);
                    }


                    /*
                     * Questo ramo appartiene ormai
                     * allo STL appena creato.
                     */
                    continue;
                }


                /*
                 * ==================================================
                 * ASSIEME INTERMEDIO NON STL
                 * ==================================================
                 *
                 * Caso:
                 *
                 * MAIN
                 * └── ASSIEME GENERICO
                 *     └── STL100
                 *
                 * L'assieme generico non deve apparire
                 * nell'albero, ma dobbiamo attraversarlo
                 * per trovare STL100.
                 *
                 * Gli STL trovati restano appartenenti
                 * allo stesso livello STL logico.
                 */
                InventorComponentOccurrences?
                nestedOccurrences =
                    InventorService.GetOccurrenceChildOccurrences(
                        occurrence);


            if (nestedOccurrences != null)
                {
                    CollectLevelIntoSameLogicalLevel(
                        nestedOccurrences,
                        rules,
                        targetNodes,
                        stlAlreadyAddedAtThisLevel,
                        parent);
                }
            }
        }


        /*
         * Attraversa assiemi intermedi NON STL mantenendo
         * la stessa deduplicazione del livello logico.
         */
        private static void CollectLevelIntoSameLogicalLevel(
            InventorComponentOccurrences occurrences,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            ICollection<AssemblyGroupMethod1TreeNode> targetNodes,
            HashSet<string> stlAlreadyAddedAtThisLevel,
            AssemblyGroupMethod1TreeNode? parent)
        {
            foreach (InventorComponentOccurrence occurrence
                in occurrences)
            {
                if (InventorService.IsOccurrenceSuppressed(
                        occurrence))
                {
                    continue;
                }


                InventorDocument? referencedDocument =
                    InventorService.GetOccurrenceDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }


                if (!InventorService.DocumentIsAssembly(
                        referencedDocument))
                {
                    continue;
                }


                string code =
                    InventorService.ReadUserDefinedProperty(
                        referencedDocument,
                        "CODICE");


                AssemblyGroupSearchRule? matchingRule =
                    FindMatchingRule(
                        code,
                        rules);


                if (matchingRule != null)
                {
                    string assemblyPath =
                        InventorService
                            .GetDocumentFullFileName(
                                referencedDocument)
                            .Trim();


                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();


                    if (!stlAlreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }


                    AssemblyGroupMethod1TreeNode node =
                        new AssemblyGroupMethod1TreeNode
                        {
                            Code =
                                code,

                            DrawingName =
                                InventorService.ReadUserDefinedProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            AssemblyPath =
                                assemblyPath,

                            DrawingSearchPath =
                                matchingRule
                                    .DrawingSearchPath
                                    ?.Trim()
                                ?? string.Empty,

                            Parent =
                                parent,

                            SelectionState =
                                AssemblyGroupMethod1SelectionState.DrawingOnly
                        };


                    targetNodes.Add(
                        node);


                    InventorComponentOccurrences?
                        childOccurrences =
                            InventorService.GetOccurrenceChildOccurrences(
                                occurrence);


                    if (childOccurrences != null)
                    {
                        /*
                         * Entrando in un vero STL,
                         * comincia un NUOVO livello logico.
                         */
                        CollectLevel(
                            childOccurrences,
                            rules,
                            node.Children,
                            node);
                    }


                    continue;
                }


                /*
                 * Ancora un assieme intermedio.
                 * Continuiamo mantenendo lo stesso livello.
                 */
                InventorComponentOccurrences?
                    nestedOccurrences =
                        InventorService.GetOccurrenceChildOccurrences(
                            occurrence);


                if (nestedOccurrences != null)
                {
                    CollectLevelIntoSameLogicalLevel(
                        nestedOccurrences,
                        rules,
                        targetNodes,
                        stlAlreadyAddedAtThisLevel,
                        parent);
                }
            }
        }


        private static AssemblyGroupSearchRule?
            FindMatchingRule(
                string code,
                IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }


            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                if (code
                    .Trim()
                    .StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }


            return null;
        }

        private static string NormalizeIdentity(
            string value)
        {
            return value
                .Trim()
                .Replace(
                    '/',
                    '\\');
        }
    }
}