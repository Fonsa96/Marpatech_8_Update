﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.Core.Inventor;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2InternalCollector
    {
        public AssemblyGroupMethod2PrintNode Collect(
            AssemblyDocument stlAssembly,
            string mainPrefix,
            IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (stlAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(stlAssembly));
            }

            string normalizedMainPrefix =
                mainPrefix
                    ?.Trim()
                ?? string.Empty;

            List<AssemblyGroupSearchRule> validRules =
                rules
                    ?.Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList()
                ?? new List<AssemblyGroupSearchRule>();


            /*
             * ROOT = STL che stiamo processando.
             *
             * Parte TRUE perché la sua tavola
             * normalmente va stampata.
             */
            AssemblyGroupMethod2PrintNode root =
                new AssemblyGroupMethod2PrintNode
                {
                    Code =
                        ReadCustomProperty(
                            stlAssembly,
                            "CODICE"),

                    DrawingName =
                        ReadCustomProperty(
                            stlAssembly,
                            "DISEGNO"),

                    SourceDocumentPath =
                        InventorService
                            .GetDocumentFullFileName(
                                stlAssembly)
                            .Trim(),

                    PrintDrawing =
                        true,

                    IsNestedMainPrefixAssembly =
                        false,

                    Parent =
                        null
                };


            /*
             * La deduplicazione NON è più globale
             * sull'intero Form 2.
             *
             * Questo HashSet appartiene solamente
             * allo STL ROOT.
             *
             * Quando incontreremo uno STL annidato
             * ne creeremo uno NUOVO.
             */
            HashSet<string> rootScopeCodes =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            ComponentOccurrences?
                rootOccurrences =
                    InventorService.GetAssemblyOccurrences(
                        stlAssembly);


            if (rootOccurrences != null)
            {
                CollectInsideStlScope(
                    rootOccurrences,
                    normalizedMainPrefix,
                    validRules,
                    root,
                    rootScopeCodes,
                    true);
            }


            return root;
        }


        /*
         * ==================================================
         * RACCOLTA DEL CONTENUTO DI UN SINGOLO STL LOGICO
         * ==================================================
         *
         * scopeCodes:
         * deduplicazione solamente dentro questo STL.
         *
         * defaultPrintDrawing:
         *
         * TRUE
         * → siamo nello STL corrente che stiamo processando.
         *
         * FALSE
         * → siamo dentro uno STL annidato:
         *   tutto il suo contenuto parte FALSE.
         */
        private static void CollectInsideStlScope(
            ComponentOccurrences occurrences,
            string mainPrefix,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            AssemblyGroupMethod2PrintNode logicalParent,
            HashSet<string> scopeCodes,
            bool defaultPrintDrawing)
        {
            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                /*
                 * SOPPRESSO:
                 *
                 * ignoriamo componente e intero ramo.
                 */
                if (InventorService.IsOccurrenceSuppressed(
                        occurrence))
                {
                    continue;
                }

                Document? referencedDocument =
                    InventorService.GetOccurrenceDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }


                /*
                 * Per ora ci interessano componenti
                 * che possiedono un documento Inventor.
                 */
                string code =
                    ReadCustomProperty(
                        referencedDocument,
                        "CODICE");

                string normalizedCode =
                    code
                        ?.Trim()
                    ?? string.Empty;

                bool isAssembly =
                    InventorService.DocumentIsAssembly(
                        referencedDocument);


                /*
                 * È un STL / famiglia definita dalla
                 * TextBox principale Metodo 2?
                 *
                 * NON esiste nessun "STL" hardcoded.
                 */
                bool isNestedMainPrefixAssembly =
                    isAssembly &&
                    !string.IsNullOrWhiteSpace(
                        mainPrefix) &&
                    !string.IsNullOrWhiteSpace(
                        normalizedCode) &&
                    normalizedCode.StartsWith(
                        mainPrefix,
                        StringComparison.OrdinalIgnoreCase);


                /*
                 * ==================================================
                 * STL ANNIDATO
                 * ==================================================
                 */
                if (isNestedMainPrefixAssembly)
                {
                    /*
                     * Anche lo stesso STL ripetuto più volte
                     * dentro QUESTO STL viene mostrato una sola volta.
                     */
                    if (!scopeCodes.Add(
                            normalizedCode))
                    {
                        continue;
                    }


                    AssemblyGroupSearchRule?
                        nestedStlRule =
                            FindExactPrefixRule(
                                mainPrefix,
                                rules);


                    AssemblyGroupMethod2PrintNode nestedStlNode =
                        new AssemblyGroupMethod2PrintNode
                        {
                            Code =
                                normalizedCode,

                            DrawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            SourceDocumentPath =
                                InventorService
                                    .GetDocumentFullFileName(
                                        referencedDocument)
                                    .Trim(),

                            DrawingSearchPath =
                                nestedStlRule
                                    ?.DrawingSearchPath
                                    ?.Trim()
                                ?? string.Empty,

                            SearchPrefix =
                             mainPrefix,

                            /*
                             * STL annidato:
                             * SEMPRE FALSE iniziale.
                             */
                            PrintDrawing =
                                false,

                            IsNestedMainPrefixAssembly =
                                true,

                            Parent =
                                logicalParent
                        };


                    logicalParent.Children.Add(
                        nestedStlNode);

                    ComponentOccurrences?
                        childOccurrences =
                            InventorService.GetOccurrenceChildOccurrences(
                                occurrence);


                    if (childOccurrences != null)
                    {
                        /*
                         * IMPORTANTISSIMO:
                         *
                         * entrando nello STL annidato
                         * comincia un NUOVO ambito di
                         * deduplicazione.
                         *
                         * Quindi GAR0000398 già trovato
                         * nel padre può ricomparire qui.
                         */
                        HashSet<string> nestedScopeCodes =
                            new HashSet<string>(
                                StringComparer.OrdinalIgnoreCase);


                        CollectInsideStlScope(
                            childOccurrences,
                            mainPrefix,
                            rules,
                            nestedStlNode,
                            nestedScopeCodes,

                            /*
                             * Tutto ciò che appartiene
                             * allo STL annidato parte FALSE.
                             */
                            false);
                    }


                    continue;
                }


                /*
                 * Cerchiamo una regola della seconda
                 * tabella Metodo 2.
                 *
                 * ASC, GAC, GAR, GAN, ecc.
                 */
                AssemblyGroupSearchRule? matchingRule =
                    FindMatchingRule(
                        normalizedCode,
                        rules);


                if (matchingRule != null)
                {
                    /*
                     * Deduplicazione solamente dentro
                     * lo STL logico corrente.
                     *
                     * Esempio:
                     *
                     * 10 x GAC220074 nello stesso STL
                     * → 1 solo nodo.
                     */
                    if (!string.IsNullOrWhiteSpace(
                            normalizedCode) &&
                        scopeCodes.Add(
                            normalizedCode))
                    {
                        AssemblyGroupMethod2PrintNode node =
                            new AssemblyGroupMethod2PrintNode
                            {
                                Code =
                                    normalizedCode,

                                DrawingName =
                                    ReadCustomProperty(
                                        referencedDocument,
                                        "DISEGNO"),

                                SourceDocumentPath =
                                    InventorService
                                        .GetDocumentFullFileName(
                                            referencedDocument)
                                        .Trim(),

                                DrawingSearchPath =
                                    matchingRule
                                        .DrawingSearchPath
                                        ?.Trim()
                                    ?? string.Empty,

                                SearchPrefix =
                                    matchingRule
                                        .CodePrefix
                                        ?.Trim()
                                    ?? string.Empty,

                                /*
                                 * Nel ROOT normalmente TRUE.
                                 *
                                 * Dentro uno STL annidato FALSE.
                                 */
                                PrintDrawing =
                                    defaultPrintDrawing,

                                IsNestedMainPrefixAssembly =
                                    false,

                                Parent =
                                    logicalParent
                            };


                        logicalParent.Children.Add(
                            node);
                    }


                    /*
                     * Anche un componente riconosciuto può
                     * essere un assieme contenente altre cose.
                     *
                     * Continuiamo quindi la scansione
                     * mantenendo lo STESSO scope.
                     */
                    ComponentOccurrences?
                        matchingChildren =
                            InventorService.GetOccurrenceChildOccurrences(
                                occurrence);


                    if (matchingChildren != null)
                    {
                        CollectInsideStlScope(
                            matchingChildren,
                            mainPrefix,
                            rules,
                            logicalParent,
                            scopeCodes,
                            defaultPrintDrawing);
                    }


                    continue;
                }


                /*
                 * ==================================================
                 * ASSIEME INTERMEDIO NON VISIBILE
                 * ==================================================
                 *
                 * Non appare nel Form 2,
                 * ma dobbiamo attraversarlo.
                 *
                 * Restiamo nello stesso STL logico,
                 * quindi utilizziamo lo stesso HashSet.
                 */
                ComponentOccurrences?
                    nestedOccurrences =
                        InventorService.GetOccurrenceChildOccurrences(
                            occurrence);


                if (nestedOccurrences != null)
                {
                    CollectInsideStlScope(
                        nestedOccurrences,
                        mainPrefix,
                        rules,
                        logicalParent,
                        scopeCodes,
                        defaultPrintDrawing);
                }
            }
        }


        private static AssemblyGroupSearchRule?
            FindMatchingRule(
                string code,
                IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }


            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                if (code.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }


            return null;
        }


        private static AssemblyGroupSearchRule?
            FindExactPrefixRule(
                string mainPrefix,
                IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                if (string.Equals(
                        rule.CodePrefix
                            ?.Trim(),
                        mainPrefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }


            return null;
        }

        private static string ReadCustomProperty(
            Document document,
            string propertyName)
        {
            return InventorService
                .ReadIProperty(
                    document,
                    propertyName)
                .Trim();
        }


        private static string ReadCustomProperty(
            AssemblyDocument document,
            string propertyName)
        {
            return InventorService
                .ReadIProperty(
                    document,
                    propertyName)
                .Trim();
        }
    }
}