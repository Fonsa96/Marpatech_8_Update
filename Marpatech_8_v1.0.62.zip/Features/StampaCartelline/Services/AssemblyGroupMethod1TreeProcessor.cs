﻿using Marpatech_8.Features.Core.Inventor;

using InventorApp =
    Inventor.Application;

using InventorAssemblyDocument =
    Inventor.AssemblyDocument;

using InventorDocument =
    Inventor.Document;

using InventorDrawingDocument =
    Inventor.DrawingDocument;

using InventorBrowserPane =
    Inventor.BrowserPane;

using InventorBrowserNode =
    Inventor.BrowserNode;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod1TreeProcessor
    {
        private readonly InventorApp _inventorApp;

        public AssemblyGroupMethod1TreeProcessor(
            InventorApp inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }

        public void Process(
            IWin32Window owner,
            InventorAssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupMethod1TreeNode> roots,
            StampaCartellineProcessProgress progress)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }
            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }


            if (roots == null)
                return;


            /*
             * Leggiamo il CODICE dell'assieme MAIN.
             *
             * Se CODICE non esiste o è vuoto,
             * usiamo il nome del file IAM.
             */
            string mainCode =
                InventorService.ReadUserDefinedProperty(
                    mainAssembly,
                    "CODICE");

            if (string.IsNullOrWhiteSpace(
                    mainCode))
            {
                mainCode =
                    InventorService
                        .GetDocumentFileNameWithoutExtension(
                            mainAssembly);
            }


            try
            {
                /*
                 * Ogni root viene processata mantenendo
                 * unito il proprio ramo.
                 *
                 * Dentro ogni ramo utilizziamo il POST-ORDER:
                 *
                 * figli prima
                 * contenitore dopo
                 */
                foreach (AssemblyGroupMethod1TreeNode root
                    in roots)
                {
                    ProcessNodePostOrder(
                        owner,
                        root,
                        mainCode,
                        progress);
                }


                /*
                 * Terminati tutti gli STL,
                 * gestiamo la tavola dell'assieme MAIN.
                 */
                ProcessMainAssemblyDrawing(
                    owner,
                    mainAssembly,
                    progress);
            }
            finally
            {
                /*
                 * Il MAIN deve sempre tornare attivo.
                 */
                InventorService.ActivateAssemblyDocument(
                    mainAssembly);
            }
        }
        private void ProcessNodePostOrder(
            IWin32Window owner,
            AssemblyGroupMethod1TreeNode node,
            string mainCode,
            StampaCartellineProcessProgress progress)
        {
            /*
             * POST-ORDER:
             *
             * prima tutti i figli...
             */
            foreach (AssemblyGroupMethod1TreeNode child
                in node.Children)
            {
                ProcessNodePostOrder(
                    owner,
                    child,
                    mainCode,
                    progress);
            }

            /*
 * Nodo presente solamente per rappresentare
 * la struttura.
 *
 * I figli sono già stati processati,
 * ma questo IAM non deve essere lavorato.
 */
            if (!node.IsProcessable)
            {
                return;
            }

            /*
             * ...poi il contenitore.
             */
            ProcessSingleNode(
                owner,
                node,
                mainCode,
                progress);
        }

        private void ProcessSingleNode(
            IWin32Window owner,
            AssemblyGroupMethod1TreeNode node,
            string mainCode,
            StampaCartellineProcessProgress progress)
        {
            InventorDrawingDocument? drawingDocument =
                null;

            /*
 * X = SALTA STL
 *
 * Nessuna tavola.
 * Nessun Jenkins.
 * Nessun popup.
 */
            if (node.SelectionState ==
                AssemblyGroupMethod1SelectionState.Skip)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - STL saltato dall'utente.");
                return;
            }

            try
            {
                /*
                 * Se il resolver ha già rilevato
                 * un problema, non tentiamo di aprire.
                 */
                if (!string.IsNullOrWhiteSpace(
                        node.FailureReason))
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - " +
                        node.FailureReason);

                    return;
                }

                string drawingPath =
                    node.DrawingPath
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        drawingPath))
                {
                    node.FailureReason =
                        "Percorso IDW non disponibile";

                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - " +
                        node.FailureReason);

                    return;
                }

                /*
                 * Apriamo direttamente l'IDW.
                 */
                InventorDocument? openedDocument =
                    InventorService.OpenDocument(
                        _inventorApp,
                        drawingPath,
                        true);

                if (openedDocument == null)
                {
                    throw new InvalidOperationException(
                        "Inventor non ha potuto aprire il documento.");
                }

                drawingDocument =
                    openedDocument as
                        InventorDrawingDocument;

                if (drawingDocument == null)
                {
                    InventorService.CloseDocument(
                        openedDocument,
                        true);

                    node.FailureReason =
                        "Il file trovato non è un documento IDW valido";

                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - " +
                        node.FailureReason);

                    return;
                }

                InventorService.ActivateDrawingDocument(
                    drawingDocument);

                System.Windows.Forms.Application
                    .DoEvents();

                progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Tavola aperta.");

                /*
                 * Costruiamo il messaggio in base
                 * a:
                 *
                 * - Jenkins TRUE/FALSE
                 * - STL contenitore TRUE/FALSE
                 */
                string message =
                    BuildDrawingQuestion(
                        node,
                        mainCode);

                DialogResult answer =
                    MessageBox.Show(
                        owner,
                        message,
                        "Gruppi di montaggio",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);


                /*
                 * Se SÌ:
                 * stampa diretta tavola.
                 */
                if (answer == DialogResult.Yes)
                {
                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");

                                        progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Tavola stampata.");
                }

                else
                {
                    progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Stampa tavola rifiutata dall'utente.");
                }

                /*
                 * Jenkins dipende SOLO dal flag
                 * scelto nella finestra iniziale.
                 *
                 * Parte sia che la risposta sopra
                 * sia SÌ sia che sia NO.
                 */
                if (node.SelectionState ==
                    AssemblyGroupMethod1SelectionState.DrawingAndJenkins)
                {
                    ExecuteInventorCommand(
                        "QS:JENKINS_StampaDistintaGruppiMontaggio");

                    progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - QS Jenkins eseguito.");
                }
            }
            catch (Exception exception)
            {
                node.FailureReason =
                    "Errore durante il processamento IDW: " +
                    GetRealExceptionMessage(
                        exception);

                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - " +
                    node.FailureReason);
            }
            finally
            {
                if (drawingDocument != null)
                {
                    InventorService.CloseDrawingDocument(
                        drawingDocument,
                        true);
                }
            }
        }

        private static string BuildDrawingQuestion(
            AssemblyGroupMethod1TreeNode node,
            string mainCode)
        {
            string message =
                "Vuoi stampare la tavola di " +
                node.Code +
                "?" +
                System.Environment.NewLine +
                System.Environment.NewLine +
                "Posizione nell'albero:" +
                System.Environment.NewLine +
                System.Environment.NewLine +
                BuildTreePosition(
                    node,
                    mainCode);


            /*
             * V =
             * Tavola + QS Jenkins
             */
            if (node.SelectionState ==
                AssemblyGroupMethod1SelectionState.DrawingAndJenkins)
            {
                message +=
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    "Fai attenzione che se l’STL è rilasciato " +
                    "verrà stampato due volte con questa procedura.";

                return message;
            }


            /*
             * CASELLA VUOTA + CONTENITORE
             *
             * La tavola può essere stampata,
             * ma Jenkins NON partirà.
             */
            if (node.IsContainer)
            {
                message +=
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    "ATTENZIONE: questo STL contiene altri STL. " +
                    "Verifica che al suo interno non siano presenti " +
                    "altre tavole da stampare.";
            }


            return message;
        }

        private static string BuildTreePosition(
    AssemblyGroupMethod1TreeNode node,
    string mainCode)
        {
            List<string> path =
                new List<string>();

            AssemblyGroupMethod1TreeNode? current =
                node;

            while (current != null)
            {
                path.Add(
                    current.Code);

                current =
                    current.Parent;
            }

            path.Reverse();

            List<string> lines =
                new List<string>();

            lines.Add(
                mainCode);

            for (int i = 0;
                i < path.Count;
                i++)
            {
                string indent =
                    new string(
                        ' ',
                        (i + 1) * 4);

                lines.Add(
                    indent +
                    path[i]);
            }

            return string.Join(
                System.Environment.NewLine,
                lines);
        }

        private void ProcessMainAssemblyDrawing(
            IWin32Window owner,
            InventorAssemblyDocument mainAssembly,
            StampaCartellineProcessProgress progress)
        {
            InventorDrawingDocument? drawingDocument =
                null;

                    string mainCode =
                InventorService.ReadUserDefinedProperty(
                    mainAssembly,
                    "CODICE");

            if (string.IsNullOrWhiteSpace(
                    mainCode))
            {
                mainCode =
                    InventorService.GetDocumentFileNameWithoutExtension(
                        mainAssembly);
            }

            string currentStep =
                "Inizio";

            try
            {
                currentStep =
                    "Attivazione IAM principale";

                if (!InventorService.ActivateAssemblyDocument(
                        mainAssembly))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare l'assieme principale.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                currentStep =
                    "Recupero browser attivo";

                InventorBrowserPane? activeBrowser =
                    InventorService.GetActiveBrowserPane(
                        mainAssembly);

                if (activeBrowser == null)
                {
                    throw new InvalidOperationException(
                        "Browser attivo dell'assieme non disponibile.");
                }


                currentStep =
                    "Recupero nodo principale";

                InventorBrowserNode? topNode =
                    InventorService.GetBrowserTopNode(
                        activeBrowser);

                if (topNode == null)
                {
                    throw new InvalidOperationException(
                        "Nodo principale dell'assieme non disponibile.");
                }


                currentStep =
                    "Selezione nodo principale";

                if (!InventorService.SelectBrowserNode(
                        topNode))
                {
                    throw new InvalidOperationException(
                        "Impossibile selezionare il nodo principale dell'assieme.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                currentStep =
                    "Apertura tavola assieme principale";

                ExecuteInventorCommand(
                    "CMxOpenDrawingCmd");

                System.Windows.Forms.Application
                    .DoEvents();


                currentStep =
                    "Verifica tavola assieme principale";

                drawingDocument =
                    InventorService.GetActiveDrawing(
                        _inventorApp);

                if (drawingDocument == null)
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Tavola dell'assieme MAIN non trovata.");
                    MessageBox.Show(
                        owner,
                        "Tavola dell’assieme di partenza non trovata.",
                        "Gruppi di montaggio",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }


                DialogResult answer =
                    MessageBox.Show(
                        owner,
                        "Vuoi stampare la tavola di " +
                        mainCode +
                        "?" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        "Posizione nell'albero:" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        mainCode,
                        "Gruppi di montaggio",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);


                if (answer == DialogResult.Yes)
                {
                    currentStep =
                        "Stampa tavola L";

                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");

                    progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Tavola MAIN stampata.");
                }

                else
                {
                    progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Stampa tavola MAIN rifiutata dall'utente.");
                }

            }
            catch (Exception exception)
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    mainCode +
                    " - Errore tavola MAIN. Fase: " +
                    currentStep +
                    ". " +
                    GetRealExceptionMessage(
                        exception));
                MessageBox.Show(
                    owner,
                    "Errore durante la gestione della tavola " +
                    "dell’assieme di partenza:" +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    "Fase: " +
                    currentStep +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    GetRealExceptionMessage(
                        exception),
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                string drawingPath =
                    string.Empty;

                if (drawingDocument != null)
                {
                    try
                    {
                        drawingPath =
                            InventorService
                                .GetDocumentFullFileName(
                                    drawingDocument)
                                .Trim();
                    }
                    catch
                    {
                    }


                    /*
                     * Primo tentativo:
                     * riattiviamo la tavola e la chiudiamo.
                     */
                    try
                    {
                        InventorService.ActivateDrawingDocument(
                            drawingDocument);

                        System.Windows.Forms.Application
                            .DoEvents();

                        InventorService.CloseDrawingDocument(
                            drawingDocument,
                            true);

                        System.Windows.Forms.Application
                            .DoEvents();
                    }
                    catch
                    {
                    }
                }


                /*
                 * Seconda sicurezza:
                 *
                 * se per qualche motivo Inventor ha lasciato
                 * ancora aperta la stessa tavola,
                 * la cerchiamo nei Documents tramite percorso
                 * e la richiudiamo esplicitamente.
                 */
                if (!string.IsNullOrWhiteSpace(
                        drawingPath))
                {
                    TryCloseDrawingByPath(
                        drawingPath);
                }


                /*
                 * Alla fine torniamo sempre
                 * all'IAM MAIN.
                 */
                InventorService.ActivateAssemblyDocument(
                    mainAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }

        private void TryCloseDrawingByPath(
            string drawingPath)
        {
            if (string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                return;
            }

            List<InventorDocument> documentsToClose =
                InventorService
                    .FindOpenDrawingDocumentsByPath(
                        _inventorApp,
                        drawingPath);

            foreach (InventorDocument document
                     in documentsToClose)
            {
                InventorService.CloseDocument(
                    document,
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }

        private void ExecuteInventorCommand(
           string commandInternalName)
        {
            bool success =
                InventorService
                    .TryExecuteControlDefinition2(
                        _inventorApp,
                        commandInternalName,
                        true,
                        out string errorMessage);

            if (success)
                return;

            throw new InvalidOperationException(
                "Errore durante l'esecuzione del comando:" +
                System.Environment.NewLine +
                commandInternalName +
                System.Environment.NewLine +
                System.Environment.NewLine +
                errorMessage);
        }

        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;

            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }

            return realException.Message;
        }
    }
}