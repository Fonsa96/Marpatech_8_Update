﻿using Marpatech_8.Features.Core.Inventor;

using InventorApp =
    Inventor.Application;

using InventorAssemblyDocument =
    Inventor.AssemblyDocument;

using InventorDocument =
    Inventor.Document;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2PrintSelectionCleanupService
    {
        private readonly InventorApp _inventorApp;

        public AssemblyGroupMethod2PrintSelectionCleanupService(
            InventorApp inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }

        public void Cleanup(
            InventorAssemblyDocument currentStl,
            AssemblyGroupMethod2PrintNode root)
        {
            if (currentStl == null ||
                root == null)
            {
                return;
            }

            HashSet<string> sourcePaths =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            HashSet<string> drawingNames =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            CollectRecursive(
                root,
                sourcePaths,
                drawingNames);


            string currentStlPath =
                NormalizePath(
                    InventorService.GetDocumentFullFileName(
                        currentStl));


            List<InventorDocument> drawingsToClose =
                new List<InventorDocument>();

            List<InventorDocument> modelsToClose =
                new List<InventorDocument>();


            foreach (InventorDocument document
                     in InventorService.GetOpenDocuments(
                         _inventorApp))
            {
                try
                {
                    string documentPath =
                        NormalizePath(
                            InventorService.GetDocumentFullFileName(
                                document));

                    /*
                     * Lo STL corrente deve rimanere aperto.
                     */
                    if (string.Equals(
                            documentPath,
                            currentStlPath,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }


                    if (InventorService.DocumentIsDrawing(
                            document))
                    {
                        string fileNameWithoutExtension =
                            IOPath.GetFileNameWithoutExtension(
                                documentPath);

                        if (drawingNames.Contains(
                                fileNameWithoutExtension))
                        {
                            drawingsToClose.Add(
                                document);
                        }

                        continue;
                    }


                    if (sourcePaths.Contains(
                            documentPath))
                    {
                        modelsToClose.Add(
                            document);
                    }
                }
                catch
                {
                }
            }


            /*
             * Prima IDW.
             */
            foreach (InventorDocument document
                in drawingsToClose)
            {
                TryClose(
                    document);
            }


            /*
             * Poi eventuali modelli aperti
             * durante l'ispezione.
             */
            foreach (InventorDocument document
                in modelsToClose)
            {
                TryClose(
                    document);
            }


            /*
             * Ritorno obbligatorio allo STL corrente.
             */
            InventorService.ActivateAssemblyDocument(
                currentStl);

            System.Windows.Forms.Application
                .DoEvents();
        }


        private static void CollectRecursive(
            AssemblyGroupMethod2PrintNode node,
            ISet<string> sourcePaths,
            ISet<string> drawingNames)
        {
            string sourcePath =
                NormalizePath(
                    node.SourceDocumentPath);

            if (!string.IsNullOrWhiteSpace(
                    sourcePath))
            {
                sourcePaths.Add(
                    sourcePath);
            }


            string drawingName =
                node.DrawingName
                    ?.Trim()
                ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(
                    drawingName))
            {
                try
                {
                    drawingName =
                        IOPath.GetFileNameWithoutExtension(
                            drawingName);
                }
                catch
                {
                }

                if (!string.IsNullOrWhiteSpace(
                        drawingName))
                {
                    drawingNames.Add(
                        drawingName);
                }
            }


            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectRecursive(
                    child,
                    sourcePaths,
                    drawingNames);
            }
        }


        private static void TryClose(
            InventorDocument document)
        {
            InventorService.CloseDocument(
                document,
                true);

            System.Windows.Forms.Application
                .DoEvents();
        }


        private static string NormalizePath(
            string? path)
        {
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return string.Empty;
            }

            try
            {
                return IOPath
                    .GetFullPath(
                        path.Trim())
                    .TrimEnd(
                        IOPath.DirectorySeparatorChar,
                        IOPath.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }
    }
}