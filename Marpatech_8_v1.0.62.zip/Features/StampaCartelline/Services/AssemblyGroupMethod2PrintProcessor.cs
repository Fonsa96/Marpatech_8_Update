﻿using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using InventorApp =
    Inventor.Application;
using InventorAssemblyDocument =
    Inventor.AssemblyDocument;
using InventorBrowserNode =
    Inventor.BrowserNode;
using InventorBrowserPane =
    Inventor.BrowserPane;
using InventorDocument =
    Inventor.Document;
using InventorDrawingDocument =
    Inventor.DrawingDocument;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2PrintProcessor
    {
        private readonly InventorApp _inventorApp;


        public AssemblyGroupMethod2PrintProcessor(
            InventorApp inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }


        public void Process(
            InventorAssemblyDocument stlAssembly,
            AssemblyGroupMethod2PrintNode root,
            IEnumerable<AssemblyGroupSearchRule> rules,
            StampaCartellineProcessProgress progress)
        {
            if (stlAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(stlAssembly));
            }

            if (root == null)
            {
                throw new ArgumentNullException(
                    nameof(root));
            }


            List<AssemblyGroupSearchRule> orderedRules =
                rules
                    ?.Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList()
                ?? new List<AssemblyGroupSearchRule>();


            /*
             * Tutti i nodi selezionati TRUE
             * escluso il ROOT.
             *
             * Il ROOT verrà gestito alla fine
             * tramite Apri Tavola di Inventor.
             */
            List<AssemblyGroupMethod2PrintNode> selectedNodes =
                new List<AssemblyGroupMethod2PrintNode>();

            CollectSelectedNodes(
                root,
                selectedNodes,
                false);


            /*
             * Cache degli indici server.
             *
             * CHIAVE:
             * percorso cartella.
             *
             * Così ogni percorso viene scandito
             * ricorsivamente UNA SOLA VOLTA.
             */
            Dictionary<
                string,
                Dictionary<string, string>>
                indexesBySearchPath =
                    new Dictionary<
                        string,
                        Dictionary<string, string>>(
                            StringComparer.OrdinalIgnoreCase);


            /*
             * Processiamo rispettando l'ordine
             * delle righe Method2Rows.
             */
            foreach (AssemblyGroupSearchRule rule
                in orderedRules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                List<AssemblyGroupMethod2PrintNode> groupNodes =
                    selectedNodes
                        .Where(
                            node =>
                                string.Equals(
                                    node.SearchPrefix,
                                    prefix,
                                    StringComparison.OrdinalIgnoreCase))
                        .ToList();


                if (groupNodes.Count == 0)
                {
                    continue;
                }


                ProcessRuleGroup(
                    stlAssembly,
                    groupNodes,
                    indexesBySearchPath,
                    progress);
            }


            /*
             * Eventuale sicurezza:
             *
             * se esiste un nodo TRUE con SearchPrefix
             * non presente nelle Method2Rows,
             * non viene stampato e gli assegniamo errore.
             */
            foreach (AssemblyGroupMethod2PrintNode node
                in selectedNodes)
            {
                bool ruleExists =
                    orderedRules.Any(
                        rule =>
                            string.Equals(
                                rule.CodePrefix
                                    ?.Trim(),
                                node.SearchPrefix,
                                StringComparison.OrdinalIgnoreCase));

                if (!ruleExists)
                {
                    SetFailure(
                        node,
                        "Nessuna regola Metodo 2 configurata per il prefisso: " +
                        node.SearchPrefix);
                }
            }


            /*
             * Terminati i gruppi interni,
             * torniamo all'IAM STL.
             */
            InventorService.ActivateAssemblyDocument(
                stlAssembly);

            System.Windows.Forms.Application
                .DoEvents();


            /*
             * ROOT TRUE:
             * stampiamo la tavola dello STL corrente.
             *
             * ROOT FALSE:
             * niente tavola STL.
             */
            if (root.PrintDrawing)
            {
                PrintCurrentStlDrawing(
                    stlAssembly,
                    root);
            }
        }


        private void ProcessRuleGroup(
            InventorAssemblyDocument stlAssembly,
            IEnumerable<AssemblyGroupMethod2PrintNode> nodes,
            IDictionary<
                string,
                Dictionary<string, string>>
                indexesBySearchPath,
            StampaCartellineProcessProgress progress)
        {
            foreach (AssemblyGroupMethod2PrintNode node
                in nodes)
            {
                string searchPath =
                    node.DrawingSearchPath
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        searchPath))
                {
                    SetFailure(
                        node,
                        "Percorso ricerca IDW non configurato");

                    continue;
                }


                if (!Directory.Exists(
                        searchPath))
                {
                    SetFailure(
                        node,
                        "Percorso ricerca IDW non trovato: " +
                        searchPath);

                    continue;
                }


                /*
                 * Creiamo l'indice solo la prima volta
                 * che incontriamo questa cartella.
                 */
                if (!indexesBySearchPath.TryGetValue(
                        searchPath,
                        out Dictionary<string, string>? index))
                {
                    index =
                        BuildDrawingIndex(
                            searchPath);

                    indexesBySearchPath[
                        searchPath] =
                            index;
                }


                string drawingName =
                    NormalizeDrawingFileName(
                        node.DrawingName);


                if (string.IsNullOrWhiteSpace(
                        drawingName))
                {
                    SetFailure(
                        node,
                        "Proprietà DISEGNO vuota");

                    continue;
                }


                /*
                 * MATCH ESATTO.
                 *
                 * DISEGNO = GAC1230
                 *
                 * trova:
                 * GAC1230.idw
                 *
                 * ma NON:
                 * GAC1230_RICAMBI.idw
                 */
                /*
                 * ==================================================
                 * RICERCA TAVOLA
                 * ==================================================
                 *
                 * 1° tentativo:
                 * proprietà DISEGNO.
                 *
                 * Esempio:
                 * CODICE  = ASC160163
                 * DISEGNO = ASC1601630
                 *
                 * cerchiamo:
                 * ASC1601630.idw
                 *
                 *
                 * 2° tentativo FALLBACK:
                 * se la tavola DISEGNO non esiste,
                 * proviamo il vecchio nome basato
                 * direttamente sul CODICE:
                 *
                 * ASC160163.idw
                 *
                 * Serve per gestire vecchie tavole
                 * presenti nel database con la
                 * nomenclatura precedente.
                 */
                if (!index.TryGetValue(
                        drawingName,
                        out string? drawingPath))
                {
                    string legacyDrawingName =
                        BuildLegacyDrawingFileName(
                            drawingName);


                    if (!string.IsNullOrWhiteSpace(
                            legacyDrawingName) &&
                        index.TryGetValue(
                            legacyDrawingName,
                            out string? legacyDrawingPath))
                    {
                        drawingPath =
                            legacyDrawingPath;


                        /*
                         * Non è un errore:
                         * la tavola è stata trovata.
                         *
                         * Però lo registriamo nel LOG
                         * perché è utile sapere che nel
                         * database esiste ancora un nome
                         * vecchio stile.
                         */
                        progress.AddWarning(
                            StampaCartellineProcessSection.AssemblyGroups,
                            node.Code +
                            " - Tavola non trovata come DISEGNO \"" +
                            drawingName +
                            "\", utilizzata tavola con nome legacy \"" +
                            legacyDrawingName +
                            "\".");
                    }
                    else
                    {
                        SetFailure(
                            node,
                            "IDW non trovato sul server. " +
                            "Ricercati: " +
                            drawingName +
                            " / " +
                            legacyDrawingName);

                        continue;
                    }
                }


                PrintDrawing(
                    stlAssembly,
                    node,
                    drawingPath);
            }
        }


        private static Dictionary<string, string>
            BuildDrawingIndex(
                string searchRoot)
        {
            Dictionary<string, string> index =
                new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase);


            try
            {
                foreach (string filePath
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.AllDirectories))
                {
                    string fileName =
                        IOPath.GetFileName(
                            filePath);


                    /*
                     * Mi hai confermato che sul server
                     * non possono esistere due file
                     * con lo stesso nome.
                     *
                     * In ogni caso non sovrascriviamo.
                     */
                    if (!index.ContainsKey(
                            fileName))
                    {
                        index.Add(
                            fileName,
                            filePath);
                    }
                }
            }
            catch
            {
                /*
                 * Eventuali directory non accessibili
                 * non devono mandare in crash il processo.
                 */
            }


            return index;
        }


        private void PrintDrawing(
            InventorAssemblyDocument stlAssembly,
            AssemblyGroupMethod2PrintNode node,
            string drawingPath)
        {
            InventorDrawingDocument? drawingDocument =
                null;

            try
            {
                /*
                 * ==================================================
                 * RESET CONTESTO PRIMA DELLA NUOVA TAVOLA
                 * ==================================================
                 *
                 * Prima di aprire ogni IDW torniamo all'IAM STL.
                 *
                 * Non tocchiamo PrinterName.
                 * Non scegliamo noi stampante o plotter.
                 *
                 * Il comando QS continuerà quindi a determinare
                 * autonomamente la destinazione corretta.
                 */
                if (!InventorService.ActivateAssemblyDocument(
                        stlAssembly))
                {
                    throw new InvalidOperationException(
                        "Impossibile riattivare l'assieme STL prima della stampa.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                InventorDocument? openedDocument =
                    InventorService.OpenDocument(
                        _inventorApp,
                        drawingPath,
                        true);

                if (openedDocument == null)
                {
                    throw new InvalidOperationException(
                        "Inventor non ha potuto aprire il documento.");
                }


                drawingDocument =
                    openedDocument
                        as InventorDrawingDocument;


                if (drawingDocument == null)
                {
                    InventorService.CloseDocument(
                        openedDocument,
                        true);

                    SetFailure(
                        node,
                        "Il file trovato non è un IDW valido");

                    return;
                }


                if (!InventorService.ActivateDrawingDocument(
                        drawingDocument))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare la tavola IDW.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                /*
                 * Il comando QS decide autonomamente
                 * stampante / plotter.
                 */
                ExecuteInventorCommand(
                    "Autodesk:InvPrint:SVCmdBtn");

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch (Exception exception)
            {
                SetFailure(
                    node,
                    "Errore durante la stampa IDW: " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                /*
                 * Chiudiamo completamente la tavola
                 * appena processata.
                 */
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }


                /*
                 * ==================================================
                 * RESET CONTESTO DOPO LA TAVOLA
                 * ==================================================
                 *
                 * Prima di processare il prossimo IDW
                 * torniamo sempre all'IAM STL.
                 */
                InventorService.ActivateAssemblyDocument(
                    stlAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        private void PrintCurrentStlDrawing(
            InventorAssemblyDocument stlAssembly,
            AssemblyGroupMethod2PrintNode root)
        {
            InventorDrawingDocument? drawingDocument =
                null;

            try
            {
                if (!InventorService.ActivateAssemblyDocument(
        stlAssembly))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare l'assieme STL.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                InventorBrowserPane? browser =
                    InventorService.GetActiveBrowserPane(
                        stlAssembly);

                if (browser == null)
                {
                    throw new InvalidOperationException(
                        "Browser attivo dell'assieme non disponibile.");
                }


                InventorBrowserNode? topNode =
                    InventorService.GetBrowserTopNode(
                        browser);

                if (topNode == null)
                {
                    throw new InvalidOperationException(
                        "Nodo principale dell'assieme non disponibile.");
                }


                if (!InventorService.SelectBrowserNode(
                     topNode))
                {
                    throw new InvalidOperationException(
                        "Impossibile selezionare il nodo principale dell'assieme.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                ExecuteInventorCommand(
                    "CMxOpenDrawingCmd");

                System.Windows.Forms.Application
                    .DoEvents();


                drawingDocument =
                    InventorService.GetActiveDrawing(
                        _inventorApp);


                if (drawingDocument == null)
                {
                    SetFailure(
                        root,
                        "Tavola dell'assieme corrente non trovata");

                    return;
                }


                ExecuteInventorCommand(
                    "Autodesk:InvPrint:SVCmdBtn");
            }
            catch (Exception exception)
            {
                SetFailure(
                    root,
                    "Errore durante la stampa della tavola dell'assieme: " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }


                InventorService.ActivateAssemblyDocument(
                    stlAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        private void TryCloseDrawing(
            InventorDrawingDocument drawingDocument)
        {
            string drawingPath =
                string.Empty;


            try
            {
                drawingPath =
                    InventorService
                        .GetDocumentFullFileName(
                            drawingDocument)
                        .Trim();
            }
            catch
            {
            }


            /*
             * Primo tentativo.
             */
            try
            {
                InventorService.ActivateDrawingDocument(
                    drawingDocument);

                System.Windows.Forms.Application
                    .DoEvents();

                InventorService.CloseDrawingDocument(
                    drawingDocument,
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }


            /*
             * Secondo tentativo per percorso,
             * come abbiamo fatto per la tavola Main
             * del Metodo 1.
             */
            if (!string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                List<InventorDocument> documentsToClose =
                    InventorService
                        .FindOpenDrawingDocumentsByPath(
                            _inventorApp,
                            drawingPath);

                foreach (InventorDocument document
                         in documentsToClose)
                {
                    InventorService.CloseDocument(
                        document,
                        true);

                    System.Windows.Forms.Application
                        .DoEvents();
                }
            }
        }


        private void ExecuteInventorCommand(
            string commandInternalName)
                {
                    bool success =
                        InventorService
                            .TryExecuteControlDefinition2(
                                _inventorApp,
                                commandInternalName,
                                true,
                                out string errorMessage);

                    if (success)
                        return;

                    throw new InvalidOperationException(
                        errorMessage);
                }


        private static string NormalizeDrawingFileName(
            string? drawingName)
        {
            string value =
                drawingName
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }


            try
            {
                value =
                    IOPath.GetFileName(
                        value);
            }
            catch
            {
            }


            string extension =
                IOPath.GetExtension(
                    value);


            if (string.IsNullOrWhiteSpace(
                    extension))
            {
                value +=
                    ".idw";
            }
            else if (!string.Equals(
                         extension,
                         ".idw",
                         StringComparison.OrdinalIgnoreCase))
            {
                value =
                    IOPath.GetFileNameWithoutExtension(
                        value)
                    + ".idw";
            }


            return value;
        }


        private static void CollectSelectedNodes(
            AssemblyGroupMethod2PrintNode node,
            ICollection<AssemblyGroupMethod2PrintNode> result,
            bool includeCurrentNode)
        {
            if (includeCurrentNode &&
                node.PrintDrawing)
            {
                result.Add(
                    node);
            }


            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectSelectedNodes(
                    child,
                    result,
                    true);
            }
        }


        private static void SetFailure(
            AssemblyGroupMethod2PrintNode node,
            string message)
        {
            /*
             * Aggiungiamo FailureReason al modello
             * nel prossimo punto.
             */
            node.FailureReason =
                message;
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception real =
                exception;


            while (real.InnerException != null)
            {
                real =
                    real.InnerException;
            }


            return real.Message;
        }
        private static string BuildLegacyDrawingFileName(
    string drawingName)
        {
            string normalized =
                NormalizeDrawingFileName(
                    drawingName);

            if (string.IsNullOrWhiteSpace(
                    normalized))
            {
                return string.Empty;
            }

            string fileNameWithoutExtension =
                IOPath.GetFileNameWithoutExtension(
                    normalized);

            if (string.IsNullOrWhiteSpace(
                    fileNameWithoutExtension))
            {
                return string.Empty;
            }

            /*
             * Vecchia nomenclatura:
             *
             * DISEGNO nuovo:
             * ASC0517150
             *
             * nome legacy:
             * ASC051715
             *
             * Togliamo quindi SOLO l'ultimo
             * carattere, ma esclusivamente
             * se è numerico.
             */
            char lastCharacter =
                fileNameWithoutExtension[
                    fileNameWithoutExtension.Length - 1];

            if (!char.IsDigit(
                    lastCharacter))
            {
                return string.Empty;
            }

            string legacyName =
                fileNameWithoutExtension.Substring(
                    0,
                    fileNameWithoutExtension.Length - 1);

            if (string.IsNullOrWhiteSpace(
                    legacyName))
            {
                return string.Empty;
            }

            return legacyName +
                ".idw";
        }
    }
}