﻿using Marpatech_8.Features.Core.Inventor;

using InventorApp =
    Inventor.Application;

using InventorAssemblyDocument =
    Inventor.AssemblyDocument;

using InventorDocument =
    Inventor.Document;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2SelectionCleanupService
    {
        private readonly InventorApp _inventorApp;

        public AssemblyGroupMethod2SelectionCleanupService(
            InventorApp inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }

        public void CleanupAfterSelection(
            InventorAssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupMethod2TreeNode> roots)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            if (roots == null)
                return;


            HashSet<string> assemblyPaths =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            foreach (AssemblyGroupMethod2TreeNode root
                in roots)
            {
                CollectAssemblyPathsRecursive(
                    root,
                    assemblyPaths);
            }


            string mainAssemblyPath =
                NormalizePath(
                    InventorService.GetDocumentFullFileName(
                        mainAssembly));


            List<InventorDocument> drawingsToClose =
                new List<InventorDocument>();

            List<InventorDocument> assembliesToClose =
                new List<InventorDocument>();


            foreach (InventorDocument document
                     in InventorService.GetOpenDocuments(
                         _inventorApp))
            {
                string documentPath;

                try
                {
                    documentPath =
                        NormalizePath(
                            InventorService.GetDocumentFullFileName(
                                document));
                }
                catch
                {
                    continue;
                }


                if (string.IsNullOrWhiteSpace(
                        documentPath))
                {
                    continue;
                }


                /*
                 * MAIN mai chiuso.
                 */
                if (string.Equals(
                        documentPath,
                        mainAssemblyPath,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }


                /*
                 * Se durante la selezione è stata
                 * aperta una tavola riconducibile
                 * a uno degli STL, la chiudiamo.
                 *
                 * Per ora usiamo il nome base IAM
                 * come ulteriore sicurezza.
                 */
                if (InventorService.DocumentIsDrawing(
                        document))
                {
                    if (IsDrawingRelatedToTree(
                            documentPath,
                            assemblyPaths))
                    {
                        drawingsToClose.Add(
                            document);
                    }

                    continue;
                }


                if (InventorService.DocumentIsAssembly(
                        document) &&
                    assemblyPaths.Contains(
                        documentPath))
                {
                    assembliesToClose.Add(
                        document);
                }
            }


            /*
             * Prima tavole.
             */
            foreach (InventorDocument drawing
                     in drawingsToClose)
            {
                TryCloseDocument(
                    drawing);
            }


            /*
             * Poi IAM STL.
             */
            foreach (InventorDocument assembly
                     in assembliesToClose)
            {
                TryCloseDocument(
                    assembly);
            }


            /*
             * Ritorno obbligatorio al MAIN.
             */
            InventorService.ActivateAssemblyDocument(
                mainAssembly);

            System.Windows.Forms.Application
                .DoEvents();
        }


        private static void CollectAssemblyPathsRecursive(
            AssemblyGroupMethod2TreeNode node,
            ISet<string> assemblyPaths)
        {
            string path =
                NormalizePath(
                    node.AssemblyPath);

            if (!string.IsNullOrWhiteSpace(
                    path))
            {
                assemblyPaths.Add(
                    path);
            }


            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                CollectAssemblyPathsRecursive(
                    child,
                    assemblyPaths);
            }
        }


        private static bool IsDrawingRelatedToTree(
            string drawingPath,
            IEnumerable<string> assemblyPaths)
        {
            string drawingBaseName;

            try
            {
                drawingBaseName =
                        IOPath.GetFileNameWithoutExtension(
                        drawingPath);
            }
            catch
            {
                return false;
            }


            foreach (string assemblyPath
                in assemblyPaths)
            {
                try
                {
                    string assemblyBaseName =
                        IOPath.GetFileNameWithoutExtension(
                            assemblyPath);

                    if (string.Equals(
                            drawingBaseName,
                            assemblyBaseName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return true;
                    }
                }
                catch
                {
                }
            }


            return false;
        }


        private static void TryCloseDocument(
            InventorDocument document)
        {
            InventorService.CloseDocument(
                document,
                true);

            System.Windows.Forms.Application
                .DoEvents();
        }


        private static string NormalizePath(
            string? path)
        {
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return string.Empty;
            }

            try
            {
                return IOPath
                    .GetFullPath(
                        path.Trim())
                    .TrimEnd(
                       IOPath.DirectorySeparatorChar,
                        IOPath.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }
    }
}