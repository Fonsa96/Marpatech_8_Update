﻿using Inventor;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2TreeProcessor
    {
        private readonly Inventor.Application
            _inventorApp;

        private readonly AssemblyGroupMethod2InternalCollector
            _internalCollector;

        private readonly AssemblyGroupMethod2PrintSelectionService
            _printSelectionService;

        private readonly AssemblyGroupMethod2PrintProcessor
            _printProcessor;

        private readonly AssemblyGroupMethod2PrintSelectionCleanupService
            _printSelectionCleanupService;


        public AssemblyGroupMethod2TreeProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));

            _internalCollector =
                new AssemblyGroupMethod2InternalCollector();

            _printSelectionService =
                new AssemblyGroupMethod2PrintSelectionService();

            _printProcessor =
                new AssemblyGroupMethod2PrintProcessor(
                    inventorApp);

            _printSelectionCleanupService =
                new AssemblyGroupMethod2PrintSelectionCleanupService(
                    inventorApp);
        }


        public void Process(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupMethod2TreeNode> roots,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules,
            StampaCartellineProcessProgress progress)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }

            if (roots == null)
                return;


            try
            {
                /*
                 * Manteniamo il processamento POST-ORDER:
                 *
                 * figli prima
                 * contenitore dopo.
                 */
                foreach (AssemblyGroupMethod2TreeNode root
                    in roots)
                {
                    ProcessNodePostOrder(
                        owner,
                        mainAssembly,
                        root,
                        mainCodePrefix,
                        method2Rules,
                        progress);
                }


                /*
                 * Terminati tutti gli STL,
                 * gestiamo la tavola MAIN.
                 */
                ProcessMainAssemblyDrawing(
                    owner,
                    mainAssembly,
                    progress);


                /*
                 * Gli errori accumulati nei ProcessLog
                 * dei singoli nodi vengono ora trasferiti
                 * nel LOG centrale.
                 *
                 * Non mostriamo più il vecchio popup LOG
                 * separato del Metodo 2.
                 */
                WriteProcessErrorsToCentralLog(
                    roots,
                    progress);
            }
            finally
            {
                /*
                 * Alla fine il MAIN deve sempre
                 * tornare attivo.
                 */
                InventorService.ActivateAssemblyDocument(
                    mainAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        private void ProcessNodePostOrder(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            AssemblyGroupMethod2TreeNode node,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules,
            StampaCartellineProcessProgress progress)
        {
            /*
             * ==================================================
             * POST-ORDER
             * ==================================================
             *
             * Prima processiamo tutti i figli.
             *
             * ATTENZIONE:
             * anche se il contenitore è FALSE,
             * eventuali figli TRUE devono comunque
             * essere processati.
             */
            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                ProcessNodePostOrder(
                    owner,
                    mainAssembly,
                    child,
                    mainCodePrefix,
                    method2Rules,
                    progress);
            }


            /*
             * Nodo presente esclusivamente per
             * mostrare la struttura gerarchica
             * nel caso "solo alcuni STL".
             *
             * I figli sono già stati processati.
             * Questo nodo non deve essere lavorato.
             */
            if (!node.IsProcessable)
            {
                return;
            }


            /*
             * Questo STL è stato deselezionato
             * nel Form 1 Metodo 2.
             */
            if (!node.ProcessStl)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - STL saltato dall'utente.");

                return;
            }


            ProcessSingleStl(
                owner,
                mainAssembly,
                node,
                mainCodePrefix,
                method2Rules,
                progress);
        }


        private void ProcessSingleStl(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            AssemblyGroupMethod2TreeNode node,
            string mainCodePrefix,
            IEnumerable<AssemblyGroupSearchRule> method2Rules,
            StampaCartellineProcessProgress progress)
        {
            AssemblyDocument? stlAssembly =
                null;


            try
            {
                string assemblyPath =
                    node.AssemblyPath
                        ?.Trim()
                    ?? string.Empty;


                /*
                 * Manteniamo il comportamento esistente:
                 * se il percorso IAM non è disponibile,
                 * saltiamo questo STL.
                 *
                 * Ora registriamo anche l'errore.
                 */
                if (string.IsNullOrWhiteSpace(
                        assemblyPath))
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Percorso IAM non disponibile.");

                    return;
                }


                /*
                 * Apertura IAM STL.
                 */
                Document? openedDocument =
                    InventorService.OpenDocument(
                        _inventorApp,
                        assemblyPath,
                        true);

                if (openedDocument == null)
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Impossibile aprire l'IAM STL.");

                    return;
                }


                stlAssembly =
                    openedDocument
                        as AssemblyDocument;


                if (stlAssembly == null)
                {
                    InventorService.CloseDocument(
                        openedDocument,
                        true);

                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Il file aperto non è un assieme Inventor valido.");

                    return;
                }

                if (!InventorService.ActivateAssemblyDocument(
                        stlAssembly))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare l'IAM STL.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - IAM STL aperto.");


                /*
                 * ==================================================
                 * STRUTTURA INTERNA STL
                 * ==================================================
                 */
                AssemblyGroupMethod2PrintNode printTree =
                    _internalCollector.Collect(
                        stlAssembly,
                        mainCodePrefix,
                        method2Rules);


                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - Struttura interna rilevata.");


                /*
                 * ==================================================
                 * FORM 2 MODELESS
                 * ==================================================
                 *
                 * TRUE  = stampa tavola
                 * FALSE = non stampare
                 *
                 * Gli STL annidati partono FALSE
                 * come già stabilito.
                 */
                bool printSelectionConfirmed =
                    _printSelectionService.ShowAndWait(
                        owner,
                        printTree);


                /*
                 * ANNULLA nel Form 2:
                 *
                 * annulla SOLO questo STL corrente.
                 *
                 * Il finally continuerà a:
                 * - chiudere IAM STL;
                 * - tornare al MAIN;
                 *
                 * poi il processo passerà al prossimo STL.
                 */
                if (!printSelectionConfirmed)
                {
                    progress.AddWarning(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Selezione tavole annullata dall'utente.");

                    return;
                }


                /*
                 * ==================================================
                 * CLEANUP DOPO FORM 2
                 * ==================================================
                 *
                 * Manteniamo esattamente la sicurezza
                 * già implementata:
                 *
                 * - chiusura documenti aperti durante l'ispezione;
                 * - ritorno allo STL IAM corrente.
                 */
                _printSelectionCleanupService.Cleanup(
                    stlAssembly,
                    printTree);


                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    node.Code +
                    " - Pulizia dopo selezione completata.");


                /*
                 * ==================================================
                 * STAMPA REALE
                 * ==================================================
                 *
                 * Non modifichiamo la logica del
                 * AssemblyGroupMethod2PrintProcessor.
                 */
                _printProcessor.Process(
                    stlAssembly,
                    printTree,
                    method2Rules,
                    progress);


                /*
                 * Recuperiamo gli eventuali FailureReason
                 * già prodotti dal PrintProcessor.
                 */
                CollectPrintErrors(
                    printTree,
                    node.ProcessLog,
                    node.Code);


                if (node.ProcessLog.Count == 0)
                {
                    progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        node.Code +
                        " - Elaborazione completata.");
                }
            }
            catch (Exception exception)
            {
                /*
                 * IMPORTANTE:
                 *
                 * Come prima, un singolo STL NON deve
                 * interrompere l'intero Metodo 2.
                 *
                 * Ora però l'errore non viene più
                 * inghiottito silenziosamente.
                 */
                string error =
                    node.Code +
                    " - Errore durante il processamento STL: " +
                    GetRealExceptionMessage(
                        exception);


                node.ProcessLog.Add(
                    error);


                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    error);
            }
            finally
            {
                /*
                 * ==================================================
                 * CHIUSURA IAM STL
                 * ==================================================
                 */
                if (stlAssembly != null)
                {
                    bool closeOk =
                        InventorService.TryCloseDocument(
                            stlAssembly,
                            true,
                            out string closeError);

                    if (closeOk)
                    {
                        System.Windows.Forms.Application
                            .DoEvents();
                    }
                    else
                    {
                        progress.AddWarning(
                            StampaCartellineProcessSection.AssemblyGroups,
                            node.Code +
                            " - Impossibile chiudere completamente l'IAM STL: " +
                            closeError);
                    }
                }


                /*
                 * Dopo OGNI STL ritorniamo sempre
                 * al MAIN.
                 */
                InventorService.ActivateAssemblyDocument(
                    mainAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        /*
         * ==================================================
         * RACCOLTA ERRORI DEL PRINT TREE
         * ==================================================
         *
         * Manteniamo la struttura esistente.
         */
        private static void CollectPrintErrors(
            AssemblyGroupMethod2PrintNode node,
            ICollection<string> log,
            string stlCode)
        {
            if (!string.IsNullOrWhiteSpace(
                    node.FailureReason))
            {
                log.Add(
                    stlCode +
                    " > " +
                    node.Code +
                    " | " +
                    node.FailureReason);
            }


            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectPrintErrors(
                    child,
                    log,
                    stlCode);
            }
        }


        /*
         * ==================================================
         * TAVOLA ASSIEME MAIN
         * ==================================================
         */
        private void ProcessMainAssemblyDrawing(
            IWin32Window owner,
            AssemblyDocument mainAssembly,
            StampaCartellineProcessProgress progress)
        {
            DrawingDocument? drawingDocument =
                null;

            string drawingPath =
                string.Empty;

            string mainCode =
                InventorService
                    .ReadIProperty(
                        mainAssembly,
                        "CODICE")
                    .Trim();


            if (string.IsNullOrWhiteSpace(
                    mainCode))
            {
                mainCode =
                    InventorService
                        .GetDocumentFileNameWithoutExtension(
                            mainAssembly);
            }


            try
            {
                if (!InventorService.ActivateAssemblyDocument(
                        mainAssembly))
                {
                    throw new InvalidOperationException(
                        "Impossibile attivare l'assieme MAIN.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                BrowserPane? activeBrowser =
                    InventorService.GetActiveBrowserPane(
                        mainAssembly);


                if (activeBrowser == null)
                {
                    throw new InvalidOperationException(
                        "Browser attivo del MAIN non disponibile.");
                }

                BrowserNode? topNode =
                    InventorService.GetBrowserTopNode(
                        activeBrowser);

                if (topNode == null)
                {
                    throw new InvalidOperationException(
                        "Nodo principale del MAIN non disponibile.");
                }


                if (!InventorService.SelectBrowserNode(
                        topNode))
                {
                    throw new InvalidOperationException(
                        "Impossibile selezionare il nodo principale del MAIN.");
                }

                System.Windows.Forms.Application
                    .DoEvents();


                /*
                 * Apertura tavola tramite comando Inventor,
                 * come già funzionante.
                 */
                ExecuteInventorCommand(
                    "CMxOpenDrawingCmd");


                System.Windows.Forms.Application
                    .DoEvents();


                drawingDocument =
                    InventorService.GetActiveDrawing(
                        _inventorApp);


                if (drawingDocument == null)
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Tavola dell'assieme MAIN non trovata.");


                    MessageBox.Show(
                        owner,
                        "Tavola di " +
                        mainCode +
                        " non trovata.",
                        "Gruppi di montaggio",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);


                    return;
                }


                drawingPath =
                    InventorService
                        .GetDocumentFullFileName(
                            drawingDocument)
                        .Trim();


                DialogResult answer =
                    MessageBox.Show(
                        owner,
                        "Vuoi stampare la tavola di " +
                        mainCode +
                        "?" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        "Posizione nell'albero:" +
                        System.Environment.NewLine +
                        System.Environment.NewLine +
                        mainCode,
                        "Gruppi di montaggio",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);


                if (answer == DialogResult.Yes)
                {
                    ExecuteInventorCommand(
                        "Autodesk:InvPrint:SVCmdBtn");


                    progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Tavola MAIN stampata.");
                }
                else
                {
                    progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        mainCode +
                        " - Stampa tavola MAIN rifiutata dall'utente.");
                }
            }
            catch (Exception exception)
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    mainCode +
                    " - Errore durante la gestione della tavola MAIN: " +
                    GetRealExceptionMessage(
                        exception));


                /*
                 * Manteniamo il popup operativo
                 * che esisteva già.
                 */
                MessageBox.Show(
                    owner,
                    "Errore durante la gestione della tavola di " +
                    mainCode +
                    ":" +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    GetRealExceptionMessage(
                        exception),
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
            finally
            {
                /*
                 * Primo tentativo di chiusura.
                 */
                if (drawingDocument != null)
                {
                    InventorService.ActivateDrawingDocument(
                        drawingDocument);

                    System.Windows.Forms.Application
                        .DoEvents();

                    InventorService.CloseDrawingDocument(
                        drawingDocument,
                        true);

                    System.Windows.Forms.Application
                        .DoEvents();
                }


                /*
                 * Seconda sicurezza per percorso,
                 * mantenuta esattamente come prima.
                 */
                if (!string.IsNullOrWhiteSpace(
                        drawingPath))
                {
                    TryCloseDrawingByPath(
                        drawingPath);
                }


                /*
                 * Ritorno al MAIN.
                 */
                InventorService.ActivateAssemblyDocument(
                    mainAssembly);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        /*
         * ==================================================
         * TRASFERIMENTO PROCESSLOG → LOG CENTRALE
         * ==================================================
         */
        private static void WriteProcessErrorsToCentralLog(
            IEnumerable<AssemblyGroupMethod2TreeNode> roots,
            StampaCartellineProcessProgress progress)
        {
            foreach (AssemblyGroupMethod2TreeNode root
                in roots)
            {
                WriteNodeErrorsToCentralLog(
                    root,
                    progress);
            }
        }


        private static void WriteNodeErrorsToCentralLog(
            AssemblyGroupMethod2TreeNode node,
            StampaCartellineProcessProgress progress)
        {
            foreach (string error
                in node.ProcessLog)
            {
                if (string.IsNullOrWhiteSpace(
                        error))
                {
                    continue;
                }


                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    error);
            }


            foreach (AssemblyGroupMethod2TreeNode child
                in node.Children)
            {
                WriteNodeErrorsToCentralLog(
                    child,
                    progress);
            }
        }


        private void ExecuteInventorCommand(
            string commandInternalName)
        {
            bool success =
                InventorService.TryExecuteControlDefinition2(
                    _inventorApp,
                    commandInternalName,
                    true,
                    out string errorMessage);

            if (success)
                return;

            throw new InvalidOperationException(
                "Errore durante l'esecuzione del comando " +
                commandInternalName +
                ": " +
                errorMessage);
        }


        private void TryCloseDrawingByPath(
            string drawingPath)
        {
            List<Document> documentsToClose =
                InventorService
                    .FindOpenDrawingDocumentsByPath(
                        _inventorApp,
                        drawingPath);

            foreach (Document document
                     in documentsToClose)
            {
                InventorService.CloseDocument(
                    document,
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }

        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;


            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }


            return realException.Message;
        }
    }
}