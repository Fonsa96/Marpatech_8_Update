﻿using Marpatech_8.Features.Core.Inventor;

using InventorAssemblyDocument =
    Inventor.AssemblyDocument;

using InventorComponentOccurrence =
    Inventor.ComponentOccurrence;

using InventorComponentOccurrences =
    Inventor.ComponentOccurrences;

using InventorDocument =
    Inventor.Document;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupCollector
    {
        public List<AssemblyGroupRuntimeItem> CollectMethod1(
            InventorAssemblyDocument mainAssembly,
            IEnumerable<AssemblyGroupSearchRule> configuredRules)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            List<AssemblyGroupSearchRule> rules =
                configuredRules
                    ?.Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .Select(
                        rule =>
                            new AssemblyGroupSearchRule
                            {
                                CodePrefix =
                                    rule.CodePrefix.Trim(),

                                DrawingSearchPath =
                                    rule.DrawingSearchPath
                                        ?.Trim()
                                    ?? string.Empty
                            })
                    .ToList()
                ?? new List<AssemblyGroupSearchRule>();

            if (rules.Count == 0)
            {
                return new List<AssemblyGroupRuntimeItem>();
            }

            Dictionary<string, AssemblyGroupRuntimeItem>
                itemsByAssemblyPath =
                    new Dictionary<string, AssemblyGroupRuntimeItem>(
                        StringComparer.OrdinalIgnoreCase);

            InventorComponentOccurrences?
                rootOccurrences =
                    InventorService.GetAssemblyOccurrences(
                        mainAssembly);

            if (rootOccurrences == null)
            {
                return new List<AssemblyGroupRuntimeItem>();
            }

            CollectOccurrencesRecursive(
                rootOccurrences,
                rules,
                itemsByAssemblyPath);


            return itemsByAssemblyPath
                .Values
                .OrderBy(
                    item =>
                        item.Code,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private static void CollectOccurrencesRecursive(
            InventorComponentOccurrences occurrences,
                    IReadOnlyCollection<AssemblyGroupSearchRule> rules,
            IDictionary<string, AssemblyGroupRuntimeItem>
                itemsByAssemblyPath)
        {
            foreach (InventorComponentOccurrence occurrence
                     in occurrences)
            {
                try
                {
                    InventorDocument? referencedDocument =
                        InventorService.GetOccurrenceDocument(
                            occurrence);

                    if (referencedDocument == null)
                    {
                        continue;
                    }

                    /*
                     * Il Metodo 1 considera solamente
                     * documenti di assieme.
                     */
                    if (!InventorService.DocumentIsAssembly(
                            referencedDocument))
                    {
                        continue;
                    }

                    string assemblyPath =
                        InventorService
                            .GetDocumentFullFileName(
                                referencedDocument)
                            .Trim();

                    string code =
                        InventorService.ReadUserDefinedProperty(
                            referencedDocument,
                            "CODICE");

                    AssemblyGroupSearchRule? matchingRule =
                        FindMatchingRule(
                            code,
                            rules);

                    if (matchingRule != null &&
                        !string.IsNullOrWhiteSpace(
                            assemblyPath))
                    {
                        string normalizedPath =
                            NormalizePath(
                                assemblyPath);

                        /*
                         * VITALE:
                         * lo stesso IAM viene memorizzato
                         * e processato una sola volta,
                         * anche se compare in molte occorrenze.
                         */
                        if (!itemsByAssemblyPath.ContainsKey(
                                normalizedPath))
                        {
                            string drawingName =
                                InventorService.ReadUserDefinedProperty(
                                    referencedDocument,
                                    "DISEGNO");

                            itemsByAssemblyPath.Add(
                                normalizedPath,
                                new AssemblyGroupRuntimeItem
                                {
                                    Code =
                                        code,

                                    DrawingName =
                                        drawingName,

                                    AssemblyPath =
                                        assemblyPath,

                                    DrawingSearchPath =
                                        matchingRule.DrawingSearchPath
                                });
                        }
                    }

                    /*
                     * Se è un sottoassieme, continuiamo
                     * a scendere a qualsiasi profondità.
                     */
                    InventorComponentOccurrences? childOccurrences =
                        InventorService.GetOccurrenceChildOccurrences(
                            occurrence);

                    if (childOccurrences != null)
                    {
                        CollectOccurrencesRecursive(
                            childOccurrences,
                            rules,
                            itemsByAssemblyPath);
                    }
                }
                catch
                {
                    /*
                     * Un singolo componente problematico
                     * non deve interrompere la scansione
                     * dell'intero assieme.
                     */
                }
            }
        }

        private static AssemblyGroupSearchRule?
            FindMatchingRule(
                string code,
                IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }

            string normalizedCode =
                code.Trim();

            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }

                if (normalizedCode.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }

            return null;
        }

        private static string NormalizePath(
            string path)
        {
            try
            {
                return IOPath
                    .GetFullPath(
                        path)
                    .TrimEnd(
                        IOPath.DirectorySeparatorChar,
                        IOPath.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }
    }
}