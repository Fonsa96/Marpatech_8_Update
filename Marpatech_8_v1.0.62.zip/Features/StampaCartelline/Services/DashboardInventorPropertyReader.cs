﻿using Inventor;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class DashboardInventorPropertyReader
    {
        private readonly Inventor.Application _inventorApp;

        public DashboardInventorPropertyReader(
            Inventor.Application inventorApp)
        {
            _inventorApp = inventorApp;
        }

        public void ReadProperties(
            StampaCartellineDashboardSession session)
        {
            AssemblyDocument? document =
                InventorService.GetActiveAssembly(
                    _inventorApp);

            if (document == null)
                return;

            foreach (DashboardPropertySession property
                in session.InventorProperties)
            {
                UpdateProperty(
                    property,
                    InventorService.ReadIPropertyExactName(
                        document,
                        property.InventorPropertyName));
            }
        }

        private static void UpdateProperty(
    DashboardPropertySession property,
    string value)
        {
            property.Value = value;
            property.OriginalValue = value;
        }
    }
}