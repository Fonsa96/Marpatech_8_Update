﻿using InventorApp = Inventor.Application;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.Mail.Forms;

namespace Marpatech_8.Features.Mail
{
    public static class MailCommand
    {
        public static void Execute(
            InventorApp inventorApp,
            FeatureOpenContext context)
        {
            /*
             * ==========================================
             * APERTURA DALLA MAIN DASHBOARD
             * ==========================================
             */
            if (context.MainDashboard != null &&
                !context.MainDashboard.IsDisposed)
            {
                FeatureNavigationService.OpenFeature(
                    context,
                    "Mail",
                    () => new MailDashboardForm(
                        inventorApp,
                        context.IsDarkTheme));

                return;
            }

            /*
             * ==========================================
             * APERTURA DIRETTA DA INVENTOR / RIBBON
             * ==========================================
             *
             * Manteniamo la logica già esistente:
             * Inventor resta owner della finestra.
             */
            InventorWindowWrapper owner =
                InventorService.GetInventorOwner(
                    inventorApp);

            SingleFormService.ShowSingle(
                "Mail",
                () => new MailDashboardForm(
                    inventorApp,
                    context.IsDarkTheme),
                owner);
        }

        /*
         * ==========================================
         * COMPATIBILITÀ CON LE VECCHIE CHIAMATE
         * ==========================================
         */
        public static void Execute(
            InventorApp inventorApp,
            bool isDarkTheme)
        {
            Execute(
                inventorApp,
                FeatureOpenContext.FromInventor(
                    isDarkTheme));
        }
    }
}