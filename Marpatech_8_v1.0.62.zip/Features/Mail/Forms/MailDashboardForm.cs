﻿using Marpatech_8.Features.Mail.Config;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings = Marpatech_8.Features.Core.Settings.WindowSettings;
using Marpatech_8.Features.Mail.Services;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using System.Collections.Generic;
using System.Linq;
using Marpatech_8.Features.Core.Inventor;
using InventorDocument = Inventor.Document;


namespace Marpatech_8.Features.Mail.Forms
{
    public class MailDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;

        private MailSettings _settings = new MailSettings();

        private FlowLayoutPanel? rowsPanel;
        private TextBox? txtSearchMailTypes;

        private readonly CoreWindowSettings _windowSettings;

        public MailDashboardForm(Inventor.Application inventorApp, bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _settings = MailSettingsService.Load();
            _windowSettings = WindowSettingsService.Load(
              "MailDashboard",
              920,
              560);

            InitializeComponent();
            WindowSettingsService.Apply(
                this,
                _windowSettings);
            ReloadRows();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            this.Text = "Invio Mail";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(920, 560);
            this.MinimumSize = new DrawingSize(1550, 560);
            this.BackColor = backgroundColor;
            this.FormClosing += MailDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Invio Mail";
            title.Font = new DrawingFont("Segoe UI", 26, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);

            Button btnAdd = CreateTopButton("Aggiungi Tipo Mail", DrawingColor.FromArgb(37, 99, 235));
            btnAdd.Location = new DrawingPoint(30, 90);
            btnAdd.Click += BtnAdd_Click;

            txtSearchMailTypes = new TextBox();
            txtSearchMailTypes.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            txtSearchMailTypes.Size = new DrawingSize(520, 38);
            txtSearchMailTypes.Location = new DrawingPoint(300, 90);
            txtSearchMailTypes.PlaceholderText = "Cerca configurazione...";
            txtSearchMailTypes.BackColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;
            txtSearchMailTypes.ForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);
            txtSearchMailTypes.BorderStyle = BorderStyle.FixedSingle;
            txtSearchMailTypes.TabStop = true;
            txtSearchMailTypes.TextChanged += (s, e) => ReloadRows();


            Button btnImport = CreateTopButton("Carica Configurazione", DrawingColor.FromArgb(245, 158, 11));
            btnImport.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnImport.Location = new DrawingPoint(this.ClientSize.Width - 380, 90);
            btnImport.Click += BtnImport_Click;

            Button btnExport = CreateTopButton("Esporta Configurazione", DrawingColor.FromArgb(124, 58, 237));
            btnExport.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnExport.Location = new DrawingPoint(this.ClientSize.Width - 200, 90);
            btnExport.Click += BtnExport_Click;

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(30, 150);
            mainPanel.Size = new DrawingSize(this.ClientSize.Width - 60, this.ClientSize.Height - 185);
            mainPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(14);

            rowsPanel = new FlowLayoutPanel();
            rowsPanel.Dock = DockStyle.Fill;
            rowsPanel.AutoScroll = true;
            rowsPanel.WrapContents = false;
            rowsPanel.FlowDirection = FlowDirection.TopDown;
            rowsPanel.BackColor = cardColor;
            rowsPanel.Padding = new Padding(6);

            mainPanel.Controls.Add(rowsPanel);

            this.Controls.Add(title);
            this.Controls.Add(btnAdd);
            this.Controls.Add(txtSearchMailTypes);
            this.Controls.Add(btnImport);
            this.Controls.Add(btnExport);
            this.Controls.Add(mainPanel);
        }

        private Button CreateTopButton(string text, DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(165, 38);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void ReloadRows()
        {
            if (rowsPanel == null)
                return;

            rowsPanel.SuspendLayout();
            rowsPanel.Controls.Clear();

            string searchText = txtSearchMailTypes?.Text.Trim() ?? "";

            List<MailTypeConfig> filteredMailTypes = _settings.MailTypes
                .Where(x =>
                    string.IsNullOrWhiteSpace(searchText) ||
                    x.Description.Contains(searchText, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(x => x.Enabled)
                .ThenBy(x => x.Description)
                .ToList();

            if (filteredMailTypes.Count == 0)
            {
                Label lblNoResults = new Label();

                lblNoResults.Text = "Nessuna configurazione trovata";
                lblNoResults.AutoSize = false;
                lblNoResults.Width = rowsPanel.ClientSize.Width - 40;
                lblNoResults.Height = 80;
                lblNoResults.TextAlign = ContentAlignment.MiddleCenter;
                lblNoResults.Font = new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold);

                lblNoResults.ForeColor = _isDarkTheme
                    ? DrawingColor.FromArgb(170, 178, 190)
                    : DrawingColor.FromArgb(100, 116, 139);

                rowsPanel.Controls.Add(lblNoResults);
                rowsPanel.ResumeLayout();
                return;
            }

            foreach (MailTypeConfig mailType in filteredMailTypes)
            {
                rowsPanel.Controls.Add(CreateMailTypeRow(mailType));
            }
            rowsPanel.ResumeLayout();
        }

        private Panel CreateMailTypeRow(MailTypeConfig mailType)
        {
            DrawingColor rowColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor textColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            int rowWidth = rowsPanel != null
                ? rowsPanel.ClientSize.Width - 28
                : 820;

            Panel row = new Panel();
            row.Size = new DrawingSize(rowWidth, 105);
            row.Margin = new Padding(4, 4, 4, 12);
            row.BackColor = rowColor;

            Label lblDescription = new Label();
            lblDescription.Text = mailType.Description;
            lblDescription.Font = new DrawingFont("Segoe UI", 18, DrawingFontStyle.Bold);
            lblDescription.ForeColor = textColor;
            lblDescription.AutoSize = false;
            lblDescription.Location = new DrawingPoint(24, 14);
            lblDescription.Size = new DrawingSize(430, 36);

            string configured = mailType.IsConfigured ? "✔" : "✖";
            string path = mailType.IncludeLink ? "✔" : "✖";
            string excel = mailType.IncludeExcelAttachment ? "✔" : "✖";
            string enabled = mailType.Enabled ? "✔" : "✖";

            Label lblStatus = new Label();
            string activeStatus = mailType.Enabled ? "ATTIVA" : "DISATTIVATA";

            lblStatus.Text =
                 $"Configurata: {configured}    |    Inserimento Percorso: {path}    |    Inserimento Excel: {excel}    |    Attiva: {enabled}";
            lblStatus.Font = new DrawingFont("Segoe UI", 12, DrawingFontStyle.Bold);
            lblStatus.ForeColor = textColor;
            lblStatus.AutoSize = false;
            lblStatus.Location = new DrawingPoint(24, 56);
            lblStatus.Size = new DrawingSize(800, 28);

            Button btnSend = CreateBigRowButton("✉  Invia Mail", DrawingColor.FromArgb(22, 163, 74));

            bool canSend = mailType.IsConfigured && mailType.Enabled;

            if (!canSend)
            {
                btnSend.Enabled = false;
                btnSend.BackColor = DrawingColor.FromArgb(100, 116, 139);
                btnSend.Cursor = Cursors.No;
            }
            Button btnConfig = CreateBigRowButton("⚙  Configura", DrawingColor.FromArgb(37, 99, 235));
            Button btnDelete = CreateBigRowButton("🗑  Elimina", DrawingColor.FromArgb(220, 38, 38));

            void PositionButtons()
            {
                int marginRight = 24;
                int gap = 14;
                int buttonTop = 24;

                btnDelete.Location = new DrawingPoint(row.Width - marginRight - btnDelete.Width, buttonTop);
                btnConfig.Location = new DrawingPoint(btnDelete.Left - gap - btnConfig.Width, buttonTop);
                btnSend.Location = new DrawingPoint(btnConfig.Left - gap - btnSend.Width, buttonTop);
            }

            btnSend.Click += (s, e) => SendMail(mailType);
            btnConfig.Click += (s, e) => ConfigureMailType(mailType);
            btnDelete.Click += (s, e) => DeleteMailType(mailType);

            row.Controls.Add(lblDescription);
            row.Controls.Add(lblStatus);
            row.Controls.Add(btnSend);
            row.Controls.Add(btnConfig);
            row.Controls.Add(btnDelete);

            row.Resize += (s, e) => PositionButtons();

            PositionButtons();

            return row;
        }

        private Button CreateBigRowButton(string text, DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(150, 58);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            MailTypeConfig newType = new MailTypeConfig
            {
                Description = "Nuovo Tipo Mail"
            };

            _settings.MailTypes.Add(newType);
            MailSettingsService.Save(_settings);

            ReloadRows();
        }

        private void DeleteMailType(MailTypeConfig mailType)
        {
            if (!MailDialogService.Confirm(
                "Sei sicuro di voler eliminare questo tipo mail?",
                "Elimina tipo mail",
                this))
            {
                return;
            }

            _settings.MailTypes.Remove(mailType);
            MailSettingsService.Save(_settings);

            ReloadRows();
        }

        private void ConfigureMailType(MailTypeConfig mailType)
        {
            MailTypeConfigForm form = new MailTypeConfigForm(
                _isDarkTheme,
                _settings,
                mailType);

            form.FormClosed += (s, e) =>
            {
                MailSettingsService.Save(_settings);
                ReloadRows();
            };

            form.Show(this);
            form.Activate();
        }

        private void SendMail(MailTypeConfig mailType)
        {
            if (!mailType.Enabled)
            {
                MailDialogService.Warning(
                    "Questo tipo mail è disattivato.",
                    "Invia Mail",
                    this);

                return;
            }

            if (!mailType.IsConfigured)
            {
                MailDialogService.Warning(
                    "Questo tipo mail non risulta ancora configurato.",
                    "Invia Mail",
                    this);

                return;
            }

            if (mailType.RunMultiReleaseCommand)
            {
                bool releaseOk =
                    InventorService.TryExecuteControlDefinition(
                        _inventorApp,
                        "DEDNETINV_RIL_MULTI",
                        out bool commandFound,
                        out string errorMessage);

                if (!releaseOk)
                {

                    if (!commandFound &&
                        string.IsNullOrWhiteSpace(
                            errorMessage))
                    {
                        MailDialogService.Warning(
                            "Comando DEDNETINV_RIL_MULTI non trovato.",
                            "Invio Mail",
                            this);

                        return;
                    }

                    MailDialogService.Error(
                        "Errore durante il rilascio multiplo.\n\n" +
                        errorMessage,
                        "Invio Mail",
                        this);

                    return;
                }

                MailDialogService.Info(
                    "Rilascio multiplo completato.\n\nOra verrà composta la mail.",
                    "Invio Mail",
                    this);
            }

            try
            {
                InventorDocument? document =
                    InventorService.GetActiveDocument(
                        _inventorApp);

                if (document == null)
                {
                    MailDialogService.Warning(
                        "Nessun documento aperto in Inventor.",
                        "Invio Mail",
                        this);

                    return;
                }

                Dictionary<string, string> values =
                    InventorService.ReadConfiguredProperties(
                        document,
                        _settings.Variables.Select(
                            variable => (
                                variable.Name,
                                variable.IPropertyName)));


                string subject =
                    MailTemplateService.ApplyVariables(
                        mailType.SubjectTemplate,
                        _settings,
                        values);

                string body =
                    MailTemplateService.ApplyVariables(
                        mailType.BodyTemplate,
                        _settings,
                        values);

                string linkPath = "";
                string attachmentPath = "";

                if (mailType.IncludeLink || mailType.IncludeExcelAttachment)
                {
                    string searchValue = "";

                    if (!string.IsNullOrWhiteSpace(mailType.SearchPropertyName) &&
                        values.ContainsKey(mailType.SearchPropertyName))
                    {
                        searchValue = values[mailType.SearchPropertyName];
                    }

                    if (string.IsNullOrWhiteSpace(searchValue))
                    {
                        MailDialogService.Warning(
                            "La variabile di ricerca cartella è vuota o non trovata:\n\n" +
                            mailType.SearchPropertyName,
                            "Invio Mail",
                            this);

                        return;
                    }

                    if (mailType.IncludeLink)
                    {
                        linkPath = MailPathService.BuildMailLinkPath(
                            mailType,
                            searchValue);

                        if (string.IsNullOrWhiteSpace(linkPath))
                            body = MailTemplateService.RemoveLinkTag(body);
                    }
                    else
                    {
                        body = MailTemplateService.RemoveLinkTag(body);
                    }

                    if (mailType.IncludeExcelAttachment)
                    {
                        string excelFolder =
                            MailPathService.BuildExcelSearchPath(
                                mailType,
                                searchValue);

                        attachmentPath =
                            MailExcelAttachmentService.FindExcelAttachment(excelFolder);

                        if (string.IsNullOrWhiteSpace(attachmentPath))
                        {
                            MailDialogService.Warning(
                                "Nessun file Excel ANTICIPI trovato.\n\n" +
                                "La mail verrà aperta senza allegato.",
                                "Invio Mail",
                                this);
                        }
                    }
                }
                else
                {
                    body = MailTemplateService.RemoveLinkTag(body);
                }

                MailOutlookService.CreateMail(
                    mailType.To,
                    mailType.Cc,
                    subject,
                    body,
                    linkPath,
                    attachmentPath);
            }
            catch (Exception ex)
            {
                MailDialogService.Error(
                    "Errore durante la preparazione della mail.\n\n" + ex.Message,
                    "Invio Mail",
                    this);
            }
        }

        private void BtnImport_Click(object? sender, EventArgs e)
        {
            try
            {
                string selectedFile =
                    MailDialogService.SelectOpenFile(
                        "Carica configurazione Mail",
                        "File JSON (*.json)|*.json",
                        this);

                if (string.IsNullOrWhiteSpace(selectedFile))
                    return;

                if (!MailDialogService.Confirm(
                    "La configurazione attuale verrà sostituita.\n\nVuoi continuare?",
                    "Carica configurazione",
                    this))
                {
                    return;
                }

                MailSettingsService.ImportFromFile(selectedFile);

                _settings = MailSettingsService.Load();

                ReloadRows();

                MailDialogService.Info(
                    "Configurazione caricata correttamente.",
                    "Carica configurazione",
                    this);
            }
            catch (Exception ex)
            {
                MailDialogService.Error(
                    ex.Message,
                    "Errore importazione",
                    this);
            }
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            try
            {
                string destinationFile =
                    MailDialogService.SelectSaveFile(
                        "Esporta configurazione Mail",
                        "File JSON (*.json)|*.json",
                        "MailSettings.json",
                        this);

                if (string.IsNullOrWhiteSpace(destinationFile))
                    return;

                string sourceFile = MailSettingsService.SettingsFilePath;

                MailFileService.CopyFileSafe(
                    sourceFile,
                    destinationFile,
                    true);

                MailDialogService.Info(
                    "Configurazione esportata correttamente.",
                    "Esporta configurazione",
                    this);
            }
            catch (Exception ex)
            {
                MailDialogService.Error(
                    ex.Message,
                    "Errore esportazione",
                    this);
            }
        }
        private void MailDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "MailDashboard");
        }
    }
}