﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Forms
{
    public static class SingleFormService
    {
        private static readonly Dictionary<string, Form> OpenForms =
            new Dictionary<string, Form>();


        public static void ShowSingle(
            string key,
            Func<Form> createForm,
            IWin32Window? owner = null,
            bool showIfAlreadyOpenButHidden = true)
        {
            if (OpenForms.ContainsKey(key))
            {
                Form existingForm =
                    OpenForms[key];


                if (!existingForm.IsDisposed)
                {
                    /*
                     * ==========================================
                     * FORM ESISTENTE MA NASCOSTO
                     * ==========================================
                     *
                     * Normalmente ShowSingle continua a
                     * comportarsi come prima.
                     *
                     * Per la Main Dashboard, invece,
                     * possiamo scegliere di NON mostrarla
                     * se è stata nascosta volutamente
                     * perché una Feature è attiva.
                     */
                    if (!existingForm.Visible &&
                        !showIfAlreadyOpenButHidden)
                    {
                        return;
                    }


                    if (existingForm.WindowState ==
                        FormWindowState.Minimized)
                    {
                        existingForm.WindowState =
                            FormWindowState.Normal;
                    }


                    existingForm.Show();

                    existingForm.Activate();

                    existingForm.BringToFront();

                    existingForm.Focus();

                    return;
                }


                OpenForms.Remove(
                    key);
            }


            /*
             * ==========================================
             * NUOVO FORM
             * ==========================================
             */
            Form form =
                createForm();


            OpenForms[key] =
                form;


            form.FormClosed +=
                (s, e) =>
                {
                    /*
                     * Rimuoviamo la chiave solamente
                     * se rappresenta ancora proprio
                     * questo Form.
                     */
                    if (OpenForms.TryGetValue(
                            key,
                            out Form? registeredForm) &&
                        ReferenceEquals(
                            registeredForm,
                            form))
                    {
                        OpenForms.Remove(
                            key);
                    }
                };


            form.Show(
                owner);

            form.Activate();

            form.BringToFront();
        }
    }
}