﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;

using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class ManualSettingsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly ManualSettings _settings;
        private readonly ManualSettingsWindowSettings _windowSettings;

        private TextBox? txtBaseTemplatePath;
        private TextBox? txtOutputFolderPath;

        public bool Saved { get; private set; } = false;

        public ManualSettingsForm(bool isDarkTheme, ManualSettings settings)
        {
            _isDarkTheme = isDarkTheme;
            _settings = settings;
            _windowSettings = ManualSettingsWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();
            LoadValues();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor inputBackColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            DrawingColor inputForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Impostazioni Genera Word";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(900, 520);
            MinimumSize = new DrawingSize(850, 480);
            BackColor = backgroundColor;
            FormClosing += ManualSettingsForm_FormClosing;

            Label title = new Label();
            title.Text = "Impostazioni Genera Word";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Panel panel = new Panel();
            panel.Location = new DrawingPoint(35, 95);
            panel.Size = new DrawingSize(ClientSize.Width - 70, ClientSize.Height - 170);
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel.BackColor = cardColor;
            panel.Padding = new Padding(20);

            Label lblBase = CreateLabel("Percorso base template manuali", titleColor);
            lblBase.Location = new DrawingPoint(25, 25);

            txtBaseTemplatePath = CreateTextBox(inputBackColor, inputForeColor);
            txtBaseTemplatePath.Location = new DrawingPoint(25, 55);
            txtBaseTemplatePath.Size = new DrawingSize(panel.Width - 190, 32);
            txtBaseTemplatePath.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            Button btnBrowseBase = CreateButton("Sfoglia", DrawingColor.FromArgb(37, 99, 235), 120, 34);
            btnBrowseBase.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnBrowseBase.Location = new DrawingPoint(panel.Width - 145, 54);
            btnBrowseBase.Click += (s, e) => BrowseFolder(txtBaseTemplatePath);

            Label lblOutput = CreateLabel("Cartella output manuali generati", titleColor);
            lblOutput.Location = new DrawingPoint(25, 115);

            txtOutputFolderPath = CreateTextBox(inputBackColor, inputForeColor);
            txtOutputFolderPath.Location = new DrawingPoint(25, 145);
            txtOutputFolderPath.Size = new DrawingSize(panel.Width - 190, 32);
            txtOutputFolderPath.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            Button btnBrowseOutput = CreateButton("Sfoglia", DrawingColor.FromArgb(37, 99, 235), 120, 34);
            btnBrowseOutput.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnBrowseOutput.Location = new DrawingPoint(panel.Width - 145, 144);
            btnBrowseOutput.Click += (s, e) => BrowseFolder(txtOutputFolderPath);

            Button btnImport = CreateButton("Carica Configurazione", DrawingColor.FromArgb(245, 158, 11), 210, 42);
            btnImport.Location = new DrawingPoint(25, 220);
            btnImport.Click += BtnImport_Click;

            Button btnExport = CreateButton("Esporta Configurazione", DrawingColor.FromArgb(124, 58, 237), 210, 42);
            btnExport.Location = new DrawingPoint(250, 220);
            btnExport.Click += BtnExport_Click;

            panel.Controls.Add(lblBase);
            panel.Controls.Add(txtBaseTemplatePath);
            panel.Controls.Add(btnBrowseBase);
            panel.Controls.Add(lblOutput);
            panel.Controls.Add(txtOutputFolderPath);
            panel.Controls.Add(btnBrowseOutput);
            panel.Controls.Add(btnImport);
            panel.Controls.Add(btnExport);

            Button btnClose = CreateButton("Chiudi", DrawingColor.FromArgb(100, 116, 139), 150, 45);
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Location = new DrawingPoint(ClientSize.Width - 370, ClientSize.Height - 65);
            btnClose.Click += (s, e) => Close();

            Button btnSave = CreateButton("Salva", DrawingColor.FromArgb(22, 163, 74), 150, 45);
            btnSave.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSave.Location = new DrawingPoint(ClientSize.Width - 205, ClientSize.Height - 65);
            btnSave.Click += BtnSave_Click;

            Controls.Add(title);
            Controls.Add(panel);
            Controls.Add(btnClose);
            Controls.Add(btnSave);
        }

        private Label CreateLabel(string text, DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;
            return label;
        }

        private TextBox CreateTextBox(DrawingColor backColor, DrawingColor foreColor)
        {
            TextBox textBox = new TextBox();
            textBox.Font = new DrawingFont("Segoe UI", 10);
            textBox.BackColor = backColor;
            textBox.ForeColor = foreColor;
            textBox.BorderStyle = BorderStyle.FixedSingle;
            return textBox;
        }

        private Button CreateButton(string text, DrawingColor color, int width, int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private void LoadValues()
        {
            if (txtBaseTemplatePath != null)
                txtBaseTemplatePath.Text = _settings.BaseTemplatePath;

            if (txtOutputFolderPath != null)
                txtOutputFolderPath.Text = _settings.OutputFolderPath;
        }

        private void BrowseFolder(TextBox? targetTextBox)
        {
            if (targetTextBox == null)
                return;

            using FolderBrowserDialog dialog = new FolderBrowserDialog();

            if (!string.IsNullOrWhiteSpace(targetTextBox.Text))
                dialog.SelectedPath = targetTextBox.Text;

            if (dialog.ShowDialog() != DialogResult.OK)
                return;

            targetTextBox.Text = dialog.SelectedPath;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (txtBaseTemplatePath == null || txtOutputFolderPath == null)
                return;

            _settings.BaseTemplatePath = txtBaseTemplatePath.Text.Trim();
            _settings.OutputFolderPath = txtOutputFolderPath.Text.Trim();

            ManualSettingsService.Save(_settings);

            Saved = true;

            MessageBox.Show(
                "Impostazioni salvate correttamente.",
                "Impostazioni Genera Word",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            Close();
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            try
            {
                using SaveFileDialog dialog = new SaveFileDialog();

                dialog.Title = "Esporta configurazione Genera Word";
                dialog.Filter = "File JSON (*.json)|*.json";
                dialog.FileName = "ManualConfigurationPackage.json";

                if (dialog.ShowDialog() != DialogResult.OK)
                    return;

                ManualConfigurationPackageService.ExportToFile(dialog.FileName);

                MessageBox.Show(
                    "Configurazione esportata correttamente.",
                    "Esporta configurazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Errore esportazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnImport_Click(object? sender, EventArgs e)
        {
            try
            {
                using OpenFileDialog dialog = new OpenFileDialog();

                dialog.Title = "Carica configurazione Genera Word";
                dialog.Filter = "File JSON (*.json)|*.json";

                if (dialog.ShowDialog() != DialogResult.OK)
                    return;

                DialogResult result = MessageBox.Show(
                    "La configurazione attuale verrà sostituita.\n\nVuoi continuare?",
                    "Carica configurazione",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result != DialogResult.Yes)
                    return;

                ManualConfigurationPackageService.ImportFromFile(dialog.FileName);

                ManualSettings importedSettings = ManualSettingsService.Load();

                _settings.BaseTemplatePath = importedSettings.BaseTemplatePath;
                _settings.OutputFolderPath = importedSettings.OutputFolderPath;
                _settings.Properties = importedSettings.Properties;

                LoadValues();

                Saved = true;

                MessageBox.Show(
                    "Configurazione caricata correttamente.",
                    "Carica configurazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Errore importazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ApplyWindowSettings()
        {
            Width = _windowSettings.Width;
            Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                StartPosition = FormStartPosition.Manual;
                Left = _windowSettings.Left;
                Top = _windowSettings.Top;
            }

            if (_windowSettings.IsMaximized)
                WindowState = FormWindowState.Maximized;
        }

        private void ManualSettingsForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = Width;
                _windowSettings.Height = Height;
                _windowSettings.Left = Left;
                _windowSettings.Top = Top;
            }

            _windowSettings.IsMaximized =
                WindowState == FormWindowState.Maximized;

            ManualSettingsWindowSettingsService.Save(_windowSettings);
        }
    }
}