﻿using System;
using System.IO;
using Inventor;
using Marpatech_8.Features.GeneraWord.Forms;
using IOPath = System.IO.Path;
using IOFile = System.IO.File;
using System.Threading.Tasks;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualImageService
    {
        private static string TempFolder
        {
            get
            {
                string appData = System.Environment.GetFolderPath(
                    System.Environment.SpecialFolder.ApplicationData);

                return IOPath.Combine(
                    appData,
                    "Marpatech",
                    "Temp",
                    "GeneraWord");
            }
        }

        public static async Task<string> PrepareAndSaveCurrentViewAsync(
    Inventor.Application inventorApp,
    bool isDarkTheme,
    IWin32Window? owner)
        {
            Directory.CreateDirectory(TempFolder);
            CleanTempFolder();

            TaskCompletionSource<bool> tcs = new TaskCompletionSource<bool>();

            PositionImageForm form = new PositionImageForm(isDarkTheme);

            form.FormClosed += (s, e) =>
            {
                tcs.TrySetResult(form.ImageCaptured);
            };

            form.Show(owner);
            form.Activate();

            bool captured = await tcs.Task;

            if (!captured)
                throw new OperationCanceledException(
                    "Generazione manuale annullata dall'utente.");

            string imagePath = IOPath.Combine(
                TempFolder,
                "InventorView.png");

            inventorApp.ActiveView.SaveAsBitmap(
                imagePath,
                1920,
                1080);

            return imagePath;
        }

        public static void CleanTempFolder()
        {
            if (!Directory.Exists(TempFolder))
                return;

            foreach (string file in Directory.GetFiles(TempFolder))
            {
                try
                {
                    IOFile.Delete(file);
                }
                catch
                {
                }
            }
        }
    }
}