﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Inventor;

using IOPath = System.IO.Path;
using IOFile = System.IO.File;

using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public class ManualWordService
    {
        public void ProcessWordFiles(
            string generationFolder,
            Dictionary<string, string> propertyValues,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf)
        {
            List<string> wordFiles = Directory
                .GetFiles(generationFolder, "*.*", SearchOption.AllDirectories)
                .Where(file =>
                    file.EndsWith(".doc", StringComparison.OrdinalIgnoreCase) ||
                    file.EndsWith(".docx", StringComparison.OrdinalIgnoreCase))
                .Where(file => !IOPath.GetFileName(file).StartsWith("~$"))
                .ToList();

            Dictionary<string, string> placeholderMap =
            BuildPlaceholderMap(propertyValues);

            Word.Application? wordApp = null;

            try
            {
                wordApp = new Word.Application();
                wordApp.Visible = false;
                wordApp.DisplayAlerts = Word.WdAlertLevel.wdAlertsNone;

                foreach (string wordFile in wordFiles)
                {
                    string currentWordFile =
                        RenameWordFileIfNeeded(
                            wordFile,
                            propertyValues);

                    ProcessSingleDocument(
                        wordApp,
                        currentWordFile,
                        placeholderMap,
                        inventorImagePath,
                        exportPdf,
                        exportOnlyDichiarazionePdf);
                }
            }
            finally
            {
                if (wordApp != null)
                {
                    wordApp.Quit(false);

                    Marshal.ReleaseComObject(wordApp);

                    wordApp = null;
                }
            }
        }
        private string RenameWordFileIfNeeded(
    string wordFile,
    Dictionary<string, string> propertyValues)
        {
            if (!propertyValues.ContainsKey("NumeroCommessa"))
                return wordFile;

            string numeroCommessa = propertyValues["NumeroCommessa"];

            if (string.IsNullOrWhiteSpace(numeroCommessa))
                return wordFile;

            string fileName = IOPath.GetFileName(wordFile);

            if (!fileName.Contains("NCOM", StringComparison.OrdinalIgnoreCase))
                return wordFile;

            string directory = IOPath.GetDirectoryName(wordFile) ?? "";

            string newFileName = fileName.Replace(
                "NCOM",
                numeroCommessa,
                StringComparison.OrdinalIgnoreCase);

            string newPath = IOPath.Combine(directory, newFileName);

            if (IOFile.Exists(newPath))
                IOFile.Delete(newPath);

            IOFile.Move(wordFile, newPath);

            return newPath;
        }
        private Dictionary<string, string> BuildPlaceholderMap(
             Dictionary<string, string> propertyValues)
                 {
            DateTime today = DateTime.Today;

            Dictionary<string, string> map = new Dictionary<string, string>();

            map["(*)"] = today.ToString("dd/MM/yyyy");
            map["(**)"] = GetValue(propertyValues, "NumeroCommessa");
            map["(***)"] = GetValue(propertyValues, "CodiceCliente");
            map["(****)"] = GetValue(propertyValues, "NomeCliente");
            map["(*****)"] = today.ToString("yyyy");
            map["(******)"] = GetValue(propertyValues, "TipoProdotto");
            map["(*******)"] = today.ToString("MM/yyyy");

            for (int i = 0; i <= 5; i++)
            {
                map["(*" + i + "*)"] = GetValue(propertyValues, "Potenza Motore " + i);
                map["(IP" + i + ")"] = GetValue(propertyValues, "IP " + i);
                map["(T" + i + ")"] = GetValue(propertyValues, "Tensione " + i);
                map["(F" + i + ")"] = GetValue(propertyValues, "Frequenza " + i);
                map["(L" + i + ")"] = GetValue(propertyValues, "Lub " + i);
            }

            return map;
        }

        private string GetValue(
            Dictionary<string, string> values,
            string key)
        {
            if (values.ContainsKey(key))
                return values[key];

            return "";
        }
        private void ProcessSingleDocument(
            Word.Application wordApp,
            string wordFile,
            Dictionary<string, string> placeholderMap,
            string inventorImagePath,
            bool exportPdf,
            bool exportOnlyDichiarazionePdf)
        {
            Word.Document? document = null;

            try
            {
                document = wordApp.Documents.Open(
                    wordFile,
                    ReadOnly: false,
                    Visible: false);

                ReplaceInRange(
                    document.Content,
                    placeholderMap);

                foreach (Word.Section section in document.Sections)
                {
                    foreach (Word.HeaderFooter footer in section.Footers)
                    {
                        ReplaceInRange(
                            footer.Range,
                            placeholderMap);
                    }
                }

                InsertInventorImage(
                             document,
                            inventorImagePath);

               document.Save();

                ExportPdfIfNeeded(
                    document,
                    wordFile,
                    exportPdf,
                    exportOnlyDichiarazionePdf);
            }
            finally
            {
                if (document != null)
                {
                    document.Close(false);

                    Marshal.ReleaseComObject(document);

                    document = null;
                }
            }
        }
        private void ReplaceInRange(
    Word.Range range,
    Dictionary<string, string> placeholderMap)
        {
            foreach (KeyValuePair<string, string> item in placeholderMap)
            {
                Word.Find find = range.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = item.Key;
                find.Replacement.Text = item.Value;

                object replaceAll =
                    Word.WdReplace.wdReplaceAll;

                find.Execute(
                    Replace: ref replaceAll);
            }
        }
        private void InsertInventorImage(
    Word.Document document,
    string inventorImagePath)
        {
            if (string.IsNullOrWhiteSpace(inventorImagePath))
                return;

            if (!IOFile.Exists(inventorImagePath))
                return;

            if (!document.Bookmarks.Exists("ImgInventor"))
                return;

            Word.Range range =
                document.Bookmarks["ImgInventor"].Range;

            range.Text = "";

            Word.InlineShape inlineShape =
                range.InlineShapes.AddPicture(
                    FileName: inventorImagePath,
                    LinkToFile: false,
                    SaveWithDocument: true);

            inlineShape.Width = 420;
        }
        private void ExportPdfIfNeeded(
    Word.Document document,
    string wordFile,
    bool exportPdf,
    bool exportOnlyDichiarazionePdf)
        {
            if (!exportPdf && !exportOnlyDichiarazionePdf)
                return;

            string fileNameWithoutExtension =
                IOPath.GetFileNameWithoutExtension(wordFile);

            if (exportOnlyDichiarazionePdf && !exportPdf)
            {
                if (!fileNameWithoutExtension.StartsWith(
                    "DICHIARAZIONE",
                    StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }
            }

            string directory =
                IOPath.GetDirectoryName(wordFile) ?? "";

            string pdfPath =
                IOPath.Combine(
                    directory,
                    fileNameWithoutExtension + ".pdf");

            if (IOFile.Exists(pdfPath))
                return;

            document.ExportAsFixedFormat(
                pdfPath,
                Word.WdExportFormat.wdExportFormatPDF);
        }

    }
}