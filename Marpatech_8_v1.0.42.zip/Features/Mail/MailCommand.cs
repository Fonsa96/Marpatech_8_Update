﻿using System;
using Inventor;
using Marpatech_8.Features.Mail.Forms;
using Marpatech_8.Features.MainDashboard.Services;

namespace Marpatech_8.Features.Mail
{
    public static class MailCommand
    {
        public static void Execute(Inventor.Application inventorApp, bool isDarkTheme)
        {
            InventorWindowWrapper owner =
             InventorService.GetInventorOwner(inventorApp);

            SingleFormService.ShowSingle(
                "Mail",
                () => new MailDashboardForm(inventorApp, isDarkTheme),
                owner);
        }
    }
}