﻿using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.MainDashboard.Services
{
    public static class FeatureNavigationService
    {
        public static void OpenFeature(
            Form mainDashboard,
            string key,
            Func<Form> createFeatureForm,
            IWin32Window? owner = null)
        {
            if (mainDashboard == null || mainDashboard.IsDisposed)
                return;

            mainDashboard.Hide();

            SingleFormService.ShowSingle(
                key,
                () =>
                {
                    Form featureForm = createFeatureForm();

                    featureForm.FormClosed += (s, e) =>
                    {
                        if (!mainDashboard.IsDisposed)
                        {
                            mainDashboard.Show();

                            if (mainDashboard.WindowState == FormWindowState.Minimized)
                                mainDashboard.WindowState = FormWindowState.Normal;

                            mainDashboard.TopMost = true;
                            mainDashboard.TopMost = false;

                            mainDashboard.Activate();
                            mainDashboard.BringToFront();
                            mainDashboard.Focus();
                        }
                    };

                    return featureForm;
                },
                owner);
        }
    }
}