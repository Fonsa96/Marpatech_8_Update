﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Marpatech_8.Features.MainDashboard.Services
{
    public static class SingleFormService
    {
        private static readonly Dictionary<string, Form> OpenForms =
            new Dictionary<string, Form>();

        public static void ShowSingle(
            string key,
            Func<Form> createForm,
            IWin32Window? owner = null)
        {
            if (OpenForms.ContainsKey(key))
            {
                Form existingForm = OpenForms[key];

                if (!existingForm.IsDisposed)
                {
                    if (existingForm.WindowState == FormWindowState.Minimized)
                        existingForm.WindowState = FormWindowState.Normal;

                    existingForm.Show();
                    existingForm.Activate();
                    existingForm.BringToFront();
                    existingForm.Focus();

                    return;
                }

                OpenForms.Remove(key);
            }

            Form form = createForm();

            OpenForms[key] = form;

            form.FormClosed += (s, e) =>
            {
                if (OpenForms.ContainsKey(key))
                    OpenForms.Remove(key);
            };

            form.Show(owner);
            form.Activate();
            form.BringToFront();
        }
    }
}