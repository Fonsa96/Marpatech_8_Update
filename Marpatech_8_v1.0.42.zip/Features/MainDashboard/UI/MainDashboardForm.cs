﻿using Marpatech_8.Features.GeneraWord;
using Marpatech_8.Features.Mail;
using Marpatech_8.Features.Mail.Forms;
using Marpatech_8.Features.GeneraWord.Forms;
using Marpatech_8.Features.MainDashboard.MainWindowSettings;
using Marpatech_8.Features.MainDashboard.Services;
using Marpatech_8.Features.Settings;
using System;
using System.IO;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingImage = System.Drawing.Image;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.MainDashboard
{
    public class MainDashboardForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly Inventor.Application _inventorApp;
        private readonly MainDashboardWindowSettings _windowSettings;
        private Button? settingsButton;

        public MainDashboardForm(Inventor.Application inventorApp, bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;
            _windowSettings = MainDashboardWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor panelColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            this.Text = "Addin Marpatech";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new DrawingSize(750, 450);
            this.BackColor = backgroundColor;
            this.FormClosing += MainDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Marpatech Add-in";
            title.Font = new DrawingFont("Segoe UI", 30, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(55, 35);

            Label subtitle = new Label();
            subtitle.Text = "Dashboard Funzioni";
            subtitle.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(58, 92);

            settingsButton = new Button();
            settingsButton.Text = "⚙";
            settingsButton.Font = new DrawingFont("Segoe UI", 18, DrawingFontStyle.Regular);
            settingsButton.Size = new DrawingSize(42, 42);
            settingsButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            settingsButton.Location = new DrawingPoint(this.ClientSize.Width - 70, 35);
            settingsButton.FlatStyle = FlatStyle.Flat;
            settingsButton.FlatAppearance.BorderSize = 0;
            settingsButton.BackColor = backgroundColor;
            settingsButton.ForeColor = titleColor;
            settingsButton.Cursor = Cursors.Hand;
            settingsButton.Click += SettingsButton_Click;

            Panel mainPanel = new Panel();
            mainPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainPanel.Location = new DrawingPoint(55, 140);
            mainPanel.Size = new DrawingSize(this.ClientSize.Width - 110, this.ClientSize.Height - 185);
            mainPanel.BackColor = panelColor;
            mainPanel.Padding = new Padding(18);

            FlowLayoutPanel tilesPanel = new FlowLayoutPanel();
            tilesPanel.Dock = DockStyle.Fill;
            tilesPanel.Padding = new Padding(8);
            tilesPanel.AutoScroll = true;
            tilesPanel.WrapContents = true;
            tilesPanel.BackColor = panelColor;

            Panel mailTile = CreateDashboardTile("Invio Mail", GetMailIconPath());
            mailTile.Click += MailTile_Click;

            foreach (Control ctrl in mailTile.Controls)
                ctrl.Click += MailTile_Click;

            tilesPanel.Controls.Add(mailTile);
            mainPanel.Controls.Add(tilesPanel);

            Panel generaWordTile = CreateDashboardTile("Genera Word Manuali", GetGeneraWordIconPath());
            generaWordTile.Click += GeneraWordTile_Click;

            foreach (Control ctrl in generaWordTile.Controls)
                ctrl.Click += GeneraWordTile_Click;

            tilesPanel.Controls.Add(generaWordTile);

            this.Controls.Add(title);
            this.Controls.Add(subtitle);
            this.Controls.Add(mainPanel);
            this.Controls.Add(settingsButton);
        }

        private Panel CreateDashboardTile(string text, string imagePath)
        {
            DrawingColor tileBackColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor tileHoverColor = _isDarkTheme
                ? DrawingColor.FromArgb(38, 42, 52)
                : DrawingColor.FromArgb(235, 241, 248);

            DrawingColor borderColor = _isDarkTheme
                ? DrawingColor.FromArgb(70, 75, 88)
                : DrawingColor.FromArgb(190, 200, 215);

            DrawingColor textColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Panel tile = new Panel();
            tile.Size = new DrawingSize(150, 135);
            tile.Margin = new Padding(2);
            tile.BackColor = tileBackColor;
            tile.Cursor = Cursors.Hand;

            PictureBox iconBox = new PictureBox();
            iconBox.Size = new DrawingSize(82, 70);
            iconBox.Size = new DrawingSize(98, 86);
            iconBox.Location = new DrawingPoint((tile.Width - iconBox.Width) / 2, 2);
            iconBox.SizeMode = PictureBoxSizeMode.Zoom;
            iconBox.Cursor = Cursors.Hand;
            iconBox.BackColor = tileBackColor;

            if (File.Exists(imagePath))
            {
                iconBox.Image = DrawingImage.FromFile(imagePath);
            }

            Label textLabel = new Label();
            textLabel.Text = text;
            textLabel.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            textLabel.ForeColor = textColor;
            textLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            textLabel.Size = new DrawingSize(tile.Width, 28);
            textLabel.Location = new DrawingPoint(0, 84);
            textLabel.Cursor = Cursors.Hand;
            textLabel.BackColor = tileBackColor;

            void ApplyHover()
            {
                tile.BackColor = tileHoverColor;
                iconBox.BackColor = tileHoverColor;
                textLabel.BackColor = tileHoverColor;
                tile.Invalidate();
            }

            void RemoveHover()
            {
                tile.BackColor = tileBackColor;
                iconBox.BackColor = tileBackColor;
                textLabel.BackColor = tileBackColor;
                tile.Invalidate();
            }

            tile.MouseEnter += (s, e) => ApplyHover();
            iconBox.MouseEnter += (s, e) => ApplyHover();
            textLabel.MouseEnter += (s, e) => ApplyHover();

            tile.MouseLeave += (s, e) => RemoveHover();
            iconBox.MouseLeave += (s, e) => RemoveHover();
            textLabel.MouseLeave += (s, e) => RemoveHover();

            tile.Controls.Add(iconBox);
            tile.Controls.Add(textLabel);

            tile.Resize += (s, e) =>
            {
                tile.Invalidate();
            };

            Panel borderTop = new Panel();
            borderTop.BackColor = borderColor;
            borderTop.Location = new DrawingPoint(0, 0);
            borderTop.Size = new DrawingSize(tile.Width, 1);

            Panel borderBottom = new Panel();
            borderBottom.BackColor = borderColor;
            borderBottom.Location = new DrawingPoint(0, tile.Height - 1);
            borderBottom.Size = new DrawingSize(tile.Width, 1);

            Panel borderLeft = new Panel();
            borderLeft.BackColor = borderColor;
            borderLeft.Location = new DrawingPoint(0, 0);
            borderLeft.Size = new DrawingSize(1, tile.Height);

            Panel borderRight = new Panel();
            borderRight.BackColor = borderColor;
            borderRight.Location = new DrawingPoint(tile.Width - 1, 0);
            borderRight.Size = new DrawingSize(1, tile.Height);

            tile.Controls.Add(borderTop);
            tile.Controls.Add(borderBottom);
            tile.Controls.Add(borderLeft);
            tile.Controls.Add(borderRight);

            borderTop.BringToFront();
            borderBottom.BringToFront();
            borderLeft.BringToFront();
            borderRight.BringToFront();

            return tile;
        }

        private string GetMailIconPath()
        {
            string fileName = _isDarkTheme ? "mail_dark.png" : "mail_light.png";

            string? dllFolder = Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            return Path.Combine(
                dllFolder ?? "",
                "Features",
                "Mail",
                "Resources",
                fileName);
        }

        private void MailTile_Click(object? sender, EventArgs e)
        {
            FeatureNavigationService.OpenFeature(
                this,
                "Mail",
                () => new MailDashboardForm(
                    _inventorApp,
                    _isDarkTheme),
                this);
        }

        private void ApplyWindowSettings()
        {
            this.Size = new DrawingSize(_windowSettings.Width, _windowSettings.Height);

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Location = new DrawingPoint(_windowSettings.Left, _windowSettings.Top);
            }

            if (_windowSettings.IsMaximized)
                this.WindowState = FormWindowState.Maximized;
        }

        private void MainDashboardForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = this.Width;
                _windowSettings.Height = this.Height;
                _windowSettings.Left = this.Left;
                _windowSettings.Top = this.Top;
                _windowSettings.IsMaximized = false;
            }
            else if (this.WindowState == FormWindowState.Maximized)
            {
                _windowSettings.IsMaximized = true;
            }

            MainDashboardWindowSettingsService.Save(_windowSettings);
        }

        private void SettingsButton_Click(object? sender, EventArgs e)
        {
            SettingsCommand.Execute(_isDarkTheme);
        }

        private void GeneraWordTile_Click(object? sender, EventArgs e)
        {
            FeatureNavigationService.OpenFeature(
                this,
                "GeneraWord",
                () => new GeneraWordDashboardForm(
                    _inventorApp,
                    _isDarkTheme),
                this);
        }

        private string GetGeneraWordIconPath()
        {
            string? dllFolder = Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().Location);

            return Path.Combine(
                dllFolder ?? "",
                "Features",
                "GeneraWord",
                "Resources",
                "genera_word_manuali.png");
        }
    }
}