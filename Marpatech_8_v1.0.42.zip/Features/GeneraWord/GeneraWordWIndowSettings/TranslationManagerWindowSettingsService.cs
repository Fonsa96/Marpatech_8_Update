﻿using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraWord.Translation.WindowSettings
{
    public static class TranslationManagerWindowSettingsService
    {
        private static string SettingsPath
        {
            get
            {
                return Path.Combine(
                    Application.StartupPath,
                    "Features",
                    "GeneraWord",
                    "Translation",
                    "WindowSettings",
                    "translation_manager_window_settings.json");
            }
        }

        public static TranslationManagerWindowSettings Load()
        {
            try
            {
                if (!File.Exists(SettingsPath))
                    return new TranslationManagerWindowSettings();

                string json = File.ReadAllText(SettingsPath);

                return JsonSerializer.Deserialize<TranslationManagerWindowSettings>(json)
                       ?? new TranslationManagerWindowSettings();
            }
            catch
            {
                return new TranslationManagerWindowSettings();
            }
        }

        public static void Save(TranslationManagerWindowSettings settings)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);

            string json = JsonSerializer.Serialize(
                settings,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });

            File.WriteAllText(SettingsPath, json);
        }
    }
}