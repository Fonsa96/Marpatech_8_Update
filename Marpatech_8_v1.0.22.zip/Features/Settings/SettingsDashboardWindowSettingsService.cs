﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Settings
{
    public static class SettingsDashboardWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "SettingsDashboardWindowSettings.json");
            }
        }

        public static SettingsDashboardWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new SettingsDashboardWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                SettingsDashboardWindowSettings? settings =
                    JsonSerializer.Deserialize<SettingsDashboardWindowSettings>(json);

                return settings ?? new SettingsDashboardWindowSettings();
            }
            catch
            {
                return new SettingsDashboardWindowSettings();
            }
        }

        public static void Save(SettingsDashboardWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}