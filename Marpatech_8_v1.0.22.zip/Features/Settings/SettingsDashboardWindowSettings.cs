﻿namespace Marpatech_8.Features.Settings
{
    public class SettingsDashboardWindowSettings
    {
        public int Width { get; set; } = 680;
        public int Height { get; set; } = 430;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}