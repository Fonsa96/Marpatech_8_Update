﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class WordPlaceholderConfig
    {
        public string Placeholder { get; set; } = "";

        public string Source { get; set; } = "";
    }
}