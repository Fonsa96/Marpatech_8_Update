﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class WordPlaceholderSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData =
                    System.Environment.GetFolderPath(
                        System.Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "WordPlaceholderSettings.json");
            }
        }

        public static WordPlaceholderSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new WordPlaceholderSettings();

                string json =
                    File.ReadAllText(SettingsFile);

                return JsonSerializer.Deserialize<WordPlaceholderSettings>(
                           json,
                           new JsonSerializerOptions
                           {
                               PropertyNameCaseInsensitive = true
                           })
                       ?? new WordPlaceholderSettings();
            }
            catch
            {
                return new WordPlaceholderSettings();
            }
        }

        public static void Save(
            WordPlaceholderSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json =
                    JsonSerializer.Serialize(
                        settings,
                        new JsonSerializerOptions
                        {
                            WriteIndented = true
                        });

                File.WriteAllText(
                    SettingsFile,
                    json);
            }
            catch
            {
            }
        }
    }
}