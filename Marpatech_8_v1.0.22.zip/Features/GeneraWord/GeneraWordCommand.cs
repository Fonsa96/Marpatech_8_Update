﻿using System;
using Inventor;
using Marpatech_8.Features.GeneraWord.Forms;
using Marpatech_8.Features.Mail;

namespace Marpatech_8.Features.GeneraWord
{
    public static class GeneraWordCommand
    {
        public static void Execute(Inventor.Application inventorApp, bool isDarkTheme)
        {
            GeneraWordDashboardForm form =
                new GeneraWordDashboardForm(inventorApp, isDarkTheme);

            IntPtr inventorHandle = new IntPtr(inventorApp.MainFrameHWND);
            InventorWindowWrapper owner = new InventorWindowWrapper(inventorHandle);

            form.Show(owner);
            form.Activate();
        }
    }
}