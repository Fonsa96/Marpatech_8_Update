﻿using System;
using System.Windows.Forms;

using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class PositionImageForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly PositionImageWindowSettings _windowSettings;

        public bool ImageCaptured { get; private set; } = false;

        public PositionImageForm(bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;
            _windowSettings = PositionImageWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Acquisizione Immagine Manuale";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(520, 260);
            MinimumSize = new DrawingSize(520, 260);
            MaximumSize = new DrawingSize(520, 260);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = backgroundColor;
            TopMost = true;

            FormClosing += PositionImageForm_FormClosing;

            Label title = new Label();
            title.Text = "Acquisizione Immagine";
            title.Font = new DrawingFont("Segoe UI", 18, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);

            Label info = new Label();
            info.Text =
                "Posiziona l'assieme nella vista desiderata.\n\n" +
                "Quando sei pronto premi \"Acquisisci Immagine\".";
            info.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            info.ForeColor = titleColor;
            info.AutoSize = false;
            info.Size = new DrawingSize(450, 80);
            info.Location = new DrawingPoint(30, 75);

            Button btnCapture = CreateButton(
                "Acquisisci Immagine",
                DrawingColor.FromArgb(22, 163, 74),
                190,
                45);

            btnCapture.Location = new DrawingPoint(270, 165);
            btnCapture.Click += (s, e) =>
            {
                ImageCaptured = true;
                Close();
            };

            Button btnCancel = CreateButton(
                "Annulla",
                DrawingColor.FromArgb(100, 116, 139),
                150,
                45);

            btnCancel.Location = new DrawingPoint(105, 165);
            btnCancel.Click += (s, e) =>
            {
                ImageCaptured = false;
                Close();
            };


            Controls.Add(title);
            Controls.Add(info);
            Controls.Add(btnCancel);
            Controls.Add(btnCapture);
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();

            button.Text = text;
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Cursor = Cursors.Hand;

            return button;
        }
        private void ApplyWindowSettings()
        {
            Width = _windowSettings.Width;
            Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                StartPosition = FormStartPosition.Manual;
                Left = _windowSettings.Left;
                Top = _windowSettings.Top;
            }
        }

        private void PositionImageForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            _windowSettings.Width = Width;
            _windowSettings.Height = Height;
            _windowSettings.Left = Left;
            _windowSettings.Top = Top;

            PositionImageWindowSettingsService.Save(_windowSettings);
        }
    }
}