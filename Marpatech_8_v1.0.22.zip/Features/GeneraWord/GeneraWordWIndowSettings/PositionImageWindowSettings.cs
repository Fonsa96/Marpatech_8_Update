﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class PositionImageWindowSettings
    {
        public int Width { get; set; } = 520;
        public int Height { get; set; } = 260;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
    }
}