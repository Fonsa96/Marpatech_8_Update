﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class WordPlaceholderWindowSettings
    {
        public int Width { get; set; } = 950;
        public int Height { get; set; } = 650;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}