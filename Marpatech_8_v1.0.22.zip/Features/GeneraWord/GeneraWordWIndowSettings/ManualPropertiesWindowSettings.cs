﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualPropertiesWindowSettings
    {
        public int Width { get; set; } = 850;
        public int Height { get; set; } = 620;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}