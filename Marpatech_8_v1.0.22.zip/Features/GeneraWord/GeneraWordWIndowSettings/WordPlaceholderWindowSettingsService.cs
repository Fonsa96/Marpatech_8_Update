﻿using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class WordPlaceholderWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = System.Environment.GetFolderPath(
                    System.Environment.SpecialFolder.ApplicationData);

                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "WordPlaceholderWindowSettings.json");
            }
        }

        public static WordPlaceholderWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new WordPlaceholderWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                return JsonSerializer.Deserialize<WordPlaceholderWindowSettings>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    }) ?? new WordPlaceholderWindowSettings();
            }
            catch
            {
                return new WordPlaceholderWindowSettings();
            }
        }

        public static void Save(WordPlaceholderWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}