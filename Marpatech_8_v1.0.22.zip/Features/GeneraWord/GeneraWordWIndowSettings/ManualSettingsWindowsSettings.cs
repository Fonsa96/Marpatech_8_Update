﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualSettingsWindowSettings
    {
        public int Width { get; set; } = 900;
        public int Height { get; set; } = 520;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}