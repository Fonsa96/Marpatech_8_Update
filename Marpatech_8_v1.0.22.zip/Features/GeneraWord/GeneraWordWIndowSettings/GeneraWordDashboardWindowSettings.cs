﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class GeneraWordDashboardWindowSettings
    {
        public int Width { get; set; } = 1300;
        public int Height { get; set; } = 760;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}