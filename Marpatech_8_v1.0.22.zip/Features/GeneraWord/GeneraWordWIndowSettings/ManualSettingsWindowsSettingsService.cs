﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualSettingsWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "ManualSettingsWindowSettings.json");
            }
        }

        public static ManualSettingsWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new ManualSettingsWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                ManualSettingsWindowSettings? settings =
                    JsonSerializer.Deserialize<ManualSettingsWindowSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? new ManualSettingsWindowSettings();
            }
            catch
            {
                return new ManualSettingsWindowSettings();
            }
        }

        public static void Save(ManualSettingsWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}