﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class PositionImageWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "PositionImageWindowSettings.json");
            }
        }

        public static PositionImageWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new PositionImageWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                return JsonSerializer.Deserialize<PositionImageWindowSettings>(
                    json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                    ?? new PositionImageWindowSettings();
            }
            catch
            {
                return new PositionImageWindowSettings();
            }
        }

        public static void Save(PositionImageWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions { WriteIndented = true });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}