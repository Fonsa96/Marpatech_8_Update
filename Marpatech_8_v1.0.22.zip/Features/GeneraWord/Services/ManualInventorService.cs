﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualInventorService
    {
        public static Document? GetActiveDocument(Inventor.Application inventorApp)
        {
            try
            {
                return inventorApp.ActiveDocument;
            }
            catch
            {
                return null;
            }
        }

        public static Dictionary<string, string> ReadConfiguredProperties(
            Document document,
            ManualSettings settings)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();

            foreach (ManualPropertyConfig property in settings.Properties)
            {
                string value = ReadIProperty(document, property.IPropertyName);
                values[property.Tag] = value;
            }

            return values;
        }

        public static string ReadIProperty(Document document, string propertyName)
        {
            try
            {
                PropertySet userProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                Property property = userProperties[propertyName];

                return property.Value?.ToString() ?? "";
            }
            catch
            {
                return "";
            }
        }

        public static void WriteIProperty(
            Document document,
            string propertyName,
            string value)
        {
            try
            {
                PropertySet userProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                try
                {
                    Property property = userProperties[propertyName];
                    property.Value = value;
                }
                catch
                {
                    userProperties.Add(value, propertyName);
                }
            }
            catch
            {
            }
        }
    }
}