﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "ManualSettings.json");
            }
        }

        public static string SettingsFilePath
        {
            get
            {
                return SettingsFile;
            }
        }

        public static ManualSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                {
                    ManualSettings defaultSettings = CreateDefaultSettings();
                    Save(defaultSettings);
                    return defaultSettings;
                }

                string json = File.ReadAllText(SettingsFile);

                ManualSettings? settings =
                    JsonSerializer.Deserialize<ManualSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? CreateDefaultSettings();
            }
            catch
            {
                return CreateDefaultSettings();
            }
        }

        public static void Save(ManualSettings settings)
        {
            if (!Directory.Exists(SettingsFolder))
                Directory.CreateDirectory(SettingsFolder);

            string json = JsonSerializer.Serialize(
                settings,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });

            File.WriteAllText(SettingsFile, json);
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!File.Exists(sourceFile))
                throw new FileNotFoundException("File configurazione manuali non trovato.", sourceFile);

            if (!Directory.Exists(SettingsFolder))
                Directory.CreateDirectory(SettingsFolder);

            File.Copy(sourceFile, SettingsFile, true);
        }

        private static ManualSettings CreateDefaultSettings()
        {
            ManualSettings settings = new ManualSettings();

            settings.BaseTemplatePath =
                @"\\SRV02\Dati\dati\Ufficio Tecnico\Manuali commesse\FILE GENERICI MANUALI\MANUALI AUTOMATICI";

            settings.OutputFolderPath =
                @"C:\_ESPORTADWG\MANUALI GENERATI";

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "NumeroCommessa",
                IPropertyName = "Commessa",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "NomeCliente",
                IPropertyName = "Nome Cliente",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "CodiceCliente",
                IPropertyName = "Codice Cliente",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "TipoProdotto",
                IPropertyName = "Tipo Prodotto",
                Required = true
            });

            return settings;
        }
    }
}