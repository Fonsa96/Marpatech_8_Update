﻿using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualConfigurationPackageService
    {
        public static void ExportToFile(string destinationFile)
        {
            ManualConfigurationPackage package = new ManualConfigurationPackage
            {
                Settings = ManualSettingsService.Load(),
                Translations = TranslationDatabaseService.Load(),
                WordPlaceholders = WordPlaceholderSettingsService.Load()
            };

            string json = JsonSerializer.Serialize(
                package,
                new JsonSerializerOptions
                {
                    WriteIndented = true
                });

            File.WriteAllText(destinationFile, json);
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!File.Exists(sourceFile))
                throw new FileNotFoundException("File pacchetto configurazione manuali non trovato.", sourceFile);

            string json = File.ReadAllText(sourceFile);

            ManualConfigurationPackage? package =
                JsonSerializer.Deserialize<ManualConfigurationPackage>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            if (package == null)
                throw new InvalidDataException("File configurazione manuali non valido.");

            ManualSettingsService.Save(package.Settings);
            TranslationDatabaseService.Save(package.Translations);
            WordPlaceholderSettingsService.Save(package.WordPlaceholders);
        }
    }
}