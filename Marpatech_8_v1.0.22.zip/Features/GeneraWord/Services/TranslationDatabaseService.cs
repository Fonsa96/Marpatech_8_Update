﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class TranslationDatabaseService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string TranslationFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "ManualTranslations.json");
            }
        }

        public static string TranslationFilePath
        {
            get
            {
                return TranslationFile;
            }
        }

        public static TranslationDatabase Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(TranslationFile))
                {
                    TranslationDatabase newDatabase =
                        new TranslationDatabase();

                    Save(newDatabase);

                    return newDatabase;
                }

                string json =
                    File.ReadAllText(TranslationFile);

                TranslationDatabase? database =
                    JsonSerializer.Deserialize<TranslationDatabase>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return database ??
                       new TranslationDatabase();
            }
            catch
            {
                return new TranslationDatabase();
            }
        }

        public static void Save(
            TranslationDatabase database)
        {
            if (!Directory.Exists(SettingsFolder))
                Directory.CreateDirectory(SettingsFolder);

            string json =
                JsonSerializer.Serialize(
                    database,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

            File.WriteAllText(
                TranslationFile,
                json);
        }

        public static void ImportFromFile(
            string sourceFile)
        {
            if (!File.Exists(sourceFile))
            {
                throw new FileNotFoundException(
                    "File traduzioni non trovato.",
                    sourceFile);
            }

            if (!Directory.Exists(SettingsFolder))
                Directory.CreateDirectory(SettingsFolder);

            File.Copy(
                sourceFile,
                TranslationFile,
                true);
        }
    }
}