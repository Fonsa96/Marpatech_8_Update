﻿using Inventor;

namespace Marpatech_8.Features.MainDashboard
{
    public static class MainDashboardCommand
    {
        public static void Execute(Inventor.Application inventorApp)
        {
            bool isDarkTheme = IsInventorDarkTheme(inventorApp);

            MainDashboardForm form = new MainDashboardForm(inventorApp, isDarkTheme);
            form.Show();
        }

        private static bool IsInventorDarkTheme(Inventor.Application inventorApp)
        {
            try
            {
                string themeName = inventorApp.ThemeManager.ActiveTheme.Name.ToLower();

                return themeName.Contains("dark") ||
                       themeName.Contains("scuro") ||
                       themeName.Contains("nero");
            }
            catch
            {
                return false;
            }
        }
    }
}