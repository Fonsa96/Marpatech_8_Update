﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.MainDashboard.MainWindowSettings
{
    public static class MainDashboardWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MainDashboardWindowSettings.json");
            }
        }

        public static MainDashboardWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new MainDashboardWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                MainDashboardWindowSettings? settings =
                    JsonSerializer.Deserialize<MainDashboardWindowSettings>(json);

                return settings ?? new MainDashboardWindowSettings();
            }
            catch
            {
                return new MainDashboardWindowSettings();
            }
        }

        public static void Save(MainDashboardWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
                // Non blocchiamo l'Add-In se il salvataggio impostazioni fallisce.
            }
        }
    }
}