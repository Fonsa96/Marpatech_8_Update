﻿namespace Marpatech_8.Features.MainDashboard.MainWindowSettings
{
    public class MainDashboardWindowSettings
    {
        public int Width { get; set; } = 900;
        public int Height { get; set; } = 550;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}