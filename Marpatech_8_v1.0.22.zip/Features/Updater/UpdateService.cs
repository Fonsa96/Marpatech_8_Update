﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;



namespace Marpatech_8.Features.Updater
{
    public class UpdateService
    {
        private readonly UpdateSettings _settings;

        public UpdateService(UpdateSettings settings)
        {
            _settings = settings;
        }

        public async Task<UpdateInfo?> CheckForUpdateAsync()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_settings.UpdateManifestUrl))
                    return null;

                string json;

                if (_settings.UpdateManifestUrl.StartsWith("file:///"))
                {
                    string localPath =
                        _settings.UpdateManifestUrl
                        .Replace("file:///", "")
                        .Replace("/", "\\");

                    json = await File.ReadAllTextAsync(localPath);

                   
                }
                else
                {
                    using HttpClient client = new HttpClient();

                    json = await client.GetStringAsync(
                        _settings.UpdateManifestUrl);
                }

                UpdateInfo? updateInfo =
                JsonSerializer.Deserialize<UpdateInfo>(
                  json,
                  new JsonSerializerOptions
                   {
                   PropertyNameCaseInsensitive = true
                  });

                if (updateInfo == null)
                    return null;

                string currentVersion = GetCurrentVersion();
           

                if (IsNewerVersion(updateInfo.Version, currentVersion))
                    return updateInfo;

                return null;
            }

            catch
            {
                return null;
            }
        }

        public async Task<bool> DownloadUpdateAsync(UpdateInfo updateInfo)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(updateInfo.DownloadUrl))
                    return false;

                PreparePendingFolder();

                string zipPath = Path.Combine(
                    _settings.PendingUpdateFolder,
                    updateInfo.ZipFileName);

                if (updateInfo.DownloadUrl.StartsWith("file:///"))
                {
                    string localZipPath =
                        updateInfo.DownloadUrl
                        .Replace("file:///", "")
                        .Replace("/", "\\");

                    File.Copy(localZipPath, zipPath, true);
                }
                else
                {
                    using HttpClient client = new HttpClient();

                    byte[] data = await client.GetByteArrayAsync(updateInfo.DownloadUrl);

                    await File.WriteAllBytesAsync(zipPath, data);
                }

                string extractFolder = Path.Combine(
                    _settings.PendingUpdateFolder,
                    "Extracted");

                if (Directory.Exists(extractFolder))
                    Directory.Delete(extractFolder, true);

                Directory.CreateDirectory(extractFolder);

                ZipFile.ExtractToDirectory(zipPath, extractFolder);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool MarkUpdateAsPending()
        {
            try
            {
                Directory.CreateDirectory(_settings.PendingUpdateFolder);

                string markerFile = Path.Combine(
                    _settings.PendingUpdateFolder,
                    "update_pending.flag");

                File.WriteAllText(markerFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void PreparePendingFolder()
        {
            if (Directory.Exists(_settings.PendingUpdateFolder))
                Directory.Delete(_settings.PendingUpdateFolder, true);

            Directory.CreateDirectory(_settings.PendingUpdateFolder);
        }

        private bool IsNewerVersion(string onlineVersion, string currentVersion)
        {
            if (!Version.TryParse(onlineVersion, out Version? online))
                return false;

            if (!Version.TryParse(currentVersion, out Version? current))
                return false;

            return online > current;
        }
        private string GetCurrentVersion()
        {
            try
            {
                if (!File.Exists(_settings.LocalVersionFile))
                    return "0.0.0";

                string json = File.ReadAllText(_settings.LocalVersionFile);

                LocalVersionInfo? versionInfo =
                    JsonSerializer.Deserialize<LocalVersionInfo>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return versionInfo?.Version ?? "0.0.0";
            }
            catch
            {
                return "0.0.0";
            }
        }
    }
}