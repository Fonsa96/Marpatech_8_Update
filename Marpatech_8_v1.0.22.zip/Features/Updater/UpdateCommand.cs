﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marpatech_8.Features.Updater
{
    public static class UpdateCommand
    {
        public static async Task ExecuteAsync()
        {
            UpdateSettings settings = new UpdateSettings();

            UpdateService service = new UpdateService(settings);

            UpdateInfo? updateInfo = await service.CheckForUpdateAsync();

            if (updateInfo == null)
            {
                MessageBox.Show(
                    "Nessun aggiornamento disponibile.",
                    "Aggiorna versione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            bool downloaded = await service.DownloadUpdateAsync(updateInfo);

            if (!downloaded)
            {
                MessageBox.Show(
                    "Aggiornamento trovato, ma download non riuscito.",
                    "Aggiorna versione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            bool pending = service.MarkUpdateAsPending();

            if (!pending)
            {
                MessageBox.Show(
                    "Aggiornamento scaricato, ma non è stato possibile marcarlo come pendente.",
                    "Aggiorna versione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            TryStartUpdaterSilent(settings);

            MessageBox.Show(
                "Aggiornamento scaricato correttamente.\n\n" +
                "Verrà installato automaticamente dopo la chiusura di Inventor.",
                "Aggiorna versione",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private static void TryStartUpdaterSilent(UpdateSettings settings)
        {
            try
            {
                string updaterExe = settings.LocalUpdaterFile;

                if (!File.Exists(updaterExe))
                    return;

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = updaterExe;
                psi.Arguments = "--silent --wait-inventor-close";
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;

                Process.Start(psi);
            }
            catch
            {
                // Update silenzioso: non blocchiamo Inventor.
            }
        }
    }
}
