﻿namespace Marpatech_8.Features.Mail.Config
{
    public class MailTypeConfigWindowSettings
    {
        public int Width { get; set; } = 1100;
        public int Height { get; set; } = 760;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}