﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Mail.Config
{
    public static class MailVariablesWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MailVariablesWindowSettings.json");
            }
        }

        public static MailVariablesWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new MailVariablesWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                MailVariablesWindowSettings? settings =
                    JsonSerializer.Deserialize<MailVariablesWindowSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? new MailVariablesWindowSettings();
            }
            catch
            {
                return new MailVariablesWindowSettings();
            }
        }

        public static void Save(MailVariablesWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}