﻿namespace Marpatech_8.Features.Mail.WindowSettings
{
    public class MailDashboardWindowSettings
    {
        public int Width { get; set; } = 920;
        public int Height { get; set; } = 560;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
    }
}