﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Mail.WindowSettings
{
    public static class MailDashboardWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MailDashboardWindowSettings.json");
            }
        }

        public static MailDashboardWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new MailDashboardWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                MailDashboardWindowSettings? settings =
                    JsonSerializer.Deserialize<MailDashboardWindowSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? new MailDashboardWindowSettings();
            }
            catch
            {
                return new MailDashboardWindowSettings();
            }
        }

        public static void Save(MailDashboardWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}