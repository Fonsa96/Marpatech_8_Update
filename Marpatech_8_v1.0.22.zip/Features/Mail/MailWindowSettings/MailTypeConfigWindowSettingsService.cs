﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Mail.Config
{
    public static class MailTypeConfigWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MailTypeConfigWindowSettings.json");
            }
        }

        public static MailTypeConfigWindowSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                    return new MailTypeConfigWindowSettings();

                string json = File.ReadAllText(SettingsFile);

                MailTypeConfigWindowSettings? settings =
                    JsonSerializer.Deserialize<MailTypeConfigWindowSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? new MailTypeConfigWindowSettings();
            }
            catch
            {
                return new MailTypeConfigWindowSettings();
            }
        }

        public static void Save(MailTypeConfigWindowSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
            }
        }
    }
}