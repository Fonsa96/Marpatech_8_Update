﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.Mail.Config;
using InventorApplication = Inventor.Application;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailInventorService
    {
        public static Document? GetActiveDocument(InventorApplication inventorApp)
        {
            try
            {
                return inventorApp.ActiveDocument;
            }
            catch
            {
                return null;
            }
        }

        public static Dictionary<string, string> ReadVariableValues(
            Document document,
            MailSettings settings)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();

            foreach (MailVariableConfig variable in settings.Variables)
            {
                string value = ReadIProperty(document, variable.IPropertyName);
                values[variable.Name] = value;
            }

            return values;
        }

        public static string ReadIProperty(Document document, string propertyName)
        {
            try
            {
                PropertySet userProperties =
                    document.PropertySets["Inventor User Defined Properties"];

                Property property = userProperties[propertyName];

                return property.Value?.ToString() ?? "";
            }
            catch
            {
                return "";
            }
        }
        public static bool RunMultiReleaseCommand(
    Inventor.Application inventorApp)
        {
            try
            {
                ControlDefinition? control =
                    inventorApp.CommandManager.ControlDefinitions[
                        "DEDNETINV_RIL_MULTI"] as ControlDefinition;

                if (control == null)
                {
                    MessageBox.Show(
                        "Comando DEDNETINV_RIL_MULTI non trovato.",
                        "Invio Mail",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return false;
                }

                control.Execute();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Errore durante il rilascio multiplo.\n\n" +
                    ex.Message,
                    "Invio Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return false;
            }
        }
    }
}