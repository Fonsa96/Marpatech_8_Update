﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailExcelAttachmentService
    {
        public static string FindExcelAttachment(string folderPath)
        {
            if (string.IsNullOrWhiteSpace(folderPath))
                return "";

            if (!Directory.Exists(folderPath))
                return "";

            string[] files = Directory
                .GetFiles(folderPath, "ANTICIPI*.xlsx")
                .OrderBy(f => Path.GetFileName(f))
                .ToArray();

            if (files.Length == 0)
                return "";

            if (files.Length == 1)
                return files[0];

            using Form form = new Form();

            form.Text = "Seleziona file Excel";
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Size = new System.Drawing.Size(620, 360);
            form.MinimumSize = new System.Drawing.Size(620, 360);

            ListBox listBox = new ListBox();
            listBox.Dock = DockStyle.Top;
            listBox.Height = 240;
            listBox.Font = new System.Drawing.Font("Segoe UI", 10);

            foreach (string file in files)
            {
                listBox.Items.Add(Path.GetFileName(file));
            }

            Button btnOk = new Button();
            btnOk.Text = "OK";
            btnOk.Dock = DockStyle.Right;
            btnOk.Width = 120;
            btnOk.DialogResult = DialogResult.OK;

            Button btnCancel = new Button();
            btnCancel.Text = "Annulla";
            btnCancel.Dock = DockStyle.Right;
            btnCancel.Width = 120;
            btnCancel.DialogResult = DialogResult.Cancel;

            Panel bottomPanel = new Panel();
            bottomPanel.Dock = DockStyle.Bottom;
            bottomPanel.Height = 55;
            bottomPanel.Controls.Add(btnCancel);
            bottomPanel.Controls.Add(btnOk);

            form.Controls.Add(listBox);
            form.Controls.Add(bottomPanel);

            form.AcceptButton = btnOk;
            form.CancelButton = btnCancel;

            if (listBox.Items.Count > 0)
                listBox.SelectedIndex = 0;

            DialogResult result = form.ShowDialog();

            if (result != DialogResult.OK)
                return "";

            if (listBox.SelectedIndex < 0)
                return "";

            return files[listBox.SelectedIndex];
        }
    }
}