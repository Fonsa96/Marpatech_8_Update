﻿using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Mail.Config
{
    public static class MailSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MailSettings.json");
            }
        }

        public static string SettingsFilePath
        {
            get
            {
                return SettingsFile;
            }
        }

        public static MailSettings Load()
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                if (!File.Exists(SettingsFile))
                {
                    MailSettings defaultSettings = CreateDefaultSettings();
                    Save(defaultSettings);
                    return defaultSettings;
                }

                string json = File.ReadAllText(SettingsFile);

                MailSettings? settings =
                    JsonSerializer.Deserialize<MailSettings>(
                        json,
                        new JsonSerializerOptions
                        {
                            PropertyNameCaseInsensitive = true
                        });

                return settings ?? CreateDefaultSettings();
            }
            catch
            {
                return CreateDefaultSettings();
            }
        }

        public static void Save(MailSettings settings)
        {
            try
            {
                if (!Directory.Exists(SettingsFolder))
                    Directory.CreateDirectory(SettingsFolder);

                string json = JsonSerializer.Serialize(
                    settings,
                    new JsonSerializerOptions
                    {
                        WriteIndented = true
                    });

                File.WriteAllText(SettingsFile, json);
            }
            catch
            {
                // Non blocchiamo Inventor se il salvataggio configurazione fallisce.
            }
        }

        public static string GetSettingsFilePath()
        {
            return SettingsFile;
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!File.Exists(sourceFile))
                return;

            if (!Directory.Exists(SettingsFolder))
                Directory.CreateDirectory(SettingsFolder);

            File.Copy(sourceFile, SettingsFile, true);
        }

        public static void ExportToFile(string destinationFile)
        {
            if (!File.Exists(SettingsFile))
            {
                MailSettings defaultSettings = CreateDefaultSettings();
                Save(defaultSettings);
            }

            File.Copy(SettingsFile, destinationFile, true);
        }

        private static MailSettings CreateDefaultSettings()
        {
            MailSettings settings = new MailSettings();

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "COMMESSA",
                IPropertyName = "COMMESSA"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CLIENTE",
                IPropertyName = "NOME CLIENTE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "DESCRIZIONE",
                IPropertyName = "DESCRIZIONE COMMESSA"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CODICE CLIENTE",
                IPropertyName = "CODICE CLIENTE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "ID",
                IPropertyName = "ID"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CODICE",
                IPropertyName = "CODICE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "REV",
                IPropertyName = "REV"
            });

            settings.MailTypes.Add(new MailTypeConfig
            {
                Description = "Esportazione L",
                SearchPropertyName = "COMMESSA",
                FolderSearchMode = "Inizia con",
                ExcelFinalPath = "",
                FinalPath = "",
                IncludeLink = true,
                IncludeExcelAttachment = false,
                SubjectTemplate = "ESPORTAZIONE: {COMMESSA}",
                BodyTemplate = "Ciao,\r\n\r\nho esportato la commessa {COMMESSA}.\r\n\r\n{LINK}"
            });

            return settings;
        }
    }
}                                                                                                                                                                                                                   