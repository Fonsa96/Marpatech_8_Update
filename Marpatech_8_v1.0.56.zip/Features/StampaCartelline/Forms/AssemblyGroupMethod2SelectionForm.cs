﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public sealed class AssemblyGroupMethod2SelectionForm :
        Form
    {
        private readonly TreeView _treeView;

        private readonly Button _confirmButton;

        private readonly Button _cancelButton;

        private readonly ImageList _stateImages;

        private bool _selectionCompleted;


        public event EventHandler? SelectionConfirmed;

        public event EventHandler? SelectionCancelled;


        public AssemblyGroupMethod2SelectionForm(
            IEnumerable<AssemblyGroupMethod2TreeNode> roots)
        {
            Text =
                "Selezione STL - Metodo 2";

            StartPosition =
                FormStartPosition.CenterScreen;

            FormBorderStyle =
                FormBorderStyle.Sizable;

            MinimizeBox =
                true;

            MaximizeBox =
                true;

            ShowInTaskbar =
                true;

            Width =
                720;

            Height =
                650;

            MinimumSize =
                new Size(
                    620,
                    480);


            /*
             * ==================================================
             * HEADER
             * ==================================================
             */
            Panel headerPanel =
                new Panel();

            headerPanel.Dock =
                DockStyle.Top;

            headerPanel.Height =
                150;


            Label title =
                new Label();

            title.Text =
                "Quali STL desideri processare?";

            title.Font =
                new Font(
                    "Segoe UI",
                    11,
                    FontStyle.Bold);

            title.AutoSize =
                true;

            title.Left =
                20;

            title.Top =
                20;


            Label description =
                new Label();

            description.Text =
                "Seleziona gli STL che devono essere processati. " +
                "Gli STL non selezionati verranno saltati.";

            description.Font =
                new Font(
                    "Segoe UI",
                    9);

            description.AutoSize =
                true;

            description.Left =
                20;

            description.Top =
                55;


            Label legend =
                new Label();

            legend.Text =
                "Legenda:" +
                System.Environment.NewLine +
                "☑ = STL da processare" +
                System.Environment.NewLine +
                "☐ = STL da saltare" +
                System.Environment.NewLine +
                "    [SOLO STRUTTURA] = elemento visibile ma non processabile";

            legend.Font =
                new Font(
                    "Segoe UI",
                    9);

            legend.AutoSize =
                true;

            legend.Left =
                20;

            legend.Top =
                88;


            headerPanel.Controls.Add(
                title);

            headerPanel.Controls.Add(
                description);

            headerPanel.Controls.Add(
                legend);


            /*
             * ==================================================
             * IMMAGINI DEGLI STATI
             * ==================================================
             *
             * 0 = FALSE
             * 1 = TRUE
             *
             * I nodi SOLO STRUTTURA useranno -1
             * e quindi non avranno alcuna immagine.
             */
            _stateImages =
                new ImageList();

            _stateImages.ImageSize =
                new Size(
                    16,
                    16);

            _stateImages.Images.Add(
                CreateStateBitmap(
                    false));

            _stateImages.Images.Add(
                CreateStateBitmap(
                    true));


            /*
             * ==================================================
             * PANNELLO PULSANTI
             * ==================================================
             */
            Panel buttonsPanel =
                new Panel();

            buttonsPanel.Dock =
                DockStyle.Bottom;

            buttonsPanel.Height =
                65;


            _confirmButton =
                new Button();

            _confirmButton.Text =
                "Conferma";

            _confirmButton.Width =
                110;

            _confirmButton.Height =
                34;

            _confirmButton.Top =
                15;

            _confirmButton.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;


            _cancelButton =
                new Button();

            _cancelButton.Text =
                "Annulla";

            _cancelButton.Width =
                110;

            _cancelButton.Height =
                34;

            _cancelButton.Top =
                15;

            _cancelButton.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;


            buttonsPanel.Resize +=
                (_, _) =>
                {
                    _cancelButton.Left =
                        buttonsPanel.ClientSize.Width
                        - _cancelButton.Width
                        - 15;

                    _confirmButton.Left =
                        _cancelButton.Left
                        - _confirmButton.Width
                        - 10;
                };


            buttonsPanel.Controls.Add(
                _confirmButton);

            buttonsPanel.Controls.Add(
                _cancelButton);


            /*
             * ==================================================
             * TREEVIEW
             * ==================================================
             */
            _treeView =
                new TreeView();

            /*
             * IMPORTANTE:
             *
             * non usiamo più CheckBoxes native,
             * altrimenti WinForms mostrerebbe una checkbox
             * anche sui nodi SOLO STRUTTURA.
             */
            _treeView.CheckBoxes =
                false;

            _treeView.StateImageList =
                _stateImages;

            _treeView.HideSelection =
                false;

            _treeView.FullRowSelect =
                true;

            _treeView.Dock =
                DockStyle.Fill;

            _treeView.Font =
                new Font(
                    "Segoe UI",
                    9);


            foreach (AssemblyGroupMethod2TreeNode root
                in roots)
            {
                TreeNode treeNode =
                    CreateTreeNode(
                        root);

                _treeView.Nodes.Add(
                    treeNode);
            }


            _treeView.ExpandAll();


            /*
             * ==================================================
             * CLICK SUL NODO
             * ==================================================
             *
             * Solo i nodi processabili possono
             * cambiare TRUE/FALSE.
             */
            _treeView.NodeMouseClick +=
                (_, e) =>
                {
                    if (e.Node == null)
                        return;

                    if (e.Node.Tag
                        is not AssemblyGroupMethod2TreeNode runtimeNode)
                    {
                        return;
                    }

                    /*
                     * SOLO STRUTTURA:
                     * nessuna modifica possibile.
                     */
                    if (!runtimeNode.IsProcessable)
                    {
                        return;
                    }


                    /*
                     * TRUE ↔ FALSE
                     */
                    if (e.Node.StateImageIndex == 1)
                    {
                        e.Node.StateImageIndex =
                            0;
                    }
                    else
                    {
                        e.Node.StateImageIndex =
                            1;
                    }
                };


            /*
             * ==================================================
             * EVENTI PULSANTI
             * ==================================================
             */
            _confirmButton.Click +=
                (_, _) =>
                {
                    ApplySelectionsToRuntime();

                    _selectionCompleted =
                        true;

                    SelectionConfirmed?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            _cancelButton.Click +=
                (_, _) =>
                {
                    _selectionCompleted =
                        true;

                    SelectionCancelled?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            FormClosing +=
                (_, _) =>
                {
                    if (!_selectionCompleted)
                    {
                        _selectionCompleted =
                            true;

                        SelectionCancelled?.Invoke(
                            this,
                            EventArgs.Empty);
                    }
                };


            /*
             * Ordine importante per DockStyle.
             */
            Controls.Add(
                _treeView);

            Controls.Add(
                buttonsPanel);

            Controls.Add(
                headerPanel);
        }


        private static TreeNode CreateTreeNode(
            AssemblyGroupMethod2TreeNode runtimeNode)
        {
            string text =
                runtimeNode.Code;


            if (runtimeNode.IsContainer)
            {
                text +=
                    "  [STL CONTENITORE]";
            }


            if (!runtimeNode.IsProcessable)
            {
                text +=
                    "  [SOLO STRUTTURA]";
            }


            TreeNode treeNode =
                new TreeNode(
                    text);

            treeNode.Tag =
                runtimeNode;


            /*
             * ==================================================
             * NODO PROCESSABILE
             * ==================================================
             */
            if (runtimeNode.IsProcessable)
            {
                treeNode.StateImageIndex =
                    runtimeNode.ProcessStl
                        ? 1
                        : 0;
            }
            else
            {
                /*
                 * Nessuna checkbox/simbolo.
                 */
                treeNode.StateImageIndex =
                    -1;

                treeNode.ForeColor =
                    Color.Gray;
            }


            foreach (AssemblyGroupMethod2TreeNode child
                in runtimeNode.Children)
            {
                treeNode.Nodes.Add(
                    CreateTreeNode(
                        child));
            }


            return treeNode;
        }


        private void ApplySelectionsToRuntime()
        {
            foreach (TreeNode root
                in _treeView.Nodes)
            {
                ApplySelectionsRecursive(
                    root);
            }
        }


        private static void ApplySelectionsRecursive(
            TreeNode treeNode)
        {
            if (treeNode.Tag
                is AssemblyGroupMethod2TreeNode runtimeNode &&
                runtimeNode.IsProcessable)
            {
                runtimeNode.ProcessStl =
                    treeNode.StateImageIndex == 1;
            }


            foreach (TreeNode child
                in treeNode.Nodes)
            {
                ApplySelectionsRecursive(
                    child);
            }
        }


        private static Bitmap CreateStateBitmap(
            bool isChecked)
        {
            Bitmap bitmap =
                new Bitmap(
                    16,
                    16);

            using Graphics graphics =
                Graphics.FromImage(
                    bitmap);

            graphics.Clear(
                Color.Transparent);


            Rectangle rectangle =
                new Rectangle(
                    1,
                    1,
                    13,
                    13);


            using Pen borderPen =
                new Pen(
                    Color.DimGray,
                    1);

            graphics.DrawRectangle(
                borderPen,
                rectangle);


            if (isChecked)
            {
                using Pen checkPen =
                    new Pen(
                        Color.Green,
                        2);

                graphics.DrawLine(
                    checkPen,
                    3,
                    8,
                    6,
                    11);

                graphics.DrawLine(
                    checkPen,
                    6,
                    11,
                    12,
                    4);
            }


            return bitmap;
        }
    }
}