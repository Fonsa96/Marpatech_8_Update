﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public sealed class AssemblyGroupMethod1SelectionForm :
        Form
    {
        private readonly TreeView _treeView;

        private readonly Button _confirmButton;

        private readonly Button _cancelButton;

        private readonly ImageList _stateImages;

        private bool _selectionCompleted;


        public event EventHandler? SelectionConfirmed;

        public event EventHandler? SelectionCancelled;


        public AssemblyGroupMethod1SelectionForm(
            IEnumerable<AssemblyGroupMethod1TreeNode> roots)
        {
            Text =
                "Selezione stampa server - Gruppi di montaggio";

            StartPosition =
                FormStartPosition.CenterScreen;

            FormBorderStyle =
                FormBorderStyle.Sizable;

            MinimizeBox =
                true;

            MaximizeBox =
                true;

            ShowInTaskbar =
                true;

            Width =
                760;

            Height =
                690;


            /*
             * ==================================================
             * TITOLO
             * ==================================================
             */
            Label title =
                new Label();

            title.Text =
                "Quali STL vuoi processare e con quale modalità?";

            title.Font =
                new Font(
                    "Segoe UI",
                    11,
                    FontStyle.Bold);

            title.AutoSize =
                true;

            title.Left =
                20;

            title.Top =
                20;


            /*
             * ==================================================
             * DESCRIZIONE
             * ==================================================
             */
            Label description =
                new Label();

            description.Text =
                "Clicca sul simbolo a sinistra di ogni STL per cambiare modalità.";

            description.Font =
                new Font(
                    "Segoe UI",
                    9);

            description.AutoSize =
                true;

            description.Left =
                20;

            description.Top =
                52;


            /*
             * ==================================================
             * LEGENDA
             * ==================================================
             */
            Label legend =
                new Label();

            legend.Text =
                "Legenda:" +
                System.Environment.NewLine +
                "□  = Stampa solo Tavola" +
                System.Environment.NewLine +
                "✓  = Stampa Tavola + QS Jenkins" +
                System.Environment.NewLine +
                "X  = Salta completamente STL";

            legend.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            legend.AutoSize =
                true;

            legend.Left =
                20;

            legend.Top =
                78;


            /*
             * ==================================================
             * IMMAGINI DEI 3 STATI
             * ==================================================
             */
            _stateImages =
                new ImageList();

            _stateImages.ImageSize =
                new Size(
                    16,
                    16);

            _stateImages.Images.Add(
                CreateStateBitmap(
                    AssemblyGroupMethod1SelectionState.DrawingOnly));

            _stateImages.Images.Add(
                CreateStateBitmap(
                    AssemblyGroupMethod1SelectionState.DrawingAndJenkins));

            _stateImages.Images.Add(
                CreateStateBitmap(
                    AssemblyGroupMethod1SelectionState.Skip));


            /*
             * ==================================================
             * ALBERO
             * ==================================================
             */
            _treeView =
                new TreeView();

            /*
             * IMPORTANTE:
             *
             * Non usiamo più CheckBoxes native.
             */
            _treeView.CheckBoxes =
                false;

            _treeView.StateImageList =
                _stateImages;

            _treeView.HideSelection =
                false;

            _treeView.FullRowSelect =
                true;

            _treeView.Left =
                20;

            _treeView.Top =
                150;

            _treeView.Width =
                700;

            _treeView.Height =
                445;

            _treeView.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            _treeView.Font =
                new Font(
                    "Segoe UI",
                    9);


            foreach (AssemblyGroupMethod1TreeNode root
                in roots)
            {
                TreeNode treeNode =
                    CreateTreeNode(
                        root);

                _treeView.Nodes.Add(
                    treeNode);
            }


            _treeView.ExpandAll();


            /*
             * Clic sul nodo:
             * cambiamo stato.
             */
            _treeView.NodeMouseClick +=
                (_, e) =>
                {
                    if (e.Node == null)
                        return;

                    if (e.Node.Tag
                        is AssemblyGroupMethod1TreeNode runtimeNode &&
                        !runtimeNode.IsProcessable)
                    {
                        return;
                    }

                    CycleNodeState(
                        e.Node);
                };


            /*
             * ==================================================
             * CONFERMA
             * ==================================================
             */
            _confirmButton =
                new Button();

            _confirmButton.Text =
                "Conferma";

            _confirmButton.Width =
                110;

            _confirmButton.Height =
                34;

            _confirmButton.Left =
                490;

            _confirmButton.Top =
                610;

            _confirmButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;


            /*
             * ==================================================
             * ANNULLA
             * ==================================================
             */
            _cancelButton =
                new Button();

            _cancelButton.Text =
                "Annulla";

            _cancelButton.Width =
                110;

            _cancelButton.Height =
                34;

            _cancelButton.Left =
                610;

            _cancelButton.Top =
                610;

            _cancelButton.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;


            _confirmButton.Click +=
                (_, _) =>
                {
                    ApplySelectionsToRuntime();

                    _selectionCompleted =
                        true;

                    SelectionConfirmed?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            _cancelButton.Click +=
                (_, _) =>
                {
                    _selectionCompleted =
                        true;

                    SelectionCancelled?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            /*
             * La X equivale ad Annulla.
             */
            FormClosing +=
                (_, _) =>
                {
                    if (!_selectionCompleted)
                    {
                        _selectionCompleted =
                            true;

                        SelectionCancelled?.Invoke(
                            this,
                            EventArgs.Empty);
                    }
                };


            Controls.Add(
                title);

            Controls.Add(
                description);

            Controls.Add(
                legend);

            Controls.Add(
                _treeView);

            Controls.Add(
                _confirmButton);

            Controls.Add(
                _cancelButton);
        }


        private static TreeNode CreateTreeNode(
            AssemblyGroupMethod1TreeNode runtimeNode)
        {
            string text =
                runtimeNode.Code;

            if (runtimeNode.IsContainer)
            {
                text +=
                    "  [STL CONTENITORE]";
            }


            TreeNode treeNode =
                new TreeNode(
                    text);

            treeNode.Tag =
                runtimeNode;


            /*
             * Tutti partono da:
             *
             * DrawingOnly
             * cioè casella vuota.
             *
             * StateImageIndex:
             *
             * 0 = vuoto
             * 1 = V
             * 2 = X
             */
            if (runtimeNode.IsProcessable)
            {
                treeNode.StateImageIndex =
                    GetStateImageIndex(
                        runtimeNode.SelectionState);
            }
            else
            {
                /*
                 * Nessun simbolo selezionabile:
                 * nodo esclusivamente strutturale.
                 */
                treeNode.StateImageIndex =
                    -1;

                treeNode.ForeColor =
                    Color.Gray;

                treeNode.Text +=
                    "  [SOLO STRUTTURA]";
            }


            foreach (AssemblyGroupMethod1TreeNode child
                in runtimeNode.Children)
            {
                treeNode.Nodes.Add(
                    CreateTreeNode(
                        child));
            }


            return treeNode;
        }


        private static void CycleNodeState(
            TreeNode treeNode)
        {
            int currentIndex =
                treeNode.StateImageIndex;

            int nextIndex;

            switch (currentIndex)
            {
                case 0:
                    nextIndex = 1;
                    break;

                case 1:
                    nextIndex = 2;
                    break;

                default:
                    nextIndex = 0;
                    break;
            }


            treeNode.StateImageIndex =
                nextIndex;
        }


        private void ApplySelectionsToRuntime()
        {
            foreach (TreeNode root
                in _treeView.Nodes)
            {
                ApplySelectionsRecursive(
                    root);
            }
        }


        private static void ApplySelectionsRecursive(
            TreeNode treeNode)
        {
            if (treeNode.Tag
                is AssemblyGroupMethod1TreeNode runtimeNode &&
                runtimeNode.IsProcessable)
            {
                runtimeNode.SelectionState =
                    GetSelectionState(
                        treeNode.StateImageIndex);
            }


            foreach (TreeNode child
                in treeNode.Nodes)
            {
                ApplySelectionsRecursive(
                    child);
            }
        }


        private static int GetStateImageIndex(
            AssemblyGroupMethod1SelectionState state)
        {
            switch (state)
            {
                case AssemblyGroupMethod1SelectionState.DrawingAndJenkins:
                    return 1;

                case AssemblyGroupMethod1SelectionState.Skip:
                    return 2;

                default:
                    return 0;
            }
        }


        private static AssemblyGroupMethod1SelectionState
            GetSelectionState(
                int stateImageIndex)
        {
            switch (stateImageIndex)
            {
                case 1:
                    return AssemblyGroupMethod1SelectionState
                        .DrawingAndJenkins;

                case 2:
                    return AssemblyGroupMethod1SelectionState
                        .Skip;

                default:
                    return AssemblyGroupMethod1SelectionState
                        .DrawingOnly;
            }
        }


        private static Bitmap CreateStateBitmap(
            AssemblyGroupMethod1SelectionState state)
        {
            Bitmap bitmap =
                new Bitmap(
                    16,
                    16);

            using Graphics graphics =
                Graphics.FromImage(
                    bitmap);

            graphics.Clear(
                Color.Transparent);


            Rectangle rectangle =
                new Rectangle(
                    1,
                    1,
                    13,
                    13);


            using Pen borderPen =
                new Pen(
                    Color.DimGray,
                    1);

            graphics.DrawRectangle(
                borderPen,
                rectangle);


            if (state ==
                AssemblyGroupMethod1SelectionState.DrawingAndJenkins)
            {
                using Pen checkPen =
                    new Pen(
                        Color.Green,
                        2);

                graphics.DrawLine(
                    checkPen,
                    3,
                    8,
                    6,
                    11);

                graphics.DrawLine(
                    checkPen,
                    6,
                    11,
                    12,
                    4);
            }
            else if (state ==
                     AssemblyGroupMethod1SelectionState.Skip)
            {
                using Pen crossPen =
                    new Pen(
                        Color.Red,
                        2);

                graphics.DrawLine(
                    crossPen,
                    4,
                    4,
                    11,
                    11);

                graphics.DrawLine(
                    crossPen,
                    11,
                    4,
                    4,
                    11);
            }


            return bitmap;
        }
    }
}