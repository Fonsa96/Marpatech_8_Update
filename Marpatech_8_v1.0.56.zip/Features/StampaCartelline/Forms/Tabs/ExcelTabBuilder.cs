﻿using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Managers;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class ExcelTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            EditorContext context)
        {
            DrawingColor backgroundColor = isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor panelColor = isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor titleColor = isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = isDarkTheme
                ? DrawingColor.FromArgb(55, 58, 68)
                : DrawingColor.White;

            TabPage page = new TabPage
            {
                Text = "Excel Distinte",
                BackColor = backgroundColor,
                Padding = new Padding(18)
            };

            Panel card = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = panelColor,
                Padding = new Padding(25)
            };

            TableLayoutPanel layout = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 1,
                RowCount = 9,
                BackColor = panelColor
            };

            layout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    100));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    42));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    34));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    28));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    40));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    28));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    40));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    28));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    40));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    50));

            Label title = new Label
            {
                Text = "Configurazione Excel Distinte",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    15,
                    DrawingFontStyle.Bold),
                ForeColor = titleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label description = new Label
            {
                Text =
                    "Definisce il percorso del file Excel da includere nel processo di stampa.",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9),
                ForeColor = subtitleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label lblStartPath =
                CreateLabel(
                    "Percorso iniziale",
                    titleColor);

            TextBox txtStartPath =
                context.ExcelStartPath;

            ConfigureTextBox(
                txtStartPath,
                inputColor,
                titleColor);

            Label lblDeterminingAttribute =
                CreateLabel(
                    "Attributo determinante",
                    titleColor);

            ComboBox cmbDeterminingAttribute =
                context.ExcelDeterminingAttribute;

            ConfigureComboBox(
                cmbDeterminingAttribute,
                inputColor,
                titleColor);

            Label lblFinalPath =
                CreateLabel(
                    "Parte finale percorso",
                    titleColor);

            TextBox txtFinalPath =
                context.ExcelFinalPath;

            ConfigureTextBox(
                txtFinalPath,
                inputColor,
                titleColor);

            CheckBox chkInclude =
                context.ExcelIncludeInPrint;

            chkInclude.Text =
                "Includi nel Processo di Stampa";

            chkInclude.Dock =
                DockStyle.Fill;

            chkInclude.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            chkInclude.ForeColor =
                titleColor;

            chkInclude.Margin =
                new Padding(
                    0,
                    12,
                    0,
                    0);

            layout.Controls.Add(
                title,
                0,
                0);

            layout.Controls.Add(
                description,
                0,
                1);

            layout.Controls.Add(
                lblStartPath,
                0,
                2);

            layout.Controls.Add(
                txtStartPath,
                0,
                3);

            layout.Controls.Add(
                lblDeterminingAttribute,
                0,
                4);

            layout.Controls.Add(
                cmbDeterminingAttribute,
                0,
                5);

            layout.Controls.Add(
                lblFinalPath,
                0,
                6);

            layout.Controls.Add(
                txtFinalPath,
                0,
                7);

            layout.Controls.Add(
                chkInclude,
                0,
                8);

            card.Controls.Add(layout);
            page.Controls.Add(card);

            return page;
        }

        private static void ConfigureTextBox(
            TextBox textBox,
            DrawingColor backgroundColor,
            DrawingColor foregroundColor)
        {
            textBox.Dock =
                DockStyle.Fill;

            textBox.Margin =
                new Padding(0);

            textBox.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            textBox.BackColor =
                backgroundColor;

            textBox.ForeColor =
                foregroundColor;

            textBox.BorderStyle =
                BorderStyle.FixedSingle;
        }

        private static void ConfigureComboBox(
            ComboBox comboBox,
            DrawingColor backgroundColor,
            DrawingColor foregroundColor)
        {
            comboBox.Dock =
                DockStyle.Fill;

            comboBox.Margin =
                new Padding(0);

            comboBox.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            comboBox.BackColor =
                backgroundColor;

            comboBox.ForeColor =
                foregroundColor;

            comboBox.DropDownStyle =
                ComboBoxStyle.DropDownList;
        }

        private static Label CreateLabel(
            string text,
            DrawingColor color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold),
                ForeColor = color,
                TextAlign =
                    System.Drawing.ContentAlignment.BottomLeft
            };
        }
    }
}