﻿using Marpatech_8.Features.StampaCartelline.Managers;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class GroupsTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            EditorContext context)
        {
            DrawingColor backgroundColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        32,
                        34,
                        40)
                    : DrawingColor.White;

            DrawingColor titleColor =
                isDarkTheme
                    ? DrawingColor.White
                    : DrawingColor.FromArgb(
                        30,
                        41,
                        59);

            DrawingColor subtitleColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        170,
                        178,
                        190)
                    : DrawingColor.FromArgb(
                        100,
                        116,
                        139);

            DrawingColor inputBackgroundColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        43,
                        46,
                        55)
                    : DrawingColor.White;

            DrawingColor borderColor =
                isDarkTheme
                    ? DrawingColor.FromArgb(
                        70,
                        75,
                        85)
                    : DrawingColor.FromArgb(
                        203,
                        213,
                        225);

            DrawingColor primaryButtonColor =
                DrawingColor.FromArgb(
                    37,
                    99,
                    235);

            DrawingColor deleteButtonColor =
                DrawingColor.FromArgb(
                    220,
                    38,
                    38);


            TabPage page =
                new TabPage();

            page.Text =
                "Gruppi di montaggio";

            page.BackColor =
                backgroundColor;

            /*
             * Rimane come sicurezza per monitor
             * piccoli o scaling Windows elevato.
             *
             * A schermo intero il contenuto
             * dovrebbe ora stare senza scroll.
             */
            page.AutoScroll =
                true;


            /*
             * ==================================================
             * TITOLO
             * ==================================================
             */
            Label title =
                new Label();

            title.Text =
                "Gruppi di montaggio";

            title.Font =
                new DrawingFont(
                    "Segoe UI",
                    16,
                    DrawingFontStyle.Bold);

            title.ForeColor =
                titleColor;

            title.AutoSize =
                true;

            title.Left =
                25;

            title.Top =
                18;


            Label description =
                new Label();

            description.Text =
                "Configura il metodo utilizzato per la stampa dei gruppi di montaggio.";

            description.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Regular);

            description.ForeColor =
                subtitleColor;

            description.AutoSize =
                true;

            description.Left =
                27;

            description.Top =
                52;


            /*
             * ==================================================
             * INCLUDI NEL PROCESSO
             * ==================================================
             */
            CheckBox chkIncludeInPrint =
                context.GroupsIncludeInPrint;

            chkIncludeInPrint.Text =
                "Includi nel processo di stampa";

            chkIncludeInPrint.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkIncludeInPrint.AutoSize =
                true;

            chkIncludeInPrint.Left =
                30;

            chkIncludeInPrint.Top =
                86;

            chkIncludeInPrint.ForeColor =
                titleColor;

            chkIncludeInPrint.BackColor =
                backgroundColor;


            /*
             * ==================================================
             * METODO 1
             * ==================================================
             */
            CheckBox chkMethod1 =
                context.GroupsMethod1Enabled;

            chkMethod1.Text =
                "Metodo 1: Stampa gruppi di montaggio";

            chkMethod1.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkMethod1.AutoSize =
                true;

            chkMethod1.Left =
                30;

            chkMethod1.Top =
                122;

            chkMethod1.ForeColor =
                titleColor;

            chkMethod1.BackColor =
                backgroundColor;


            Label method1Description =
                new Label();

            method1Description.Text =
                "Testi utilizzati per individuare gli assiemi da processare con il Metodo 1.";

            method1Description.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method1Description.ForeColor =
                subtitleColor;

            method1Description.AutoSize =
                true;

            method1Description.Left =
                50;

            method1Description.Top =
                148;


            DataGridView method1Grid =
                context.GroupsMethod1Grid;

            ConfigureRulesGrid(
                method1Grid,
                inputBackgroundColor,
                titleColor);

            method1Grid.Left =
                50;

            method1Grid.Top =
                170;

            method1Grid.Width =
                610;

            method1Grid.Height =
                90;


            ConfigureButton(
                context.GroupsMethod1Add,
                "Aggiungi",
                primaryButtonColor,
                685,
                170,
                100);

            ConfigureButton(
                context.GroupsMethod1Edit,
                "Modifica",
                primaryButtonColor,
                685,
                201,
                100);

            ConfigureButton(
                context.GroupsMethod1Delete,
                "Elimina",
                deleteButtonColor,
                685,
                232,
                100);

            ConfigureButton(
                context.GroupsMethod1Up,
                "↑",
                primaryButtonColor,
                805,
                170,
                50);

            ConfigureButton(
                context.GroupsMethod1Down,
                "↓",
                primaryButtonColor,
                805,
                201,
                50);


            /*
             * ==================================================
             * SEPARATORE
             * ==================================================
             */
            Panel separator =
                new Panel();

            separator.Left =
                30;

            separator.Top =
                278;

            separator.Width =
                825;

            separator.Height =
                1;

            separator.BackColor =
                borderColor;


            /*
             * ==================================================
             * METODO 2
             * ==================================================
             */
            CheckBox chkMethod2 =
                context.GroupsMethod2Enabled;

            chkMethod2.Text =
                "Metodo 2: Stampa con ricerca dei codici";

            chkMethod2.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            chkMethod2.AutoSize =
                true;

            chkMethod2.Left =
                30;

            chkMethod2.Top =
                295;

            chkMethod2.ForeColor =
                titleColor;

            chkMethod2.BackColor =
                backgroundColor;


            /*
             * Prefisso da ricercare nell'assieme Main.
             *
             * Label e TextBox sulla stessa riga.
             */
            Label method2MainPrefixLabel =
                new Label();

            method2MainPrefixLabel.Text =
                "Prefisso Codice Ricerca nell'assieme Main";

            method2MainPrefixLabel.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method2MainPrefixLabel.ForeColor =
                titleColor;

            method2MainPrefixLabel.AutoSize =
                true;

            method2MainPrefixLabel.Left =
                50;

            method2MainPrefixLabel.Top =
                326;


            System.Windows.Forms.TextBox method2MainPrefix =
                context.GroupsMethod2MainAssemblyCodePrefix;

            method2MainPrefix.Left =
                310;

            method2MainPrefix.Top =
                322;

            method2MainPrefix.Width =
                150;

            method2MainPrefix.Height =
                25;


            /*
             * Descrizione della tabella Metodo 2.
             *
             * Ora è chiaramente sopra la tabella
             * e NON si sovrappone alla TextBox.
             */
            Label method2Description =
                new Label();

            method2Description.Text =
                "Testi utilizzati per individuare gli assiemi da processare con il Metodo 2.";

            method2Description.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            method2Description.ForeColor =
                subtitleColor;

            method2Description.AutoSize =
                true;

            method2Description.Left =
                50;

            method2Description.Top =
                353;


            DataGridView method2Grid =
                context.GroupsMethod2Grid;

            ConfigureRulesGrid(
                method2Grid,
                inputBackgroundColor,
                titleColor);

            method2Grid.Left =
                50;

            method2Grid.Top =
                375;

            method2Grid.Width =
                610;

            method2Grid.Height =
                200;


            ConfigureButton(
                context.GroupsMethod2Add,
                "Aggiungi",
                primaryButtonColor,
                685,
                375,
                100);

            ConfigureButton(
                context.GroupsMethod2Edit,
                "Modifica",
                primaryButtonColor,
                685,
                406,
                100);

            ConfigureButton(
                context.GroupsMethod2Delete,
                "Elimina",
                deleteButtonColor,
                685,
                437,
                100);

            ConfigureButton(
                context.GroupsMethod2Up,
                "↑",
                primaryButtonColor,
                805,
                375,
                50);

            ConfigureButton(
                context.GroupsMethod2Down,
                "↓",
                primaryButtonColor,
                805,
                406,
                50);


            /*
             * ==================================================
             * AGGIUNTA CONTROLLI
             * ==================================================
             */
            page.Controls.Add(
                title);

            page.Controls.Add(
                description);

            page.Controls.Add(
                chkIncludeInPrint);


            page.Controls.Add(
                chkMethod1);

            page.Controls.Add(
                method1Description);

            page.Controls.Add(
                method1Grid);

            page.Controls.Add(
                context.GroupsMethod1Add);

            page.Controls.Add(
                context.GroupsMethod1Edit);

            page.Controls.Add(
                context.GroupsMethod1Delete);

            page.Controls.Add(
                context.GroupsMethod1Up);

            page.Controls.Add(
                context.GroupsMethod1Down);


            page.Controls.Add(
                separator);


            page.Controls.Add(
                chkMethod2);

            page.Controls.Add(
                method2MainPrefixLabel);

            page.Controls.Add(
                method2MainPrefix);

            page.Controls.Add(
                method2Description);

            page.Controls.Add(
                method2Grid);

            page.Controls.Add(
                context.GroupsMethod2Add);

            page.Controls.Add(
                context.GroupsMethod2Edit);

            page.Controls.Add(
                context.GroupsMethod2Delete);

            page.Controls.Add(
                context.GroupsMethod2Up);

            page.Controls.Add(
                context.GroupsMethod2Down);


            return page;
        }


        private static void ConfigureButton(
            Button button,
            string text,
            DrawingColor backgroundColor,
            int left,
            int top,
            int width)
        {
            button.Text =
                text;

            button.Left =
                left;

            button.Top =
                top;

            button.Width =
                width;

            button.Height =
                28;

            button.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            button.FlatStyle =
                FlatStyle.Flat;

            button.FlatAppearance.BorderSize =
                0;

            button.BackColor =
                backgroundColor;

            button.ForeColor =
                DrawingColor.White;

            button.Cursor =
                Cursors.Hand;

            button.UseVisualStyleBackColor =
                false;
        }


        private static void ConfigureRulesGrid(
            DataGridView grid,
            DrawingColor backgroundColor,
            DrawingColor textColor)
        {
            grid.AllowUserToAddRows =
                false;

            grid.AllowUserToDeleteRows =
                false;

            grid.AllowUserToResizeRows =
                false;

            grid.MultiSelect =
                false;

            grid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            grid.RowHeadersVisible =
                false;

            grid.AutoGenerateColumns =
                false;

            grid.BackgroundColor =
                backgroundColor;

            grid.ForeColor =
                textColor;

            grid.DefaultCellStyle.BackColor =
                backgroundColor;

            grid.DefaultCellStyle.ForeColor =
                textColor;

            grid.DefaultCellStyle.SelectionBackColor =
                DrawingColor.FromArgb(
                    0,
                    120,
                    215);

            grid.DefaultCellStyle.SelectionForeColor =
                DrawingColor.White;

            grid.AlternatingRowsDefaultCellStyle.BackColor =
                backgroundColor;

            grid.AlternatingRowsDefaultCellStyle.ForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                backgroundColor;

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            grid.BorderStyle =
                BorderStyle.FixedSingle;

            grid.EnableHeadersVisualStyles =
                false;

            grid.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;

            grid.Columns.Clear();


            DataGridViewTextBoxColumn prefixColumn =
                new DataGridViewTextBoxColumn();

            prefixColumn.Name =
                "CodePrefix";

            prefixColumn.HeaderText =
                "Prefisso CODICE";

            prefixColumn.Width =
                160;

            prefixColumn.ReadOnly =
                true;


            DataGridViewTextBoxColumn pathColumn =
                new DataGridViewTextBoxColumn();

            pathColumn.Name =
                "DrawingSearchPath";

            pathColumn.HeaderText =
                "Percorso ricerca IDW";

            pathColumn.AutoSizeMode =
                DataGridViewAutoSizeColumnMode.Fill;

            pathColumn.ReadOnly =
                true;


            grid.Columns.Add(
                prefixColumn);

            grid.Columns.Add(
                pathColumn);
        }
    }
}