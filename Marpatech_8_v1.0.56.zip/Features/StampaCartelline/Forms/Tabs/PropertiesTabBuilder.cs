﻿using System.Windows.Forms;
using System;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Forms.Styling;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class PropertiesTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            EditorContext context)
        {
            DrawingColor backgroundColor = isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor detailsColor = isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor titleColor = isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = isDarkTheme
                ? DrawingColor.FromArgb(55, 58, 68)
                : DrawingColor.White;

            TabPage page = new TabPage
            {
                Text = "Proprietà Inventor",
                BackColor = backgroundColor,
                Padding = new Padding(15)
            };

            SplitContainer split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                BackColor = backgroundColor
            };

            split.Panel1.BackColor = backgroundColor;
            split.Panel2.BackColor = detailsColor;

            split.SizeChanged += (_, _) =>
            {
                int availableWidth =
                    split.ClientSize.Width -
                    split.SplitterWidth;

                if (availableWidth < 600)
                    return;

                int desiredDistance =
                    (int)(availableWidth * 0.60);

                int maximumDistance =
                    availableWidth - 300;

                if (desiredDistance > maximumDistance)
                    desiredDistance = maximumDistance;

                if (desiredDistance < 350)
                    desiredDistance = 350;

                split.SplitterDistance =
                    desiredDistance;
            };

            BuildLeftPanel(
                split.Panel1,
                context,
                titleColor,
                subtitleColor,
                isDarkTheme);

            BuildRightPanel(
                split.Panel2,
                context,
                titleColor,
                subtitleColor,
                inputColor);

            page.Controls.Add(split);

            return page;
        }

        private static void BuildLeftPanel(
            SplitterPanel panel,
            EditorContext context,
            DrawingColor titleColor,
            DrawingColor subtitleColor,
            bool isDarkTheme)
        {
            TableLayoutPanel layout =
                new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    Padding = new Padding(15),
                    ColumnCount = 1,
                    RowCount = 4,
                    BackColor = panel.BackColor
                };

            layout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    100));

            // Titolo
            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            // Descrizione
            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            // Lista: occupa tutto lo spazio disponibile
            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100));

            // Pulsanti sempre nella parte inferiore
            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    48));

            Label title = new Label
            {
                Text = "Proprietà Dashboard",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold),
                ForeColor = titleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label description = new Label
            {
                Text =
                    "Definisce le proprietà Inventor utilizzate dalla configurazione.",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9),
                ForeColor = subtitleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            ListView list =
                context.PropertiesList;

            list.Dock =
                DockStyle.Fill;

            list.View =
                View.Details;

            list.FullRowSelect =
                true;

            list.GridLines =
                true;

            list.HideSelection =
                false;

            list.MultiSelect =
                false;

            list.AllowColumnReorder =
                false;

            list.HeaderStyle =
                ColumnHeaderStyle.Nonclickable;

            EditorThemeStyler.ApplyListViewTheme(
                list,
                isDarkTheme);

            list.Columns.Clear();

            list.Columns.Add(
                "Tag");

            list.Columns.Add(
                "Proprietà Inventor");

            list.Columns.Add(
                "Mod. da Dashboard");

            bool isUpdatingColumnWidths =
                false;

            void UpdateColumnWidths()
            {
                if (isUpdatingColumnWidths)
                    return;

                if (list.ClientSize.Width <= 0 ||
                    list.Columns.Count != 3)
                {
                    return;
                }

                try
                {
                    isUpdatingColumnWidths =
                        true;

                    /*
                     * Sottraiamo qualche pixel per evitare
                     * la comparsa della scrollbar orizzontale.
                     */
                    int availableWidth =
                        Math.Max(
                            0,
                            list.ClientSize.Width - 4);

                    int tagWidth =
                        (int)(availableWidth * 0.40);

                    int propertyWidth =
                        (int)(availableWidth * 0.40);

                    int dashboardWidth =
                        availableWidth -
                        tagWidth -
                        propertyWidth;

                    list.Columns[0].Width =
                        tagWidth;

                    list.Columns[1].Width =
                        propertyWidth;

                    list.Columns[2].Width =
                        dashboardWidth;
                }
                finally
                {
                    isUpdatingColumnWidths =
                        false;
                }
            }

            list.Resize += (_, _) =>
            {
                UpdateColumnWidths();
            };

            list.HandleCreated += (_, _) =>
            {
                UpdateColumnWidths();
            };

            list.ColumnWidthChanging += (_, e) =>
            {
                if (isUpdatingColumnWidths)
                    return;

                e.Cancel =
                    true;

                e.NewWidth =
                    list.Columns[e.ColumnIndex].Width;
            };

            FlowLayoutPanel actions =
                new FlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    FlowDirection =
                        FlowDirection.LeftToRight,
                    WrapContents = true,
                    Padding =
                        new Padding(
                            0,
                            8,
                            0,
                            0),
                    BackColor =
                        panel.BackColor
                };

            Button btnAdd =
                CreateButton(
                    "Aggiungi",
                    95);

            Button btnDelete =
                CreateButton(
                    "Elimina",
                    90);

            Button btnDuplicate =
                CreateButton(
                    "Duplica",
                    90);

            Button btnUp =
                CreateButton(
                    "↑",
                    55);

            Button btnDown =
                CreateButton(
                    "↓",
                    55);

            context.RegisterButton(
                EditorAction.AddProperty,
                btnAdd);

            context.RegisterButton(
                EditorAction.DeleteProperty,
                btnDelete);

            context.RegisterButton(
                EditorAction.DuplicateProperty,
                btnDuplicate);

            context.RegisterButton(
                EditorAction.MovePropertyUp,
                btnUp);

            context.RegisterButton(
                EditorAction.MovePropertyDown,
                btnDown);

            actions.Controls.Add(
                btnAdd);

            actions.Controls.Add(
                btnDelete);

            actions.Controls.Add(
                btnDuplicate);

            actions.Controls.Add(
                btnUp);

            actions.Controls.Add(
                btnDown);

            layout.Controls.Add(
                title,
                0,
                0);

            layout.Controls.Add(
                description,
                0,
                1);

            layout.Controls.Add(
                list,
                0,
                2);

            layout.Controls.Add(
                actions,
                0,
                3);

            panel.Controls.Add(
                layout);
        }

        private static void BuildRightPanel(
            SplitterPanel panel,
            EditorContext context,
            DrawingColor titleColor,
            DrawingColor subtitleColor,
            DrawingColor inputColor)
        {
            TableLayoutPanel layout =
                new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    Padding = new Padding(20),
                    ColumnCount = 1,
                    RowCount = 9,
                    BackColor = panel.BackColor
                };

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    27));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    27));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    42));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    1));

            Label title = new Label
            {
                Text = "Dettagli parametro",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold),
                ForeColor = titleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label description = new Label
            {
                Text =
                    "Inserisci un nuovo parametro oppure selezionane uno dall'elenco.",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9),
                ForeColor = subtitleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label lblDisplayName =
                CreateLabel(
                    "Tag",
                    titleColor);

            ConfigureTextBox(
                context.PropertyDisplayName,
                inputColor,
                titleColor);


            Label lblInventorProperty =
                CreateLabel(
                    "Proprietà Inventor",
                    titleColor);

            ConfigureTextBox(
                context.PropertyInternalName,
                inputColor,
                titleColor);

            CheckBox chkEditable =
                context.PropertyEditable;

            chkEditable.Text =
                "Modificabile dalla Dashboard";

            chkEditable.Dock =
                DockStyle.Fill;

            chkEditable.ForeColor =
                titleColor;

            chkEditable.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);


            layout.Controls.Add(title, 0, 0);
            layout.Controls.Add(description, 0, 1);

            layout.Controls.Add(lblDisplayName, 0, 2);
            layout.Controls.Add(context.PropertyDisplayName, 0, 3);

            layout.Controls.Add(lblInventorProperty, 0, 4);
            layout.Controls.Add(context.PropertyInternalName, 0, 5);

            layout.Controls.Add(chkEditable, 0, 6);

            panel.Controls.Add(layout);
        }

        private static void ConfigureTextBox(
            TextBox textBox,
            DrawingColor backgroundColor,
            DrawingColor foregroundColor)
        {
            textBox.Dock =
                DockStyle.Fill;

            textBox.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            textBox.BackColor =
                backgroundColor;

            textBox.ForeColor =
                foregroundColor;

            textBox.BorderStyle =
                BorderStyle.FixedSingle;
        }

        private static Label CreateLabel(
            string text,
            DrawingColor color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold),
                ForeColor = color,
                TextAlign =
                    System.Drawing.ContentAlignment.BottomLeft
            };
        }

        private static Button CreateButton(
            string text,
            int width)
        {
            Button button =
                new Button
                {
                    Text = text,
                    Size =
                        new DrawingSize(
                            width,
                            34),
                    Margin =
                        new Padding(
                            0,
                            0,
                            7,
                            0),
                    FlatStyle =
                        FlatStyle.Flat,
                    BackColor =
                        DrawingColor.FromArgb(
                            71,
                            85,
                            105),
                    ForeColor =
                        DrawingColor.White,
                    Cursor =
                        Cursors.Hand
                };

            button.FlatAppearance.BorderSize = 0;

            return button;
        }
    }
}