﻿using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.StampaCartelline.Forms.Tabs;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Forms.Styling;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Windows.Forms;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class ConfigurationEditorForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly bool _isNew;

        private readonly PrintFolderConfiguration
            _configuration;
        private readonly CoreWindowSettings _windowSettings;

        private TextBox? txtName;
        private TextBox? txtDescription;
        private TabControl? tabControl;

        private readonly EditorContext _editorContext;
        private readonly ConfigurationEditorManager _editorManager;

        public string ConfigurationName =>
            txtName?.Text.Trim()
            ?? string.Empty;

        public string ConfigurationDescription =>
            txtDescription?.Text.Trim()
            ?? string.Empty;

        public PrintFolderConfiguration Configuration =>
            _editorManager.GetConfiguration();

        public ConfigurationEditorForm(
            bool isDarkTheme,
            PrintFolderConfiguration configuration,
            bool isNew)
        {
            _isDarkTheme = isDarkTheme;
            _isNew = isNew;

            _configuration =
                configuration
                ?? throw new ArgumentNullException(
                    nameof(configuration));

            _windowSettings = WindowSettingsService.Load(
                "StampaCartellineConfigurationEditor",
                1100,
                800);

            _editorContext =
                new EditorContext(this);

            InitializeComponent();

            _editorManager =
                new ConfigurationEditorManager(
                    _editorContext);

            _editorManager.BindRegisteredButtons();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            LoadConfigurationData();
        }

        private void InitializeComponent()
        {

            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            Text = _isNew
                ? "Nuova Configurazione"
                : "Modifica Configurazione";

            StartPosition = FormStartPosition.CenterParent;
            Size = new DrawingSize(1100, 800);
            MinimumSize = new DrawingSize(900, 680);
            BackColor = backgroundColor;
            FormClosing += ConfigurationEditorForm_FormClosing;

            Label title = new Label();
            title.Text = Text;
            title.Font = new DrawingFont(
                "Segoe UI",
                24,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 20);

            Label subtitle = new Label();
            subtitle.Text =
                "Scegli tutto ciò che è necessario alla tua configurazione custom.";
            subtitle.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(38, 66);

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 100);
            mainPanel.Size = new DrawingSize(
                ClientSize.Width - 70,
                ClientSize.Height - 175);
            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            mainPanel.BackColor = cardColor;

            Label lblName = CreateLabel(
                "Nome configurazione",
                titleColor);

            lblName.Location = new DrawingPoint(25, 20);

            txtName = new TextBox();
            txtName.Location = new DrawingPoint(25, 46);
            txtName.Size = new DrawingSize(410, 29);
            txtName.Font = new DrawingFont("Segoe UI", 10);
            txtName.BackColor = inputColor;
            txtName.ForeColor = titleColor;
            txtName.BorderStyle = BorderStyle.FixedSingle;

            Label lblDescription = CreateLabel(
                "Descrizione",
                titleColor);

            lblDescription.Location = new DrawingPoint(465, 20);

            txtDescription = new TextBox();
            txtDescription.Location = new DrawingPoint(465, 46);
            txtDescription.Size = new DrawingSize(
                mainPanel.ClientSize.Width - 490,
                58);
            txtDescription.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Left |
                AnchorStyles.Right;
            txtDescription.Font = new DrawingFont("Segoe UI", 9);
            txtDescription.BackColor = inputColor;
            txtDescription.ForeColor = titleColor;
            txtDescription.BorderStyle = BorderStyle.FixedSingle;
            txtDescription.Multiline = true;
            txtDescription.ScrollBars = ScrollBars.Vertical;

            tabControl = new TabControl();
            tabControl.Location = new DrawingPoint(25, 125);
            tabControl.Size = new DrawingSize(
                mainPanel.ClientSize.Width - 50,
                mainPanel.ClientSize.Height - 150);
            tabControl.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            tabControl.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);

            tabControl.TabPages.Add(
                PropertiesTabBuilder.Build(
                    _isDarkTheme,
                    _editorContext));

            tabControl.TabPages.Add(
                WordTabBuilder.Build(
                    _isDarkTheme,
                    _editorContext));

            tabControl.TabPages.Add(
                ExcelTabBuilder.Build(
                    _isDarkTheme,
                    _editorContext));

            tabControl.TabPages.Add(
                PdfTabBuilder.Build(
                    _isDarkTheme,
                    _editorContext));

            tabControl.TabPages.Add(
                GroupsTabBuilder.Build(
                    _isDarkTheme,
                    _editorContext));

            EditorThemeStyler.ApplyColoredTabs(
                tabControl,
                _isDarkTheme);

            mainPanel.Controls.Add(lblName);
            mainPanel.Controls.Add(txtName);
            mainPanel.Controls.Add(lblDescription);
            mainPanel.Controls.Add(txtDescription);
            mainPanel.Controls.Add(tabControl);

            Button btnSave = CreateButton(
                "Salva",
                DrawingColor.FromArgb(37, 99, 235),
                125);

            btnSave.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;
            btnSave.Location = new DrawingPoint(
                ClientSize.Width - 300,
                ClientSize.Height - 55);
            btnSave.Click += BtnSave_Click;

            Button btnCancel = CreateButton(
                "Annulla",
                DrawingColor.FromArgb(71, 85, 105),
                125);

            btnCancel.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;
            btnCancel.Location = new DrawingPoint(
                ClientSize.Width - 160,
                ClientSize.Height - 55);
            btnCancel.Click += BtnCancel_Click;

            Controls.Add(title);
            Controls.Add(subtitle);
            Controls.Add(mainPanel);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);

            AcceptButton = btnSave;
            CancelButton = btnCancel;
        }

        private Label CreateLabel(
            string text,
            DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;

            return label;
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width)
        {
            Button button = new Button();
            button.Text = text;
            button.Size = new DrawingSize(width, 38);
            button.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void LoadConfigurationData()
        {
            if (txtName != null)
            {
                txtName.Text =
                    _configuration.Name;
            }

            if (txtDescription != null)
            {
                txtDescription.Text =
                    _configuration.Description;
            }

            _editorManager.LoadConfiguration(
                _configuration);

            if (_isNew)
            {
                txtName?.Focus();
                txtName?.SelectAll();
            }
        }

        private bool ValidateConfiguration()
        {
            if (!string.IsNullOrWhiteSpace(ConfigurationName))
                return true;

            MessageBox.Show(
                this,
                "Inserisci il nome della configurazione.",
                "Dati mancanti",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            txtName?.Focus();

            return false;
        }

        private void BtnSave_Click(
            object? sender,
            EventArgs e)
        {
            if (!ValidateConfiguration())
                return;

            PrintFolderConfiguration configuration =
                _editorManager.GetConfiguration();

            configuration.Name =
                ConfigurationName;

            configuration.Description =
                ConfigurationDescription;

            DialogResult =
                DialogResult.OK;

            Close();
        }

        private void BtnCancel_Click(
            object? sender,
            EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void ConfigurationEditorForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "StampaCartellineConfigurationEditor");
        }
    }
}