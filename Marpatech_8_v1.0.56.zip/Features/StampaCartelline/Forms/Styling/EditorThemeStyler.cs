﻿using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms.Styling
{
    public static class EditorThemeStyler
    {
        public static void ApplyColoredTabs(
            TabControl tabControl,
            bool isDarkTheme)
        {
            tabControl.DrawMode =
                TabDrawMode.OwnerDrawFixed;

            tabControl.SizeMode =
                TabSizeMode.Fixed;

            tabControl.ItemSize =
                new Size(145, 30);

            tabControl.Padding =
                new Point(12, 4);

            tabControl.DrawItem += (_, e) =>
            {
                if (e.Index < 0 ||
                    e.Index >= tabControl.TabPages.Count)
                {
                    return;
                }

                TabPage page =
                    tabControl.TabPages[e.Index];

                Rectangle bounds =
                    e.Bounds;

                bool isSelected =
                    tabControl.SelectedIndex == e.Index;

                Color tabColor =
                    GetTabColor(
                        e.Index,
                        isDarkTheme,
                        isSelected);

                Color textColor =
                    isDarkTheme
                        ? Color.White
                        : Color.FromArgb(15, 23, 42);

                using Brush backgroundBrush =
                    new SolidBrush(tabColor);

                using Brush textBrush =
                    new SolidBrush(textColor);

                e.Graphics.FillRectangle(
                    backgroundBrush,
                    bounds);

                StringFormat format =
                    new StringFormat
                    {
                        Alignment =
                            StringAlignment.Center,

                        LineAlignment =
                            StringAlignment.Center
                    };

                Font font =
                    new Font(
                        "Segoe UI",
                        9,
                        isSelected
                            ? FontStyle.Bold
                            : FontStyle.Regular);

                e.Graphics.DrawString(
                    page.Text,
                    font,
                    textBrush,
                    bounds,
                    format);

                font.Dispose();

                if (isSelected)
                {
                    using Pen selectedPen =
                        new Pen(
                            isDarkTheme
                                ? Color.White
                                : Color.FromArgb(
                                    30,
                                    41,
                                    59),
                            2);

                    e.Graphics.DrawLine(
                        selectedPen,
                        bounds.Left,
                        bounds.Bottom - 1,
                        bounds.Right,
                        bounds.Bottom - 1);
                }
            };
        }

        public static void ApplyListViewTheme(
            ListView listView,
            bool isDarkTheme)
        {
            Color backgroundColor =
                isDarkTheme
                    ? Color.FromArgb(35, 38, 45)
                    : Color.FromArgb(241, 245, 249);

            Color alternateColor =
                isDarkTheme
                    ? Color.FromArgb(40, 43, 51)
                    : Color.FromArgb(248, 250, 252);

            Color headerColor =
                isDarkTheme
                    ? Color.FromArgb(48, 52, 61)
                    : Color.FromArgb(226, 232, 240);

            Color textColor =
                isDarkTheme
                    ? Color.FromArgb(235, 238, 244)
                    : Color.FromArgb(30, 41, 59);

            Color gridColor =
                isDarkTheme
                    ? Color.FromArgb(65, 70, 82)
                    : Color.FromArgb(203, 213, 225);

            Color selectionColor =
                isDarkTheme
                    ? Color.FromArgb(45, 91, 160)
                    : Color.FromArgb(191, 219, 254);

            listView.BackColor =
                backgroundColor;

            listView.ForeColor =
                textColor;

            listView.BorderStyle =
                BorderStyle.FixedSingle;

            listView.GridLines =
                false;

            listView.OwnerDraw =
                true;

            listView.DrawColumnHeader += (_, e) =>
            {
                using Brush backgroundBrush =
                    new SolidBrush(headerColor);

                using Brush textBrush =
                    new SolidBrush(textColor);

                using Pen borderPen =
                    new Pen(gridColor);

                e.Graphics.FillRectangle(
                    backgroundBrush,
                    e.Bounds);

                e.Graphics.DrawRectangle(
                    borderPen,
                    e.Bounds);

                Rectangle textBounds =
                    new Rectangle(
                        e.Bounds.X + 6,
                        e.Bounds.Y,
                        e.Bounds.Width - 10,
                        e.Bounds.Height);

                TextRenderer.DrawText(
                    e.Graphics,
                    e.Header?.Text ?? string.Empty,
                    new Font(
                        "Segoe UI",
                        9,
                        FontStyle.Bold),
                    textBounds,
                    textColor,
                    TextFormatFlags.Left |
                    TextFormatFlags.VerticalCenter |
                    TextFormatFlags.EndEllipsis);
            };

            listView.DrawItem += (_, e) =>
            {
                if (listView.View != View.Details)
                {
                    e.DrawDefault = true;
                }
            };

            listView.DrawSubItem += (_, e) =>
            {
                bool selected =
                    e.Item?.Selected ?? false;

                Color rowColor =
                    selected
                        ? selectionColor
                        : e.ItemIndex % 2 == 0
                            ? backgroundColor
                            : alternateColor;

                using Brush rowBrush =
                    new SolidBrush(rowColor);

                using Pen gridPen =
                    new Pen(gridColor);

                e.Graphics.FillRectangle(
                    rowBrush,
                    e.Bounds);

                e.Graphics.DrawRectangle(
                    gridPen,
                    e.Bounds);

                Rectangle textBounds =
                    new Rectangle(
                        e.Bounds.X + 6,
                        e.Bounds.Y,
                        e.Bounds.Width - 10,
                        e.Bounds.Height);

                TextRenderer.DrawText(
                    e.Graphics,
                    e.SubItem?.Text ?? string.Empty,
                    listView.Font,
                    textBounds,
                    textColor,
                    TextFormatFlags.Left |
                    TextFormatFlags.VerticalCenter |
                    TextFormatFlags.EndEllipsis);
            };
        }

        public static void ApplyDataGridViewTheme(
            DataGridView grid,
            bool isDarkTheme)
        {
            Color backgroundColor =
                isDarkTheme
                    ? Color.FromArgb(35, 38, 45)
                    : Color.FromArgb(241, 245, 249);

            Color alternateColor =
                isDarkTheme
                    ? Color.FromArgb(40, 43, 51)
                    : Color.FromArgb(248, 250, 252);

            Color headerColor =
                isDarkTheme
                    ? Color.FromArgb(48, 52, 61)
                    : Color.FromArgb(226, 232, 240);

            Color textColor =
                isDarkTheme
                    ? Color.FromArgb(235, 238, 244)
                    : Color.FromArgb(30, 41, 59);

            Color gridColor =
                isDarkTheme
                    ? Color.FromArgb(65, 70, 82)
                    : Color.FromArgb(203, 213, 225);

            Color selectionColor =
                isDarkTheme
                    ? Color.FromArgb(45, 91, 160)
                    : Color.FromArgb(191, 219, 254);

            Color selectionTextColor =
                isDarkTheme
                    ? Color.White
                    : Color.FromArgb(15, 23, 42);

            grid.BackgroundColor =
                backgroundColor;

            grid.BorderStyle =
                BorderStyle.FixedSingle;

            grid.GridColor =
                gridColor;

            grid.EnableHeadersVisualStyles =
                false;

            grid.ColumnHeadersDefaultCellStyle.BackColor =
                headerColor;

            grid.ColumnHeadersDefaultCellStyle.ForeColor =
                textColor;

            grid.ColumnHeadersDefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            grid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
                headerColor;

            grid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
                textColor;

            grid.DefaultCellStyle.BackColor =
                backgroundColor;

            grid.DefaultCellStyle.ForeColor =
                textColor;

            grid.DefaultCellStyle.SelectionBackColor =
                selectionColor;

            grid.DefaultCellStyle.SelectionForeColor =
                selectionTextColor;

            grid.AlternatingRowsDefaultCellStyle.BackColor =
                alternateColor;

            grid.AlternatingRowsDefaultCellStyle.ForeColor =
                textColor;

            grid.RowHeadersVisible =
                false;

            grid.DefaultCellStyle.Font =
                new Font(
                    "Segoe UI",
                    9);

            grid.DefaultCellStyle.Padding =
                new Padding(4, 2, 4, 2);

            grid.RowTemplate.Height =
                28;

            grid.ColumnHeadersHeight =
                30;
        }

        private static Color GetTabColor(
            int index,
            bool isDarkTheme,
            bool selected)
        {
            Color[] darkColors =
            {
                Color.FromArgb(42, 91, 146),
                Color.FromArgb(104, 74, 145),
                Color.FromArgb(49, 117, 94),
                Color.FromArgb(155, 91, 46),
                Color.FromArgb(120, 68, 84)
            };

            Color[] lightColors =
            {
                Color.FromArgb(147, 197, 253),
                Color.FromArgb(196, 181, 253),
                Color.FromArgb(167, 243, 208),
                Color.FromArgb(253, 186, 116),
                Color.FromArgb(251, 182, 206)
            };

            Color[] colors =
                isDarkTheme
                    ? darkColors
                    : lightColors;

            Color baseColor =
                colors[index % colors.Length];

            if (selected)
                return baseColor;

            return isDarkTheme
                ? ControlPaint.Dark(
                    baseColor,
                    0.25f)
                : ControlPaint.Light(
                    baseColor,
                    0.35f);
        }
    }
}