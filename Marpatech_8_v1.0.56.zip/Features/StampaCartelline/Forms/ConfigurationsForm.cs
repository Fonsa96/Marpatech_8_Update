﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Models;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class ConfigurationsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly CoreWindowSettings _windowSettings;

        private ListBox? lstConfigurations;
        private Button? btnEdit;
        private Button? btnDuplicate;
        private Button? btnDelete;

        private ConfigurationListManager?
    _configurationManager;

        public ConfigurationsForm(bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "StampaCartellineConfigurations",
                820,
                620);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            if (lstConfigurations != null)
            {
                _configurationManager =
                    new ConfigurationListManager(
                        lstConfigurations);

                try
                {
                    _configurationManager.Load();
                }
                catch (Exception exception)
                {
                    MessageBox.Show(
                        this,
                        exception.Message,
                        "Errore caricamento configurazioni",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }

            UpdateButtonsState();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            this.Text = "Gestione Configurazioni";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new DrawingSize(820, 620);
            this.MinimumSize = new DrawingSize(720, 520);
            this.BackColor = backgroundColor;
            this.FormClosing += ConfigurationsForm_FormClosing;

            Label title = new Label();
            title.Text = "Gestione Configurazioni";
            title.Font = new DrawingFont(
                "Segoe UI",
                24,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Label subtitle = new Label();
            subtitle.Text =
                "Crea, modifica, duplica o elimina le configurazioni disponibili.";
            subtitle.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(38, 70);

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 115);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 70,
                this.ClientSize.Height - 185);
            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(25);

            Label listTitle = new Label();
            listTitle.Text = "Configurazioni salvate";
            listTitle.Font = new DrawingFont(
                "Segoe UI",
                11,
                DrawingFontStyle.Bold);
            listTitle.ForeColor = titleColor;
            listTitle.AutoSize = true;
            listTitle.Location = new DrawingPoint(25, 22);

            lstConfigurations = new ListBox();
            lstConfigurations.Location = new DrawingPoint(25, 55);
            lstConfigurations.Size = new DrawingSize(
                mainPanel.ClientSize.Width - 50,
                mainPanel.ClientSize.Height - 135);
            lstConfigurations.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            lstConfigurations.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            lstConfigurations.BackColor = inputColor;
            lstConfigurations.ForeColor = titleColor;
            lstConfigurations.BorderStyle =
                BorderStyle.FixedSingle;
            lstConfigurations.IntegralHeight = false;
            lstConfigurations.SelectedIndexChanged +=
                LstConfigurations_SelectedIndexChanged;
            lstConfigurations.DoubleClick +=
                LstConfigurations_DoubleClick;

            FlowLayoutPanel actionsPanel =
                new FlowLayoutPanel();

            actionsPanel.Location = new DrawingPoint(
                25,
                mainPanel.ClientSize.Height - 65);
            actionsPanel.Size = new DrawingSize(
                mainPanel.ClientSize.Width - 50,
                42);
            actionsPanel.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            actionsPanel.FlowDirection =
                FlowDirection.LeftToRight;
            actionsPanel.WrapContents = false;

            Button btnNew = CreateActionButton(
                "Nuova",
                DrawingColor.FromArgb(37, 99, 235),
                125);

            btnNew.Click += BtnNew_Click;

            btnEdit = CreateActionButton(
                "Modifica",
                DrawingColor.FromArgb(124, 58, 237),
                125);

            btnEdit.Click += BtnEdit_Click;

            btnDuplicate = CreateActionButton(
                "Duplica",
                DrawingColor.FromArgb(5, 150, 105),
                125);

            btnDuplicate.Click += BtnDuplicate_Click;

            btnDelete = CreateActionButton(
                "Elimina",
                DrawingColor.FromArgb(220, 38, 38),
                125);

            btnDelete.Click += BtnDelete_Click;

            actionsPanel.Controls.Add(btnNew);
            actionsPanel.Controls.Add(btnEdit);
            actionsPanel.Controls.Add(btnDuplicate);
            actionsPanel.Controls.Add(btnDelete);

            mainPanel.Controls.Add(listTitle);
            mainPanel.Controls.Add(lstConfigurations);
            mainPanel.Controls.Add(actionsPanel);

            Button btnClose = CreateActionButton(
                "Chiudi",
                DrawingColor.FromArgb(71, 85, 105),
                120);

            btnClose.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnClose.Location = new DrawingPoint(
                this.ClientSize.Width - 155,
                this.ClientSize.Height - 55);

            btnClose.Click += BtnClose_Click;

            this.Controls.Add(title);
            this.Controls.Add(subtitle);
            this.Controls.Add(mainPanel);
            this.Controls.Add(btnClose);
        }

        private Button CreateActionButton(
            string text,
            DrawingColor color,
            int width)
        {
            Button button = new Button();
            button.Text = text;
            button.Size = new DrawingSize(width, 38);
            button.Margin = new Padding(0, 0, 10, 0);
            button.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void UpdateButtonsState()
        {
            bool hasSelection =
                lstConfigurations != null &&
                lstConfigurations.SelectedItem != null;

            if (btnEdit != null)
                btnEdit.Enabled = hasSelection;

            if (btnDuplicate != null)
                btnDuplicate.Enabled = hasSelection;

            if (btnDelete != null)
                btnDelete.Enabled = hasSelection;
        }

        private string? GetSelectedConfigurationName()
        {
            return lstConfigurations?
                .SelectedItem?
                .ToString();
        }

        private void LstConfigurations_SelectedIndexChanged(
            object? sender,
            EventArgs e)
        {
            UpdateButtonsState();
        }

        private void LstConfigurations_DoubleClick(
            object? sender,
            EventArgs e)
        {
            BtnEdit_Click(
                sender,
                e);
        }

        private void BtnNew_Click(
            object? sender,
            EventArgs e)
        {
            if (_configurationManager == null)
                return;

            PrintFolderConfiguration configuration =
                new PrintFolderConfiguration();

            using ConfigurationEditorForm form =
                new ConfigurationEditorForm(
                    _isDarkTheme,
                    configuration,
                    true);

            if (form.ShowDialog(this) != DialogResult.OK)
                return;

            try
            {
                _configurationManager.Add(
                    form.Configuration);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    exception.Message,
                    "Errore",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnEdit_Click(
            object? sender,
            EventArgs e)
        {
            if (_configurationManager == null)
                return;

            PrintFolderConfiguration? configuration =
                _configurationManager.SelectedConfiguration;

            if (configuration == null)
                return;

            using ConfigurationEditorForm form =
                new ConfigurationEditorForm(
                    _isDarkTheme,
                    configuration,
                    false);

            if (form.ShowDialog(this) != DialogResult.OK)
                return;

            try
            {
                _configurationManager.UpdateSelected(
                    form.Configuration);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    exception.Message,
                    "Errore",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnDuplicate_Click(
            object? sender,
            EventArgs e)
        {
            if (_configurationManager == null)
                return;

            try
            {
                PrintFolderConfiguration duplicate =
                    _configurationManager
                        .CreateDuplicateOfSelected();

                using ConfigurationEditorForm form =
                    new ConfigurationEditorForm(
                        _isDarkTheme,
                        duplicate,
                        true);

                if (form.ShowDialog(this) != DialogResult.OK)
                    return;

                _configurationManager.Add(
                    form.Configuration);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    exception.Message,
                    "Errore",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnDelete_Click(
            object? sender,
            EventArgs e)
        {
            string? configurationName =
                GetSelectedConfigurationName();

            if (string.IsNullOrWhiteSpace(configurationName))
                return;

            DialogResult result = MessageBox.Show(
                this,
                $"Eliminare la configurazione \"{configurationName}\"?",
                "Conferma eliminazione",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
                return;

            _configurationManager?.DeleteSelected();

            UpdateButtonsState();
        }

        private void BtnClose_Click(
            object? sender,
            EventArgs e)
        {
            Close();
        }

        private void ConfigurationsForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "StampaCartellineConfigurations");
        }
    }
}