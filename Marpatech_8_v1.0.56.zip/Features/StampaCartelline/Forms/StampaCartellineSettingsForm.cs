﻿using System;
using System.IO;
using Marpatech_8.Features.StampaCartelline.Services;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class StampaCartellineSettingsForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly CoreWindowSettings _windowSettings;

        public StampaCartellineSettingsForm(bool isDarkTheme)
        {
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "StampaCartellineSettings",
                720,
                520);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            this.Text = "Impostazioni Stampa Cartelline";
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new DrawingSize(720, 520);
            this.MinimumSize = new DrawingSize(650, 470);
            this.BackColor = backgroundColor;
            this.FormClosing += StampaCartellineSettingsForm_FormClosing;

            Label title = new Label();
            title.Text = "Impostazioni";
            title.Font = new DrawingFont(
                "Segoe UI",
                24,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Label subtitle = new Label();
            subtitle.Text =
                "Gestione delle configurazioni della funzione Stampa Cartelline";
            subtitle.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(38, 70);

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 115);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 70,
                this.ClientSize.Height - 150);
            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(28);

            TableLayoutPanel buttonsLayout = new TableLayoutPanel();
            buttonsLayout.Dock = DockStyle.Fill;
            buttonsLayout.ColumnCount = 2;
            buttonsLayout.RowCount = 2;
            buttonsLayout.Padding = new Padding(8);

            buttonsLayout.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 50));

            buttonsLayout.ColumnStyles.Add(
                new ColumnStyle(SizeType.Percent, 50));

            buttonsLayout.RowStyles.Add(
                new RowStyle(SizeType.Percent, 50));

            buttonsLayout.RowStyles.Add(
                new RowStyle(SizeType.Percent, 50));

            Button btnConfigurations = CreateSettingsButton(
                "Gestione Configurazioni",
                DrawingColor.FromArgb(37, 99, 235));

            btnConfigurations.Click +=
                BtnConfigurations_Click;

            Button btnImport = CreateSettingsButton(
                "Importa Configurazioni",
                DrawingColor.FromArgb(5, 150, 105));

            btnImport.Click +=
                BtnImport_Click;

            Button btnExport = CreateSettingsButton(
                "Esporta Configurazioni",
                DrawingColor.FromArgb(217, 119, 6));

            btnExport.Click +=
                BtnExport_Click;

            buttonsLayout.Controls.Add(
                btnConfigurations,
                0,
                0);

            buttonsLayout.SetColumnSpan(
            btnConfigurations,
            2);


            buttonsLayout.Controls.Add(
                btnImport,
                0,
                1);

            buttonsLayout.Controls.Add(
                btnExport,
                1,
                1);

            mainPanel.Controls.Add(buttonsLayout);

            this.Controls.Add(title);
            this.Controls.Add(subtitle);
            this.Controls.Add(mainPanel);
        }

        private Button CreateSettingsButton(
            string text,
            DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Dock = DockStyle.Fill;
            button.Margin = new Padding(10);
            button.Font = new DrawingFont(
                "Segoe UI",
                11,
                DrawingFontStyle.Bold);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void BtnConfigurations_Click(
            object? sender,
            EventArgs e)
        {
            ConfigurationsForm form =
                new ConfigurationsForm(
                    _isDarkTheme);

            form.ShowDialog(this);
        }

        private void BtnImport_Click(
            object? sender,
            EventArgs e)
        {
            using OpenFileDialog dialog =
                new OpenFileDialog();

            dialog.Title =
                "Importa configurazioni Stampa Cartelline";

            dialog.Filter =
                "File JSON (*.json)|*.json";

            dialog.Multiselect = false;

            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            try
            {
                StampaCartellineStorage.Import(
                    dialog.FileName);

                MessageBox.Show(
                    this,
                    "Configurazioni importate con successo.\n\n" +
                    "Chiudi e riapri la finestra \"Gestione Configurazioni\" " +
                    "per visualizzare le modifiche.",
                    "Importazione completata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    exception.Message,
                    "Errore",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnExport_Click(
            object? sender,
            EventArgs e)
        {
            using SaveFileDialog dialog =
                new SaveFileDialog();

            dialog.Title =
                "Esporta configurazioni Stampa Cartelline";

            dialog.Filter =
                "File JSON (*.json)|*.json";

            dialog.FileName =
                "StampaCartelline.json";

            if (dialog.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            try
            {
                StampaCartellineStorage.Export(
                    dialog.FileName);

                MessageBox.Show(
                    this,
                    "Configurazioni esportate con successo.",
                    "Esportazione completata",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    this,
                    exception.Message,
                    "Errore",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void StampaCartellineSettingsForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "StampaCartellineSettings");
        }
    }
}