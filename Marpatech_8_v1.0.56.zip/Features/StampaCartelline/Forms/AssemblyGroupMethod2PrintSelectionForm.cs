﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public sealed class AssemblyGroupMethod2PrintSelectionForm :
        Form
    {
        private readonly TreeView _treeView;

        private bool _selectionCompleted;


        public event EventHandler? SelectionConfirmed;

        public event EventHandler? SelectionCancelled;


        public AssemblyGroupMethod2PrintSelectionForm(
            AssemblyGroupMethod2PrintNode root)
        {
            Text =
                "Selezione tavole - Metodo 2";

            StartPosition =
                FormStartPosition.CenterScreen;

            FormBorderStyle =
                FormBorderStyle.Sizable;

            MinimizeBox =
                true;

            MaximizeBox =
                true;

            ShowInTaskbar =
                true;

            Width =
                760;

            Height =
                700;

            MinimumSize =
                new Size(
                    650,
                    500);


            /*
             * ==================================================
             * PANNELLO SUPERIORE
             * ==================================================
             */
            Panel headerPanel =
                new Panel();

            headerPanel.Dock =
                DockStyle.Top;

            headerPanel.Height =
                135;


            Label title =
                new Label();

            title.Text =
                "Quali tavole desideri stampare?";

            title.Font =
                new Font(
                    "Segoe UI",
                    11,
                    FontStyle.Bold);

            title.AutoSize =
                true;

            title.Left =
                20;

            title.Top =
                18;


            Label description =
                new Label();

            description.Text =
                "Seleziona le tavole da stampare per l'assieme corrente.";

            description.Font =
                new Font(
                    "Segoe UI",
                    9);

            description.AutoSize =
                true;

            description.Left =
                20;

            description.Top =
                50;


            Label legend =
                new Label();

            legend.Text =
                "Legenda:" +
                System.Environment.NewLine +
                "☑ = Stampa tavola" +
                System.Environment.NewLine +
                "☐ = Non stampare tavola";

            legend.Font =
                new Font(
                    "Segoe UI",
                    9);

            legend.AutoSize =
                true;

            legend.Left =
                20;

            legend.Top =
                78;


            headerPanel.Controls.Add(
                title);

            headerPanel.Controls.Add(
                description);

            headerPanel.Controls.Add(
                legend);


            /*
             * ==================================================
             * PANNELLO INFERIORE
             * ==================================================
             */
            Panel buttonsPanel =
                new Panel();

            buttonsPanel.Dock =
                DockStyle.Bottom;

            buttonsPanel.Height =
                65;


            Button confirmButton =
                new Button();

            confirmButton.Text =
                "Conferma";

            confirmButton.Width =
                110;

            confirmButton.Height =
                34;

            confirmButton.Top =
                15;

            confirmButton.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;


            Button cancelButton =
                new Button();

            cancelButton.Text =
                "Annulla";

            cancelButton.Width =
                110;

            cancelButton.Height =
                34;

            cancelButton.Top =
                15;

            cancelButton.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Right;


            /*
             * Posizionamento dinamico.
             */
            buttonsPanel.Resize +=
                (_, _) =>
                {
                    cancelButton.Left =
                        buttonsPanel.ClientSize.Width
                        - cancelButton.Width
                        - 15;

                    confirmButton.Left =
                        cancelButton.Left
                        - confirmButton.Width
                        - 10;
                };


            buttonsPanel.Controls.Add(
                confirmButton);

            buttonsPanel.Controls.Add(
                cancelButton);


            /*
             * ==================================================
             * ALBERO
             * ==================================================
             */
            _treeView =
                new TreeView();

            _treeView.CheckBoxes =
                true;

            _treeView.HideSelection =
                false;

            _treeView.FullRowSelect =
                true;

            /*
             * Fill utilizza automaticamente
             * lo spazio tra header e pulsanti.
             */
            _treeView.Dock =
                DockStyle.Fill;

            _treeView.Font =
                new Font(
                    "Segoe UI",
                    9);

            _treeView.Nodes.Add(
                CreateTreeNode(
                    root));

            _treeView.ExpandAll();


            /*
             * ==================================================
             * EVENTI
             * ==================================================
             */
            confirmButton.Click +=
                (_, _) =>
                {
                    if (_treeView.Nodes.Count > 0)
                    {
                        ApplySelectionsRecursive(
                            _treeView.Nodes[0]);
                    }

                    _selectionCompleted =
                        true;

                    SelectionConfirmed?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            cancelButton.Click +=
                (_, _) =>
                {
                    _selectionCompleted =
                        true;

                    SelectionCancelled?.Invoke(
                        this,
                        EventArgs.Empty);
                };


            FormClosing +=
                (_, _) =>
                {
                    if (!_selectionCompleted)
                    {
                        _selectionCompleted =
                            true;

                        SelectionCancelled?.Invoke(
                            this,
                            EventArgs.Empty);
                    }
                };


            /*
             * L'ordine di Add è importante
             * per DockStyle.
             */
            Controls.Add(
                _treeView);

            Controls.Add(
                buttonsPanel);

            Controls.Add(
                headerPanel);
        }


        private static TreeNode CreateTreeNode(
            AssemblyGroupMethod2PrintNode runtimeNode)
        {
            string text =
                runtimeNode.Code;

            if (runtimeNode.IsNestedMainPrefixAssembly)
            {
                text +=
                    "  [ASSIEME ANNIDATO]";
            }


            TreeNode treeNode =
                new TreeNode(
                    text);

            treeNode.Tag =
                runtimeNode;

            treeNode.Checked =
                runtimeNode.PrintDrawing;


            foreach (AssemblyGroupMethod2PrintNode child
                in runtimeNode.Children)
            {
                treeNode.Nodes.Add(
                    CreateTreeNode(
                        child));
            }


            return treeNode;
        }


        private static void ApplySelectionsRecursive(
            TreeNode treeNode)
        {
            if (treeNode.Tag
                is AssemblyGroupMethod2PrintNode runtimeNode)
            {
                runtimeNode.PrintDrawing =
                    treeNode.Checked;
            }


            foreach (TreeNode child
                in treeNode.Nodes)
            {
                ApplySelectionsRecursive(
                    child);
            }
        }
    }
}