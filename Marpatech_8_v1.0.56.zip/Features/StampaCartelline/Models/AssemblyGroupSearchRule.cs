﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class AssemblyGroupSearchRule
    {
        public string CodePrefix
        {
            get;
            set;
        } = string.Empty;

        public string DrawingSearchPath
        {
            get;
            set;
        } = string.Empty;
    }
}