﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{

    public enum AssemblyGroupMethod1SelectionState
    {
        DrawingOnly = 0,
        DrawingAndJenkins = 1,
        Skip = 2
    }

    public sealed class AssemblyGroupMethod1TreeNode
    {
        /*
         * CODICE letto dalle Custom iProperties.
         */
        public string Code
        {
            get;
            set;
        } = string.Empty;


        /*
         * DISEGNO letto dalle Custom iProperties.
         */
        public string DrawingName
        {
            get;
            set;
        } = string.Empty;


        /*
         * Percorso fisico dell'IAM.
         */
        public string AssemblyPath
        {
            get;
            set;
        } = string.Empty;


        /*
         * Percorso server nel quale ricercare
         * esattamente DISEGNO.idw.
         */
        public string DrawingSearchPath
        {
            get;
            set;
        } = string.Empty;


        /*
         * Percorso IDW risolto.
         *
         * Verrà utilizzato nel blocco successivo.
         */
        public string DrawingPath
        {
            get;
            set;
        } = string.Empty;


        public AssemblyGroupMethod1SelectionState SelectionState
        {
            get;
            set;
        } =
            AssemblyGroupMethod1SelectionState.DrawingOnly;

        public AssemblyGroupMethod1TreeNode?
    Parent
        {
            get;
            set;
        }


        /*
         * Eventuale errore associato
         * specificamente a questo nodo.
         */
        public string FailureReason
        {
            get;
            set;
        } = string.Empty;


        /*
         * Figli STL reali del nodo.
         */
        public List<AssemblyGroupMethod1TreeNode>
            Children
        {
            get;
            set;
        } =
            new List<AssemblyGroupMethod1TreeNode>();


        /*
         * TRUE se questo STL contiene
         * almeno un altro STL valido
         * nella struttura rilevata.
         */
        public bool IsContainer =>
            Children.Count > 0;

        /*
 * TRUE:
 * questo STL fa parte della selezione effettiva
 * e può essere processato.
 *
 * FALSE:
 * questo STL viene mantenuto solamente per
 * mostrare la struttura dell'albero.
 */
        public bool IsProcessable
        {
            get;
            set;
        } = true;
    }
}