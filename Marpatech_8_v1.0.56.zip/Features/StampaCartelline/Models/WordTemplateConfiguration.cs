﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class WordTemplateConfiguration
    {
        public string Name { get; set; } =
            string.Empty;

        public string TemplatePath { get; set; } =
            string.Empty;

        public List<WordPlaceholderMapping>
            PlaceholderMappings
        { get; set; } =
                new List<WordPlaceholderMapping>();
    }
}
