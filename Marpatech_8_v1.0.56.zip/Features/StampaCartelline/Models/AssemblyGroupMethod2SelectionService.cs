﻿using Marpatech_8.Features.StampaCartelline.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2SelectionService
    {
        public bool ShowAndWait(
            IWin32Window owner,
            IEnumerable<AssemblyGroupMethod2TreeNode> roots)
        {
            bool completed =
                false;

            bool confirmed =
                false;


            using AssemblyGroupMethod2SelectionForm form =
                new AssemblyGroupMethod2SelectionForm(
                    roots);


            form.SelectionConfirmed +=
                (_, _) =>
                {
                    confirmed =
                        true;

                    completed =
                        true;
                };


            form.SelectionCancelled +=
                (_, _) =>
                {
                    confirmed =
                        false;

                    completed =
                        true;
                };


            /*
             * MODELLESS:
             * Inventor rimane utilizzabile.
             */
            form.Show();

            form.BringToFront();

            form.Activate();


            while (!completed &&
                   !form.IsDisposed)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }


            if (!form.IsDisposed)
            {
                form.Close();
            }


            return confirmed;
        }
    }
}