﻿public class DashboardPropertySession
{
    public Guid Id { get; } =
        Guid.NewGuid();

    public string Tag { get; set; } =
        string.Empty;

    public string InventorPropertyName { get; set; } =
        string.Empty;

    public bool Editable { get; set; }

    public string Value { get; set; } =
        string.Empty;

    public string OriginalValue { get; set; } = string.Empty;
}