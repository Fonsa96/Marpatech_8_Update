﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class AssemblyGroupMethod2TreeNode
    {
        public string Code
        {
            get;
            set;
        } = string.Empty;

        public string AssemblyPath
        {
            get;
            set;
        } = string.Empty;

        public string DrawingName
        {
            get;
            set;
        } = string.Empty;

        public AssemblyGroupMethod2TreeNode?
            Parent
        {
            get;
            set;
        }

        /*
         * FORM 1:
         *
         * TRUE  = processa questo STL
         * FALSE = salta questo STL
         *
         * Tutti partono TRUE.
         */
        public bool ProcessStl
        {
            get;
            set;
        } = true;

        public List<AssemblyGroupMethod2TreeNode>
            Children
        {
            get;
            set;
        } =
            new List<AssemblyGroupMethod2TreeNode>();

        /*
         * Per contenitore intendiamo:
         * questo STL contiene almeno un altro
         * STL nella struttura rilevata.
         */
        public bool IsContainer =>
            Children.Count > 0;

        public List<string> ProcessLog
        {
            get;
            set;
        } =
         new List<string>();

        /*
 * TRUE:
 * questo STL fa parte della selezione effettiva
 * e può essere processato.
 *
 * FALSE:
 * questo STL viene mantenuto solamente per
 * mostrare la struttura dell'albero.
 */
        public bool IsProcessable
        {
            get;
            set;
        } = true;
    }
}