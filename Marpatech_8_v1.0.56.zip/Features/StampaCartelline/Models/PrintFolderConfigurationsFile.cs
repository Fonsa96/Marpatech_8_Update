﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class PrintFolderConfigurationsFile
    {
        public string FileType { get; set; } =
            "Marpatech.StampaCartelline";

        public int Version { get; set; } = 1;

        public List<PrintFolderConfiguration>
            Configurations
        { get; set; } =
            new List<PrintFolderConfiguration>();
    }
}