﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class AssemblyGroupsConfiguration
    {
        public bool IncludeInPrintProcess
        {
            get;
            set;
        }

        public bool Method1Enabled
        {
            get;
            set;
        }

        public List<AssemblyGroupSearchRule> Method1Rows
        {
            get;
            set;
        } =
            new List<AssemblyGroupSearchRule>();

        public bool Method2Enabled
        {
            get;
            set;
        }

        public string Method2MainAssemblyCodePrefix
        {
            get;
            set;
        } = string.Empty;

        public List<AssemblyGroupSearchRule> Method2Rows
        {
            get;
            set;
        } =
            new List<AssemblyGroupSearchRule>();

        /*
         * Manteniamo per ora questa proprietà
         * se è già utilizzata da vecchie parti
         * della configurazione.
         *
         * Non la eliminiamo finché non abbiamo
         * verificato tutti i riferimenti.
         */
        public List<AssemblyGroupDefinition> Groups
        {
            get;
            set;
        } =
            new List<AssemblyGroupDefinition>();
    }

    public class AssemblyGroupDefinition
    {
        public string Name
        {
            get;
            set;
        } = string.Empty;
    }
}