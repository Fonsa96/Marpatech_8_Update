﻿using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class DashboardPathSection
    {
        public Panel Card
        {
            get;
        }

        public TextBox PathTextBox
        {
            get;
        }

        public Button BrowseButton
        {
            get;
        }

        public CheckBox IncludeInPrintCheckBox
        {
            get;
        }

        public DashboardPathSession? Session
        {
            get;
            set;
        }

        public DashboardPathSection(
            Panel card,
            TextBox pathTextBox,
            Button browseButton,
            CheckBox includeInPrintCheckBox)
        {
            Card =
                card;

            PathTextBox =
                pathTextBox;

            BrowseButton =
                browseButton;

            IncludeInPrintCheckBox =
                includeInPrintCheckBox;
        }
    }
}