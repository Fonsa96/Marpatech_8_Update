﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public enum StampaCartellineProcessSection
    {
        Inventor = 1,
        Word = 2,
        Excel = 3,
        Pdf = 4,
        AssemblyGroups = 5
    }
}