﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class AssemblyGroupMethod2PrintNode
    {
        public string Code
        {
            get;
            set;
        } = string.Empty;

        public string DrawingName
        {
            get;
            set;
        } = string.Empty;

        public string DrawingSearchPath
        {
            get;
            set;
        } = string.Empty;

        public string FailureReason
        {
            get;
            set;
        } = string.Empty;

        public string SearchPrefix
        {
            get;
            set;
        } = string.Empty;

        public bool PrintDrawing
        {
            get;
            set;
        }

        public bool IsNestedMainPrefixAssembly
        {
            get;
            set;
        }

        public AssemblyGroupMethod2PrintNode?
            Parent
        {
            get;
            set;
        }

        public List<AssemblyGroupMethod2PrintNode>
            Children
        {
            get;
            set;
        } =
            new List<AssemblyGroupMethod2PrintNode>();

        public string SourceDocumentPath
        {
            get;
            set;
        } = string.Empty;

    }
}