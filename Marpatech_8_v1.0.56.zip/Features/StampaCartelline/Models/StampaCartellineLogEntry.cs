﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public enum StampaCartellineLogEntryType
    {
        Information,
        Success,
        Warning,
        Error,
        Skipped
    }

    public sealed class StampaCartellineLogEntry
    {
        public StampaCartellineProcessSection Section
        {
            get;
            set;
        }

        public StampaCartellineLogEntryType Type
        {
            get;
            set;
        }

        public string Message
        {
            get;
            set;
        } = string.Empty;
    }
}