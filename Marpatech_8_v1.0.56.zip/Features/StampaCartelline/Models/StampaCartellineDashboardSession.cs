﻿using System;
using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class StampaCartellineDashboardSession
    {
        public string ConfigurationName { get; set; } =
            string.Empty;

        public string ConfigurationDescription { get; set; } =
            string.Empty;

        public List<DashboardPropertySession>
            InventorProperties
        { get; set; } =
            new List<DashboardPropertySession>();

        public DashboardPathSession ExcelDrawings
        { get; set; } =
            new DashboardPathSession();

        public DashboardPathSession SheetMetalPdfs
        { get; set; } =
            new DashboardPathSession();

        public bool IncludePrintFolders
        {
            get;
            set;
        } = true;

        public bool IsPrintingStl
        {
            get;
            set;
        }

        public string StlDescription
        {
            get;
            set;
        } = string.Empty;

        public string StlDeterminingAttribute
        {
            get;
            set;
        } = string.Empty;

        public bool LockStlDeterminingAttribute
        {
            get;
            set;
        } = true;

        public bool IncludeAssemblyGroups
        {
            get;
            set;
        } = true;

        public bool PrintOnlySelectedStl
        {
            get;
            set;
        }

        public string SelectedStlList
        {
            get;
            set;
        } = string.Empty;

        public bool PrintOnlySelectedAssemblyCodes
        {
            get;
            set;
        }

        public List<AssemblyCodeSelection>
            SelectedAssemblyCodes
        {
            get;
            set;
        }
            = new List<AssemblyCodeSelection>();

        public DashboardPropertySession?
            GetProperty(string inventorPropertyName)
        {
            return InventorProperties.Find(
                property =>
                    string.Equals(
                        property.InventorPropertyName,
                        inventorPropertyName,
                        StringComparison.OrdinalIgnoreCase));
        }

        public DashboardPropertySession?
            GetPropertyByTag(string tag)
        {
            return InventorProperties.Find(
                property =>
                    string.Equals(
                        property.Tag,
                        tag,
                        StringComparison.OrdinalIgnoreCase));
        }
    }
}