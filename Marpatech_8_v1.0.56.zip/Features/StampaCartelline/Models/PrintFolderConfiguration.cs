﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class PrintFolderConfiguration
    {
        public string Name { get; set; } =
            string.Empty;

        public string Description { get; set; } =
            string.Empty;

        public List<InventorPropertyDefinition>
            InventorProperties
        { get; set; } =
                new List<InventorPropertyDefinition>();

        public List<WordTemplateConfiguration>
            WordTemplates
        { get; set; } =
                new List<WordTemplateConfiguration>();

        public PathBasedPrintConfiguration
            ExcelDrawings
        { get; set; } =
                new PathBasedPrintConfiguration();

        public PathBasedPrintConfiguration
            SheetMetalPdfs
        { get; set; } =
                new PathBasedPrintConfiguration();

        public AssemblyGroupsConfiguration
            AssemblyGroups
        { get; set; } =
                new AssemblyGroupsConfiguration();
    }
}