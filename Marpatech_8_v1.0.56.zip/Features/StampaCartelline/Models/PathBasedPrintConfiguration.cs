﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class PathBasedPrintConfiguration
    {
        public string InitialPath { get; set; } =
            string.Empty;

        public string DeterminingAttributeTag { get; set; } =
            string.Empty;

        public string FinalPath { get; set; } =
            string.Empty;

        public bool IncludeInPrintProcess { get; set; }
    }
}