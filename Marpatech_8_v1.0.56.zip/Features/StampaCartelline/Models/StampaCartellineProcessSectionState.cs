﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class StampaCartellineProcessSectionState
    {
        public StampaCartellineProcessSection Section
        {
            get;
            set;
        }

        /*
         * TRUE:
         * questa funzione deve essere eseguita
         * e quindi pesa nella barra.
         *
         * FALSE:
         * non pesa nella barra e nel LOG
         * comparirà "Funzione Saltata".
         */
        public bool Included
        {
            get;
            set;
        }

        public bool Completed
        {
            get;
            set;
        }

        public List<StampaCartellineLogEntry> Entries
        {
            get;
            set;
        } =
            new List<StampaCartellineLogEntry>();
    }
}