﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public sealed class StampaCartellineProcessProgress
    {
        private readonly Dictionary<
            StampaCartellineProcessSection,
            StampaCartellineProcessSectionState>
            _sections;


        public event EventHandler?
            ProgressChanged;

        public event EventHandler?
            LogChanged;


        public StampaCartellineProcessProgress()
        {
            _sections =
                new Dictionary<
                    StampaCartellineProcessSection,
                    StampaCartellineProcessSectionState>();


            foreach (StampaCartellineProcessSection section
                in Enum.GetValues(
                    typeof(
                        StampaCartellineProcessSection)))
            {
                _sections.Add(
                    section,
                    new StampaCartellineProcessSectionState
                    {
                        Section =
                            section
                    });
            }
        }


        public IReadOnlyCollection<
            StampaCartellineProcessSectionState>
            Sections =>
                _sections
                    .Values
                    .OrderBy(
                        state =>
                            (int)state.Section)
                    .ToList();


        /*
         * Percentuale basata ESCLUSIVAMENTE
         * sui blocchi Included = TRUE.
         *
         * Tutti hanno peso uguale.
         */
        public int Percentage
        {
            get
            {
                List<StampaCartellineProcessSectionState>
                    included =
                        _sections
                            .Values
                            .Where(
                                state =>
                                    state.Included)
                            .ToList();


                if (included.Count == 0)
                {
                    return 100;
                }


                int completed =
                    included.Count(
                        state =>
                            state.Completed);


                double percentage =
                    ((double)completed /
                     included.Count)
                    * 100.0;


                return (int)Math.Round(
                    percentage);
            }
        }


        /*
         * TRUE se esiste almeno un errore
         * in qualsiasi sezione.
         */
        public bool HasErrors =>
            _sections
                .Values
                .SelectMany(
                    section =>
                        section.Entries)
                .Any(
                    entry =>
                        entry.Type ==
                        StampaCartellineLogEntryType.Error);


        public void ConfigureSection(
            StampaCartellineProcessSection section,
            bool included)
        {
            StampaCartellineProcessSectionState state =
                _sections[
                    section];


            state.Included =
                included;

            state.Completed =
                false;

            state.Entries.Clear();


            if (!included)
            {
                state.Entries.Add(
                    new StampaCartellineLogEntry
                    {
                        Section =
                            section,

                        Type =
                            StampaCartellineLogEntryType.Skipped,

                        Message =
                            "Funzione Saltata"
                    });
            }


            RaiseProgressChanged();
            RaiseLogChanged();
        }


        public void AddInformation(
            StampaCartellineProcessSection section,
            string message)
        {
            AddEntry(
                section,
                StampaCartellineLogEntryType.Information,
                message);
        }


        public void AddSuccess(
            StampaCartellineProcessSection section,
            string message)
        {
            AddEntry(
                section,
                StampaCartellineLogEntryType.Success,
                message);
        }


        public void AddWarning(
            StampaCartellineProcessSection section,
            string message)
        {
            AddEntry(
                section,
                StampaCartellineLogEntryType.Warning,
                message);
        }


        public void AddError(
            StampaCartellineProcessSection section,
            string message)
        {
            AddEntry(
                section,
                StampaCartellineLogEntryType.Error,
                message);
        }


        public void MarkCompleted(
            StampaCartellineProcessSection section)
        {
            StampaCartellineProcessSectionState state =
                _sections[
                    section];


            /*
             * Una funzione saltata non contribuisce
             * comunque alla percentuale.
             */
            if (!state.Included)
            {
                return;
            }


            state.Completed =
                true;


            RaiseProgressChanged();
        }


        public void Reset()
        {
            foreach (StampaCartellineProcessSectionState state
                in _sections.Values)
            {
                state.Included =
                    false;

                state.Completed =
                    false;

                state.Entries.Clear();
            }


            RaiseProgressChanged();
            RaiseLogChanged();
        }


        private void AddEntry(
            StampaCartellineProcessSection section,
            StampaCartellineLogEntryType type,
            string message)
        {
            if (string.IsNullOrWhiteSpace(
                    message))
            {
                return;
            }


            _sections[
                    section]
                .Entries
                .Add(
                    new StampaCartellineLogEntry
                    {
                        Section =
                            section,

                        Type =
                            type,

                        Message =
                            message.Trim()
                    });


            RaiseLogChanged();
        }


        private void RaiseProgressChanged()
        {
            ProgressChanged?.Invoke(
                this,
                EventArgs.Empty);
        }


        private void RaiseLogChanged()
        {
            LogChanged?.Invoke(
                this,
                EventArgs.Empty);
        }
    }
}