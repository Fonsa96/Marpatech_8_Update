﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class AssemblyCodeSelection
    {
        /*
         * CODICE originale letto da Inventor.
         *
         * Esempio:
         * STL0008880
         * GAC220074
         *
         * Serve internamente anche per riconoscere
         * i separatori STL.
         */
        public string Code
        {
            get;
            set;
        } = string.Empty;


        /*
         * Attributo DISEGNO letto da Inventor.
         *
         * È questo il valore mostrato nella
         * tabella "Configura codici" ed è questo
         * il nome utilizzato per cercare l'IDW.
         */
        public string DrawingName
        {
            get;
            set;
        } = string.Empty;


        /*
         * Prefisso della riga della tabella
         * Metodo 2 che ha riconosciuto il CODICE.
         *
         * Esempio:
         * GAC
         * ASC
         * STL
         */
        public string SourceCodePrefix
        {
            get;
            set;
        } = string.Empty;


        /*
         * Percorso configurato a fianco del
         * relativo prefisso nella tabella Metodo 2.
         */
        public string DrawingSearchPath
        {
            get;
            set;
        } = string.Empty;


        /*
         * Numero di stampe richieste.
         */
        public int Copies
        {
            get;
            set;
        } = 1;


        public AssemblyCodeSelection()
        {
        }


        /*
         * Manteniamo questo costruttore per
         * compatibilità con il codice precedente.
         */
        public AssemblyCodeSelection(
            string code,
            int copies)
        {
            Code =
                code
                ?? string.Empty;

            /*
             * Per gli elementi creati con la
             * vecchia modalità usiamo temporaneamente
             * Code anche come DrawingName.
             */
            DrawingName =
                code
                ?? string.Empty;

            Copies =
                copies < 1
                    ? 1
                    : copies;
        }


        public AssemblyCodeSelection Clone()
        {
            return new AssemblyCodeSelection
            {
                Code =
                    Code,

                DrawingName =
                    DrawingName,

                SourceCodePrefix =
                    SourceCodePrefix,

                DrawingSearchPath =
                    DrawingSearchPath,

                Copies =
                    Copies
            };
        }
    }
}