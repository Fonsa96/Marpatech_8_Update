﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class WordPlaceholderMapping
    {
        public string WordText { get; set; } =
            string.Empty;

        public string Placeholder { get; set; } =
            string.Empty;

        public bool IsInventorTag { get; set; }
    }
}