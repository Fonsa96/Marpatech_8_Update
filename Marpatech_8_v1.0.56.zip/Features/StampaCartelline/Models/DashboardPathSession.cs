﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class DashboardPathSession
    {
        /*
         * Servono ancora per ricostruire
         * automaticamente il percorso
         * quando viene creata la sessione.
         */
        public string InitialPath
        {
            get;
            set;
        } = string.Empty;

        public string DeterminingAttributeTag
        {
            get;
            set;
        } = string.Empty;

        public string FinalPath
        {
            get;
            set;
        } = string.Empty;

        /*
         * Percorso realmente utilizzato
         * dalla funzione.
         */
        public string ResolvedPath
        {
            get;
            set;
        } = string.Empty;

        public bool IncludeInPrintProcess
        {
            get;
            set;
        }
    }
}