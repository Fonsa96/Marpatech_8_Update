﻿namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class InventorPropertyDefinition
    {
        public string Tag { get; set; } =
            string.Empty;

        public string InventorPropertyName { get; set; } =
            string.Empty;

        public bool EditableFromDashboard { get; set; }
    }
}