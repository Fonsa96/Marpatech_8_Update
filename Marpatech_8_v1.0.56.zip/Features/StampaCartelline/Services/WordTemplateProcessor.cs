﻿using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Runtime;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

using WordApplication =
    Microsoft.Office.Interop.Word.Application;

using WordDocument =
    Microsoft.Office.Interop.Word.Document;

using WordSaveOptions =
    Microsoft.Office.Interop.Word.WdSaveOptions;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class WordTemplateProcessor
    {
        private readonly WordTemplateRuntimeBuilder
            _runtimeBuilder;


        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(
            IntPtr hWnd);


        public WordTemplateProcessor()
        {
            _runtimeBuilder =
                new WordTemplateRuntimeBuilder();
        }


        public bool Process(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }


            /*
             * La configurazione originale stabilisce
             * quali template esistono.
             *
             * La sessione stabilisce se la parte Word
             * deve essere eseguita.
             *
             * LOGICA INVARIATA.
             */
            if (!session.IncludePrintFolders)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Word,
                    "Generazione Word Cartelline disattivata nella sessione.");

                return true;
            }


            List<WordTemplateRuntime> runtimes =
                _runtimeBuilder.Build(
                    configuration,
                    session);


            if (runtimes.Count == 0)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Word,
                    "Nessun template Word da elaborare.");

                return true;
            }


            progress.AddInformation(
                StampaCartellineProcessSection.Word,
                "Template Word da elaborare: " +
                runtimes.Count);


            string temporaryDirectory =
                WordTemplateRuntimeBuilder
                    .GetTemporaryDirectory();


            Directory.CreateDirectory(
                temporaryDirectory);


            WordApplication? wordApplication =
                null;


            try
            {
                wordApplication =
                    new WordApplication
                    {
                        Visible =
                            false,

                        DisplayAlerts =
                            Microsoft.Office.Interop.Word
                                .WdAlertLevel
                                .wdAlertsNone
                    };


                progress.AddInformation(
                    StampaCartellineProcessSection.Word,
                    "Microsoft Word avviato.");


                foreach (
                    WordTemplateRuntime runtime
                    in runtimes)
                {
                    string templateName =
                        GetTemplateDescription(
                            runtime);


                    progress.AddInformation(
                        StampaCartellineProcessSection.Word,
                        "Elaborazione template: " +
                        templateName);


                    if (!ValidateTemplate(
                            owner,
                            runtime,
                            progress))
                    {
                        continue;
                    }


                    if (!PrepareTemporaryTemplate(
                            owner,
                            temporaryDirectory,
                            runtime,
                            progress))
                    {
                        continue;
                    }


                    ProcessSingleTemplate(
                        owner,
                        wordApplication,
                        runtime,
                        progress);
                }


                return true;
            }
            catch (Exception exception)
            {
                /*
                 * Manteniamo il popup esistente.
                 */
                MessageBox.Show(
                    owner,
                    "Si è verificato un errore durante " +
                    "l'elaborazione dei template Word.\n\n" +
                    exception.Message,
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);


                /*
                 * Aggiunta esclusivamente per
                 * il LOG centrale.
                 */
                progress.AddError(
                    StampaCartellineProcessSection.Word,
                    "Errore generale durante l'elaborazione dei template Word: " +
                    GetRealExceptionMessage(
                        exception));


                /*
                 * LOGICA ESISTENTE INVARIATA:
                 *
                 * l'errore Word non interrompe
                 * il processo generale.
                 */
                return true;
            }
            finally
            {
                CloseWordApplication(
                    wordApplication);


                try
                {
                    ClearTemporaryDirectory(
                        temporaryDirectory);
                }
                catch (Exception exception)
                {
                    /*
                     * Come prima, l'errore di pulizia
                     * non interrompe il processo.
                     *
                     * Ora viene solamente registrato.
                     */
                    progress.AddWarning(
                        StampaCartellineProcessSection.Word,
                        "Impossibile completare la pulizia della cartella temporanea Word: " +
                        GetRealExceptionMessage(
                            exception));
                }
            }
        }


        private static bool ValidateTemplate(
            IWin32Window owner,
            WordTemplateRuntime runtime,
            StampaCartellineProcessProgress progress)
        {
            string sourcePath =
                runtime.Template.TemplatePath
                    ?.Trim()
                ?? string.Empty;


            if (!string.IsNullOrWhiteSpace(
                    sourcePath) &&
                File.Exists(
                    sourcePath))
            {
                return true;
            }


            string templateDescription =
                !string.IsNullOrWhiteSpace(
                    runtime.Template.Name)
                    ? runtime.Template.Name
                    : sourcePath;


            if (string.IsNullOrWhiteSpace(
                    templateDescription))
            {
                templateDescription =
                    "Percorso non specificato";
            }


            /*
             * Popup esistente mantenuto.
             */
            MessageBox.Show(
                owner,
                "Template non trovato:\n\n" +
                templateDescription +
                "\n\nIl template verrà saltato.",
                "Stampa Cartelline",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);


            progress.AddError(
                StampaCartellineProcessSection.Word,
                "Template non trovato: " +
                templateDescription +
                ". Template saltato.");


            return false;
        }


        private static bool PrepareTemporaryTemplate(
            IWin32Window owner,
            string temporaryDirectory,
            WordTemplateRuntime runtime,
            StampaCartellineProcessProgress progress)
        {
            try
            {
                ClearTemporaryDirectory(
                    temporaryDirectory);


                string sourcePath =
                    runtime.Template.TemplatePath
                        ?.Trim()
                    ?? string.Empty;


                string fileName =
                    Path.GetFileName(
                        sourcePath);


                if (string.IsNullOrWhiteSpace(
                        fileName))
                {
                    /*
                     * Popup esistente mantenuto.
                     */
                    MessageBox.Show(
                        owner,
                        "Il nome del template Word non è valido.\n\n" +
                        "Il template verrà saltato.",
                        "Stampa Cartelline",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);


                    progress.AddError(
                        StampaCartellineProcessSection.Word,
                        "Nome template Word non valido. Template saltato.");


                    return false;
                }


                string destinationPath =
                    Path.Combine(
                        temporaryDirectory,
                        fileName);


                File.Copy(
                    sourcePath,
                    destinationPath,
                    true);


                runtime.TemporaryFilePath =
                    destinationPath;


                progress.AddSuccess(
                    StampaCartellineProcessSection.Word,
                    "Template temporaneo preparato: " +
                    GetTemplateDescription(
                        runtime));


                return true;
            }
            catch (Exception exception)
            {
                /*
                 * Popup esistente mantenuto.
                 */
                MessageBox.Show(
                    owner,
                    "Non è stato possibile preparare il template Word:\n\n" +
                    runtime.Template.Name +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl template verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);


                progress.AddError(
                    StampaCartellineProcessSection.Word,
                    "Impossibile preparare il template Word \"" +
                    GetTemplateDescription(
                        runtime) +
                    "\": " +
                    GetRealExceptionMessage(
                        exception));


                return false;
            }
        }


        private static void ClearTemporaryDirectory(
            string temporaryDirectory)
        {
            Directory.CreateDirectory(
                temporaryDirectory);


            foreach (string filePath
                in Directory.GetFiles(
                    temporaryDirectory))
            {
                File.SetAttributes(
                    filePath,
                    FileAttributes.Normal);


                File.Delete(
                    filePath);
            }


            foreach (string directoryPath
                in Directory.GetDirectories(
                    temporaryDirectory))
            {
                Directory.Delete(
                    directoryPath,
                    true);
            }
        }


        private static void ProcessSingleTemplate(
            IWin32Window owner,
            WordApplication wordApplication,
            WordTemplateRuntime runtime,
            StampaCartellineProcessProgress progress)
        {
            WordDocument? document =
                null;


            string templateName =
                GetTemplateDescription(
                    runtime);


            try
            {
                document =
                    wordApplication.Documents.Open(
                        FileName:
                            runtime.TemporaryFilePath,
                        ReadOnly:
                            false,
                        AddToRecentFiles:
                            false,
                        Visible:
                            false);


                progress.AddInformation(
                    StampaCartellineProcessSection.Word,
                    "Template Word aperto: " +
                    templateName);


                ReplacePlaceholders(
                    document,
                    runtime);


                progress.AddSuccess(
                    StampaCartellineProcessSection.Word,
                    "Placeholder sostituiti: " +
                    templateName);


                ShowWordInForeground(
                    wordApplication,
                    document);


                DialogResult printResult =
                    MessageBox.Show(
                        "Desideri stampare la cartellina Word?",
                        "Stampa Cartelline",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2);


                if (printResult == DialogResult.Yes)
                {
                    PrintDocument(
                        document);


                    progress.AddSuccess(
                        StampaCartellineProcessSection.Word,
                        "Cartellina Word stampata: " +
                        templateName);
                }
                else
                {
                    progress.AddInformation(
                        StampaCartellineProcessSection.Word,
                        "Stampa cartellina Word rifiutata dall'utente: " +
                        templateName);
                }
            }
            catch (Exception exception)
            {
                /*
                 * Popup esistente mantenuto.
                 */
                MessageBox.Show(
                    owner,
                    "Non è stato possibile elaborare il template Word:\n\n" +
                    runtime.Template.Name +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl template verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);


                progress.AddError(
                    StampaCartellineProcessSection.Word,
                    "Impossibile elaborare il template Word \"" +
                    templateName +
                    "\": " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                CloseWordDocument(
                    document);


                DeleteTemporaryTemplate(
                    runtime.TemporaryFilePath);


                runtime.TemporaryFilePath =
                    string.Empty;


                /*
                 * Dopo ogni template Word torna
                 * sempre nascosto.
                 *
                 * LOGICA INVARIATA.
                 */
                try
                {
                    wordApplication.Visible =
                        false;
                }
                catch
                {
                }
            }
        }


        private static void CloseWordDocument(
            WordDocument? document)
        {
            if (document == null)
                return;


            try
            {
                document.Close(
                    SaveChanges:
                        WordSaveOptions
                            .wdDoNotSaveChanges);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    document);
            }
        }


        private static void DeleteTemporaryTemplate(
            string temporaryFilePath)
        {
            if (string.IsNullOrWhiteSpace(
                    temporaryFilePath))
            {
                return;
            }


            try
            {
                if (!File.Exists(
                        temporaryFilePath))
                {
                    return;
                }


                File.SetAttributes(
                    temporaryFilePath,
                    FileAttributes.Normal);


                File.Delete(
                    temporaryFilePath);
            }
            catch
            {
            }
        }


        private static void CloseWordApplication(
            WordApplication? wordApplication)
        {
            if (wordApplication == null)
                return;


            try
            {
                wordApplication.Quit(
                    SaveChanges:
                        WordSaveOptions
                            .wdDoNotSaveChanges);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    wordApplication);


                GC.Collect();
                GC.WaitForPendingFinalizers();


                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }


        private static void ReleaseComObject(
            object? comObject)
        {
            if (comObject == null)
                return;


            try
            {
                if (Marshal.IsComObject(
                        comObject))
                {
                    Marshal.FinalReleaseComObject(
                        comObject);
                }
            }
            catch
            {
            }
        }


        private static void ReplacePlaceholders(
            WordDocument document,
            WordTemplateRuntime runtime)
        {
            foreach (
                KeyValuePair<string, string> replacement
                in runtime.Replacements)
            {
                ReplaceText(
                    document,
                    replacement.Key,
                    replacement.Value);
            }
        }


        private static void ReplaceText(
            WordDocument document,
            string placeholder,
            string replacementValue)
        {
            if (string.IsNullOrWhiteSpace(
                    placeholder))
            {
                return;
            }


            Microsoft.Office.Interop.Word.Range? range =
                null;


            Microsoft.Office.Interop.Word.Find? find =
                null;


            try
            {
                range =
                    document.Content;


                find =
                    range.Find;


                find.ClearFormatting();


                find.Replacement.ClearFormatting();


                find.Text =
                    placeholder;


                find.Replacement.Text =
                    replacementValue
                    ?? string.Empty;


                find.Forward =
                    true;


                find.Wrap =
                    Microsoft.Office.Interop.Word
                        .WdFindWrap
                        .wdFindContinue;


                find.Format =
                    false;


                find.MatchCase =
                    false;


                find.MatchWholeWord =
                    false;


                find.MatchWildcards =
                    false;


                find.MatchSoundsLike =
                    false;


                find.MatchAllWordForms =
                    false;


                find.Execute(
                    Replace:
                        Microsoft.Office.Interop.Word
                            .WdReplace
                            .wdReplaceAll);
            }
            finally
            {
                ReleaseComObject(
                    find);


                ReleaseComObject(
                    range);
            }
        }


        private static void ShowWordInForeground(
            WordApplication wordApplication,
            WordDocument document)
        {
            Microsoft.Office.Interop.Word.Window?
                activeWindow =
                    null;


            try
            {
                wordApplication.Visible =
                    true;


                document.Activate();


                wordApplication.Activate();


                Application.DoEvents();


                Thread.Sleep(
                    150);


                activeWindow =
                    wordApplication.ActiveWindow;


                if (activeWindow == null)
                    return;


                SetForegroundWindow(
                    new IntPtr(
                        activeWindow.Hwnd));
            }
            finally
            {
                ReleaseComObject(
                    activeWindow);
            }
        }


        private static void PrintDocument(
            WordDocument document)
        {
            document.PrintOut(
                Background:
                    false);
        }


        /*
         * ==================================================
         * SOLO SUPPORTO LOG
         * ==================================================
         */
        private static string GetTemplateDescription(
            WordTemplateRuntime runtime)
        {
            string name =
                runtime.Template.Name
                    ?.Trim()
                ?? string.Empty;


            if (!string.IsNullOrWhiteSpace(
                    name))
            {
                return name;
            }


            string path =
                runtime.Template.TemplatePath
                    ?.Trim()
                ?? string.Empty;


            if (!string.IsNullOrWhiteSpace(
                    path))
            {
                try
                {
                    string fileName =
                        Path.GetFileName(
                            path);


                    if (!string.IsNullOrWhiteSpace(
                            fileName))
                    {
                        return fileName;
                    }
                }
                catch
                {
                }


                return path;
            }


            return "Template Word";
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;


            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }


            return realException.Message;
        }
    }
}