﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupSelectedStlService
    {
        /*
         * Converte:
         *
         * STL1, STL2,STL3, STL1
         *
         * in:
         *
         * STL1
         * STL2
         * STL3
         *
         * senza distinzione maiuscole/minuscole.
         */
        public HashSet<string> ParseSelectedCodes(
            string? value)
        {
            HashSet<string> result =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return result;
            }

            string[] parts =
                value.Split(
                    new[] { ',' },
                    StringSplitOptions.RemoveEmptyEntries);

            foreach (string part
                in parts)
            {
                string code =
                    part.Trim();

                if (string.IsNullOrWhiteSpace(
                        code))
                {
                    continue;
                }

                result.Add(
                    code);
            }

            return result;
        }


        /*
         * ==================================================
         * METODO 1
         * ==================================================
         */
        public void FilterMethod1Tree(
            IList<AssemblyGroupMethod1TreeNode> roots,
            ISet<string> selectedCodes)
        {
            if (roots == null)
                return;

            for (int i =
                    roots.Count - 1;
                i >= 0;
                i--)
            {
                if (!FilterMethod1Node(
                        roots[i],
                        selectedCodes))
                {
                    roots.RemoveAt(
                        i);
                }
            }
        }


        private static bool FilterMethod1Node(
            AssemblyGroupMethod1TreeNode node,
            ISet<string> selectedCodes)
        {
            /*
             * Prima filtriamo i figli.
             */
            for (int i =
                    node.Children.Count - 1;
                i >= 0;
                i--)
            {
                if (!FilterMethod1Node(
                        node.Children[i],
                        selectedCodes))
                {
                    node.Children.RemoveAt(
                        i);
                }
            }


            bool selected =
                selectedCodes.Contains(
                    node.Code?.Trim()
                    ?? string.Empty);


            /*
             * Il nodo rimane se:
             *
             * - è stato richiesto direttamente
             * oppure
             * - possiede almeno un discendente richiesto.
             */
            bool neededForStructure =
                node.Children.Count > 0;


            if (!selected &&
                !neededForStructure)
            {
                return false;
            }


            node.IsProcessable =
                selected;


            return true;
        }


        /*
         * ==================================================
         * METODO 2
         * ==================================================
         */
        public void FilterMethod2Tree(
            IList<AssemblyGroupMethod2TreeNode> roots,
            ISet<string> selectedCodes)
        {
            if (roots == null)
                return;

            for (int i =
                    roots.Count - 1;
                i >= 0;
                i--)
            {
                if (!FilterMethod2Node(
                        roots[i],
                        selectedCodes))
                {
                    roots.RemoveAt(
                        i);
                }
            }
        }


        private static bool FilterMethod2Node(
            AssemblyGroupMethod2TreeNode node,
            ISet<string> selectedCodes)
        {
            for (int i =
                    node.Children.Count - 1;
                i >= 0;
                i--)
            {
                if (!FilterMethod2Node(
                        node.Children[i],
                        selectedCodes))
                {
                    node.Children.RemoveAt(
                        i);
                }
            }


            bool selected =
                selectedCodes.Contains(
                    node.Code?.Trim()
                    ?? string.Empty);


            bool neededForStructure =
                node.Children.Count > 0;


            if (!selected &&
                !neededForStructure)
            {
                return false;
            }


            node.IsProcessable =
                selected;


            return true;
        }


        /*
         * Utile per il futuro LOG:
         * restituisce i CODICI richiesti ma mai
         * presenti nell'albero originale.
         */
        public List<string> FindMissingCodes(
            IEnumerable<string> selectedCodes,
            IEnumerable<string> foundCodes)
        {
            HashSet<string> found =
                new HashSet<string>(
                    foundCodes,
                    StringComparer.OrdinalIgnoreCase);

            return selectedCodes
                .Where(
                    code =>
                        !found.Contains(
                            code))
                .OrderBy(
                    code =>
                        code,
                    StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
    }
}