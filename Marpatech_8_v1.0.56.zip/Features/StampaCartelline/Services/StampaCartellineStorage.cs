﻿using System;
using System.IO;
using System.Text.Json;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    internal static class StampaCartellineStorage
    {
        private const string ExpectedFileType =
            "Marpatech.StampaCartelline";

        private const string ConfigurationFileName =
            "StampaCartelline.json";

        private static readonly JsonSerializerOptions
            JsonOptions =
                new JsonSerializerOptions
                {
                    WriteIndented = true,
                    PropertyNameCaseInsensitive = true
                };

        public static string SettingsDirectory
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.ApplicationData),
                    "Marpatech",
                    "Settings");
            }
        }

        public static string ConfigurationFilePath
        {
            get
            {
                return Path.Combine(
                    SettingsDirectory,
                    ConfigurationFileName);
            }
        }

        public static PrintFolderConfigurationsFile Load()
        {
            Directory.CreateDirectory(
                SettingsDirectory);

            if (!File.Exists(ConfigurationFilePath))
            {
                return CreateEmptyFile();
            }

            string json =
                File.ReadAllText(ConfigurationFilePath);

            return DeserializeAndValidate(json);
        }

        public static void Save(
            PrintFolderConfigurationsFile data)
        {
            if (data == null)
            {
                throw new ArgumentNullException(
                    nameof(data));
            }

            PrepareForSave(data);

            Directory.CreateDirectory(
                SettingsDirectory);

            string json =
                JsonSerializer.Serialize(
                    data,
                    JsonOptions);

            string temporaryPath =
                ConfigurationFilePath + ".tmp";

            File.WriteAllText(
                temporaryPath,
                json);

            File.Move(
                temporaryPath,
                ConfigurationFilePath,
                true);
        }

        public static void Export(
            string destinationFilePath)
        {
            if (string.IsNullOrWhiteSpace(
                    destinationFilePath))
            {
                throw new ArgumentException(
                    "Il percorso di esportazione non è valido.",
                    nameof(destinationFilePath));
            }

            if (!File.Exists(ConfigurationFilePath))
            {
                throw new FileNotFoundException(
                    "Non esistono configurazioni di " +
                    "Stampa Cartelline da esportare.",
                    ConfigurationFilePath);
            }

            PrintFolderConfigurationsFile data =
                Load();

            string? destinationDirectory =
                Path.GetDirectoryName(
                    destinationFilePath);

            if (!string.IsNullOrWhiteSpace(
                    destinationDirectory))
            {
                Directory.CreateDirectory(
                    destinationDirectory);
            }

            string json =
                JsonSerializer.Serialize(
                    data,
                    JsonOptions);

            File.WriteAllText(
                destinationFilePath,
                json);
        }

        public static PrintFolderConfigurationsFile Import(
            string sourceFilePath)
        {
            if (string.IsNullOrWhiteSpace(
                    sourceFilePath))
            {
                throw new ArgumentException(
                    "Il file selezionato non è valido.",
                    nameof(sourceFilePath));
            }

            if (!File.Exists(sourceFilePath))
            {
                throw new FileNotFoundException(
                    "Il file selezionato non esiste.",
                    sourceFilePath);
            }

            string json =
                File.ReadAllText(sourceFilePath);

            PrintFolderConfigurationsFile data =
                DeserializeAndValidate(json);

            Save(data);

            return data;
        }

        private static PrintFolderConfigurationsFile
            DeserializeAndValidate(
                string json)
        {
            if (string.IsNullOrWhiteSpace(json))
            {
                throw new InvalidDataException(
                    "Il file delle configurazioni è vuoto.");
            }

            PrintFolderConfigurationsFile? data;

            try
            {
                data =
                    JsonSerializer.Deserialize
                        <PrintFolderConfigurationsFile>(
                            json,
                            JsonOptions);
            }
            catch (JsonException exception)
            {
                throw new InvalidDataException(
                    "Il file selezionato non contiene " +
                    "un JSON valido.",
                    exception);
            }

            if (data == null)
            {
                throw new InvalidDataException(
                    "Il file selezionato non contiene dati validi.");
            }

            if (!string.Equals(
                    data.FileType,
                    ExpectedFileType,
                    StringComparison.Ordinal))
            {
                throw new InvalidDataException(
                    "Il file selezionato non appartiene " +
                    "alla funzione Stampa Cartelline.");
            }

            if (data.Version <= 0)
            {
                throw new InvalidDataException(
                    "La versione del file non è valida.");
            }

            data.Configurations ??=
                new();

            return data;
        }

        private static void PrepareForSave(
            PrintFolderConfigurationsFile data)
        {
            data.FileType =
                ExpectedFileType;

            if (data.Version <= 0)
            {
                data.Version = 1;
            }

            data.Configurations ??=
                new();
        }

        private static PrintFolderConfigurationsFile
            CreateEmptyFile()
        {
            return new PrintFolderConfigurationsFile
            {
                FileType = ExpectedFileType,
                Version = 1
            };
        }
    }
}