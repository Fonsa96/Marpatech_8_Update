﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod1TreeDrawingResolver
    {
        public void Resolve(
            IEnumerable<AssemblyGroupMethod1TreeNode> roots)
        {
            if (roots == null)
                return;

            foreach (AssemblyGroupMethod1TreeNode root
                in roots)
            {
                ResolveRecursive(
                    root);
            }
        }


        private static void ResolveRecursive(
            AssemblyGroupMethod1TreeNode node)
        {
            ResolveSingleNode(
                node);

            foreach (AssemblyGroupMethod1TreeNode child
                in node.Children)
            {
                ResolveRecursive(
                    child);
            }
        }


        private static void ResolveSingleNode(
            AssemblyGroupMethod1TreeNode node)
        {
            node.DrawingPath =
                string.Empty;

            node.FailureReason =
                string.Empty;


            /*
             * ==================================================
             * DISEGNO
             * ==================================================
             */
            string drawingName =
                node.DrawingName
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                node.FailureReason =
                    "Proprietà DISEGNO vuota";

                return;
            }


            /*
             * ==================================================
             * PERCORSO SERVER
             * ==================================================
             */
            string searchRoot =
                node.DrawingSearchPath
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    searchRoot))
            {
                node.FailureReason =
                    "Percorso server di ricerca IDW non configurato";

                return;
            }

            if (!Directory.Exists(
                    searchRoot))
            {
                node.FailureReason =
                    "Percorso server non trovato: " +
                    searchRoot;

                return;
            }


            /*
             * ==================================================
             * NOME IDW
             * ==================================================
             */
            string expectedFileName =
                NormalizeDrawingFileName(
                    drawingName);

            if (string.IsNullOrWhiteSpace(
                    expectedFileName))
            {
                node.FailureReason =
                    "Nome DISEGNO non valido";

                return;
            }


            /*
             * ==================================================
             * RICERCA RICORSIVA
             * ==================================================
             *
             * Match ESATTO del nome.
             *
             * DISEGNO:
             * STL00084310
             *
             * trova:
             * STL00084310.idw
             *
             * ma NON:
             *
             * STL00084310_RICAMBI.idw
             * STL00084310_OLD.idw
             * STL000843100.idw
             */
            string? foundPath =
                FindDrawingRecursive(
                    searchRoot,
                    expectedFileName);

            if (string.IsNullOrWhiteSpace(
                    foundPath))
            {
                node.FailureReason =
                    "IDW non trovato sul server: " +
                    expectedFileName;

                return;
            }


            node.DrawingPath =
                foundPath;
        }


        private static string NormalizeDrawingFileName(
            string drawingName)
        {
            string value =
                drawingName.Trim();

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }

            try
            {
                value =
                    Path.GetFileName(
                        value);
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }


            string extension =
                Path.GetExtension(
                    value);

            if (string.IsNullOrWhiteSpace(
                    extension))
            {
                value +=
                    ".idw";
            }
            else if (!string.Equals(
                         extension,
                         ".idw",
                         StringComparison.OrdinalIgnoreCase))
            {
                value =
                    Path.GetFileNameWithoutExtension(
                        value)
                    + ".idw";
            }


            return value;
        }


        private static string?
            FindDrawingRecursive(
                string searchRoot,
                string expectedFileName)
        {
            try
            {
                /*
                 * Prima controlliamo la cartella corrente.
                 */
                foreach (string filePath
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.TopDirectoryOnly))
                {
                    string fileName =
                        Path.GetFileName(
                            filePath);

                    if (string.Equals(
                            fileName,
                            expectedFileName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return filePath;
                    }
                }


                /*
                 * Poi scendiamo nelle sottocartelle.
                 */
                foreach (string subDirectory
                    in Directory.EnumerateDirectories(
                        searchRoot))
                {
                    string? found =
                        FindDrawingRecursive(
                            subDirectory,
                            expectedFileName);

                    if (!string.IsNullOrWhiteSpace(
                            found))
                    {
                        return found;
                    }
                }
            }
            catch
            {
                /*
                 * Una singola cartella non accessibile
                 * non deve bloccare tutto il processo.
                 */
            }


            return null;
        }
    }
}