﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupDrawingResolver
    {
        public void Resolve(
            IEnumerable<AssemblyGroupRuntimeItem> items)
        {
            if (items == null)
                return;

            foreach (AssemblyGroupRuntimeItem item
                in items)
            {
                ResolveSingleItem(
                    item);
            }
        }

        private static void ResolveSingleItem(
            AssemblyGroupRuntimeItem item)
        {
            item.DrawingPath =
                string.Empty;

            item.CanProcess =
                false;

            item.FailureReason =
                string.Empty;

            string drawingName =
                item.DrawingName
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                item.FailureReason =
                    "Proprietà DISEGNO vuota";

                return;
            }

            string searchRoot =
                item.DrawingSearchPath
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    searchRoot))
            {
                item.FailureReason =
                    "Percorso server di ricerca IDW non configurato";

                return;
            }

            if (!Directory.Exists(
                    searchRoot))
            {
                item.FailureReason =
                    "Percorso server non trovato: " +
                    searchRoot;

                return;
            }

            /*
             * DISEGNO può essere:
             *
             * STL00084310
             *
             * oppure:
             *
             * STL00084310.idw
             *
             * In entrambi i casi costruiamo
             * il nome esatto dell'IDW da cercare.
             */
            string expectedFileName =
                NormalizeDrawingFileName(
                    drawingName);

            if (string.IsNullOrWhiteSpace(
                    expectedFileName))
            {
                item.FailureReason =
                    "Nome DISEGNO non valido";

                return;
            }

            string? foundPath =
                FindDrawingRecursive(
                    searchRoot,
                    expectedFileName);

            if (string.IsNullOrWhiteSpace(
                    foundPath))
            {
                item.FailureReason =
                    "IDW non trovato sul server: " +
                    expectedFileName;

                return;
            }

            item.DrawingPath =
                foundPath;

            item.CanProcess =
                true;
        }

        private static string NormalizeDrawingFileName(
            string drawingName)
        {
            string value =
                drawingName.Trim();

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }

            /*
             * Se DISEGNO contiene accidentalmente
             * un percorso completo, utilizziamo
             * soltanto il nome del file.
             */
            try
            {
                value =
                    Path.GetFileName(
                        value);
            }
            catch
            {
            }

            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }

            /*
             * Se manca l'estensione,
             * aggiungiamo .idw.
             */
            if (!string.Equals(
                    Path.GetExtension(
                        value),
                    ".idw",
                    StringComparison.OrdinalIgnoreCase))
            {
                /*
                 * Se non c'è alcuna estensione,
                 * aggiungiamo .idw.
                 *
                 * Se invece DISEGNO contiene
                 * un'altra estensione, togliamo
                 * quella esistente e imponiamo .idw.
                 */
                value =
                    Path.GetFileNameWithoutExtension(
                        value)
                    + ".idw";
            }

            return value;
        }

        private static string?
            FindDrawingRecursive(
                string searchRoot,
                string expectedFileName)
        {
            try
            {
                /*
                 * Prima controlliamo i file
                 * direttamente presenti nella
                 * cartella corrente.
                 *
                 * Confronto ESATTO del nome.
                 */
                foreach (string filePath
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.TopDirectoryOnly))
                {
                    string fileName =
                        Path.GetFileName(
                            filePath);

                    if (string.Equals(
                            fileName,
                            expectedFileName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return filePath;
                    }
                }

                /*
                 * Poi scendiamo ricorsivamente
                 * nelle sottocartelle.
                 */
                foreach (string subDirectory
                    in Directory.EnumerateDirectories(
                        searchRoot))
                {
                    string? foundPath =
                        FindDrawingRecursive(
                            subDirectory,
                            expectedFileName);

                    if (!string.IsNullOrWhiteSpace(
                            foundPath))
                    {
                        return foundPath;
                    }
                }
            }
            catch
            {
                /*
                 * Una cartella non accessibile
                 * non deve interrompere l'intera ricerca.
                 */
            }

            return null;
        }
    }
}