﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class SheetMetalPdfProcessor
    {
        [DllImport(
            "shell32.dll",
            CharSet = CharSet.Ansi,
            SetLastError = true)]
        private static extern IntPtr ShellExecute(
            IntPtr hwnd,
            string lpOperation,
            string lpFile,
            string? lpParameters,
            string? lpDirectory,
            int nShowCmd);

        public bool Process(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }

            /*
             * Se la sezione PDF è disattivata
             * nella sessione, viene saltata.
             *
             * LOGICA INVARIATA.
             */
            if (!session.SheetMetalPdfs
                    .IncludeInPrintProcess)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Stampa PDF Lamiere disattivata nella sessione.");

                return true;
            }

            string resolvedPath =
                session.SheetMetalPdfs
                    .ResolvedPath
                    ?.Trim()
                ?? string.Empty;

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                string.IsNullOrWhiteSpace(
                    resolvedPath)
                    ? "Nessun percorso PDF risolto."
                    : "Percorso PDF risolto: " +
                      resolvedPath);

            /*
             * Se il percorso della sessione è vuoto
             * o non esiste, saltiamo il blocco.
             *
             * La scelta manuale del percorso viene
             * già gestita dalla Dashboard.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    resolvedPath) ||
                !Directory.Exists(
                    resolvedPath))
            {
                MessageBox.Show(
                    owner,
                    "Il percorso PDF della sessione non è valido.\n\n" +
                    "Il blocco Stampa PDF verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Pdf,
                    "Percorso PDF della sessione non valido: " +
                    resolvedPath +
                    ". Blocco PDF saltato.");

                return true;
            }

            string? pdfDirectory =
                ResolvePdfDirectory(
                    owner,
                    resolvedPath,
                    progress);

            /*
             * L'utente ha scelto No quando
             * Lamiera/Lamiere non era presente.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    pdfDirectory))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Stampa PDF annullata dall'utente.");

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "Cartella utilizzata per la stampa PDF: " +
                pdfDirectory);

            List<string> pdfFiles =
                FindPdfFiles(
                    pdfDirectory);

            if (pdfFiles.Count == 0)
            {
                MessageBox.Show(
                    owner,
                    "Nessun file PDF trovato nella cartella:\n\n" +
                    pdfDirectory,
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Nessun file PDF trovato nella cartella: " +
                    pdfDirectory);

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "File PDF trovati: " +
                pdfFiles.Count);

            /*
 * ==================================================
 * CONFERMA PRIMA DELLA STAMPA PDF
 * ==================================================
 *
 * Questa finestra viene mostrata SEMPRE
 * prima di iniziare a stampare i PDF.
 *
 * PROCEDi:
 * avvia normalmente il blocco.
 *
 * SALTA BLOCCO PDF:
 * non stampa nulla e passa al blocco successivo.
 *
 * X:
 * equivale a SALTA BLOCCO PDF.
 */
            bool proceedWithPdfPrint =
                ShowPdfPrintConfirmation(
                    owner,
                    pdfFiles.Count);

            if (!proceedWithPdfPrint)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Blocco PDF saltato dall'utente prima dell'avvio della stampa.");

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "Confermata la stampa di " +
                pdfFiles.Count +
                " PDF.");

            try
            {
                PrintPdfFiles(
                    owner,
                    pdfFiles,
                    progress);
            }
            finally
            {
                /*
                 * LOGICA INVARIATA:
                 * chiusura Acrobat dopo la lista.
                 */
                CloseAllAcrobatProcesses();

                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Chiusura processi Acrobat completata.");
            }

            return true;
        }

        private static bool ShowPdfPrintConfirmation(
    IWin32Window owner,
    int pdfCount)
        {
            using PdfPrintConfirmationDialog dialog =
                new PdfPrintConfirmationDialog(
                    pdfCount);

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            /*
             * Solo il click esplicito su PROCEDi
             * permette di iniziare la stampa.
             *
             * SALTA BLOCCO PDF
             * oppure
             * X
             *
             * restituiscono FALSE.
             */
            return result == DialogResult.OK &&
                   dialog.ProceedWithPrint;
        }

        private enum MissingSheetMetalFolderChoice
        {
            Cancel,
            PrintCurrentFolder,
            ChooseFolder
        }

        private static MissingSheetMetalFolderChoice
    ShowMissingSheetMetalFolderDialog(
        IWin32Window owner,
        string resolvedPath)
        {
            using MissingSheetMetalFolderDialog dialog =
                new MissingSheetMetalFolderDialog(
                    resolvedPath);

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            if (result != DialogResult.OK)
            {
                return MissingSheetMetalFolderChoice.Cancel;
            }

            return dialog.SelectedChoice;
        }

        private static string?
    SelectPdfFolder(
        IWin32Window owner,
        string initialPath)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog();

            dialog.Description =
                "Seleziona la cartella contenente i PDF delle lamiere da stampare.";

            dialog.UseDescriptionForTitle =
                true;


            if (!string.IsNullOrWhiteSpace(
                    initialPath) &&
                Directory.Exists(
                    initialPath))
            {
                dialog.SelectedPath =
                    initialPath;
            }


            DialogResult result =
                dialog.ShowDialog(
                    owner);


            if (result != DialogResult.OK)
            {
                return null;
            }


            string selectedPath =
                dialog.SelectedPath
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    selectedPath) ||
                !Directory.Exists(
                    selectedPath))
            {
                return null;
            }


            return selectedPath;
        }

        private static string?
            ResolvePdfDirectory(
                IWin32Window owner,
                string resolvedPath,
                StampaCartellineProcessProgress progress)
        {
            string? lamieraDirectory =
                FindSheetMetalDirectory(
                    resolvedPath);

            if (!string.IsNullOrWhiteSpace(
                    lamieraDirectory))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Cartella Lamiera/Lamiere rilevata: " +
                    lamieraDirectory);

                return lamieraDirectory;
            }


            progress.AddWarning(
                StampaCartellineProcessSection.Pdf,
                "Cartella Lamiera/Lamiere non trovata nel percorso: " +
                resolvedPath);


            MissingSheetMetalFolderChoice choice =
                ShowMissingSheetMetalFolderDialog(
                    owner,
                    resolvedPath);


            /*
             * X in alto a destra:
             * annulla esclusivamente il blocco PDF.
             */
            if (choice ==
                MissingSheetMetalFolderChoice.Cancel)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Blocco PDF annullato dall'utente.");

                return null;
            }


            /*
             * STAMPA LAMIERE:
             *
             * usa direttamente il percorso già
             * selezionato/rilevato.
             *
             * FindPdfFiles continuerà poi a leggere
             * esclusivamente i PDF al primo livello,
             * come già previsto dalla logica esistente.
             */
            if (choice ==
                MissingSheetMetalFolderChoice.PrintCurrentFolder)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Scelta \"Stampa Lamiere\": verranno utilizzati i PDF presenti nel percorso: " +
                    resolvedPath);

                return resolvedPath;
            }


            /*
             * SCEGLI PERCORSO:
             * l'utente può indicare manualmente
             * la cartella desiderata.
             */
            string? selectedPath =
                SelectPdfFolder(
                    owner,
                    resolvedPath);


            /*
             * Anche la X del FolderBrowserDialog
             * oppure Annulla devono saltare
             * esclusivamente il blocco PDF.
             */
            if (string.IsNullOrWhiteSpace(
                    selectedPath))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Selezione manuale del percorso PDF annullata. Blocco PDF saltato.");

                return null;
            }


            progress.AddInformation(
                StampaCartellineProcessSection.Pdf,
                "Percorso PDF scelto manualmente: " +
                selectedPath);


            return selectedPath;
        }

        private static string?
            FindSheetMetalDirectory(
                string rootDirectory)
        {
            try
            {
                if (!Directory.Exists(
                        rootDirectory))
                {
                    return null;
                }

                /*
                 * Se il percorso selezionato è già
                 * una cartella che contiene la parola
                 * "Lamiere" oppure "Lamiera",
                 * usiamo direttamente questa.
                 */
                string rootFolderName =
                    Path.GetFileName(
                        rootDirectory.TrimEnd(
                            Path.DirectorySeparatorChar,
                            Path.AltDirectorySeparatorChar));

                if (ContainsSheetMetalWord(
                        rootFolderName))
                {
                    return rootDirectory;
                }

                /*
                 * Altrimenti controlliamo soltanto
                 * le cartelle immediatamente contenute
                 * nel percorso selezionato.
                 *
                 * NON facciamo ricerca ricorsiva.
                 */
                string[] directories =
                    Directory.GetDirectories(
                        rootDirectory);

                /*
                 * Prima priorità:
                 * nome cartella contenente "Lamiere".
                 */
                string? lamiere =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiere",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                if (!string.IsNullOrWhiteSpace(
                        lamiere))
                {
                    return lamiere;
                }

                /*
                 * Seconda priorità:
                 * nome cartella contenente "Lamiera".
                 */
                string? lamiera =
                    directories.FirstOrDefault(
                        directory =>
                            Path.GetFileName(
                                    directory)
                                .IndexOf(
                                    "Lamiera",
                                    StringComparison.OrdinalIgnoreCase)
                                >= 0);

                return lamiera;
            }
            catch
            {
                return null;
            }
        }

        private static bool ContainsSheetMetalWord(
            string folderName)
        {
            if (string.IsNullOrWhiteSpace(
                    folderName))
            {
                return false;
            }

            return
                folderName.IndexOf(
                    "Lamiere",
                    StringComparison.OrdinalIgnoreCase) >= 0
                ||
                folderName.IndexOf(
                    "Lamiera",
                    StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static List<string>
            FindPdfFiles(
                string directory)
        {
            try
            {
                /*
                 * IMPORTANTE:
                 * processiamo solo ed esclusivamente
                 * i PDF presenti al primo livello.
                 *
                 * Le sottocartelle vengono ignorate.
                 */
                return Directory
                    .EnumerateFiles(
                        directory,
                        "*.pdf",
                        SearchOption.TopDirectoryOnly)
                    .OrderBy(
                        filePath =>
                            filePath,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        private static void PrintPdfFiles(
            IWin32Window owner,
            IEnumerable<string> pdfFiles,
            StampaCartellineProcessProgress progress)
        {
            foreach (string filePath
                in pdfFiles)
            {
                PrintSinglePdf(
                    owner,
                    filePath,
                    progress);
            }

            /*
             * Importante:
             * dopo l'ultimo PDF lasciamo a Reader
             * il tempo di completare l'invio allo spooler
             * prima che il finally chiuda Acrobat.
             *
             * LOGICA INVARIATA.
             */
            WaitSeconds(
                5);
        }

        private static void PrintSinglePdf(
            IWin32Window owner,
            string filePath,
            StampaCartellineProcessProgress progress)
        {
            string fileName;

            try
            {
                fileName =
                    Path.GetFileName(
                        filePath);

                if (string.IsNullOrWhiteSpace(
                        fileName))
                {
                    fileName =
                        filePath;
                }
            }
            catch
            {
                fileName =
                    filePath;
            }

            try
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Avvio stampa PDF: " +
                    fileName);

                /*
                 * IDENTICO alla VBA:
                 *
                 * ret = ShellExecute(
                 *     0,
                 *     "print",
                 *     file.path,
                 *     vbNullString,
                 *     vbNullString,
                 *     0)
                 */
                IntPtr result =
                    ShellExecute(
                        IntPtr.Zero,
                        "print",
                        filePath,
                        null,
                        null,
                        0);

                System.Windows.Forms.Application
                    .DoEvents();

                /*
                 * Nella VBA:
                 *
                 * If ret <= 32 Then
                 *     AttendiSecondi(2)
                 *     ret = ShellExecute(...)
                 *     DoEvents
                 * End If
                 */
                if (result.ToInt64() <= 32)
                {
                    progress.AddWarning(
                        StampaCartellineProcessSection.Pdf,
                        "Primo tentativo di stampa fallito per \"" +
                        fileName +
                        "\". Codice ShellExecute: " +
                        result.ToInt64() +
                        ". Verrà eseguito il retry.");

                    WaitSeconds(
                        2);

                    result =
                        ShellExecute(
                            IntPtr.Zero,
                            "print",
                            filePath,
                            null,
                            null,
                            0);

                    System.Windows.Forms.Application
                        .DoEvents();

                    if (result.ToInt64() <= 32)
                    {
                        MessageBox.Show(
                            owner,
                            "Errore stampa PDF:\n\n" +
                            filePath +
                            "\n\nCodice: " +
                            result.ToInt64(),
                            "Stampa PDF",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        progress.AddError(
                            StampaCartellineProcessSection.Pdf,
                            "Errore stampa PDF \"" +
                            fileName +
                            "\" dopo il retry. Codice ShellExecute: " +
                            result.ToInt64());
                    }
                    else
                    {
                        progress.AddSuccess(
                            StampaCartellineProcessSection.Pdf,
                            "PDF inviato alla stampa dopo il retry: " +
                            fileName);
                    }
                }
                else
                {
                    progress.AddSuccess(
                        StampaCartellineProcessSection.Pdf,
                        "PDF inviato alla stampa: " +
                        fileName);
                }

                /*
                 * IDENTICO alla VBA:
                 *
                 * Call AttendiSecondi(3)
                 *
                 * Viene eseguito anche dopo il retry,
                 * prima di passare al PDF successivo.
                 */
                WaitSeconds(
                    3);
            }
            catch (Exception exception)
            {
                MessageBox.Show(
                    owner,
                    "Errore stampa PDF:\n\n" +
                    filePath +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl file verrà saltato.",
                    "Stampa PDF",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Pdf,
                    "Errore durante la stampa del PDF \"" +
                    fileName +
                    "\": " +
                    GetRealExceptionMessage(
                        exception));

                /*
                 * Anche in caso di eccezione su un file
                 * non interrompiamo la lista.
                 *
                 * PrintPdfFiles passerà al PDF successivo.
                 *
                 * LOGICA INVARIATA.
                 */
            }
        }

        private static void WaitSeconds(
            int seconds)
        {
            /*
             * Replica di AttendiSecondi della VBA:
             *
             * Do While Now < fine
             *     DoEvents
             * Loop
             *
             * Sleep(20) evita di saturare la CPU,
             * lasciando comunque viva la UI WinForms.
             */
            DateTime endTime =
                DateTime.Now.AddSeconds(
                    seconds);

            while (DateTime.Now < endTime)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }
        }

        private static void KillProcessByName(
            string processName)
        {
            try
            {
                System.Diagnostics.Process[] processes =
                    System.Diagnostics.Process.GetProcessesByName(
                        processName);

                foreach (System.Diagnostics.Process process
                    in processes)
                {
                    try
                    {
                        process.Kill();

                        process.WaitForExit(
                            5000);
                    }
                    catch
                    {
                    }
                    finally
                    {
                        process.Dispose();
                    }
                }
            }
            catch
            {
            }
        }

        private static void CloseAllAcrobatProcesses()
        {
            /*
             * Traduzione diretta di:
             *
             * taskkill /IM AcroRd32.exe /F
             * taskkill /IM Acrobat.exe /F
             */
            KillProcessByName(
                "AcroRd32");

            KillProcessByName(
                "Acrobat");
        }

        private sealed class PdfPrintConfirmationDialog
    : Form
        {
            public bool ProceedWithPrint
            {
                get;
                private set;
            }


            public PdfPrintConfirmationDialog(
                int pdfCount)
            {
                ProceedWithPrint =
                    false;


                Text =
                    "Stampa PDF";

                StartPosition =
                    FormStartPosition.CenterParent;

                ClientSize =
                    new System.Drawing.Size(
                        560,
                        205);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;


                Label message =
                    new Label();

                message.Text =
                    "Sono stati trovati " +
                    pdfCount +
                    " PDF da stampare." +
                    System.Environment.NewLine +
                    System.Environment.NewLine +
                    "Vuoi procedere?";

                message.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        11,
                        System.Drawing.FontStyle.Regular);

                message.Location =
                    new System.Drawing.Point(
                        25,
                        25);

                message.Size =
                    new System.Drawing.Size(
                        510,
                        85);


                Button btnProceed =
                    new Button();

                btnProceed.Text =
                    "Procedi";

                btnProceed.Size =
                    new System.Drawing.Size(
                        140,
                        40);

                btnProceed.Location =
                    new System.Drawing.Point(
                        220,
                        135);

                btnProceed.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9,
                        System.Drawing.FontStyle.Bold);

                btnProceed.Click +=
                    (_, _) =>
                    {
                        ProceedWithPrint =
                            true;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };


                Button btnSkip =
                    new Button();

                btnSkip.Text =
                    "Salta blocco PDF";

                btnSkip.Size =
                    new System.Drawing.Size(
                        165,
                        40);

                btnSkip.Location =
                    new System.Drawing.Point(
                        370,
                        135);

                btnSkip.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9,
                        System.Drawing.FontStyle.Bold);

                btnSkip.Click +=
                    (_, _) =>
                    {
                        ProceedWithPrint =
                            false;

                        DialogResult =
                            DialogResult.Cancel;

                        Close();
                    };


                /*
                 * Sicurezza:
                 *
                 * se viene premuta la X,
                 * ProceedWithPrint rimane FALSE.
                 *
                 * Quindi la X equivale sempre
                 * a "Salta blocco PDF".
                 */
                FormClosing +=
                    (_, _) =>
                    {
                        if (!ProceedWithPrint)
                        {
                            DialogResult =
                                DialogResult.Cancel;
                        }
                    };


                Controls.Add(
                    message);

                Controls.Add(
                    btnProceed);

                Controls.Add(
                    btnSkip);


                AcceptButton =
                    btnProceed;

                CancelButton =
                    btnSkip;
            }
        }

        /*
         * ==================================================
         * SOLO SUPPORTO LOG
         * ==================================================
         */
        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;

            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }

            return realException.Message;
        }
        private sealed class MissingSheetMetalFolderDialog
    : Form
        {
            public MissingSheetMetalFolderChoice
                SelectedChoice
            {
                get;
                private set;
            } =
                MissingSheetMetalFolderChoice.Cancel;


            public MissingSheetMetalFolderDialog(
                string resolvedPath)
            {
                Text =
                    "Stampa PDF Lamiere";

                StartPosition =
                    FormStartPosition.CenterParent;

                ClientSize =
                    new System.Drawing.Size(
                        680,
                        285);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;


                Label message =
                    new Label();

                message.Text =
                    "Cartella Lamiera/Lamiere non trovata." +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Percorso attualmente selezionato:" +
                    Environment.NewLine +
                    resolvedPath +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Per annullare il blocco PDF premi la X in alto a destra.";

                message.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9.5F,
                        System.Drawing.FontStyle.Regular);

                message.Location =
                    new System.Drawing.Point(
                        25,
                        20);

                message.Size =
                    new System.Drawing.Size(
                        630,
                        190);


                Button btnPrint =
                    new Button();

                btnPrint.Text =
                    "Stampa Lamiere";

                btnPrint.Size =
                    new System.Drawing.Size(
                        155,
                        40);

                btnPrint.Location =
                    new System.Drawing.Point(
                        330,
                        220);

                btnPrint.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9,
                        System.Drawing.FontStyle.Bold);

                btnPrint.Click +=
                    (_, _) =>
                    {
                        SelectedChoice =
                            MissingSheetMetalFolderChoice
                                .PrintCurrentFolder;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };


                Button btnChoose =
                    new Button();

                btnChoose.Text =
                    "Scegli Percorso";

                btnChoose.Size =
                    new System.Drawing.Size(
                        155,
                        40);

                btnChoose.Location =
                    new System.Drawing.Point(
                        500,
                        220);

                btnChoose.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        9,
                        System.Drawing.FontStyle.Bold);

                btnChoose.Click +=
                    (_, _) =>
                    {
                        SelectedChoice =
                            MissingSheetMetalFolderChoice
                                .ChooseFolder;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };


                Controls.Add(
                    message);

                Controls.Add(
                    btnPrint);

                Controls.Add(
                    btnChoose);


                /*
                 * IMPORTANTE:
                 *
                 * non impostiamo un AcceptButton
                 * né un CancelButton.
                 *
                 * La X lascia SelectedChoice = Cancel
                 * e ShowDialog restituisce Cancel.
                 */
                FormClosing +=
                    (_, _) =>
                    {
                        if (SelectedChoice ==
                            MissingSheetMetalFolderChoice.Cancel)
                        {
                            DialogResult =
                                DialogResult.Cancel;
                        }
                    };
            }
        }
    }
}