﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class DashboardInventorPropertyWriter
    {
        private readonly Inventor.Application _inventorApp;

        public DashboardInventorPropertyWriter(
            Inventor.Application inventorApp)
        {
            _inventorApp = inventorApp;
        }

        public bool WriteProperties(
            IEnumerable<DashboardPropertySession> properties)
        {
            if (_inventorApp.ActiveDocument
                is not AssemblyDocument document)
            {
                return false;
            }

            foreach (DashboardPropertySession property
                in properties)
            {
                bool written =
                    WriteInventorProperty(
                        document,
                        property.InventorPropertyName,
                        property.Value);

                if (!written)
                    return false;

                property.OriginalValue =
                    property.Value;
            }

            return true;
        }

        private static bool WriteInventorProperty(
            AssemblyDocument document,
            string propertyName,
            string value)
        {
            foreach (PropertySet propertySet
                in document.PropertySets)
            {
                foreach (Property property
                    in propertySet)
                {
                    if (property.Name != propertyName)
                        continue;

                    property.Value =
                        value ?? string.Empty;

                    return true;
                }
            }

            return false;
        }
    }
}