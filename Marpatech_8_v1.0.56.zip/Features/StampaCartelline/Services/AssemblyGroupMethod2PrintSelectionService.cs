﻿using Marpatech_8.Features.StampaCartelline.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2PrintSelectionService
    {
        public bool ShowAndWait(
            IWin32Window owner,
            AssemblyGroupMethod2PrintNode root)
        {
            bool completed =
                false;

            bool confirmed =
                false;


            using AssemblyGroupMethod2PrintSelectionForm form =
                new AssemblyGroupMethod2PrintSelectionForm(
                    root);


            form.SelectionConfirmed +=
                (_, _) =>
                {
                    confirmed =
                        true;

                    completed =
                        true;
                };


            form.SelectionCancelled +=
                (_, _) =>
                {
                    confirmed =
                        false;

                    completed =
                        true;
                };


            form.Show();

            form.BringToFront();

            form.Activate();


            while (!completed &&
                   !form.IsDisposed)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }


            if (!form.IsDisposed)
            {
                form.Close();
            }


            return confirmed;
        }
    }
}