﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod1TreeCollector
    {
        public List<AssemblyGroupMethod1TreeNode> Collect(
            AssemblyDocument mainAssembly,
           IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            if (rules == null)
            {
                return new List<AssemblyGroupMethod1TreeNode>();
            }


            List<AssemblyGroupSearchRule> validRules=
                rules
                    .Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList();


            if (validRules.Count == 0)
            {
                return new List<AssemblyGroupMethod1TreeNode>();
            }


            /*
             * Nodi STL di primo livello rispetto
             * all'assieme MAIN.
             */
            List<AssemblyGroupMethod1TreeNode> roots =
                new List<AssemblyGroupMethod1TreeNode>();


            CollectLevel(
                mainAssembly
                    .ComponentDefinition
                    .Occurrences,
                validRules,
                roots,
                null);


            return roots;
        }


        /*
         * ==================================================
         * SCANSIONE DEL SINGOLO LIVELLO
         * ==================================================
         *
         * Questa funzione implementa una regola fondamentale:
         *
         * lo stesso STL ripetuto nello STESSO contenitore
         * viene considerato una sola volta.
         *
         * La deduplicazione NON viene passata ai livelli
         * successivi.
         *
         * Di conseguenza:
         *
         * STL100
         * ├── STL500
         * └── STL500
         *
         * produce un solo STL500.
         *
         * Ma:
         *
         * STL100
         * └── STL500
         *
         * STL200
         * └── STL500
         *
         * produce correttamente DUE nodi STL500.
         */
        private static void CollectLevel(
            ComponentOccurrences occurrences,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            ICollection<AssemblyGroupMethod1TreeNode> targetNodes,
            AssemblyGroupMethod1TreeNode? parent)
        {
            /*
             * Deduplicazione esclusivamente
             * all'interno di QUESTO contenitore.
             */
            HashSet<string> stlAlreadyAddedAtThisLevel =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                /*
                 * ==================================================
                 * SOPPRESSI
                 * ==================================================
                 *
                 * Se l'occorrenza è soppressa:
                 *
                 * - non viene aggiunta;
                 * - non viene attraversata;
                 * - tutto quel ramo viene ignorato.
                 */
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }


                Document? referencedDocument =
                    GetReferencedDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }


                if (referencedDocument.DocumentType !=
                    DocumentTypeEnum.kAssemblyDocumentObject)
                {
                    continue;
                }


                string code =
                    ReadCustomProperty(
                        referencedDocument,
                        "CODICE");


                AssemblyGroupSearchRule? matchingRule =
                    FindMatchingRule(
                        code,
                        rules);


                /*
                 * ==================================================
                 * QUESTO ASSIEME È UNO STL VALIDO
                 * ==================================================
                 */
                if (matchingRule != null)
                {
                    string assemblyPath =
                        referencedDocument
                            .FullFileName
                            ?.Trim()
                        ?? string.Empty;


                    /*
                     * Per la deduplicazione dello stesso
                     * livello usiamo preferibilmente il
                     * percorso IAM.
                     *
                     * Se per qualche motivo non è disponibile,
                     * ripieghiamo sul CODICE.
                     */
                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();


                    /*
                     * Se lo stesso IAM è già comparso
                     * nello stesso contenitore,
                     * questa seconda occorrenza viene ignorata.
                     */
                    if (!stlAlreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }


                    AssemblyGroupMethod1TreeNode node =
                        new AssemblyGroupMethod1TreeNode
                        {
                            Code =
                                code,

                            DrawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            AssemblyPath =
                                assemblyPath,

                            DrawingSearchPath =
                                matchingRule
                                    .DrawingSearchPath
                                    ?.Trim()
                                ?? string.Empty,

                            Parent =
                                parent,

                            /*
                             * Stato iniziale:
                             *
                             * casella vuota =
                             * stampa solamente la tavola.
                             */
                            SelectionState =
                                AssemblyGroupMethod1SelectionState.DrawingOnly
                        };


                    targetNodes.Add(
                        node);


                    /*
                     * Ora cerchiamo eventuali STL
                     * contenuti DENTRO questo STL.
                     *
                     * IMPORTANTE:
                     *
                     * viene creato un nuovo HashSet locale
                     * nella successiva CollectLevel().
                     *
                     * Quindi la deduplicazione del padre
                     * NON influenza altri macro-STL.
                     */
                    ComponentOccurrences?
                        childOccurrences =
                            TryGetChildOccurrences(
                                occurrence);


                    if (childOccurrences != null)
                    {
                        CollectLevel(
                            childOccurrences,
                            rules,
                            node.Children,
                            node);
                    }


                    /*
                     * Questo ramo appartiene ormai
                     * allo STL appena creato.
                     *
                     * Non dobbiamo anche riportare
                     * i suoi STL figli al livello
                     * del contenitore precedente.
                     */
                    continue;
                }


                /*
                 * ==================================================
                 * ASSIEME INTERMEDIO NON STL
                 * ==================================================
                 *
                 * Caso:
                 *
                 * MAIN
                 * └── ASSIEME GENERICO
                 *     └── STL100
                 *
                 * L'assieme generico non deve apparire
                 * nell'albero, ma dobbiamo attraversarlo
                 * per trovare STL100.
                 *
                 * Gli STL trovati restano appartenenti
                 * allo stesso livello STL logico.
                 */
                ComponentOccurrences?
                    nestedOccurrences =
                        TryGetChildOccurrences(
                            occurrence);


                if (nestedOccurrences != null)
                {
                    CollectLevelIntoSameLogicalLevel(
                        nestedOccurrences,
                        rules,
                        targetNodes,
                        stlAlreadyAddedAtThisLevel,
                        parent);
                }
            }
        }


        /*
         * Attraversa assiemi intermedi NON STL mantenendo
         * la stessa deduplicazione del livello logico.
         */
        private static void CollectLevelIntoSameLogicalLevel(
            ComponentOccurrences occurrences,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            ICollection<AssemblyGroupMethod1TreeNode> targetNodes,
            HashSet<string> stlAlreadyAddedAtThisLevel,
            AssemblyGroupMethod1TreeNode? parent)
        {
            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }


                Document? referencedDocument =
                    GetReferencedDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }


                if (referencedDocument.DocumentType !=
                    DocumentTypeEnum.kAssemblyDocumentObject)
                {
                    continue;
                }


                string code =
                    ReadCustomProperty(
                        referencedDocument,
                        "CODICE");


                AssemblyGroupSearchRule? matchingRule =
                    FindMatchingRule(
                        code,
                        rules);


                if (matchingRule != null)
                {
                    string assemblyPath =
                        referencedDocument
                            .FullFileName
                            ?.Trim()
                        ?? string.Empty;


                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();


                    if (!stlAlreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }


                    AssemblyGroupMethod1TreeNode node =
                        new AssemblyGroupMethod1TreeNode
                        {
                            Code =
                                code,

                            DrawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            AssemblyPath =
                                assemblyPath,

                            DrawingSearchPath =
                                matchingRule
                                    .DrawingSearchPath
                                    ?.Trim()
                                ?? string.Empty,

                            Parent =
                                parent,

                            SelectionState =
                                AssemblyGroupMethod1SelectionState.DrawingOnly
                        };


                    targetNodes.Add(
                        node);


                    ComponentOccurrences?
                        childOccurrences =
                            TryGetChildOccurrences(
                                occurrence);


                    if (childOccurrences != null)
                    {
                        /*
                         * Entrando in un vero STL,
                         * comincia un NUOVO livello logico.
                         */
                        CollectLevel(
                            childOccurrences,
                            rules,
                            node.Children,
                            node);
                    }


                    continue;
                }


                /*
                 * Ancora un assieme intermedio.
                 * Continuiamo mantenendo lo stesso livello.
                 */
                ComponentOccurrences?
                    nestedOccurrences =
                        TryGetChildOccurrences(
                            occurrence);


                if (nestedOccurrences != null)
                {
                    CollectLevelIntoSameLogicalLevel(
                        nestedOccurrences,
                        rules,
                        targetNodes,
                        stlAlreadyAddedAtThisLevel,
                        parent);
                }
            }
        }


        private static AssemblyGroupSearchRule?
            FindMatchingRule(
                string code,
                IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }


            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                if (code
                    .Trim()
                    .StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }


            return null;
        }


        private static bool IsSuppressed(
            ComponentOccurrence occurrence)
        {
            try
            {
                return occurrence.Suppressed;
            }
            catch
            {
                /*
                 * Se Inventor non consente di leggere
                 * correttamente l'occorrenza,
                 * la trattiamo prudentemente come
                 * non utilizzabile.
                 */
                return true;
            }
        }


        private static Document?
            GetReferencedDocument(
                ComponentOccurrence occurrence)
        {
            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;


                return documentObject
                    as Document;
            }
            catch
            {
                return null;
            }
        }


        private static ComponentOccurrences?
            TryGetChildOccurrences(
                ComponentOccurrence occurrence)
        {
            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }


            return null;
        }


        private static string ReadCustomProperty(
            Document document,
            string propertyName)
        {
            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];


                foreach (Inventor.Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }


            return string.Empty;
        }


        private static string NormalizeIdentity(
            string value)
        {
            return value
                .Trim()
                .Replace(
                    '/',
                    '\\');
        }
    }
}