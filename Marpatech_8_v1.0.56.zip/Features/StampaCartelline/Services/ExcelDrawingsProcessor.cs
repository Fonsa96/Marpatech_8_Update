﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

using ExcelApplication =
    Microsoft.Office.Interop.Excel.Application;

using ExcelWorkbook =
    Microsoft.Office.Interop.Excel.Workbook;

using ExcelWorkbooks =
    Microsoft.Office.Interop.Excel.Workbooks;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class ExcelDrawingsProcessor
    {
        public bool Process(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }

            /*
             * La sessione corrente determina
             * completamente il comportamento.
             *
             * LOGICA INVARIATA.
             */
            if (!session.ExcelDrawings
                    .IncludeInPrintProcess)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "Stampa distinte Excel disattivata nella sessione.");

                return true;
            }

            string detectedPath =
                session.ExcelDrawings
                    .ResolvedPath
                    ?.Trim()
                ?? string.Empty;

            progress.AddInformation(
                StampaCartellineProcessSection.Excel,
                string.IsNullOrWhiteSpace(
                    detectedPath)
                    ? "Nessun percorso Excel rilevato automaticamente."
                    : "Percorso Excel rilevato: " +
                      detectedPath);

            string? selectedPath =
                ResolveWorkingDirectory(
                    owner,
                    detectedPath);

            /*
             * L'utente ha annullato la scelta:
             * si salta soltanto il blocco Excel.
             *
             * LOGICA INVARIATA.
             */
            if (string.IsNullOrWhiteSpace(
                    selectedPath))
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "Selezione cartella Excel annullata dall'utente. " +
                    "Blocco Excel saltato.");

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Excel,
                "Cartella Excel utilizzata: " +
                selectedPath);

            List<string> excelFiles =
                FindExcelFiles(
                    selectedPath);

            if (excelFiles.Count == 0)
            {
                /*
                 * Popup esistente mantenuto.
                 */
                MessageBox.Show(
                    owner,
                    "Nessun file Excel trovato " +
                    "nel percorso selezionato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "Nessun file Excel trovato nel percorso selezionato.");

                return true;
            }

            progress.AddInformation(
                StampaCartellineProcessSection.Excel,
                "File Excel trovati: " +
                excelFiles.Count);

            PrintExcelFiles(
                owner,
                excelFiles,
                progress);

            return true;
        }


        private static string?
            ResolveWorkingDirectory(
                IWin32Window owner,
                string detectedPath)
        {
            bool detectedPathExists =
                !string.IsNullOrWhiteSpace(
                    detectedPath) &&
                Directory.Exists(
                    detectedPath);

            if (detectedPathExists)
            {
                DetectedExcelPathChoice choice =
                    ShowDetectedPathDialog(
                        owner,
                        detectedPath);

                if (choice ==
                    DetectedExcelPathChoice.Print)
                {
                    return detectedPath;
                }

                if (choice ==
                    DetectedExcelPathChoice.Cancel)
                {
                    return null;
                }
            }

            return SelectFolder(
                owner,
                detectedPath);
        }


        private static string?
            SelectFolder(
                IWin32Window owner,
                string detectedPath)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog();

            dialog.Description =
                "Seleziona la cartella contenente " +
                "le distinte Excel da stampare.";

            dialog.UseDescriptionForTitle =
                true;

            if (!string.IsNullOrWhiteSpace(
                    detectedPath))
            {
                string? existingParent =
                    FindExistingParentDirectory(
                        detectedPath);

                if (!string.IsNullOrWhiteSpace(
                        existingParent))
                {
                    dialog.SelectedPath =
                        existingParent;
                }
            }

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            if (result != DialogResult.OK)
                return null;

            string selectedPath =
                dialog.SelectedPath?.Trim()
                ?? string.Empty;

            return Directory.Exists(
                    selectedPath)
                ? selectedPath
                : null;
        }


        private static string?
            FindExistingParentDirectory(
                string path)
        {
            try
            {
                DirectoryInfo? directory =
                    new DirectoryInfo(
                        path);

                while (directory != null)
                {
                    if (directory.Exists)
                    {
                        return directory.FullName;
                    }

                    directory =
                        directory.Parent;
                }
            }
            catch
            {
            }

            return null;
        }


        private static List<string>
            FindExcelFiles(
                string rootDirectory)
        {
            try
            {
                return Directory
                    .EnumerateFiles(
                        rootDirectory,
                        "*.xlsx",
                        SearchOption.AllDirectories)
                    .OrderBy(
                        filePath =>
                            filePath,
                        StringComparer.OrdinalIgnoreCase)
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }


        private static DetectedExcelPathChoice
            ShowDetectedPathDialog(
                IWin32Window owner,
                string detectedPath)
        {
            using DetectedExcelPathDialog dialog =
                new DetectedExcelPathDialog(
                    detectedPath);

            DialogResult result =
                dialog.ShowDialog(
                    owner);

            if (result != DialogResult.OK)
            {
                return DetectedExcelPathChoice.Cancel;
            }

            return dialog.SelectedChoice;
        }


        private enum DetectedExcelPathChoice
        {
            Cancel,
            Print,
            ChooseFolder
        }


        private sealed class DetectedExcelPathDialog
            : Form
        {
            private bool
                     _choiceConfirmed;

            public DetectedExcelPathChoice
                SelectedChoice
            {
                get;
                private set;
            } =
                DetectedExcelPathChoice.Cancel;


            public DetectedExcelPathDialog(
                string detectedPath)
            {
                Text =
                    "Distinte Excel";

                StartPosition =
                    FormStartPosition.CenterParent;

                ClientSize =
                    new System.Drawing.Size(
                        700,
                        285);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;

                Label message =
                    new Label();

                message.Text =
                    "Il percorso rilevato è la cartella:\n\n" +
                    detectedPath +
                    "\n\nProcediamo con la stampa " +
                    "dei file Excel?\n\n" +
                    "ATTENZIONE: SE IL PERCORSO È ERRATO " +
                    "STAMPERÀ COMUNQUE TUTTI I FILE EXCEL PRESENTI.";

                message.Location =
                    new System.Drawing.Point(
                        25,
                        20);

                message.Size =
                    new System.Drawing.Size(
                        650,
                        175);

                message.Font =
                    new System.Drawing.Font(
                        "Segoe UI",
                        10);

                Button btnPrint =
                    new Button();

                btnPrint.Text =
                    "Stampa";

                btnPrint.Size =
                    new System.Drawing.Size(
                        130,
                        38);

                btnPrint.Location =
                    new System.Drawing.Point(
                        365,
                        220);

                btnPrint.Click +=
                    (_, _) =>
                    {
                        _choiceConfirmed =
                            true;

                        SelectedChoice =
                            DetectedExcelPathChoice.Print;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Button btnChoose =
                    new Button();

                btnChoose.Text =
                    "Scegli Cartella";

                btnChoose.Size =
                    new System.Drawing.Size(
                        150,
                        38);

                btnChoose.Location =
                    new System.Drawing.Point(
                        510,
                        220);

                btnChoose.Click +=
                    (_, _) =>
                    {
                        _choiceConfirmed =
                            true;

                        SelectedChoice =
                            DetectedExcelPathChoice
                                .ChooseFolder;

                        DialogResult =
                            DialogResult.OK;

                        Close();
                    };

                Controls.Add(
                    message);

                Controls.Add(
                    btnPrint);

                Controls.Add(
                    btnChoose);

                FormClosing +=
                (_, _) =>
                {
                    /*
                     * Se la finestra viene chiusa con la X
                     * e NON tramite uno dei pulsanti,
                     * significa:
                     *
                     * ANNULLA QUESTO BLOCCO.
                     */
                    if (!_choiceConfirmed)
                    {
                        SelectedChoice =
                            DetectedExcelPathChoice.Cancel;

                        DialogResult =
                            DialogResult.Cancel;
                    }
                };

            }
        }


        private static void PrintExcelFiles(
            IWin32Window owner,
            IEnumerable<string> excelFiles,
            StampaCartellineProcessProgress progress)
        {
            ExcelApplication? excelApplication =
                null;

            ExcelWorkbooks? workbooks =
                null;

            try
            {
                excelApplication =
                    new ExcelApplication
                    {
                        Visible =
                            false,

                        DisplayAlerts =
                            false,

                        AskToUpdateLinks =
                            false,

                        ScreenUpdating =
                            false,

                        EnableEvents =
                            false
                    };

                workbooks =
                    excelApplication.Workbooks;

                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "Microsoft Excel avviato.");

                foreach (string filePath
                    in excelFiles)
                {
                    PrintSingleWorkbook(
                        owner,
                        workbooks,
                        filePath,
                        progress);
                }
            }
            catch (Exception exception)
            {
                /*
                 * Popup esistente mantenuto.
                 */
                MessageBox.Show(
                    owner,
                    "Si è verificato un errore durante " +
                    "la stampa delle distinte Excel.\n\n" +
                    exception.Message +
                    "\n\nIl blocco Excel verrà terminato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Excel,
                    "Errore generale durante la stampa delle distinte Excel: " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                CloseExcelApplication(
                    excelApplication,
                    workbooks);
            }
        }


        private static void PrintSingleWorkbook(
            IWin32Window owner,
            ExcelWorkbooks workbooks,
            string filePath,
            StampaCartellineProcessProgress progress)
        {
            ExcelWorkbook? workbook =
                null;

            string fileName;

            try
            {
                fileName =
                    Path.GetFileName(
                        filePath);

                if (string.IsNullOrWhiteSpace(
                        fileName))
                {
                    fileName =
                        filePath;
                }
            }
            catch
            {
                fileName =
                    filePath;
            }

            try
            {
                workbook =
                    workbooks.Open(
                        Filename:
                            filePath,
                        UpdateLinks:
                            0,
                        ReadOnly:
                            true,
                        AddToMru:
                            false,
                        Notify:
                            false);

                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "File Excel aperto: " +
                    fileName);

                workbook.PrintOut();

                /*
                 * Excel può accodare la stampa.
                 * Attendiamo che termini prima
                 * di chiudere il file.
                 *
                 * LOGICA INVARIATA.
                 */
                WaitForExcelPrintCompletion();

                progress.AddSuccess(
                    StampaCartellineProcessSection.Excel,
                    "File Excel stampato: " +
                    fileName);
            }
            catch (Exception exception)
            {
                /*
                 * Popup esistente mantenuto.
                 */
                MessageBox.Show(
                    owner,
                    "Non è stato possibile stampare il file Excel:\n\n" +
                    filePath +
                    "\n\n" +
                    exception.Message +
                    "\n\nIl file verrà saltato.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                progress.AddError(
                    StampaCartellineProcessSection.Excel,
                    "Impossibile stampare il file Excel \"" +
                    fileName +
                    "\": " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                CloseWorkbook(
                    workbook);
            }
        }


        private static void WaitForExcelPrintCompletion()
        {
            System.Windows.Forms.Application
                .DoEvents();

            System.Threading.Thread.Sleep(
                30);
        }


        private static void CloseWorkbook(
            ExcelWorkbook? workbook)
        {
            if (workbook == null)
                return;

            try
            {
                workbook.Close(
                    SaveChanges:
                        false);
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    workbook);
            }
        }


        private static void CloseExcelApplication(
            ExcelApplication? excelApplication,
            ExcelWorkbooks? workbooks)
        {
            try
            {
                ReleaseComObject(
                    workbooks);

                if (excelApplication != null)
                {
                    excelApplication.Quit();
                }
            }
            catch
            {
            }
            finally
            {
                ReleaseComObject(
                    excelApplication);

                GC.Collect();
                GC.WaitForPendingFinalizers();

                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }


        private static void ReleaseComObject(
            object? comObject)
        {
            if (comObject == null)
                return;

            try
            {
                if (Marshal.IsComObject(
                        comObject))
                {
                    Marshal.FinalReleaseComObject(
                        comObject);
                }
            }
            catch
            {
            }
        }


        /*
         * ==================================================
         * SOLO SUPPORTO LOG
         * ==================================================
         */
        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;

            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }

            return realException.Message;
        }
    }
}