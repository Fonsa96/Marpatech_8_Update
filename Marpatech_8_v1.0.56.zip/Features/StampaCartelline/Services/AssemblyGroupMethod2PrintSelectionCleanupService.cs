﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2PrintSelectionCleanupService
    {
        private readonly Inventor.Application _inventorApp;

        public AssemblyGroupMethod2PrintSelectionCleanupService(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }

        public void Cleanup(
            AssemblyDocument currentStl,
            AssemblyGroupMethod2PrintNode root)
        {
            if (currentStl == null ||
                root == null)
            {
                return;
            }

            HashSet<string> sourcePaths =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            HashSet<string> drawingNames =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            CollectRecursive(
                root,
                sourcePaths,
                drawingNames);


            string currentStlPath =
                NormalizePath(
                    currentStl.FullFileName);


            List<Document> drawingsToClose =
                new List<Document>();

            List<Document> modelsToClose =
                new List<Document>();


            foreach (Document document
                in _inventorApp.Documents)
            {
                try
                {
                    string documentPath =
                        NormalizePath(
                            document.FullFileName);

                    /*
                     * Lo STL corrente deve rimanere aperto.
                     */
                    if (string.Equals(
                            documentPath,
                            currentStlPath,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }


                    if (document.DocumentType ==
                        DocumentTypeEnum.kDrawingDocumentObject)
                    {
                        string fileNameWithoutExtension =
                            IOPath.GetFileNameWithoutExtension(
                                documentPath);

                        if (drawingNames.Contains(
                                fileNameWithoutExtension))
                        {
                            drawingsToClose.Add(
                                document);
                        }

                        continue;
                    }


                    if (sourcePaths.Contains(
                            documentPath))
                    {
                        modelsToClose.Add(
                            document);
                    }
                }
                catch
                {
                }
            }


            /*
             * Prima IDW.
             */
            foreach (Document document
                in drawingsToClose)
            {
                TryClose(
                    document);
            }


            /*
             * Poi eventuali modelli aperti
             * durante l'ispezione.
             */
            foreach (Document document
                in modelsToClose)
            {
                TryClose(
                    document);
            }


            /*
             * Ritorno obbligatorio allo STL corrente.
             */
            try
            {
                currentStl.Activate();

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }
        }


        private static void CollectRecursive(
            AssemblyGroupMethod2PrintNode node,
            ISet<string> sourcePaths,
            ISet<string> drawingNames)
        {
            string sourcePath =
                NormalizePath(
                    node.SourceDocumentPath);

            if (!string.IsNullOrWhiteSpace(
                    sourcePath))
            {
                sourcePaths.Add(
                    sourcePath);
            }


            string drawingName =
                node.DrawingName
                    ?.Trim()
                ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(
                    drawingName))
            {
                try
                {
                    drawingName =
                        IOPath.GetFileNameWithoutExtension(
                            drawingName);
                }
                catch
                {
                }

                if (!string.IsNullOrWhiteSpace(
                        drawingName))
                {
                    drawingNames.Add(
                        drawingName);
                }
            }


            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectRecursive(
                    child,
                    sourcePaths,
                    drawingNames);
            }
        }


        private static void TryClose(
            Document document)
        {
            try
            {
                document.Close(
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }
        }


        private static string NormalizePath(
            string? path)
        {
            if (string.IsNullOrWhiteSpace(
                    path))
            {
                return string.Empty;
            }

            try
            {
                return IOPath
                    .GetFullPath(
                        path.Trim())
                    .TrimEnd(
                        IOPath.DirectorySeparatorChar,
                        IOPath.AltDirectorySeparatorChar);
            }
            catch
            {
                return path.Trim();
            }
        }
    }
}