﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyCodesScannerService
    {
        public List<AssemblyCodeSelection> Scan(
            AssemblyDocument activeAssembly,
            string mainAssemblyPrefix,
            IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (activeAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(activeAssembly));
            }

            string mainPrefix =
                mainAssemblyPrefix
                    ?.Trim()
                ?? string.Empty;


            List<AssemblyGroupSearchRule> validRules =
                rules
                    ?.Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList()
                ?? new List<AssemblyGroupSearchRule>();


            List<AssemblyCodeSelection> result =
                new List<AssemblyCodeSelection>();


            /*
             * Scansioniamo il ROOT come un singolo
             * ambito logico.
             */
            ScanAssemblyScope(
                activeAssembly,
                mainPrefix,
                validRules,
                result,
                true);


            return result;
        }


        /*
         * ==================================================
         * SINGOLO AMBITO STL / ASSIEME
         * ==================================================
         *
         * La deduplicazione vale SOLAMENTE
         * dentro questo ambito.
         *
         * Entrando in uno STL annidato
         * viene creato un nuovo HashSet.
         */
        private static void ScanAssemblyScope(
            AssemblyDocument assembly,
            string mainPrefix,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            ICollection<AssemblyCodeSelection> result,
            bool includeCurrentAssembly)
        {
            HashSet<string> codesInThisScope =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);


            /*
             * Prima individuiamo gli STL annidati.
             *
             * Devono essere processati prima
             * del contenitore.
             */
            List<ComponentOccurrence> nestedMainAssemblies =
                new List<ComponentOccurrence>();


            /*
             * Tutto ciò che NON appartiene
             * a uno STL annidato viene raccolto
             * successivamente nello scope corrente.
             */
            CollectNestedMainAssemblies(
                assembly
                    .ComponentDefinition
                    .Occurrences,
                mainPrefix,
                nestedMainAssemblies);


            /*
             * ==================================================
             * 1. STL ANNIDATI
             * ==================================================
             */
            foreach (ComponentOccurrence nestedOccurrence
                in nestedMainAssemblies)
            {
                if (IsSuppressed(
                        nestedOccurrence))
                {
                    continue;
                }


                AssemblyDocument? nestedAssembly =
                    GetAssemblyDocument(
                        nestedOccurrence);

                if (nestedAssembly == null)
                {
                    continue;
                }


                /*
                 * Prima inseriamo il CODICE dello
                 * STL annidato, ma solo se corrisponde
                 * a una riga Method2Rows.
                 */
                string nestedCode =
                    ReadCustomProperty(
                        nestedAssembly,
                        "CODICE");


                AssemblyCodeSelection?
                    nestedSelection =
                        CreateSelection(
                            nestedAssembly,
                            rules);

                if (nestedSelection != null)
                {
                    result.Add(
                        nestedSelection);
                }


                /*
                 * Poi il contenuto dello STL annidato.
                 *
                 * Qui nasce un NUOVO scope:
                 * quindi lo stesso GAC presente anche
                 * nel padre potrà essere aggiunto
                 * nuovamente.
                 */
                ScanAssemblyScope(
                    nestedAssembly,
                    mainPrefix,
                    rules,
                    result,
                    false);
            }


            /*
             * ==================================================
             * 2. ASSIEME CORRENTE / CONTENITORE
             * ==================================================
             *
             * Se il documento stesso possiede un CODICE
             * che corrisponde a Method2Rows, lo aggiungiamo.
             *
             * Per il ROOT questo consente, ad esempio,
             * di riportare anche il codice STL contenitore.
             */
            if (includeCurrentAssembly)
            {
                string currentAssemblyCode =
                    ReadCustomProperty(
                        assembly,
                        "CODICE");

                AssemblyCodeSelection?
                    currentSelection =
                        CreateSelection(
                            assembly,
                            rules);

                if (currentSelection != null)
                {
                    result.Add(
                        currentSelection);

                    codesInThisScope.Add(
                        currentSelection.Code);
                }
            }


            /*
             * ==================================================
             * 3. CODICI DELLO SCOPE CORRENTE
             * ==================================================
             *
             * Attraversiamo tutto ciò che appartiene
             * al contenitore ma NON scendiamo nuovamente
             * dentro gli STL annidati già processati sopra.
             */
            CollectCodesInCurrentScope(
                assembly
                    .ComponentDefinition
                    .Occurrences,
                mainPrefix,
                rules,
                codesInThisScope,
                result);
        }


        /*
         * Trova gli STL annidati di PRIMO livello logico.
         *
         * Gli assiemi intermedi vengono attraversati,
         * ma appena troviamo un assieme che inizia con
         * mainPrefix non scendiamo oltre:
         * quello diventa un nuovo scope autonomo.
         */
        private static void CollectNestedMainAssemblies(
            ComponentOccurrences occurrences,
            string mainPrefix,
            ICollection<ComponentOccurrence> result)
        {
            if (string.IsNullOrWhiteSpace(
                    mainPrefix))
            {
                return;
            }


            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }


                AssemblyDocument? assembly =
                    GetAssemblyDocument(
                        occurrence);

                if (assembly == null)
                {
                    continue;
                }


                string code =
                    ReadCustomProperty(
                        assembly,
                        "CODICE");


                if (!string.IsNullOrWhiteSpace(
                        code) &&
                    code.StartsWith(
                        mainPrefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    result.Add(
                        occurrence);

                    /*
                     * Non attraversiamo qui il contenuto.
                     * Verrà gestito come nuovo scope.
                     */
                    continue;
                }


                ComponentOccurrences?
                    children =
                        TryGetChildOccurrences(
                            occurrence);


                if (children != null)
                {
                    CollectNestedMainAssemblies(
                        children,
                        mainPrefix,
                        result);
                }
            }
        }


        private static void CollectCodesInCurrentScope(
            ComponentOccurrences occurrences,
            string mainPrefix,
            IReadOnlyList<AssemblyGroupSearchRule> rules,
            ISet<string> codesInThisScope,
            ICollection<AssemblyCodeSelection> result)
        {
            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }


                Document? document =
                    GetReferencedDocument(
                        occurrence);

                if (document == null)
                {
                    continue;
                }


                string code =
                    ReadCustomProperty(
                        document,
                        "CODICE");


                bool isNestedMainAssembly =
                    document.DocumentType ==
                        DocumentTypeEnum.kAssemblyDocumentObject &&
                    !string.IsNullOrWhiteSpace(
                        mainPrefix) &&
                    !string.IsNullOrWhiteSpace(
                        code) &&
                    code.StartsWith(
                        mainPrefix,
                        StringComparison.OrdinalIgnoreCase);


                /*
                 * Questo ramo STL è già stato
                 * gestito separatamente.
                 */
                if (isNestedMainAssembly)
                {
                    continue;
                }


                /*
                 * CODICE valido Method2Rows.
                 *
                 * Nello scope corrente:
                 * stesso codice = una sola riga.
                 */
                AssemblyGroupSearchRule? matchingRule =
                    FindMatchingRule(
                        code,
                        rules);

                if (matchingRule != null &&
                    codesInThisScope.Add(
                        code))
                {
                    string drawingName =
                        ReadCustomProperty(
                            document,
                            "DISEGNO");

                    if (!string.IsNullOrWhiteSpace(
                            drawingName))
                    {
                        result.Add(
                            new AssemblyCodeSelection
                            {
                                Code =
                                    code.Trim(),

                                DrawingName =
                                    drawingName.Trim(),

                                SourceCodePrefix =
                                    matchingRule.CodePrefix
                                        ?.Trim()
                                    ?? string.Empty,

                                DrawingSearchPath =
                                    matchingRule.DrawingSearchPath
                                        ?.Trim()
                                    ?? string.Empty,

                                Copies =
                                    1
                            });
                    }
                }


                /*
                 * Assieme intermedio:
                 * continuiamo nello STESSO scope.
                 */
                ComponentOccurrences?
                    children =
                        TryGetChildOccurrences(
                            occurrence);


                if (children != null)
                {
                    CollectCodesInCurrentScope(
                        children,
                        mainPrefix,
                        rules,
                        codesInThisScope,
                        result);
                }
            }
        }


        private static bool MatchesAnyRule(
            string code,
            IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return false;
            }


            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                if (code.StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }


            return false;
        }


        private static bool IsSuppressed(
            ComponentOccurrence occurrence)
        {
            try
            {
                return occurrence.Suppressed;
            }
            catch
            {
                return true;
            }
        }


        private static Document?
            GetReferencedDocument(
                ComponentOccurrence occurrence)
        {
            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as Document;
            }
            catch
            {
                return null;
            }
        }


        private static AssemblyDocument?
            GetAssemblyDocument(
                ComponentOccurrence occurrence)
        {
            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as AssemblyDocument;
            }
            catch
            {
                return null;
            }
        }


        private static ComponentOccurrences?
            TryGetChildOccurrences(
                ComponentOccurrence occurrence)
        {
            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }


            return null;
        }


        private static string ReadCustomProperty(
            Document document,
            string propertyName)
        {
            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];


                foreach (Inventor.Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }


            return string.Empty;
        }


        private static string ReadCustomProperty(
            AssemblyDocument document,
            string propertyName)
        {
            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];


                foreach (Inventor.Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }


            return string.Empty;
        }
        private static AssemblyGroupSearchRule?
    FindMatchingRule(
        string code,
        IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }

            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }

                if (code
                    .Trim()
                    .StartsWith(
                        prefix,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return rule;
                }
            }

            return null;
        }
        private static AssemblyCodeSelection?
    CreateSelection(
        Document document,
        IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            string code =
                ReadCustomProperty(
                    document,
                    "CODICE");

            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }


            AssemblyGroupSearchRule? rule =
                FindMatchingRule(
                    code,
                    rules);

            if (rule == null)
            {
                return null;
            }


            string drawingName =
                ReadCustomProperty(
                    document,
                    "DISEGNO");

            /*
             * Un componente riconosciuto ma senza DISEGNO
             * non è una tavola valida da aggiungere alla lista.
             */
            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                return null;
            }


            return new AssemblyCodeSelection
            {
                Code =
                    code.Trim(),

                DrawingName =
                    drawingName.Trim(),

                SourceCodePrefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty,

                DrawingSearchPath =
                    rule.DrawingSearchPath
                        ?.Trim()
                    ?? string.Empty,

                Copies =
                    1
            };
        }
        private static AssemblyCodeSelection?
    CreateSelection(
        AssemblyDocument document,
        IReadOnlyList<AssemblyGroupSearchRule> rules)
        {
            string code =
                ReadCustomProperty(
                    document,
                    "CODICE");

            if (string.IsNullOrWhiteSpace(
                    code))
            {
                return null;
            }


            AssemblyGroupSearchRule? rule =
                FindMatchingRule(
                    code,
                    rules);

            if (rule == null)
            {
                return null;
            }


            string drawingName =
                ReadCustomProperty(
                    document,
                    "DISEGNO");

            if (string.IsNullOrWhiteSpace(
                    drawingName))
            {
                return null;
            }


            return new AssemblyCodeSelection
            {
                Code =
                    code.Trim(),

                DrawingName =
                    drawingName.Trim(),

                SourceCodePrefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty,

                DrawingSearchPath =
                    rule.DrawingSearchPath
                        ?.Trim()
                    ?? string.Empty,

                Copies =
                    1
            };
        }
    }
}