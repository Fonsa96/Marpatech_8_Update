﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public static class DashboardPathResolver
    {
        public static string Resolve(
            PathBasedPrintConfiguration configuration,
            StampaCartellineDashboardSession session)
        {
            if (configuration == null)
                return string.Empty;

            if (session == null)
                return string.Empty;

            string initialPath =
                configuration.InitialPath?.Trim()
                ?? string.Empty;

            string determiningTag =
                configuration.DeterminingAttributeTag?.Trim()
                ?? string.Empty;

            string finalPath =
                configuration.FinalPath?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    initialPath))
            {
                return string.Empty;
            }

            if (!Directory.Exists(
                    initialPath))
            {
                return string.Empty;
            }

            if (string.IsNullOrWhiteSpace(
                    determiningTag))
            {
                return string.Empty;
            }

            DashboardPropertySession? property =
                session.GetPropertyByTag(
                    determiningTag);

            string determiningValue =
                property?.Value?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    determiningValue))
            {
                return string.Empty;
            }

            string? determiningDirectory =
                FindDeterminingDirectory(
                    initialPath,
                    determiningValue);

            if (string.IsNullOrWhiteSpace(
                    determiningDirectory))
            {
                return string.Empty;
            }

            string resolvedPath;

            try
            {
                resolvedPath =
                    string.IsNullOrWhiteSpace(
                        finalPath)
                        ? determiningDirectory
                        : Path.Combine(
                            determiningDirectory,
                            finalPath);
            }
            catch
            {
                return string.Empty;
            }

            if (!Directory.Exists(
                    resolvedPath))
            {
                return string.Empty;
            }

            return resolvedPath;
        }

        private static string?
            FindDeterminingDirectory(
                string initialPath,
                string determiningValue)
        {
            try
            {
                string[] directories =
                    Directory.GetDirectories(
                        initialPath);

                /*
                 * Prima cerchiamo una corrispondenza
                 * esatta del nome cartella.
                 */
                string? exactMatch =
                    directories
                        .FirstOrDefault(
                            directory =>
                                string.Equals(
                                    Path.GetFileName(
                                        directory),
                                    determiningValue,
                                    StringComparison
                                        .OrdinalIgnoreCase));

                if (!string.IsNullOrWhiteSpace(
                        exactMatch))
                {
                    return exactMatch;
                }

                /*
                 * Se non esiste una corrispondenza
                 * esatta, il valore determinante viene
                 * trattato come testo parziale iniziale.
                 *
                 * Esempio:
                 *
                 * 02626TS
                 *
                 * trova:
                 *
                 * 02626TS ed altro testo
                 */
                string? partialMatch =
                    directories
                        .FirstOrDefault(
                            directory =>
                                Path.GetFileName(
                                        directory)
                                    .StartsWith(
                                        determiningValue,
                                        StringComparison
                                            .OrdinalIgnoreCase));

                return partialMatch;
            }
            catch
            {
                return null;
            }
        }
    }
}