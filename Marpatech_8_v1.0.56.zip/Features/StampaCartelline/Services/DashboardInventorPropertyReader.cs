﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class DashboardInventorPropertyReader
    {
        private readonly Inventor.Application _inventorApp;

        public DashboardInventorPropertyReader(
            Inventor.Application inventorApp)
        {
            _inventorApp = inventorApp;
        }

        public void ReadProperties(
            StampaCartellineDashboardSession session)
        {
            if (_inventorApp.ActiveDocument is not AssemblyDocument document)
                return;

            foreach (DashboardPropertySession property
                in session.InventorProperties)
            {
                UpdateProperty(
                    property,
                    ReadInventorProperty(
                        document,
                        property.InventorPropertyName));
            }
        }

        private string ReadInventorProperty(
            AssemblyDocument document,
            string propertyName)
        {
            foreach (PropertySet propertySet
                in document.PropertySets)
            {
                foreach (Property property
                    in propertySet)
                {
                    if (property.Name == propertyName)
                    {
                        return property.Value?.ToString()
                            ?? string.Empty;
                    }
                }
            }

            return string.Empty;
        }

        private static void UpdateProperty(
    DashboardPropertySession property,
    string value)
        {
            property.Value = value;
            property.OriginalValue = value;
        }
    }
}