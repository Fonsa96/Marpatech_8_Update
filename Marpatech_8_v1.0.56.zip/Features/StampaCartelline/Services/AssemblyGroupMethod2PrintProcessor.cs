﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using IOPath = System.IO.Path;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2PrintProcessor
    {
        private readonly Inventor.Application _inventorApp;


        public AssemblyGroupMethod2PrintProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));
        }


        public void Process(
            AssemblyDocument stlAssembly,
            AssemblyGroupMethod2PrintNode root,
            IEnumerable<AssemblyGroupSearchRule> rules)
        {
            if (stlAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(stlAssembly));
            }

            if (root == null)
            {
                throw new ArgumentNullException(
                    nameof(root));
            }


            List<AssemblyGroupSearchRule> orderedRules =
                rules
                    ?.Where(
                        rule =>
                            rule != null &&
                            !string.IsNullOrWhiteSpace(
                                rule.CodePrefix))
                    .ToList()
                ?? new List<AssemblyGroupSearchRule>();


            /*
             * Tutti i nodi selezionati TRUE
             * escluso il ROOT.
             *
             * Il ROOT verrà gestito alla fine
             * tramite Apri Tavola di Inventor.
             */
            List<AssemblyGroupMethod2PrintNode> selectedNodes =
                new List<AssemblyGroupMethod2PrintNode>();

            CollectSelectedNodes(
                root,
                selectedNodes,
                false);


            /*
             * Cache degli indici server.
             *
             * CHIAVE:
             * percorso cartella.
             *
             * Così ogni percorso viene scandito
             * ricorsivamente UNA SOLA VOLTA.
             */
            Dictionary<
                string,
                Dictionary<string, string>>
                indexesBySearchPath =
                    new Dictionary<
                        string,
                        Dictionary<string, string>>(
                            StringComparer.OrdinalIgnoreCase);


            /*
             * Processiamo rispettando l'ordine
             * delle righe Method2Rows.
             */
            foreach (AssemblyGroupSearchRule rule
                in orderedRules)
            {
                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix))
                {
                    continue;
                }


                List<AssemblyGroupMethod2PrintNode> groupNodes =
                    selectedNodes
                        .Where(
                            node =>
                                string.Equals(
                                    node.SearchPrefix,
                                    prefix,
                                    StringComparison.OrdinalIgnoreCase))
                        .ToList();


                if (groupNodes.Count == 0)
                {
                    continue;
                }


                ProcessRuleGroup(
                    groupNodes,
                    indexesBySearchPath);
            }


            /*
             * Eventuale sicurezza:
             *
             * se esiste un nodo TRUE con SearchPrefix
             * non presente nelle Method2Rows,
             * non viene stampato e gli assegniamo errore.
             */
            foreach (AssemblyGroupMethod2PrintNode node
                in selectedNodes)
            {
                bool ruleExists =
                    orderedRules.Any(
                        rule =>
                            string.Equals(
                                rule.CodePrefix
                                    ?.Trim(),
                                node.SearchPrefix,
                                StringComparison.OrdinalIgnoreCase));

                if (!ruleExists)
                {
                    SetFailure(
                        node,
                        "Nessuna regola Metodo 2 configurata per il prefisso: " +
                        node.SearchPrefix);
                }
            }


            /*
             * Terminati i gruppi interni,
             * torniamo all'IAM STL.
             */
            try
            {
                stlAssembly.Activate();

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }


            /*
             * ROOT TRUE:
             * stampiamo la tavola dello STL corrente.
             *
             * ROOT FALSE:
             * niente tavola STL.
             */
            if (root.PrintDrawing)
            {
                PrintCurrentStlDrawing(
                    stlAssembly,
                    root);
            }
        }


        private void ProcessRuleGroup(
            IEnumerable<AssemblyGroupMethod2PrintNode> nodes,
            IDictionary<
                string,
                Dictionary<string, string>>
                indexesBySearchPath)
        {
            foreach (AssemblyGroupMethod2PrintNode node
                in nodes)
            {
                string searchPath =
                    node.DrawingSearchPath
                        ?.Trim()
                    ?? string.Empty;


                if (string.IsNullOrWhiteSpace(
                        searchPath))
                {
                    SetFailure(
                        node,
                        "Percorso ricerca IDW non configurato");

                    continue;
                }


                if (!Directory.Exists(
                        searchPath))
                {
                    SetFailure(
                        node,
                        "Percorso ricerca IDW non trovato: " +
                        searchPath);

                    continue;
                }


                /*
                 * Creiamo l'indice solo la prima volta
                 * che incontriamo questa cartella.
                 */
                if (!indexesBySearchPath.TryGetValue(
                        searchPath,
                        out Dictionary<string, string>? index))
                {
                    index =
                        BuildDrawingIndex(
                            searchPath);

                    indexesBySearchPath[
                        searchPath] =
                            index;
                }


                string drawingName =
                    NormalizeDrawingFileName(
                        node.DrawingName);


                if (string.IsNullOrWhiteSpace(
                        drawingName))
                {
                    SetFailure(
                        node,
                        "Proprietà DISEGNO vuota");

                    continue;
                }


                /*
                 * MATCH ESATTO.
                 *
                 * DISEGNO = GAC1230
                 *
                 * trova:
                 * GAC1230.idw
                 *
                 * ma NON:
                 * GAC1230_RICAMBI.idw
                 */
                if (!index.TryGetValue(
                        drawingName,
                        out string? drawingPath))
                {
                    SetFailure(
                        node,
                        "IDW non trovato sul server: " +
                        drawingName);

                    continue;
                }


                PrintDrawing(
                    node,
                    drawingPath);
            }
        }


        private static Dictionary<string, string>
            BuildDrawingIndex(
                string searchRoot)
        {
            Dictionary<string, string> index =
                new Dictionary<string, string>(
                    StringComparer.OrdinalIgnoreCase);


            try
            {
                foreach (string filePath
                    in Directory.EnumerateFiles(
                        searchRoot,
                        "*.idw",
                        SearchOption.AllDirectories))
                {
                    string fileName =
                        IOPath.GetFileName(
                            filePath);


                    /*
                     * Mi hai confermato che sul server
                     * non possono esistere due file
                     * con lo stesso nome.
                     *
                     * In ogni caso non sovrascriviamo.
                     */
                    if (!index.ContainsKey(
                            fileName))
                    {
                        index.Add(
                            fileName,
                            filePath);
                    }
                }
            }
            catch
            {
                /*
                 * Eventuali directory non accessibili
                 * non devono mandare in crash il processo.
                 */
            }


            return index;
        }


        private void PrintDrawing(
            AssemblyGroupMethod2PrintNode node,
            string drawingPath)
        {
            DrawingDocument? drawingDocument =
                null;

            try
            {
                Document openedDocument =
                    _inventorApp.Documents.Open(
                        drawingPath,
                        true);


                drawingDocument =
                    openedDocument
                        as DrawingDocument;


                if (drawingDocument == null)
                {
                    try
                    {
                        openedDocument.Close(
                            true);
                    }
                    catch
                    {
                    }

                    SetFailure(
                        node,
                        "Il file trovato non è un IDW valido");

                    return;
                }


                drawingDocument.Activate();

                System.Windows.Forms.Application
                    .DoEvents();


                ExecuteInventorCommand(
                    "Autodesk:InvPrint:SVCmdBtn");
            }
            catch (Exception exception)
            {
                SetFailure(
                    node,
                    "Errore durante la stampa IDW: " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }
            }
        }


        private void PrintCurrentStlDrawing(
            AssemblyDocument stlAssembly,
            AssemblyGroupMethod2PrintNode root)
        {
            DrawingDocument? drawingDocument =
                null;

            try
            {
                stlAssembly.Activate();

                System.Windows.Forms.Application
                    .DoEvents();


                BrowserPane browser =
                    stlAssembly
                        .BrowserPanes
                        .ActivePane;


                BrowserNode topNode =
                    browser.TopNode;


                topNode.DoSelect();

                System.Windows.Forms.Application
                    .DoEvents();


                ExecuteInventorCommand(
                    "CMxOpenDrawingCmd");

                System.Windows.Forms.Application
                    .DoEvents();


                drawingDocument =
                    _inventorApp.ActiveDocument
                        as DrawingDocument;


                if (drawingDocument == null)
                {
                    SetFailure(
                        root,
                        "Tavola dell'assieme corrente non trovata");

                    return;
                }


                ExecuteInventorCommand(
                    "Autodesk:InvPrint:SVCmdBtn");
            }
            catch (Exception exception)
            {
                SetFailure(
                    root,
                    "Errore durante la stampa della tavola dell'assieme: " +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                if (drawingDocument != null)
                {
                    TryCloseDrawing(
                        drawingDocument);
                }


                try
                {
                    stlAssembly.Activate();

                    System.Windows.Forms.Application
                        .DoEvents();
                }
                catch
                {
                }
            }
        }


        private void TryCloseDrawing(
            DrawingDocument drawingDocument)
        {
            string drawingPath =
                string.Empty;


            try
            {
                drawingPath =
                    drawingDocument
                        .FullFileName
                        ?.Trim()
                    ?? string.Empty;
            }
            catch
            {
            }


            /*
             * Primo tentativo.
             */
            try
            {
                drawingDocument.Activate();

                System.Windows.Forms.Application
                    .DoEvents();

                drawingDocument.Close(
                    true);

                System.Windows.Forms.Application
                    .DoEvents();
            }
            catch
            {
            }


            /*
             * Secondo tentativo per percorso,
             * come abbiamo fatto per la tavola Main
             * del Metodo 1.
             */
            if (!string.IsNullOrWhiteSpace(
                    drawingPath))
            {
                List<Document> documentsToClose =
                    new List<Document>();


                foreach (Document document
                    in _inventorApp.Documents)
                {
                    try
                    {
                        if (document.DocumentType !=
                            DocumentTypeEnum.kDrawingDocumentObject)
                        {
                            continue;
                        }


                        if (string.Equals(
                                document.FullFileName,
                                drawingPath,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            documentsToClose.Add(
                                document);
                        }
                    }
                    catch
                    {
                    }
                }


                foreach (Document document
                    in documentsToClose)
                {
                    try
                    {
                        document.Close(
                            true);

                        System.Windows.Forms.Application
                            .DoEvents();
                    }
                    catch
                    {
                    }
                }
            }
        }


        private void ExecuteInventorCommand(
            string commandInternalName)
        {
            ControlDefinition command =
                _inventorApp
                    .CommandManager
                    .ControlDefinitions[
                        commandInternalName];


            command.Execute2(
                true);
        }


        private static string NormalizeDrawingFileName(
            string? drawingName)
        {
            string value =
                drawingName
                    ?.Trim()
                ?? string.Empty;


            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return string.Empty;
            }


            try
            {
                value =
                    IOPath.GetFileName(
                        value);
            }
            catch
            {
            }


            string extension =
                IOPath.GetExtension(
                    value);


            if (string.IsNullOrWhiteSpace(
                    extension))
            {
                value +=
                    ".idw";
            }
            else if (!string.Equals(
                         extension,
                         ".idw",
                         StringComparison.OrdinalIgnoreCase))
            {
                value =
                    IOPath.GetFileNameWithoutExtension(
                        value)
                    + ".idw";
            }


            return value;
        }


        private static void CollectSelectedNodes(
            AssemblyGroupMethod2PrintNode node,
            ICollection<AssemblyGroupMethod2PrintNode> result,
            bool includeCurrentNode)
        {
            if (includeCurrentNode &&
                node.PrintDrawing)
            {
                result.Add(
                    node);
            }


            foreach (AssemblyGroupMethod2PrintNode child
                in node.Children)
            {
                CollectSelectedNodes(
                    child,
                    result,
                    true);
            }
        }


        private static void SetFailure(
            AssemblyGroupMethod2PrintNode node,
            string message)
        {
            /*
             * Aggiungiamo FailureReason al modello
             * nel prossimo punto.
             */
            node.FailureReason =
                message;
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception real =
                exception;


            while (real.InnerException != null)
            {
                real =
                    real.InnerException;
            }


            return real.Message;
        }
    }
}