﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{

    public sealed class AssemblyGroupsProcessor
    {
        private readonly Inventor.Application _inventorApp;


        private readonly AssemblyGroupMethod1TreeCollector
    _method1TreeCollector;

        private readonly AssemblyGroupMethod1TreeDrawingResolver
    _method1TreeDrawingResolver;

        private readonly AssemblyGroupMethod1TreeProcessor
    _method1TreeProcessor;

        private readonly AssemblyGroupMethod1SelectionService
            _method1SelectionService;

        private readonly AssemblyGroupMethod2TreeCollector
    _method2TreeCollector;

        private readonly AssemblyGroupMethod2SelectionService
            _method2SelectionService;

        private readonly AssemblyGroupMethod2SelectionCleanupService
    _method2SelectionCleanupService;

        private readonly AssemblyGroupMethod2TreeProcessor
            _method2TreeProcessor;

        private readonly AssemblyGroupSelectedStlService
    _selectedStlService;

        private readonly SelectedAssemblyCodesPrintProcessor
    _selectedAssemblyCodesPrintProcessor;

        public AssemblyGroupsProcessor(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp
                ?? throw new ArgumentNullException(
                    nameof(inventorApp));

                    _method1TreeCollector =
            new AssemblyGroupMethod1TreeCollector();

                    _method1TreeDrawingResolver =
            new AssemblyGroupMethod1TreeDrawingResolver();

            _method1TreeProcessor =
                new AssemblyGroupMethod1TreeProcessor(
                    inventorApp);

            _method1SelectionService =
                new AssemblyGroupMethod1SelectionService();
            _method2TreeCollector =
                 new AssemblyGroupMethod2TreeCollector();

            _method2SelectionService =
                new AssemblyGroupMethod2SelectionService();
            _method2SelectionCleanupService =
                  new AssemblyGroupMethod2SelectionCleanupService(
              inventorApp);

            _method2TreeProcessor =
                new AssemblyGroupMethod2TreeProcessor(
                    inventorApp);

            _selectedStlService =
             new AssemblyGroupSelectedStlService();

            _selectedAssemblyCodesPrintProcessor =
                new SelectedAssemblyCodesPrintProcessor(
                    inventorApp);
        }

        public bool Process(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            /*
             * La Dashboard di sessione ha priorità.
             *
             * Se Gruppi di montaggio è disattivato
             * nella sessione, saltiamo tutto il blocco
             * senza interrompere il processo generale.
             */
            if (!session.IncludeAssemblyGroups)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Gruppi di montaggio disattivati nella sessione.");

                return true;
            }

            AssemblyGroupsConfiguration?
                groupsConfiguration =
                    configuration.AssemblyGroups;

            if (groupsConfiguration == null)
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Configurazione Gruppi di montaggio non disponibile.");

                return false;
            }

            /*
             * Se nessuno dei due metodi è configurato,
             * mostriamo l'avviso ma consideriamo
             * completato il blocco.
             */
            if (!groupsConfiguration.Method1Enabled &&
                !groupsConfiguration.Method2Enabled)
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Nessun metodo di stampa dei gruppi di montaggio selezionato.");

                MessageBox.Show(
                    owner,
                    "Nessun metodo di stampa dei gruppi selezionato, " +
                    "Selezionalo nella configurazione e ripeti il comando",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            /*
             * Entrambi i metodi partono sempre
             * dall'assieme MAIN attualmente aperto.
             *
             * Lo recuperiamo UNA SOLA VOLTA.
             */
            if (_inventorApp.ActiveDocument
                is not AssemblyDocument mainAssembly)
            {
                progress.AddError(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Il documento attivo non è un assieme Inventor.");

                MessageBox.Show(
                    owner,
                    "Il documento attivo non è un assieme Inventor.",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return false;
            }

            /*
 * ==================================================
 * MODALITÀ:
 * STAMPA SOLO SERIE DI CODICI SELEZIONATI
 * ==================================================
 *
 * Questa modalità ha priorità su Metodo 1 / Metodo 2.
 */
            if (session.PrintOnlySelectedAssemblyCodes)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Modalità selezionata: stampa della serie di tavole configurata manualmente.");

                if (session.SelectedAssemblyCodes == null ||
                    session.SelectedAssemblyCodes.Count == 0)
                {
                    progress.AddError(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "La modalità di stampa della serie di tavole è attiva, ma la lista è vuota.");

                    MessageBox.Show(
                        owner,
                        "Hai selezionato \"Vuoi stampare solo una serie di codici contenuta nell’assieme\" " +
                        "ma la lista è vuota.",
                        "Gruppi di montaggio",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return false;
                }

                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Righe da processare: " +
                    session.SelectedAssemblyCodes.Count);


                _selectedAssemblyCodesPrintProcessor.Process(
                    owner,
                    session.SelectedAssemblyCodes,
                    groupsConfiguration
                        .Method2MainAssemblyCodePrefix,
                    progress);

                progress.AddSuccess(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Elaborazione della serie di tavole completata.");


                return true;
            }

            /*
             * ==================================================
             * METODO 1
             * ==================================================
             */
            if (groupsConfiguration.Method1Enabled)
            {
                progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Modalità selezionata: Metodo 1.");
                /*
                 * Costruiamo la nuova struttura gerarchica
                 * degli STL.
                 */
                List<AssemblyGroupMethod1TreeNode> method1Tree =
                    _method1TreeCollector.Collect(
                        mainAssembly,
                        groupsConfiguration.Method1Rows);

                progress.AddInformation(
                     StampaCartellineProcessSection.AssemblyGroups,
                     "Struttura STL Metodo 1 rilevata.");

                /*
 * Dashboard:
 * "Vuoi stampare solo alcuni STL?"
 */
                if (session.PrintOnlySelectedStl)
                {
                    HashSet<string> selectedCodes =
                        _selectedStlService.ParseSelectedCodes(
                            session.SelectedStlList);


                    /*
                     * Se la funzione è attiva ma la textbox
                     * è vuota, non processiamo nessun STL.
                     */
                    if (selectedCodes.Count == 0)
                    {
                        progress.AddError(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Filtro \"solo alcuni STL\" attivo ma nessun codice STL è stato indicato.");
                        MessageBox.Show(
                            owner,
                            "Hai selezionato \"Vuoi stampare solo alcuni STL\" " +
                            "ma non hai indicato alcun codice.",
                            "Gruppi di montaggio",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return false;
                    }

                    _selectedStlService.FilterMethod1Tree(
                        method1Tree,
                        selectedCodes);
                }


                /*
                 * Mostriamo la finestra MODELESS
                 * con tutte le checkbox Jenkins inizialmente FALSE.
                 *
                 * Inventor deve rimanere utilizzabile
                 * mentre l'utente effettua la scelta.
                 */
                bool confirmed =
                    _method1SelectionService.ShowAndWait(
                        owner,
                        method1Tree);


                /*
                 * ANNULLA:
                 *
                 * nessuna stampa e nessun Jenkins.
                 * Consideriamo completato Gruppi di montaggio.
                 */
                if (!confirmed)
                {
                    progress.AddWarning(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Metodo 1 annullato dall'utente nella finestra di selezione STL.");
                    try
                    {
                        mainAssembly.Activate();
                    }
                    catch
                    {
                    }

                    return true;
                }


                /*
                 * Risolviamo tutti gli IDW della nuova
                 * struttura tramite:
                 *
                 * DISEGNO
                 * +
                 * DrawingSearchPath
                 */
                _method1TreeDrawingResolver.Resolve(
                    method1Tree);

                progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Risoluzione delle tavole Metodo 1 completata.");

                /*
                 * NUOVO PROCESSO GERARCHICO REALE.
                 */
                _method1TreeProcessor.Process(
                    owner,
                    mainAssembly,
                    method1Tree,
                    progress);

                progress.AddSuccess(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Metodo 1 completato.");

                return true;
            }


            /*
             * ==================================================
             * METODO 2
             * ==================================================
             */
            if (groupsConfiguration.Method2Enabled)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Modalità selezionata: Metodo 2.");
                List<AssemblyGroupMethod2TreeNode> method2Tree =
                    _method2TreeCollector.Collect(
                        mainAssembly,
                        groupsConfiguration
                            .Method2MainAssemblyCodePrefix);

                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Struttura STL Metodo 2 rilevata.");

                if (session.PrintOnlySelectedStl)
                {
                    HashSet<string> selectedCodes =
                        _selectedStlService.ParseSelectedCodes(
                            session.SelectedStlList);

                    progress.AddInformation(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Filtro Dashboard attivo: processare solo gli STL richiesti. " +
                        "Codici richiesti: " +
                        selectedCodes.Count);

                    if (selectedCodes.Count == 0)
                    {
                        progress.AddError(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Filtro \"solo alcuni STL\" attivo ma nessun codice STL è stato indicato.");
                        MessageBox.Show(
                            owner,
                            "Hai selezionato \"Vuoi stampare solo alcuni STL\" " +
                            "ma non hai indicato alcun codice.",
                            "Gruppi di montaggio",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return false;
                    }

                    _selectedStlService.FilterMethod2Tree(
                        method2Tree,
                        selectedCodes);
                }


                bool confirmed =
                    _method2SelectionService.ShowAndWait(
                        owner,
                        method2Tree);


                if (!confirmed)
                {
                    progress.AddWarning(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Metodo 2 annullato dall'utente nella finestra di selezione STL.");
                    try
                    {
                        mainAssembly.Activate();
                    }
                    catch
                    {
                    }

                    return true;
                }


                /*
                 * Pulizia di sicurezza dopo il Form 1:
                 *
                 * - chiude eventuali IAM STL aperti;
                 * - chiude eventuali relative tavole;
                 * - non tocca documenti estranei;
                 * - ritorna al MAIN.
                 */
                _method2SelectionCleanupService
                    .CleanupAfterSelection(
                        mainAssembly,
                        method2Tree);

                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Pulizia dopo la selezione Metodo 2 completata.");

                /*
                 * Processamento gerarchico:
                 *
                 * figli prima dei contenitori;
                 * solo nodi TRUE.
                 */
                _method2TreeProcessor.Process(
                    owner,
                    mainAssembly,
                    method2Tree,
                    groupsConfiguration
                        .Method2MainAssemblyCodePrefix,
                    groupsConfiguration
                        .Method2Rows,
                    progress);

                progress.AddSuccess(
                        StampaCartellineProcessSection.AssemblyGroups,
                        "Metodo 2 completato.");

                return true;
            }

            return true;
        }
    }
}