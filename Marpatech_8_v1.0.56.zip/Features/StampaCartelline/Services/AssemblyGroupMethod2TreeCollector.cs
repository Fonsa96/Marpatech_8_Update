﻿using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod2TreeCollector
    {
        public List<AssemblyGroupMethod2TreeNode> Collect(
            AssemblyDocument mainAssembly,
            string mainCodePrefix)
        {
            if (mainAssembly == null)
            {
                throw new ArgumentNullException(
                    nameof(mainAssembly));
            }

            string prefix =
                mainCodePrefix
                    ?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    prefix))
            {
                return new List<AssemblyGroupMethod2TreeNode>();
            }

            List<AssemblyGroupMethod2TreeNode> roots =
                new List<AssemblyGroupMethod2TreeNode>();

            CollectLevel(
                mainAssembly
                    .ComponentDefinition
                    .Occurrences,
                prefix,
                roots,
                null);

            return roots;
        }

        private static void CollectLevel(
            ComponentOccurrences occurrences,
            string prefix,
            ICollection<AssemblyGroupMethod2TreeNode> targetNodes,
            AssemblyGroupMethod2TreeNode? parent)
        {
            /*
             * Deduplicazione soltanto nel
             * livello logico corrente.
             *
             * Lo stesso IAM ripetuto nello stesso
             * contenitore entra una sola volta.
             */
            HashSet<string> alreadyAddedAtThisLevel =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                /*
                 * SOPPRESSO:
                 * ignoriamo completamente il ramo.
                 */
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }

                Document? referencedDocument =
                    GetReferencedDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }

                if (referencedDocument.DocumentType !=
                    DocumentTypeEnum.kAssemblyDocumentObject)
                {
                    continue;
                }

                string code =
                    ReadCustomProperty(
                        referencedDocument,
                        "CODICE");

                bool isTargetStl =
                    MatchesPrefix(
                        code,
                        prefix);

                if (isTargetStl)
                {
                    string assemblyPath =
                        referencedDocument
                            .FullFileName
                            ?.Trim()
                        ?? string.Empty;

                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();

                    if (!alreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }

                    AssemblyGroupMethod2TreeNode node =
                        new AssemblyGroupMethod2TreeNode
                        {
                            Code =
                                code,

                            AssemblyPath =
                                assemblyPath,

                            DrawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            Parent =
                                parent,

                            /*
                             * FORM 1:
                             * tutti partono TRUE.
                             */
                            ProcessStl =
                                true
                        };

                    targetNodes.Add(
                        node);

                    ComponentOccurrences?
                        childOccurrences =
                            TryGetChildOccurrences(
                                occurrence);

                    if (childOccurrences != null)
                    {
                        /*
                         * Entrando in un vero STL
                         * iniziamo un nuovo livello logico.
                         */
                        CollectLevel(
                            childOccurrences,
                            prefix,
                            node.Children,
                            node);
                    }

                    continue;
                }

                /*
                 * Assieme intermedio NON STL:
                 *
                 * lo attraversiamo senza mostrarlo,
                 * mantenendo lo stesso livello logico.
                 */
                ComponentOccurrences?
                    nestedOccurrences =
                        TryGetChildOccurrences(
                            occurrence);

                if (nestedOccurrences != null)
                {
                    CollectSameLogicalLevel(
                        nestedOccurrences,
                        prefix,
                        targetNodes,
                        alreadyAddedAtThisLevel,
                        parent);
                }
            }
        }

        private static void CollectSameLogicalLevel(
            ComponentOccurrences occurrences,
            string prefix,
            ICollection<AssemblyGroupMethod2TreeNode> targetNodes,
            HashSet<string> alreadyAddedAtThisLevel,
            AssemblyGroupMethod2TreeNode? parent)
        {
            foreach (ComponentOccurrence occurrence
                in occurrences)
            {
                if (IsSuppressed(
                        occurrence))
                {
                    continue;
                }

                Document? referencedDocument =
                    GetReferencedDocument(
                        occurrence);

                if (referencedDocument == null)
                {
                    continue;
                }

                if (referencedDocument.DocumentType !=
                    DocumentTypeEnum.kAssemblyDocumentObject)
                {
                    continue;
                }

                string code =
                    ReadCustomProperty(
                        referencedDocument,
                        "CODICE");

                if (MatchesPrefix(
                        code,
                        prefix))
                {
                    string assemblyPath =
                        referencedDocument
                            .FullFileName
                            ?.Trim()
                        ?? string.Empty;

                    string localIdentity =
                        !string.IsNullOrWhiteSpace(
                            assemblyPath)
                            ? NormalizeIdentity(
                                assemblyPath)
                            : code.Trim();

                    if (!alreadyAddedAtThisLevel.Add(
                            localIdentity))
                    {
                        continue;
                    }

                    AssemblyGroupMethod2TreeNode node =
                        new AssemblyGroupMethod2TreeNode
                        {
                            Code =
                                code,

                            AssemblyPath =
                                assemblyPath,

                            DrawingName =
                                ReadCustomProperty(
                                    referencedDocument,
                                    "DISEGNO"),

                            Parent =
                                parent,

                            ProcessStl =
                                true
                        };

                    targetNodes.Add(
                        node);

                    ComponentOccurrences?
                        childOccurrences =
                            TryGetChildOccurrences(
                                occurrence);

                    if (childOccurrences != null)
                    {
                        CollectLevel(
                            childOccurrences,
                            prefix,
                            node.Children,
                            node);
                    }

                    continue;
                }

                ComponentOccurrences?
                    nestedOccurrences =
                        TryGetChildOccurrences(
                            occurrence);

                if (nestedOccurrences != null)
                {
                    CollectSameLogicalLevel(
                        nestedOccurrences,
                        prefix,
                        targetNodes,
                        alreadyAddedAtThisLevel,
                        parent);
                }
            }
        }

        private static bool MatchesPrefix(
            string code,
            string prefix)
        {
            if (string.IsNullOrWhiteSpace(
                    code) ||
                string.IsNullOrWhiteSpace(
                    prefix))
            {
                return false;
            }

            return code
                .Trim()
                .StartsWith(
                    prefix.Trim(),
                    StringComparison.OrdinalIgnoreCase);
        }

        private static bool IsSuppressed(
            ComponentOccurrence occurrence)
        {
            try
            {
                return occurrence.Suppressed;
            }
            catch
            {
                return true;
            }
        }

        private static Document?
            GetReferencedDocument(
                ComponentOccurrence occurrence)
        {
            try
            {
                object documentObject =
                    occurrence
                        .Definition
                        .Document;

                return documentObject
                    as Document;
            }
            catch
            {
                return null;
            }
        }

        private static ComponentOccurrences?
            TryGetChildOccurrences(
                ComponentOccurrence occurrence)
        {
            try
            {
                if (occurrence.Definition is
                    AssemblyComponentDefinition
                    assemblyDefinition)
                {
                    return assemblyDefinition
                        .Occurrences;
                }
            }
            catch
            {
            }

            return null;
        }

        private static string ReadCustomProperty(
            Document document,
            string propertyName)
        {
            try
            {
                PropertySet customProperties =
                    document.PropertySets[
                        "Inventor User Defined Properties"];

                foreach (Inventor.Property property
                    in customProperties)
                {
                    if (string.Equals(
                            property.Name,
                            propertyName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        return property.Value
                                   ?.ToString()
                                   ?.Trim()
                            ?? string.Empty;
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }

        private static string NormalizeIdentity(
            string value)
        {
            return value
                .Trim()
                .Replace(
                    '/',
                    '\\');
        }
    }
}