﻿using Marpatech_8.Features.StampaCartelline.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public sealed class AssemblyGroupMethod1SelectionService
    {
        public bool ShowAndWait(
            IWin32Window owner,
            IEnumerable<AssemblyGroupMethod1TreeNode> roots)
        {
            bool completed =
                false;

            bool confirmed =
                false;


            using AssemblyGroupMethod1SelectionForm form =
                new AssemblyGroupMethod1SelectionForm(
                    roots);


            form.SelectionConfirmed +=
                (_, _) =>
                {
                    confirmed =
                        true;

                    completed =
                        true;
                };


            form.SelectionCancelled +=
                (_, _) =>
                {
                    confirmed =
                        false;

                    completed =
                        true;
                };


            /*
             * IMPORTANTE:
             *
             * NON assegniamo la Dashboard come owner.
             *
             * Durante AVVIA PROCESSO la Dashboard può
             * essere nascosta e trascinere con sé
             * anche una finestra modeless posseduta.
             */
            form.Show();


            /*
             * Portiamo esplicitamente davanti
             * la finestra di selezione.
             */
            form.BringToFront();

            form.Activate();


            /*
             * La finestra rimane MODELESS.
             *
             * Inventor continua quindi a essere
             * completamente utilizzabile.
             *
             * Il nostro processo invece resta fermo
             * qui finché non viene premuto:
             *
             * - Conferma
             * - Annulla
             * - X
             */
            while (!completed &&
                   !form.IsDisposed)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    20);
            }


            /*
             * La scelta è stata acquisita.
             * Chiudiamo ora la finestra.
             */
            if (!form.IsDisposed)
            {
                form.Close();
            }


            return confirmed;
        }
    }
}