﻿using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class ConfigurationListManager
    {
        private readonly ListBox _listBox;

        private PrintFolderConfigurationsFile _file =
            new PrintFolderConfigurationsFile();

        private static readonly JsonSerializerOptions
            CloneJsonOptions =
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

        public ConfigurationListManager(
            ListBox listBox)
        {
            _listBox = listBox ??
                throw new ArgumentNullException(
                    nameof(listBox));
        }

        public IReadOnlyList<PrintFolderConfiguration>
            Configurations =>
                _file.Configurations;

        public int SelectedIndex =>
            _listBox.SelectedIndex;

        public PrintFolderConfiguration?
            SelectedConfiguration
        {
            get
            {
                int selectedIndex =
                    _listBox.SelectedIndex;

                if (selectedIndex < 0)
                    return null;

                if (selectedIndex >=
                    _file.Configurations.Count)
                {
                    return null;
                }

                return _file.Configurations[
                    selectedIndex];
            }
        }

        public void Load()
        {
            _file =
                StampaCartellineStorage.Load();

            RefreshList();
        }

        public void Save()
        {
            StampaCartellineStorage.Save(
                _file);
        }

        public void Add(
            PrintFolderConfiguration configuration)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            ValidateName(
                configuration.Name);

            EnsureUniqueName(
                configuration.Name);

            _file.Configurations.Add(
                configuration);

            Save();

            RefreshList(
                _file.Configurations.Count - 1);
        }

        public void UpdateSelected(
            PrintFolderConfiguration configuration)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            int selectedIndex =
                _listBox.SelectedIndex;

            if (selectedIndex < 0 ||
                selectedIndex >=
                _file.Configurations.Count)
            {
                throw new InvalidOperationException(
                    "Nessuna configurazione selezionata.");
            }

            ValidateName(
                configuration.Name);

            EnsureUniqueName(
                configuration.Name,
                selectedIndex);

            _file.Configurations[selectedIndex] =
                configuration;

            Save();

            RefreshList(
                selectedIndex);
        }

        public PrintFolderConfiguration
            CreateDuplicateOfSelected()
        {
            PrintFolderConfiguration source =
                SelectedConfiguration
                ?? throw new InvalidOperationException(
                    "Nessuna configurazione selezionata.");

            PrintFolderConfiguration duplicate =
                CloneConfiguration(source);

            duplicate.Name =
                CreateUniqueDuplicateName(
                    source.Name);

            return duplicate;
        }

        public void DeleteSelected()
        {
            int selectedIndex =
                _listBox.SelectedIndex;

            if (selectedIndex < 0 ||
                selectedIndex >=
                _file.Configurations.Count)
            {
                return;
            }

            _file.Configurations.RemoveAt(
                selectedIndex);

            Save();

            RefreshList(
                Math.Min(
                    selectedIndex,
                    _file.Configurations.Count - 1));
        }

        public void RefreshList(
            int selectedIndex = 0)
        {
            _listBox.BeginUpdate();

            try
            {
                _listBox.Items.Clear();

                foreach (
                    PrintFolderConfiguration configuration
                    in _file.Configurations)
                {
                    _listBox.Items.Add(
                        configuration.Name);
                }

                if (_listBox.Items.Count == 0)
                    return;

                if (selectedIndex < 0)
                    selectedIndex = 0;

                if (selectedIndex >=
                    _listBox.Items.Count)
                {
                    selectedIndex =
                        _listBox.Items.Count - 1;
                }

                _listBox.SelectedIndex =
                    selectedIndex;
            }
            finally
            {
                _listBox.EndUpdate();
            }
        }

        private void EnsureUniqueName(
            string name,
            int ignoredIndex = -1)
        {
            for (
                int index = 0;
                index < _file.Configurations.Count;
                index++)
            {
                if (index == ignoredIndex)
                    continue;

                string existingName =
                    _file.Configurations[index].Name;

                if (string.Equals(
                        existingName,
                        name,
                        StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidOperationException(
                        $"Esiste già una configurazione chiamata \"{name}\".");
                }
            }
        }

        private string CreateUniqueDuplicateName(
            string originalName)
        {
            string baseName =
                string.IsNullOrWhiteSpace(originalName)
                    ? "Nuova configurazione"
                    : originalName.Trim();

            string candidate =
                baseName + " - Copia";

            int copyNumber = 2;

            while (NameExists(candidate))
            {
                candidate =
                    baseName +
                    " - Copia " +
                    copyNumber;

                copyNumber++;
            }

            return candidate;
        }

        private bool NameExists(
            string name)
        {
            foreach (
                PrintFolderConfiguration configuration
                in _file.Configurations)
            {
                if (string.Equals(
                        configuration.Name,
                        name,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private static void ValidateName(
            string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new InvalidOperationException(
                    "Il nome della configurazione non può essere vuoto.");
            }
        }

        private static PrintFolderConfiguration
            CloneConfiguration(
                PrintFolderConfiguration source)
        {
            string json =
                JsonSerializer.Serialize(
                    source,
                    CloneJsonOptions);

            PrintFolderConfiguration? clone =
                JsonSerializer.Deserialize
                    <PrintFolderConfiguration>(
                        json,
                        CloneJsonOptions);

            return clone
                ?? throw new InvalidOperationException(
                    "Impossibile duplicare la configurazione.");
        }
    }
}