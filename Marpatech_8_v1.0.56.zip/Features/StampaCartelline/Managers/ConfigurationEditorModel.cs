﻿using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class ConfigurationEditorModel
    {
        public PrintFolderConfiguration
            CurrentConfiguration
        { get; private set; }

        public ConfigurationEditorModel()
        {
            CurrentConfiguration =
                new PrintFolderConfiguration();
        }

        public void SetConfiguration(
            PrintFolderConfiguration configuration)
        {
            CurrentConfiguration =
                configuration
                ?? new PrintFolderConfiguration();
        }
    }
}