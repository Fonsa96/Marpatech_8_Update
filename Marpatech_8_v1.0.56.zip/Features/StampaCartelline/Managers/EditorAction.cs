﻿namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public enum EditorAction
    {
        AddProperty,
        DuplicateProperty,
        DeleteProperty,
        MovePropertyUp,
        MovePropertyDown,

        AddWordTemplate,
        DuplicateWordTemplate,
        DeleteWordTemplate,
        MoveWordTemplateUp,
        MoveWordTemplateDown,

        AddWordTag,
        DeleteWordTag,
        BrowseWordTemplate,

    }
}