﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class DashboardConfigurationManager
    {
        private readonly ComboBox _configurationComboBox;

        private List<PrintFolderConfiguration>
            _configurations =
                new List<PrintFolderConfiguration>();

        public DashboardConfigurationManager(
            ComboBox configurationComboBox)
        {
            _configurationComboBox =
                configurationComboBox
                ?? throw new ArgumentNullException(
                    nameof(configurationComboBox));
        }

        public PrintFolderConfiguration?
            SelectedConfiguration
        {
            get
            {
                return _configurationComboBox
                    .SelectedItem
                    as PrintFolderConfiguration;
            }
        }

        public void Load(
            string? configurationNameToRestore = null)
        {
            PrintFolderConfigurationsFile file =
                StampaCartellineStorage.Load();

            _configurations =
                file.Configurations
                ?? new List<PrintFolderConfiguration>();

            _configurationComboBox
                .BeginUpdate();

            try
            {
                _configurationComboBox
                    .DataSource = null;

                _configurationComboBox
                    .DisplayMember =
                        nameof(
                            PrintFolderConfiguration.Name);

                _configurationComboBox
                    .DataSource =
                        _configurations;

                RestoreSelection(
                    configurationNameToRestore);
            }
            finally
            {
                _configurationComboBox
                    .EndUpdate();
            }
        }

        private void RestoreSelection(
            string? configurationName)
        {
            if (_configurations.Count == 0)
            {
                _configurationComboBox
                    .SelectedIndex = -1;

                return;
            }

            int index = -1;

            if (!string.IsNullOrWhiteSpace(
                    configurationName))
            {
                index =
                    _configurations.FindIndex(
                        configuration =>
                            string.Equals(
                                configuration.Name,
                                configurationName,
                                StringComparison
                                    .OrdinalIgnoreCase));
            }

            _configurationComboBox
                .SelectedIndex =
                    index >= 0
                        ? index
                        : 0;
        }
    }
}