﻿using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class GridRuleActions
    {
        private readonly DataGridView _grid;

        public GridRuleActions(DataGridView grid)
        {
            _grid = grid;
        }

        public void Add()
        {
            if (_grid == null)
                return;

            int rowIndex = _grid.Rows.Add(
                string.Empty,
                string.Empty,
                string.Empty,
                true);

            _grid.CurrentCell =
                _grid.Rows[rowIndex].Cells[0];

            _grid.BeginEdit(true);
        }

        public void Duplicate()
        {
            DataGridViewRow? selected =
                GetSelectedRow();

            if (selected == null)
                return;

            int newIndex =
                selected.Index + 1;

            _grid.Rows.Insert(
                newIndex,
                selected.Cells[0].Value,
                selected.Cells[1].Value,
                selected.Cells[2].Value,
                selected.Cells[3].Value);

            SelectRow(newIndex);
        }

        public void Delete()
        {
            DataGridViewRow? selected =
                GetSelectedRow();

            if (selected == null)
                return;

            _grid.Rows.Remove(selected);
        }

        public void MoveUp()
        {
            Move(-1);
        }

        public void MoveDown()
        {
            Move(1);
        }

        private DataGridViewRow? GetSelectedRow()
        {
            if (_grid == null)
                return null;

            if (_grid.CurrentRow == null)
                return null;

            if (_grid.CurrentRow.IsNewRow)
                return null;

            return _grid.CurrentRow;
        }

        private void Move(int direction)
        {
            DataGridViewRow? selected =
                GetSelectedRow();

            if (selected == null)
                return;

            int oldIndex = selected.Index;
            int newIndex = oldIndex + direction;

            if (newIndex < 0 ||
                newIndex >= _grid.Rows.Count)
            {
                return;
            }

            DataGridViewRow movedRow =
                (DataGridViewRow)selected.Clone();

            for (int columnIndex = 0;
                 columnIndex < selected.Cells.Count;
                 columnIndex++)
            {
                movedRow.Cells[columnIndex].Value =
                    selected.Cells[columnIndex].Value;
            }

            _grid.Rows.RemoveAt(oldIndex);
            _grid.Rows.Insert(newIndex, movedRow);

            SelectRow(newIndex);
        }

        private void SelectRow(int rowIndex)
        {
            _grid.ClearSelection();

            _grid.Rows[rowIndex].Selected = true;
            _grid.CurrentCell =
                _grid.Rows[rowIndex].Cells[0];
        }
    }
}