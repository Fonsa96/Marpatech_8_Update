﻿using System;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class WordActions
    {
        private readonly EditorContext _context;
        private readonly ConfigurationEditorModel _model;

        private WordTemplateConfiguration?
            _loadedTemplate;

        private bool _isChangingTemplate;

        public WordActions(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context = context;
            _model = model;

        }

        public void AddTemplate()
        {
            SaveLoadedTemplate();

            WordTemplateConfiguration template =
                new WordTemplateConfiguration
                {
                    Name =
                        CreateUniqueTemplateName()
                };

            _model.CurrentConfiguration
                .WordTemplates
                .Add(template);

            RefreshTemplateList(
                template);

            LoadTemplate(
                template);
        }

        public void SelectTemplate()
        {
            if (_isChangingTemplate)
                return;

            WordTemplateConfiguration? selected =
                GetSelectedTemplate();

            if (selected == null)
                return;

            if (ReferenceEquals(
                    selected,
                    _loadedTemplate))
            {
                return;
            }

            SaveLoadedTemplate();
            LoadTemplate(selected);
        }

        public void DuplicateTemplate()
        {
            WordTemplateConfiguration? selected =
                GetSelectedTemplate();

            if (selected == null)
                return;

            SaveLoadedTemplate();

            WordTemplateConfiguration copy =
                new WordTemplateConfiguration
                {
                    Name =
                        CreateUniqueTemplateName(
                            selected.Name +
                            " - Copia"),

                    TemplatePath =
                        selected.TemplatePath
                };

            foreach (
                WordPlaceholderMapping mapping
                in selected.PlaceholderMappings)
            {
                copy.PlaceholderMappings.Add(
                    new WordPlaceholderMapping
                    {
                        WordText =
                            mapping.WordText,

                        Placeholder =
                            mapping.Placeholder,

                        IsInventorTag =
                            mapping.IsInventorTag
                    });
            }

            int selectedIndex =
                _model.CurrentConfiguration
                    .WordTemplates
                    .IndexOf(selected);

            int newIndex =
                selectedIndex + 1;

            _model.CurrentConfiguration
                .WordTemplates
                .Insert(
                    newIndex,
                    copy);

            RefreshTemplateList(
                copy);

            LoadTemplate(copy);
        }

        public void DeleteTemplate()
        {
            WordTemplateConfiguration? selected =
                GetSelectedTemplate();

            if (selected == null)
                return;

            int selectedIndex =
                _model.CurrentConfiguration
                    .WordTemplates
                    .IndexOf(selected);

            if (ReferenceEquals(
                    selected,
                    _loadedTemplate))
            {
                _loadedTemplate = null;
            }

            _model.CurrentConfiguration
                .WordTemplates
                .Remove(selected);

            if (_model.CurrentConfiguration
                    .WordTemplates.Count == 0)
            {
                RefreshTemplateList();
                ClearDetails();
                return;
            }

            int newIndex =
                Math.Min(
                    selectedIndex,
                    _model.CurrentConfiguration
                        .WordTemplates.Count - 1);

            WordTemplateConfiguration newSelection =
                _model.CurrentConfiguration
                    .WordTemplates[newIndex];

            RefreshTemplateList(
                newSelection);

            LoadTemplate(
                newSelection);
        }

        public void MoveTemplateUp()
        {
            MoveTemplate(-1);
        }

        public void MoveTemplateDown()
        {
            MoveTemplate(1);
        }

        public void AddTag()
        {
            if (_loadedTemplate == null)
                return;

            DataGridView grid =
                _context.WordMappingsGrid;

            int rowIndex =
                grid.Rows.Add(
                    string.Empty,
                    string.Empty,
                    false);

            grid.CurrentCell =
                grid.Rows[rowIndex]
                    .Cells[0];

            grid.Focus();
            grid.BeginEdit(true);
        }

        public void InsertInventorTag(
            string inventorTag)
        {
            if (_loadedTemplate == null)
                return;

            if (string.IsNullOrWhiteSpace(
                    inventorTag))
            {
                return;
            }

            DataGridView grid =
                _context.WordMappingsGrid;

            DataGridViewRow? targetRow =
                null;

            if (grid.CurrentCell != null &&
                grid.CurrentCell.ColumnIndex == 1 &&
                !grid.CurrentCell
                    .OwningRow
                    .IsNewRow)
            {
                targetRow =
                    grid.CurrentCell.OwningRow;
            }

            if (targetRow == null)
            {
                int rowIndex =
                    grid.Rows.Add();

                targetRow =
                    grid.Rows[rowIndex];
            }

            /*
             * La seconda colonna contiene il valore
             * da sostituire nel documento Word.
             */
            targetRow.Cells[1].Value =
                inventorTag.Trim();

            /*
             * Il Tag della riga registra che il valore
             * è stato inserito dal menu dei Tag Inventor.
             */
            targetRow.Tag =
                true;

            grid.CurrentCell =
                targetRow.Cells[1];

            grid.EndEdit();
        }

        public void DeleteTag()
        {
            DataGridView grid =
                _context.WordMappingsGrid;

            if (grid.CurrentRow == null ||
                grid.CurrentRow.IsNewRow)
            {
                return;
            }

            grid.Rows.Remove(
                grid.CurrentRow);
        }

        public void BrowseTemplate()
        {
            using (
                OpenFileDialog dialog =
                    new OpenFileDialog())
            {
                dialog.Title =
                    "Seleziona il modello Word";

                dialog.Filter =
                    "Documenti Word (*.docx)|*.docx";

                dialog.CheckFileExists =
                    true;

                dialog.Multiselect =
                    false;

                if (dialog.ShowDialog(
                        _context.EditorForm) !=
                    DialogResult.OK)
                {
                    return;
                }

                _context.WordTemplatePath.Text =
                    dialog.FileName;

                if (string.IsNullOrWhiteSpace(
                        _context.WordTemplateName.Text))
                {
                    _context.WordTemplateName.Text =
                        Path.GetFileNameWithoutExtension(
                            dialog.FileName);
                }
            }
        }

        private void SaveLoadedTemplate()
        {
            if (_isChangingTemplate ||
                _loadedTemplate == null)
            {
                return;
            }

            if (!_model.CurrentConfiguration
                    .WordTemplates
                    .Contains(_loadedTemplate))
            {
                _loadedTemplate = null;
                return;
            }

            string name =
                _context.WordTemplateName
                    .Text
                    .Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                name =
                    "Template";
            }

            _loadedTemplate.Name =
                name;

            _loadedTemplate.TemplatePath =
                _context.WordTemplatePath
                    .Text
                    .Trim();

            SaveMappings(
                _loadedTemplate);

            UpdateTemplateListItem(
                _loadedTemplate);
        }

        private void SaveMappings(
            WordTemplateConfiguration template)
        {
            DataGridView grid =
                _context.WordMappingsGrid;

            grid.EndEdit();

            template.PlaceholderMappings.Clear();

            foreach (
                DataGridViewRow row
                in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                string wordText =
                    row.Cells[0]
                        .Value?
                        .ToString()?
                        .Trim()
                    ?? string.Empty;

                string placeholder =
                    row.Cells[1]
                        .Value?
                        .ToString()?
                        .Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        wordText) &&
                    string.IsNullOrWhiteSpace(
                        placeholder))
                {
                    continue;
                }

                bool isInventorTag =
                    row.Cells["IsInventorTag"]
                        .Value is bool value &&
                    value;

                template.PlaceholderMappings.Add(
                    new WordPlaceholderMapping
                    {
                        WordText =
                            wordText,

                        Placeholder =
                            placeholder,

                        IsInventorTag =
                            isInventorTag
                    });
            }
        }

        private void LoadTemplate(
            WordTemplateConfiguration template)
        {
            _isChangingTemplate = true;

            try
            {
                _context.WordTemplateName.Text =
                    template.Name;

                _context.WordTemplatePath.Text =
                    template.TemplatePath;

                DataGridView grid =
                    _context.WordMappingsGrid;

                grid.Rows.Clear();

                foreach (
                    WordPlaceholderMapping mapping
                    in template.PlaceholderMappings)
                {
                    grid.Rows.Add(
                        mapping.WordText,
                        mapping.Placeholder,
                        mapping.IsInventorTag);
                }

                _loadedTemplate =
                    template;
            }
            finally
            {
                _isChangingTemplate = false;
            }
        }

        private void MoveTemplate(
            int direction)
        {
            WordTemplateConfiguration? selected =
                GetSelectedTemplate();

            if (selected == null)
                return;

            SaveLoadedTemplate();

            int oldIndex =
                _model.CurrentConfiguration
                    .WordTemplates
                    .IndexOf(selected);

            int newIndex =
                oldIndex + direction;

            if (newIndex < 0 ||
                newIndex >=
                _model.CurrentConfiguration
                    .WordTemplates.Count)
            {
                return;
            }

            _model.CurrentConfiguration
                .WordTemplates
                .RemoveAt(oldIndex);

            _model.CurrentConfiguration
                .WordTemplates
                .Insert(
                    newIndex,
                    selected);

            RefreshTemplateList(
                selected);

            LoadTemplate(
                selected);
        }

        private void RefreshTemplateList(
            WordTemplateConfiguration?
                selectedTemplate = null)
        {
            ListBox list =
                _context.WordTemplatesList;

            _isChangingTemplate = true;

            try
            {
                list.BeginUpdate();
                list.Items.Clear();

                foreach (
                    WordTemplateConfiguration template
                    in _model.CurrentConfiguration
                        .WordTemplates)
                {
                    list.Items.Add(
                        template);
                }

                list.DisplayMember =
                    nameof(
                        WordTemplateConfiguration.Name);

                if (selectedTemplate != null)
                {
                    list.SelectedItem =
                        selectedTemplate;
                }
                else
                {
                    list.SelectedIndex =
                        -1;
                }
            }
            finally
            {
                list.EndUpdate();
                _isChangingTemplate = false;
            }
        }

        private void UpdateTemplateListItem(
            WordTemplateConfiguration template)
        {
            ListBox list =
                _context.WordTemplatesList;

            int index =
                list.Items.IndexOf(
                    template);

            if (index < 0)
                return;

            int selectedIndex =
                list.SelectedIndex;

            _isChangingTemplate = true;

            try
            {
                /*
                 * Forza il ListBox a rileggere
                 * il valore Name senza sostituire
                 * l'oggetto del modello.
                 */
                list.Items[index] =
                    template;

                list.DisplayMember =
                    string.Empty;

                list.DisplayMember =
                    nameof(
                        WordTemplateConfiguration.Name);

                if (selectedIndex >= 0 &&
                    selectedIndex <
                    list.Items.Count)
                {
                    list.SelectedIndex =
                        selectedIndex;
                }
            }
            finally
            {
                _isChangingTemplate = false;
            }
        }


        private WordTemplateConfiguration?
            GetSelectedTemplate()
        {
            return
                _context.WordTemplatesList
                    .SelectedItem
                as WordTemplateConfiguration;
        }

        private string CreateUniqueTemplateName(
            string baseName =
                "Nuovo template")
        {
            string candidate =
                baseName;

            int counter =
                2;

            while (
                ContainsTemplateName(
                    candidate))
            {
                candidate =
                    baseName +
                    " " +
                    counter;

                counter++;
            }

            return candidate;
        }

        private bool ContainsTemplateName(
            string name)
        {
            foreach (
                WordTemplateConfiguration template
                in _model.CurrentConfiguration
                    .WordTemplates)
            {
                if (string.Equals(
                        template.Name,
                        name,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private void ClearDetails()
        {
            _isChangingTemplate = true;

            try
            {
                _context.WordTemplateName.Clear();
                _context.WordTemplatePath.Clear();
                _context.WordMappingsGrid
                    .Rows
                    .Clear();

                _loadedTemplate = null;
            }
            finally
            {
                _isChangingTemplate = false;
            }
        }
        public void Load()
        {
            _loadedTemplate = null;

            WordTemplateConfiguration? firstTemplate = null;

            if (_model.CurrentConfiguration
                    .WordTemplates.Count > 0)
            {
                firstTemplate =
                    _model.CurrentConfiguration
                        .WordTemplates[0];
            }

            RefreshTemplateList(
                firstTemplate);

            if (firstTemplate == null)
            {
                ClearDetails();
                return;
            }

            LoadTemplate(
                firstTemplate);
        }

        public void Commit()
        {
            SaveLoadedTemplate();
        }
    }
}