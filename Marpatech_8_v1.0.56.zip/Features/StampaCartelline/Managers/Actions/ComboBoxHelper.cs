﻿using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    internal static class ComboBoxHelper
    {
        public static void SelectItem(
            ComboBox comboBox,
            string value)
        {
            comboBox.SelectedIndex = -1;

            for (
                int index = 0;
                index < comboBox.Items.Count;
                index++)
            {
                string itemText =
                    comboBox.Items[index]?
                        .ToString()
                    ?? string.Empty;

                if (!string.Equals(
                        itemText,
                        value,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                comboBox.SelectedIndex =
                    index;

                return;
            }
        }
    }
}