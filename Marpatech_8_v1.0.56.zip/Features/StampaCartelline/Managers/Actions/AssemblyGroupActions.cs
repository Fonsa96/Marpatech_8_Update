﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class AssemblyGroupAction
    {
        private readonly EditorContext _context;

        private readonly ConfigurationEditorModel _model;

        private bool _isLoading;

        private bool _isChangingMethod;

        private PrintFolderConfiguration Configuration
        {
            get
            {
                return _model.CurrentConfiguration;
            }
        }

        public AssemblyGroupAction(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context =
                context;

            _model =
                model;

            ConfigureEvents();

            UpdateMethodControls();
        }

        public void BeginLoading()
        {
            _isLoading =
                true;
        }

        public void EndLoading()
        {
            _isLoading =
                false;
        }

        public void Load()
        {
            bool wasLoading =
                _isLoading;

            _isLoading =
                true;

            try
            {
                AssemblyGroupsConfiguration configuration =
                    Configuration.AssemblyGroups
                    ?? new AssemblyGroupsConfiguration();

                _context.GroupsIncludeInPrint.Checked =
                    configuration.IncludeInPrintProcess;

                _context.GroupsMethod1Enabled.Checked =
                    configuration.Method1Enabled;

                _context.GroupsMethod2Enabled.Checked =
                    configuration.Method2Enabled;

                _context
                    .GroupsMethod2MainAssemblyCodePrefix
                    .Text =
                        configuration
                            .Method2MainAssemblyCodePrefix
                        ?? string.Empty;

                /*
                 * Sicurezza:
                 * se un vecchio JSON avesse entrambi true,
                 * manteniamo Metodo 1.
                 */
                if (_context.GroupsMethod1Enabled.Checked &&
                    _context.GroupsMethod2Enabled.Checked)
                {
                    _context.GroupsMethod2Enabled.Checked =
                        false;
                }

                LoadGrid(
                    _context.GroupsMethod1Grid,
                    configuration.Method1Rows);

                LoadGrid(
                    _context.GroupsMethod2Grid,
                    configuration.Method2Rows);

                UpdateMethodControls();
            }
            finally
            {
                _isLoading =
                    wasLoading;
            }
        }

        public void Save()
        {
            if (_isLoading)
                return;

            Configuration.AssemblyGroups ??=
                new AssemblyGroupsConfiguration();

            AssemblyGroupsConfiguration configuration =
                Configuration.AssemblyGroups;

            configuration.IncludeInPrintProcess =
                _context.GroupsIncludeInPrint.Checked;

            configuration.Method1Enabled =
                _context.GroupsMethod1Enabled.Checked;

            configuration.Method2Enabled =
                _context.GroupsMethod2Enabled.Checked;

            configuration.Method2MainAssemblyCodePrefix =
                _context
                    .GroupsMethod2MainAssemblyCodePrefix
                    .Text
                    .Trim();

            configuration.Method1Rows =
                ReadGrid(
                    _context.GroupsMethod1Grid);

            configuration.Method2Rows =
                ReadGrid(
                    _context.GroupsMethod2Grid);
        }

        private void ConfigureEvents()
        {
            _context.GroupsIncludeInPrint.CheckedChanged +=
                (_, _) =>
                {
                    Save();
                };

            _context.GroupsMethod1Enabled.CheckedChanged +=
                (_, _) =>
                {
                    Method1CheckedChanged();
                };

            _context.GroupsMethod2Enabled.CheckedChanged +=
                (_, _) =>
                {
                    Method2CheckedChanged();
                };


            _context.GroupsMethod1Add.Click +=
                (_, _) =>
                {
                    AddRule(
                        _context.GroupsMethod1Grid,
                        "Metodo 1");
                };

            _context.GroupsMethod1Edit.Click +=
                (_, _) =>
                {
                    EditRule(
                        _context.GroupsMethod1Grid,
                        "Metodo 1");
                };

            _context.GroupsMethod1Delete.Click +=
                (_, _) =>
                {
                    DeleteRule(
                        _context.GroupsMethod1Grid);
                };

            _context.GroupsMethod1Up.Click +=
                (_, _) =>
                {
                    MoveRule(
                        _context.GroupsMethod1Grid,
                        -1);
                };

            _context.GroupsMethod1Down.Click +=
                (_, _) =>
                {
                    MoveRule(
                        _context.GroupsMethod1Grid,
                        1);
                };


            _context.GroupsMethod2Add.Click +=
                (_, _) =>
                {
                    AddRule(
                        _context.GroupsMethod2Grid,
                        "Metodo 2");
                };

            _context.GroupsMethod2Edit.Click +=
                (_, _) =>
                {
                    EditRule(
                        _context.GroupsMethod2Grid,
                        "Metodo 2");
                };

            _context.GroupsMethod2Delete.Click +=
                (_, _) =>
                {
                    DeleteRule(
                        _context.GroupsMethod2Grid);
                };

            _context.GroupsMethod2Up.Click +=
                (_, _) =>
                {
                    MoveRule(
                        _context.GroupsMethod2Grid,
                        -1);
                };

            _context.GroupsMethod2Down.Click +=
                (_, _) =>
                {
                    MoveRule(
                        _context.GroupsMethod2Grid,
                        1);
                };


            _context.GroupsMethod1Grid.CellDoubleClick +=
                (_, e) =>
                {
                    if (e.RowIndex >= 0)
                    {
                        EditRule(
                            _context.GroupsMethod1Grid,
                            "Metodo 1");
                    }
                };

            _context.GroupsMethod2Grid.CellDoubleClick +=
                (_, e) =>
                {
                    if (e.RowIndex >= 0)
                    {
                        EditRule(
                            _context.GroupsMethod2Grid,
                            "Metodo 2");
                    }
                };
        }

        private void Method1CheckedChanged()
        {
            if (_isLoading ||
                _isChangingMethod)
            {
                return;
            }

            _isChangingMethod =
                true;

            try
            {
                if (_context.GroupsMethod1Enabled.Checked)
                {
                    _context.GroupsMethod2Enabled.Checked =
                        false;
                }

                UpdateMethodControls();

                Save();
            }
            finally
            {
                _isChangingMethod =
                    false;
            }
        }

        private void Method2CheckedChanged()
        {
            if (_isLoading ||
                _isChangingMethod)
            {
                return;
            }

            _isChangingMethod =
                true;

            try
            {
                if (_context.GroupsMethod2Enabled.Checked)
                {
                    _context.GroupsMethod1Enabled.Checked =
                        false;
                }

                UpdateMethodControls();

                Save();
            }
            finally
            {
                _isChangingMethod =
                    false;
            }
        }

        private void UpdateMethodControls()
        {
            bool method1Enabled =
                _context.GroupsMethod1Enabled.Checked;

            bool method2Enabled =
                _context.GroupsMethod2Enabled.Checked;

            _context.GroupsMethod1Grid.Enabled =
                method1Enabled;

            _context.GroupsMethod1Add.Enabled =
                method1Enabled;

            _context.GroupsMethod1Edit.Enabled =
                method1Enabled;

            _context.GroupsMethod1Delete.Enabled =
                method1Enabled;

            _context.GroupsMethod1Up.Enabled =
                method1Enabled;

            _context.GroupsMethod1Down.Enabled =
                method1Enabled;


            _context.GroupsMethod2Grid.Enabled =
                method2Enabled;

            _context.GroupsMethod2Add.Enabled =
                method2Enabled;

            _context.GroupsMethod2Edit.Enabled =
                method2Enabled;

            _context.GroupsMethod2Delete.Enabled =
                method2Enabled;

            _context.GroupsMethod2Up.Enabled =
                method2Enabled;

            _context.GroupsMethod2Down.Enabled =
                method2Enabled;
        }

        private void AddRule(
            DataGridView grid,
            string methodName)
        {
            AssemblyGroupSearchRule? rule =
                ShowRuleEditor(
                    methodName,
                    null);

            if (rule == null)
                return;

            int rowIndex =
                grid.Rows.Add(
                    rule.CodePrefix,
                    rule.DrawingSearchPath);

            grid.ClearSelection();

            grid.Rows[rowIndex]
                .Selected =
                    true;

            Save();
        }

        private void EditRule(
            DataGridView grid,
            string methodName)
        {
            if (grid.CurrentRow == null ||
                grid.CurrentRow.IsNewRow)
            {
                return;
            }

            DataGridViewRow row =
                grid.CurrentRow;

            AssemblyGroupSearchRule current =
                new AssemblyGroupSearchRule
                {
                    CodePrefix =
                        row.Cells["CodePrefix"]
                            .Value?
                            .ToString()
                            ?.Trim()
                        ?? string.Empty,

                    DrawingSearchPath =
                        row.Cells["DrawingSearchPath"]
                            .Value?
                            .ToString()
                            ?.Trim()
                        ?? string.Empty
                };

            AssemblyGroupSearchRule? edited =
                ShowRuleEditor(
                    methodName,
                    current);

            if (edited == null)
                return;

            row.Cells["CodePrefix"].Value =
                edited.CodePrefix;

            row.Cells["DrawingSearchPath"].Value =
                edited.DrawingSearchPath;

            Save();
        }

        private void DeleteRule(
            DataGridView grid)
        {
            if (grid.CurrentRow == null ||
                grid.CurrentRow.IsNewRow)
            {
                return;
            }

            string prefix =
                grid.CurrentRow
                    .Cells["CodePrefix"]
                    .Value?
                    .ToString()
                ?? string.Empty;

            DialogResult result =
                MessageBox.Show(
                    _context.EditorForm,
                    "Vuoi eliminare questa regola?\n\n" +
                    prefix,
                    "Gruppi di montaggio",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning,
                    MessageBoxDefaultButton.Button2);

            if (result != DialogResult.Yes)
                return;

            grid.Rows.Remove(
                grid.CurrentRow);

            Save();
        }

        private void MoveRule(
            DataGridView grid,
            int direction)
        {
            if (grid.CurrentRow == null ||
                grid.CurrentRow.IsNewRow)
            {
                return;
            }

            int currentIndex =
                grid.CurrentRow.Index;

            int newIndex =
                currentIndex +
                direction;

            if (newIndex < 0 ||
                newIndex >=
                    grid.Rows.Count)
            {
                return;
            }

            string prefix =
                grid.CurrentRow
                    .Cells["CodePrefix"]
                    .Value?
                    .ToString()
                ?? string.Empty;

            string path =
                grid.CurrentRow
                    .Cells["DrawingSearchPath"]
                    .Value?
                    .ToString()
                ?? string.Empty;

            grid.Rows.RemoveAt(
                currentIndex);

            grid.Rows.Insert(
                newIndex,
                prefix,
                path);

            grid.ClearSelection();

            grid.Rows[newIndex]
                .Selected =
                    true;

            grid.CurrentCell =
                grid.Rows[newIndex]
                    .Cells[0];

            Save();
        }

        private static void LoadGrid(
            DataGridView grid,
            IEnumerable<AssemblyGroupSearchRule>? rules)
        {
            grid.Rows.Clear();

            if (rules == null)
                return;

            foreach (AssemblyGroupSearchRule rule
                in rules)
            {
                if (rule == null)
                    continue;

                string prefix =
                    rule.CodePrefix
                        ?.Trim()
                    ?? string.Empty;

                string path =
                    rule.DrawingSearchPath
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix) &&
                    string.IsNullOrWhiteSpace(
                        path))
                {
                    continue;
                }

                grid.Rows.Add(
                    prefix,
                    path);
            }
        }

        private static List<AssemblyGroupSearchRule>
            ReadGrid(
                DataGridView grid)
        {
            List<AssemblyGroupSearchRule> rules =
                new List<AssemblyGroupSearchRule>();

            foreach (DataGridViewRow row
                in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                string prefix =
                    row.Cells["CodePrefix"]
                        .Value?
                        .ToString()
                        ?.Trim()
                    ?? string.Empty;

                string path =
                    row.Cells["DrawingSearchPath"]
                        .Value?
                        .ToString()
                        ?.Trim()
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(
                        prefix) &&
                    string.IsNullOrWhiteSpace(
                        path))
                {
                    continue;
                }

                rules.Add(
                    new AssemblyGroupSearchRule
                    {
                        CodePrefix =
                            prefix,

                        DrawingSearchPath =
                            path
                    });
            }

            return rules;
        }

        private AssemblyGroupSearchRule?
            ShowRuleEditor(
                string methodName,
                AssemblyGroupSearchRule? current)
        {
            using Form dialog =
                new Form();

            dialog.Text =
                current == null
                    ? "Aggiungi regola"
                    : "Modifica regola";

            dialog.StartPosition =
                FormStartPosition.CenterParent;

            dialog.FormBorderStyle =
                FormBorderStyle.FixedDialog;

            dialog.MaximizeBox =
                false;

            dialog.MinimizeBox =
                false;

            dialog.ShowInTaskbar =
                false;

            dialog.ClientSize =
                new Size(
                    650,
                    235);


            Label lblMethod =
                new Label();

            lblMethod.Text =
                methodName;

            lblMethod.Font =
                new Font(
                    "Segoe UI",
                    10,
                    FontStyle.Bold);

            lblMethod.AutoSize =
                true;

            lblMethod.Location =
                new Point(
                    20,
                    15);


            Label lblPrefix =
                new Label();

            lblPrefix.Text =
                "Prefisso CODICE";

            lblPrefix.AutoSize =
                true;

            lblPrefix.Location =
                new Point(
                    20,
                    55);


            TextBox txtPrefix =
                new TextBox();

            txtPrefix.Location =
                new Point(
                    20,
                    78);

            txtPrefix.Size =
                new Size(
                    610,
                    27);

            txtPrefix.Text =
                current?.CodePrefix
                ?? string.Empty;


            Label lblPath =
                new Label();

            lblPath.Text =
                "Percorso server ricerca IDW";

            lblPath.AutoSize =
                true;

            lblPath.Location =
                new Point(
                    20,
                    120);


            TextBox txtPath =
                new TextBox();

            txtPath.Location =
                new Point(
                    20,
                    143);

            txtPath.Size =
                new Size(
                    500,
                    27);

            txtPath.Text =
                current?.DrawingSearchPath
                ?? string.Empty;


            Button btnBrowse =
                new Button();

            btnBrowse.Text =
                "Sfoglia";

            btnBrowse.Location =
                new Point(
                    530,
                    141);

            btnBrowse.Size =
                new Size(
                    100,
                    30);


            Button btnOk =
                new Button();

            btnOk.Text =
                "OK";

            btnOk.DialogResult =
                DialogResult.OK;

            btnOk.Location =
                new Point(
                    420,
                    190);

            btnOk.Size =
                new Size(
                    100,
                    32);


            Button btnCancel =
                new Button();

            btnCancel.Text =
                "Annulla";

            btnCancel.DialogResult =
                DialogResult.Cancel;

            btnCancel.Location =
                new Point(
                    530,
                    190);

            btnCancel.Size =
                new Size(
                    100,
                    32);


            btnBrowse.Click +=
                (_, _) =>
                {
                    using FolderBrowserDialog folderDialog =
                        new FolderBrowserDialog();

                    folderDialog.Description =
                        "Seleziona la cartella server in cui cercare gli IDW";

                    folderDialog.UseDescriptionForTitle =
                        true;

                    string currentPath =
                        txtPath.Text.Trim();

                    if (!string.IsNullOrWhiteSpace(
                            currentPath) &&
                        System.IO.Directory.Exists(
                            currentPath))
                    {
                        folderDialog.SelectedPath =
                            currentPath;
                    }

                    if (folderDialog.ShowDialog(
                            dialog) ==
                        DialogResult.OK)
                    {
                        txtPath.Text =
                            folderDialog.SelectedPath;
                    }
                };


            dialog.Controls.Add(
                lblMethod);

            dialog.Controls.Add(
                lblPrefix);

            dialog.Controls.Add(
                txtPrefix);

            dialog.Controls.Add(
                lblPath);

            dialog.Controls.Add(
                txtPath);

            dialog.Controls.Add(
                btnBrowse);

            dialog.Controls.Add(
                btnOk);

            dialog.Controls.Add(
                btnCancel);

            dialog.AcceptButton =
                btnOk;

            dialog.CancelButton =
                btnCancel;


            if (dialog.ShowDialog(
                    _context.EditorForm) !=
                DialogResult.OK)
            {
                return null;
            }

            string prefix =
                txtPrefix.Text.Trim();

            string path =
                txtPath.Text.Trim();

            if (string.IsNullOrWhiteSpace(
                    prefix))
            {
                MessageBox.Show(
                    _context.EditorForm,
                    "Inserisci il prefisso CODICE.",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return null;
            }

            if (string.IsNullOrWhiteSpace(
                    path))
            {
                MessageBox.Show(
                    _context.EditorForm,
                    "Seleziona il percorso server di ricerca IDW.",
                    "Gruppi di montaggio",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return null;
            }

            return new AssemblyGroupSearchRule
            {
                CodePrefix =
                    prefix,

                DrawingSearchPath =
                    path
            };
        }
    }
}