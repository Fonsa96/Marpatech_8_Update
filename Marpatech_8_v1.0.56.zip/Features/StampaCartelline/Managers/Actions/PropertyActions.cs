﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Managers;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class PropertyActions
    {
        private readonly EditorContext _context;
        private readonly ConfigurationEditorModel _model;
        private bool _isLoadingDetails;

        private InventorPropertyDefinition? _loadedProperty;
        private bool _isChangingSelection;

        public PropertyActions(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context = context;
            _model = model;
        }

        public void Add()
        {
            if (!ValidateDetails())
                return;

            InventorPropertyDefinition property =
                CreateProperty();

            property.Tag =
                CreateUniqueDisplayName(
                    property.Tag);

            _model.CurrentConfiguration
                .InventorProperties
                .Add(property);

            RefreshPropertyList();

            if (_context.PropertiesList.Items.Count > 0)
            {
                SelectItem(
                    _context.PropertiesList.Items[
                        _context.PropertiesList.Items.Count - 1]);
            }
        }

        public void Edit()
        {
            ListViewItem? selected =
                GetSelectedItem();

            if (selected == null)
            {
                MessageBox.Show(
                    _context.EditorForm,
                    "Seleziona il parametro da modificare.",
                    "Nessun parametro selezionato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            if (!ValidateDetails())
                return;

            EnsureSubItems(selected);

            selected.SubItems[0].Text =
                _context.PropertyDisplayName.Text.Trim();

            selected.SubItems[1].Text =
                _context.PropertyInternalName.Text.Trim();

            selected.SubItems[2].Text =
                _context.PropertyEditable.Checked
                    ? "Sì"
                    : "No";

            selected.EnsureVisible();

            RefreshDependentControls();
        }

        public void Duplicate()
        {
            InventorPropertyDefinition? selected =
                GetSelectedProperty();

            if (selected == null)
                return;

            InventorPropertyDefinition copy =
                new InventorPropertyDefinition
                {
                    Tag =
                        CreateUniqueDisplayName(
                            selected.Tag + " - Copia"),

                    InventorPropertyName =
                        selected.InventorPropertyName,

                    EditableFromDashboard =
                        selected.EditableFromDashboard
                };

            int index =
                _model.CurrentConfiguration
                    .InventorProperties
                    .IndexOf(selected);

            _model.CurrentConfiguration
                .InventorProperties
                .Insert(index + 1, copy);

            RefreshPropertyList();

            SelectItem(
                _context.PropertiesList.Items[
                    index + 1]);
        }
        public void Delete()
        {
            InventorPropertyDefinition? selected =
                GetSelectedProperty();

            if (selected == null)
                return;

            int index =
                _model.CurrentConfiguration
                    .InventorProperties
                    .IndexOf(selected);

            if (ReferenceEquals(
                    selected,
                    _loadedProperty))
            {
                _loadedProperty = null;
            }

            _model.CurrentConfiguration
                .InventorProperties
                .Remove(selected);

            RefreshPropertyList();

            if (_context.PropertiesList.Items.Count == 0)
            {
                ClearDetails();
                return;
            }

            index =
                Math.Min(
                    index,
                    _context.PropertiesList.Items.Count - 1);

            SelectItem(
                _context.PropertiesList.Items[index]);
        }
        public void MoveUp()
        {
            MoveSelectedItem(-1);
        }

        public void MoveDown()
        {
            MoveSelectedItem(1);
        }

        public void SelectProperty()
        {
            if (_isChangingSelection ||
                _isLoadingDetails)
            {
                return;
            }

            InventorPropertyDefinition? selected =
                GetSelectedProperty();

            if (selected == null)
                return;

            if (ReferenceEquals(
                    selected,
                    _loadedProperty))
            {
                return;
            }

            SaveLoadedProperty();
            LoadProperty(selected);
        }

        private bool ValidateDetails()
        {
            if (string.IsNullOrWhiteSpace(
                    _context.PropertyDisplayName.Text))
            {
                ShowMissingValue(
                    "Inserisci il Tag.",
                    _context.PropertyDisplayName);

                return false;
            }

            if (string.IsNullOrWhiteSpace(
                    _context.PropertyInternalName.Text))
            {
                ShowMissingValue(
                    "Inserisci la proprietà Inventor.",
                    _context.PropertyInternalName);

                return false;
            }

            return true;
        }

        private void ShowMissingValue(
            string message,
            Control control)
        {
            MessageBox.Show(
                _context.EditorForm,
                message,
                "Dato mancante",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);

            control.Focus();
        }

        private ListViewItem
            CreatePropertyItemFromDetails()
        {
            string displayName =
                CreateUniqueDisplayName(
                    _context.PropertyDisplayName.Text.Trim());

            ListViewItem item =
                new ListViewItem(displayName);

            item.SubItems.Add(
                _context.PropertyInternalName.Text.Trim());

            item.SubItems.Add(
                _context.PropertyEditable.Checked
                    ? "Sì"
                    : "No");

            return item;
        }

        private ListViewItem? GetSelectedItem()
        {
            if (_context.PropertiesList.SelectedItems.Count == 0)
                return null;

            return _context.PropertiesList.SelectedItems[0];
        }

        private void SelectItem(
            ListViewItem item)
        {
            SaveLoadedProperty();

            _isChangingSelection = true;

            try
            {
                _context.PropertiesList
                    .SelectedItems
                    .Clear();

                item.Selected = true;
                item.Focused = true;
                item.EnsureVisible();
            }
            finally
            {
                _isChangingSelection = false;
            }

            InventorPropertyDefinition? property =
                item.Tag
                as InventorPropertyDefinition;

            if (property != null)
            {
                LoadProperty(property);
            }
        }

        private InventorPropertyDefinition?
    GetSelectedProperty()
        {
            ListViewItem? item =
                GetSelectedItem();

            if (item == null)
                return null;

            return item.Tag
                as InventorPropertyDefinition;
        }

        private void MoveSelectedItem(
            int direction)
        {
            InventorPropertyDefinition? selected =
                GetSelectedProperty();

            if (selected == null)
                return;

            int oldIndex =
                _model.CurrentConfiguration
                    .InventorProperties
                    .IndexOf(selected);

            int newIndex =
                oldIndex + direction;

            if (newIndex < 0 ||
                newIndex >=
                _model.CurrentConfiguration
                    .InventorProperties.Count)
            {
                return;
            }

            _model.CurrentConfiguration
                .InventorProperties
                .RemoveAt(oldIndex);

            _model.CurrentConfiguration
                .InventorProperties
                .Insert(
                    newIndex,
                    selected);

            RefreshPropertyList();

            SelectItem(
                _context.PropertiesList.Items[
                    newIndex]);
        }

        private void ClearDetails()
        {
            _isLoadingDetails = true;

            try
            {
                _context.PropertyDisplayName.Clear();
                _context.PropertyInternalName.Clear();
                _context.PropertyEditable.Checked = false;

                _loadedProperty = null;
            }
            finally
            {
                _isLoadingDetails = false;
            }
        }

        private void EnsureSubItems(
            ListViewItem item)
        {
            while (item.SubItems.Count < 3)
            {
                item.SubItems.Add(
                    string.Empty);
            }
        }

        private void RefreshDependentControls()
        {
            _context.RefreshDeterminingAttributes(
                _model.CurrentConfiguration
                    .InventorProperties);
        }

        private string CreateUniqueDisplayName(
            string baseName)
        {
            string candidate =
                baseName;

            int counter = 2;

            while (ContainsDisplayName(candidate))
            {
                candidate =
                    baseName +
                    " " +
                    counter;

                counter++;
            }

            return candidate;
        }

        private bool ContainsDisplayName(
            string displayName)
        {
            foreach (
                ListViewItem item
                in _context.PropertiesList.Items)
            {
                if (string.Equals(
                        item.Text,
                        displayName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }
        private void SaveLoadedProperty()
        {
            if (_loadedProperty == null)
                return;

            if (!_model.CurrentConfiguration
                    .InventorProperties
                    .Contains(_loadedProperty))
            {
                _loadedProperty = null;
                return;
            }

            string tag =
                _context.PropertyDisplayName.Text.Trim();

            string inventorProperty =
                _context.PropertyInternalName.Text.Trim();

            if (string.IsNullOrWhiteSpace(tag) ||
                string.IsNullOrWhiteSpace(inventorProperty))
            {
                return;
            }

            _loadedProperty.Tag =
                tag;

            _loadedProperty.InventorPropertyName =
                inventorProperty;

            _loadedProperty.EditableFromDashboard =
                _context.PropertyEditable.Checked;

            UpdatePropertyListItem(
                _loadedProperty);

            RefreshDependentControls();
        }
        private void LoadProperty(
            InventorPropertyDefinition property)
        {
            _isLoadingDetails = true;

            try
            {
                _context.PropertyDisplayName.Text =
                    property.Tag;

                _context.PropertyInternalName.Text =
                    property.InventorPropertyName;

                _context.PropertyEditable.Checked =
                    property.EditableFromDashboard;

                _loadedProperty =
                    property;
            }
            finally
            {
                _isLoadingDetails = false;
            }
        }
        private void RefreshPropertyList()
        {
            ListView list =
                _context.PropertiesList;

            list.BeginUpdate();

            try
            {
                list.Items.Clear();

                foreach (
                    InventorPropertyDefinition property
                    in _model.CurrentConfiguration
                        .InventorProperties)
                {
                    ListViewItem item =
                        new ListViewItem(
                            property.Tag);

                    item.SubItems.Add(
                        property.InventorPropertyName);

                    item.SubItems.Add(
                        property.EditableFromDashboard
                            ? "Sì"
                            : "No");

                    item.Tag = property;

                    list.Items.Add(item);
                }
            }
            finally
            {
                list.EndUpdate();
            }

            RefreshDependentControls();
        }
        private InventorPropertyDefinition
    CreateProperty()
        {
            return new InventorPropertyDefinition
            {
                Tag =
                    _context.PropertyDisplayName.Text.Trim(),

                InventorPropertyName =
                    _context.PropertyInternalName.Text.Trim(),

                EditableFromDashboard =
                    _context.PropertyEditable.Checked
            };
        }
        private void UpdatePropertyListItem(
    InventorPropertyDefinition property)
        {
            foreach (
                ListViewItem item
                in _context.PropertiesList.Items)
            {
                if (!ReferenceEquals(
                        item.Tag,
                        property))
                {
                    continue;
                }

                EnsureSubItems(item);

                item.SubItems[0].Text =
                    property.Tag;

                item.SubItems[1].Text =
                    property.InventorPropertyName;

                item.SubItems[2].Text =
                    property.EditableFromDashboard
                        ? "Sì"
                        : "No";

                break;
            }
        }
        public void Load()
        {
            _loadedProperty = null;

            RefreshPropertyList();

            if (_context.PropertiesList.Items.Count == 0)
            {
                ClearDetails();
                return;
            }

            SelectItem(
                _context.PropertiesList.Items[0]);
        }

        public void Commit()
        {
            SaveLoadedProperty();
        }
    }
}