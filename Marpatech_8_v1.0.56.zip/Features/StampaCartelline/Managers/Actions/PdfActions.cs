﻿using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class PdfActions
    {
        private readonly EditorContext _context;
        private readonly ConfigurationEditorModel _model;

        private bool _isLoading;

        private PathBasedPrintConfiguration Configuration
        {
            get
            {
                return _model.CurrentConfiguration
                    .SheetMetalPdfs;
            }
        }

        public PdfActions(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context = context;
            _model = model;
        }

        public void Load()
        {
            bool wasLoading =
                _isLoading;

            _isLoading = true;

            try
            {
                _context.PdfStartPath.Text =
                    Configuration.InitialPath;

                _context.PdfFinalPath.Text =
                    Configuration.FinalPath;

                _context.PdfIncludeInPrint.Checked =
                    Configuration.IncludeInPrintProcess;

                ComboBoxHelper.SelectItem(
                    _context.PdfDeterminingAttribute,
                    Configuration.DeterminingAttributeTag);
            }
            finally
            {
                _isLoading =
                    wasLoading;
            }
        }

        public void Save()
        {
            if (_isLoading)
                return;

            Configuration.InitialPath =
                _context.PdfStartPath.Text.Trim();

            Configuration.FinalPath =
                _context.PdfFinalPath.Text.Trim();

            Configuration.DeterminingAttributeTag =
                _context.PdfDeterminingAttribute
                    .SelectedItem?
                    .ToString()
                ?? string.Empty;

            Configuration.IncludeInPrintProcess =
                _context.PdfIncludeInPrint.Checked;
        }
        public void BeginLoading()
        {
            _isLoading = true;
        }

        public void EndLoading()
        {
            _isLoading = false;
        }
    }
}