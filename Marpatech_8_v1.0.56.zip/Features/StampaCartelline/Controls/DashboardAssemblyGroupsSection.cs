﻿using Marpatech_8.Features.StampaCartelline.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.StampaCartelline.Controls
{
    public class DashboardAssemblyGroupsSection
    {
        private readonly Panel _container;
        private readonly bool _isDarkTheme;

        private bool _isUpdatingControls;

        private StampaCartellineDashboardSession?
            _session;

        private readonly CheckBox
            chkInclude;

        private readonly CheckBox
            chkOnlySelectedStl;

        private readonly TextBox
            txtSelectedStl;

        private readonly CheckBox
            chkOnlySelectedCodes;

        private readonly Label
            lblSelectedCodes;

        private readonly Button
            btnConfigureCodes;

        public event EventHandler?
            ConfigureCodesRequested;

        public DashboardAssemblyGroupsSection(
            Panel container,
            bool isDarkTheme)
        {
            _container =
                container;

            _isDarkTheme =
                isDarkTheme;

            Color titleColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(
                        30,
                        41,
                        59);

            Color inputColor =
                _isDarkTheme
                    ? Color.FromArgb(
                        43,
                        46,
                        55)
                    : Color.White;

            chkInclude =
                new CheckBox();

            chkOnlySelectedStl =
                new CheckBox();

            txtSelectedStl =
                new TextBox();

            chkOnlySelectedCodes =
                new CheckBox();

            lblSelectedCodes =
                new Label();

            btnConfigureCodes =
                new Button();

            BuildControls(
                titleColor,
                inputColor);
        }

        public void LoadSession(
            StampaCartellineDashboardSession session)
        {
            _session =
                session
                ?? throw new ArgumentNullException(
                    nameof(session));

            RefreshControls();
        }

        public void Clear()
        {
            _session =
                null;

            RefreshControls();
        }

        public void RefreshSelectedCodesCount()
        {
            UpdateSelectedCodesLabel();
        }

        public StampaCartellineDashboardSession?
            Session
        {
            get
            {
                return _session;
            }
        }

        private void BuildControls(
            Color titleColor,
            Color inputColor)
        {
            chkInclude.Text =
                "Includi nel processo di stampa";

            chkInclude.AutoSize =
                true;

            chkInclude.Location =
                new Point(
                    0,
                    75);

            chkInclude.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            chkInclude.ForeColor =
                titleColor;

            chkInclude.CheckedChanged +=
                ChkInclude_CheckedChanged;

            chkOnlySelectedStl.Text =
                "Vuoi stampare solo alcuni STL?";

            chkOnlySelectedStl.AutoSize =
                true;

            chkOnlySelectedStl.Location =
                new Point(
                    0,
                    110);

            chkOnlySelectedStl.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            chkOnlySelectedStl.ForeColor =
                titleColor;

            chkOnlySelectedStl.CheckedChanged +=
                ChkOnlySelectedStl_CheckedChanged;

            txtSelectedStl.Location =
                new Point(
                    20,
                    140);

            txtSelectedStl.Size =
                new Size(
                    830,
                    55);

            txtSelectedStl.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            txtSelectedStl.Multiline =
                true;

            txtSelectedStl.ScrollBars =
                ScrollBars.Vertical;

            txtSelectedStl.BackColor =
                inputColor;

            txtSelectedStl.ForeColor =
                titleColor;

            txtSelectedStl.BorderStyle =
                BorderStyle.FixedSingle;

            txtSelectedStl.Visible =
                false;

            txtSelectedStl.TextChanged +=
                TxtSelectedStl_TextChanged;

            chkOnlySelectedCodes.Text =
                "Vuoi stampare solo una serie di codici contenuta nell'assieme?";

            chkOnlySelectedCodes.AutoSize =
                true;

            chkOnlySelectedCodes.Location =
                new Point(
                    0,
                    210);

            chkOnlySelectedCodes.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            chkOnlySelectedCodes.ForeColor =
                titleColor;

            chkOnlySelectedCodes.CheckedChanged +=
                ChkOnlySelectedCodes_CheckedChanged;

            lblSelectedCodes.Text =
                "Codici selezionati: 0";

            lblSelectedCodes.AutoSize =
                true;

            lblSelectedCodes.Location =
                new Point(
                    20,
                    244);

            lblSelectedCodes.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Regular);

            lblSelectedCodes.ForeColor =
                titleColor;

            lblSelectedCodes.Visible =
                false;

            btnConfigureCodes.Text =
                "CONFIGURA CODICI";

            btnConfigureCodes.Size =
                new Size(
                    180,
                    36);

            btnConfigureCodes.Location =
                new Point(
                    20,
                    272);

            btnConfigureCodes.Font =
                new Font(
                    "Segoe UI",
                    9,
                    FontStyle.Bold);

            btnConfigureCodes.FlatStyle =
                FlatStyle.Flat;

            btnConfigureCodes.FlatAppearance.BorderSize =
                0;

            btnConfigureCodes.BackColor =
                Color.FromArgb(
                    37,
                    99,
                    235);

            btnConfigureCodes.ForeColor =
                Color.White;

            btnConfigureCodes.Cursor =
                Cursors.Hand;

            btnConfigureCodes.Visible =
                false;

            btnConfigureCodes.Click +=
                BtnConfigureCodes_Click;

            _container.Controls.Add(
                chkInclude);

            _container.Controls.Add(
                chkOnlySelectedStl);

            _container.Controls.Add(
                txtSelectedStl);

            _container.Controls.Add(
                chkOnlySelectedCodes);

            _container.Controls.Add(
                lblSelectedCodes);

            _container.Controls.Add(
                btnConfigureCodes);
        }

        private void RefreshControls()
        {
            try
            {
                _isUpdatingControls =
                    true;

                bool hasSession =
                    _session != null;

                chkInclude.Enabled =
                    hasSession;

                chkOnlySelectedStl.Enabled =
                    hasSession;

                chkOnlySelectedCodes.Enabled =
                    hasSession;

                txtSelectedStl.Enabled =
                    hasSession;

                btnConfigureCodes.Enabled =
                    hasSession;

                if (_session == null)
                {
                    chkInclude.Checked =
                        false;

                    chkOnlySelectedStl.Checked =
                        false;

                    chkOnlySelectedCodes.Checked =
                        false;

                    txtSelectedStl.Text =
                        string.Empty;

                    UpdateControlsVisibility();
                    UpdateSelectedCodesLabel();

                    return;
                }

                chkInclude.Checked =
                    _session.IncludeAssemblyGroups;

                chkOnlySelectedStl.Checked =
                    _session.PrintOnlySelectedStl;

                chkOnlySelectedCodes.Checked =
                    _session.PrintOnlySelectedAssemblyCodes;

                txtSelectedStl.Text =
                    _session.SelectedStlList
                    ?? string.Empty;

                UpdateControlsVisibility();
                UpdateSelectedCodesLabel();
            }
            finally
            {
                _isUpdatingControls =
                    false;
            }
        }

        private void ChkInclude_CheckedChanged(
            object? sender,
            EventArgs e)
        {
            if (_isUpdatingControls ||
                _session == null)
            {
                return;
            }

            _session.IncludeAssemblyGroups =
                chkInclude.Checked;

            UpdateControlsVisibility();
        }

        private void ChkOnlySelectedStl_CheckedChanged(
            object? sender,
            EventArgs e)
        {
            if (_isUpdatingControls ||
                _session == null)
            {
                return;
            }

            try
            {
                _isUpdatingControls =
                    true;

                bool isChecked =
                    chkOnlySelectedStl.Checked;

                _session.PrintOnlySelectedStl =
                    isChecked;

                if (isChecked)
                {
                    chkOnlySelectedCodes.Checked =
                        false;

                    _session.PrintOnlySelectedAssemblyCodes =
                        false;
                }

                UpdateControlsVisibility();
            }
            finally
            {
                _isUpdatingControls =
                    false;
            }
        }

        private void ChkOnlySelectedCodes_CheckedChanged(
            object? sender,
            EventArgs e)
        {
            if (_isUpdatingControls ||
                _session == null)
            {
                return;
            }

            try
            {
                _isUpdatingControls =
                    true;

                bool isChecked =
                    chkOnlySelectedCodes.Checked;

                _session.PrintOnlySelectedAssemblyCodes =
                    isChecked;

                if (isChecked)
                {
                    chkOnlySelectedStl.Checked =
                        false;

                    _session.PrintOnlySelectedStl =
                        false;
                }

                UpdateControlsVisibility();
            }
            finally
            {
                _isUpdatingControls =
                    false;
            }
        }

        private void TxtSelectedStl_TextChanged(
            object? sender,
            EventArgs e)
        {
            if (_isUpdatingControls ||
                _session == null)
            {
                return;
            }

            _session.SelectedStlList =
                txtSelectedStl.Text;
        }

        private void BtnConfigureCodes_Click(
            object? sender,
            EventArgs e)
        {
            if (_session == null)
                return;

            ConfigureCodesRequested?.Invoke(
                this,
                EventArgs.Empty);
        }

        private void UpdateControlsVisibility()
        {
            bool hasSession =
                _session != null;

            bool includeSection =
                hasSession &&
                chkInclude.Checked;

            chkOnlySelectedStl.Enabled =
                includeSection;

            chkOnlySelectedCodes.Enabled =
                includeSection;

            txtSelectedStl.Enabled =
                includeSection;

            btnConfigureCodes.Enabled =
                includeSection;

            txtSelectedStl.Visible =
                includeSection &&
                chkOnlySelectedStl.Checked;

            bool showCodeControls =
                includeSection &&
                chkOnlySelectedCodes.Checked;

            lblSelectedCodes.Visible =
                showCodeControls;

            btnConfigureCodes.Visible =
                showCodeControls;
        }

        private void UpdateSelectedCodesLabel()
        {
            int selectedCodesCount =
                _session?
                    .SelectedAssemblyCodes?
                    .Count
                ?? 0;

            lblSelectedCodes.Text =
                "Codici selezionati: " +
                selectedCodesCount;
        }
    }
}