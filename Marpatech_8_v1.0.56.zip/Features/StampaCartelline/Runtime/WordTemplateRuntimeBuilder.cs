﻿using System;
using System.Collections.Generic;
using System.IO;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Runtime
{
    public sealed class WordTemplateRuntimeBuilder
    {
        public List<WordTemplateRuntime> Build(
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            List<WordTemplateRuntime> result =
                new List<WordTemplateRuntime>();

            foreach (
                WordTemplateConfiguration template
                in configuration.WordTemplates)
            {
                if (template == null)
                    continue;

                WordTemplateRuntime runtime =
                    BuildTemplate(
                        template,
                        session);

                result.Add(
                    runtime);
            }

            return result;
        }

        private static WordTemplateRuntime BuildTemplate(
            WordTemplateConfiguration template,
            StampaCartellineDashboardSession session)
        {
            string fileName =
                Path.GetFileName(
                    template.TemplatePath
                    ?? string.Empty);

            string temporaryFilePath =
                string.IsNullOrWhiteSpace(
                    fileName)
                    ? string.Empty
                    : Path.Combine(
                        GetTemporaryDirectory(),
                        fileName);

            WordTemplateRuntime runtime =
                new WordTemplateRuntime
                {
                    Template =
                        template,

                    TemporaryFilePath =
                        temporaryFilePath
                };

            foreach (
                WordPlaceholderMapping mapping
                in template.PlaceholderMappings)
            {
                AddReplacement(
                    runtime,
                    mapping,
                    session);
            }

            return runtime;
        }

        private static void AddReplacement(
            WordTemplateRuntime runtime,
            WordPlaceholderMapping mapping,
            StampaCartellineDashboardSession session)
        {
            if (mapping == null)
                return;

            string placeholder =
                mapping.Placeholder?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(
                    placeholder))
            {
                return;
            }

            string replacementValue =
                ResolveReplacementValue(
                    mapping,
                    session);

            runtime.Replacements[
                placeholder] =
                    replacementValue;
        }

        private static string ResolveReplacementValue(
            WordPlaceholderMapping mapping,
            StampaCartellineDashboardSession session)
        {
            string configuredValue =
                mapping.WordText?.Trim()
                ?? string.Empty;

            string replacementValue;

            if (!mapping.IsInventorTag)
            {
                replacementValue =
                    configuredValue;
            }
            else
            {
                DashboardPropertySession? property =
                    session.GetPropertyByTag(
                        configuredValue);

                replacementValue =
                    property?.Value
                    ?? string.Empty;
            }

            bool isStlDeterminingAttribute =
                session.IsPrintingStl &&
                !string.IsNullOrWhiteSpace(
                    session.StlDescription) &&
                string.Equals(
                    configuredValue,
                    session.StlDeterminingAttribute,
                    StringComparison.OrdinalIgnoreCase);

            if (!isStlDeterminingAttribute)
            {
                return replacementValue;
            }

            string stlText =
                session.StlDescription.Trim();

            if (string.IsNullOrWhiteSpace(
                    replacementValue))
            {
                return stlText;
            }

            return replacementValue.TrimEnd() +
                " " +
                stlText;
        }

        public static string GetTemporaryDirectory()
        {
            return Path.Combine(
                Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData),
                "Marpatech",
                "Temp",
                "Stampa Cartelline");
        }
    }
}