﻿using System.Collections.Generic;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Runtime
{
    /// <summary>
    /// Contiene tutti i dati necessari
    /// per elaborare un template Word.
    /// </summary>
    public sealed class WordTemplateRuntime
    {
        /// <summary>
        /// Configurazione del template.
        /// </summary>
        public WordTemplateConfiguration Template
        {
            get;
            init;
        } = null!;

        /// <summary>
        /// Percorso del file temporaneo
        /// che verrà aperto da Word.
        /// </summary>
        public string TemporaryFilePath
        {
            get;
            set;
        } = string.Empty;

        /// <summary>
        /// Coppie:
        /// Placeholder -> Valore finale
        /// </summary>
        public Dictionary<string, string> Replacements
        {
            get;
        } = new Dictionary<string, string>();
    }
}