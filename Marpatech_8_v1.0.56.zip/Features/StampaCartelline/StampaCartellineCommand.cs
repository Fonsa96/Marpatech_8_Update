﻿using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.StampaCartelline.Forms;

namespace Marpatech_8.Features.StampaCartelline
{
    public static class StampaCartellineCommand
    {
        public static void Execute(
            Inventor.Application inventorApp,
            FeatureOpenContext context)
        {
            FeatureNavigationService.OpenFeature(
                context,
                "StampaCartelline",
                () =>
                    new StampaCartellineDashboardForm(
                        inventorApp,
                        context.IsDarkTheme));
        }
    }
}