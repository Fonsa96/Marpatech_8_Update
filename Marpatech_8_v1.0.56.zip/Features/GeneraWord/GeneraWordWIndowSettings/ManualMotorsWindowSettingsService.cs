﻿using System;
using System.IO;
using Marpatech_8.Features.Core.Compatibility;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualMotorsWindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "ManualMotorsWindowSettings.json");
            }
        }

        public static ManualMotorsWindowSettings Load()
        {
            try
            {
                return JsonCompatibilityService
                    .LoadFromFile<ManualMotorsWindowSettings>(SettingsFile)
                    ?? new ManualMotorsWindowSettings();
            }
            catch
            {
                return new ManualMotorsWindowSettings();
            }
        }

        public static void Save(
            ManualMotorsWindowSettings settings)
        {
            try
            {
                JsonCompatibilityService.SaveToFile(
                    SettingsFile,
                    settings);
            }
            catch
            {
            }
        }
    }
}