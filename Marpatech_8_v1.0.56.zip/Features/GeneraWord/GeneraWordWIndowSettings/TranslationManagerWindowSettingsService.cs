﻿using System.IO;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.GeneraWord.Translation.WindowSettings
{
    public static class TranslationManagerWindowSettingsService
    {
        private static string SettingsPath
        {
            get
            {
                return AppPathService.GetAppFolder(
                    "Features",
                    "GeneraWord",
                    "Translation",
                    "WindowSettings",
                    "translation_manager_window_settings.json");
            }
        }

        public static TranslationManagerWindowSettings Load()
        {
            try
            {
                return JsonCompatibilityService
                    .LoadFromFile<TranslationManagerWindowSettings>(
                        SettingsPath)
                    ?? new TranslationManagerWindowSettings();
            }
            catch
            {
                return new TranslationManagerWindowSettings();
            }
        }

        public static void Save(
            TranslationManagerWindowSettings settings)
        {
            JsonCompatibilityService.SaveToFile(
                SettingsPath,
                settings);
        }
    }
}