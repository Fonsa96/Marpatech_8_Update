﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Translation.WindowSettings
{
    public class TranslationManagerWindowSettings
    {
        public int Width { get; set; } = 1100;

        public int Height { get; set; } = 650;

        public int Left { get; set; } = -1;

        public int Top { get; set; } = -1;

        public bool IsMaximized { get; set; } = false;

        public Dictionary<string, int> ColumnDisplayIndexes { get; set; }
            = new Dictionary<string, int>();
        public Dictionary<string, int> ColumnWidths { get; set; }
    = new Dictionary<string, int>();

        public Dictionary<string, int> RowHeights { get; set; }
            = new Dictionary<string, int>();
    }
}