﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualMotorsWindowSettings
    {
        public int Width { get; set; } = 950;
        public int Height { get; set; } = 520;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; } = false;
        public int[] ColumnWidths { get; set; } = new int[0];
        public int[] RowHeights { get; set; } = new int[0];
        public bool LockGridResize { get; set; } = false;
    }
}