﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualGenerationError
    {
        public string FileName { get; set; } = "";
        public string ErrorMessage { get; set; } = "";
    }
}