﻿using System;
using System.IO;
using Marpatech_8.Features.Core.Compatibility;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class WordPlaceholderSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData =
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "WordPlaceholderSettings.json");
            }
        }

        public static WordPlaceholderSettings Load()
        {
            try
            {
                return JsonCompatibilityService
                    .LoadFromFile<WordPlaceholderSettings>(
                        SettingsFile)
                    ?? new WordPlaceholderSettings();
            }
            catch
            {
                return new WordPlaceholderSettings();
            }
        }

        public static void Save(
            WordPlaceholderSettings settings)
        {
            try
            {
                JsonCompatibilityService.SaveToFile(
                    SettingsFile,
                    settings);
            }
            catch
            {
            }
        }
    }
}