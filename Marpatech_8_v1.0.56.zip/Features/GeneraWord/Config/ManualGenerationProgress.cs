﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualGenerationProgress
    {
        public int Current { get; set; }
        public int Total { get; set; }
        public string CurrentFile { get; set; } = "";
        public int Percentage { get; set; }
    }
}