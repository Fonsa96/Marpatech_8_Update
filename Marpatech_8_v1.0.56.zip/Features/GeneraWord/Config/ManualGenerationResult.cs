﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualGenerationResult
    {
        public bool Success
        {
            get
            {
                return Errors.Count == 0;
            }
        }

        public List<ManualGenerationError> Errors { get; set; } = new List<ManualGenerationError>();

        public string GenerationFolder { get; set; } = "";
    }
}