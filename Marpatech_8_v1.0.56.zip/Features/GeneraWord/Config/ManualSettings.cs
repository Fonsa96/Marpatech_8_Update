﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualSettings
    {
        public string BaseTemplatePath { get; set; } = "";
        public string OutputFolderPath { get; set; } = "";

        public List<ManualPropertyConfig> Properties { get; set; } = new List<ManualPropertyConfig>();
    }

    public class ManualPropertyConfig
    {
        public string Tag { get; set; } = "";
        public string IPropertyName { get; set; } = "";
        public bool Required { get; set; } = true;
    }
}