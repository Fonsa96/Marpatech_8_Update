﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Config
{
    public class TranslationDatabase
    {
        public Dictionary<string, Dictionary<string, string>> TipoProdotto { get; set; }
            = new();

        public Dictionary<string, Dictionary<string, string>> Lub { get; set; }
            = new();

        public Dictionary<string, Dictionary<string, string>> Tensione { get; set; }
            = new();
    }
}