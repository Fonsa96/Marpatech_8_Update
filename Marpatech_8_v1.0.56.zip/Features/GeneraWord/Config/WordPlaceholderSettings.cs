﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Config
{
    public class WordPlaceholderSettings
    {
        public bool LockEditing { get; set; }

        public string ManualFolderProperty { get; set; } = "";

        public List<WordPlaceholderConfig> Placeholders { get; set; }
            = new();
    }
}