﻿namespace Marpatech_8.Features.GeneraWord.Config
{
    public class ManualConfigurationPackage
    {
        public ManualSettings Settings { get; set; } = new ManualSettings();

        public TranslationDatabase Translations { get; set; } = new TranslationDatabase();

        public WordPlaceholderSettings WordPlaceholders { get; set; } = new WordPlaceholderSettings();
    }
}