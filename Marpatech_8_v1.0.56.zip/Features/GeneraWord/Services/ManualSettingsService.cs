﻿using Marpatech_8.Features.GeneraWord.Config;
using System;
using System.Diagnostics;
using System.IO;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "ManualSettings.json");
            }
        }

        public static string SettingsFilePath
        {
            get
            {
                return SettingsFile;
            }
        }

        public static ManualSettings Load()
        {
            try
            {
                ManualFileService.EnsureDirectory(SettingsFolder);

                if (!ManualFileService.FileExists(SettingsFile))
                {
                    ManualSettings defaultSettings = CreateDefaultSettings();
                    Save(defaultSettings);
                    return defaultSettings;
                }

                ManualSettings? settings =
                    ManualJsonService.LoadFromFile<ManualSettings>(
                        SettingsFile);

                return settings ?? CreateDefaultSettings();
            }
            catch
            {
                return CreateDefaultSettings();
            }
        }

        public static void Save(ManualSettings settings)
        {
            ManualFileService.EnsureDirectory(SettingsFolder);

            ManualJsonService.SaveToFile(
                SettingsFile,
                settings);
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!ManualFileService.FileExists(sourceFile))
                throw new FileNotFoundException(
                    "File configurazione manuali non trovato.",
                    sourceFile);

            ManualFileService.EnsureDirectory(SettingsFolder);

            ManualFileService.CopyFileSafe(
                sourceFile,
                SettingsFile,
                true);
        }

        private static ManualSettings CreateDefaultSettings()
        {
            ManualSettings settings = new ManualSettings();

            settings.BaseTemplatePath =
                @"\\SRV02\Dati\dati\Ufficio Tecnico\Manuali commesse\FILE GENERICI MANUALI\MANUALI AUTOMATICI";

            settings.OutputFolderPath =
                @"C:\_ESPORTADWG\MANUALI GENERATI";

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "NumeroCommessa",
                IPropertyName = "Commessa",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "NomeCliente",
                IPropertyName = "Nome Cliente",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "CodiceCliente",
                IPropertyName = "Codice Cliente",
                Required = true
            });

            settings.Properties.Add(new ManualPropertyConfig
            {
                Tag = "TipoProdotto",
                IPropertyName = "Tipo Prodotto",
                Required = true
            });

            return settings;
        }
    }
}