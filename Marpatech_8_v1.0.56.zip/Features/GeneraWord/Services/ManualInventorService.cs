﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualInventorService
    {
        public static Document? GetActiveDocument(Inventor.Application inventorApp)
        {
            return InventorService.GetActiveDocument(inventorApp);
        }

        public static Dictionary<string, string> ReadConfiguredProperties(
            Document document,
            ManualSettings settings)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();

            foreach (ManualPropertyConfig property in settings.Properties)
            {
                string value = InventorService.ReadIProperty(
                    document,
                    property.IPropertyName);

                values[property.Tag] = value;
            }

            return values;
        }

        public static string ReadIProperty(Document document, string propertyName)
        {
            return InventorService.ReadIProperty(
                document,
                propertyName);
        }

        public static void WriteIProperty(
            Document document,
            string propertyName,
            string value)
        {
            InventorService.WriteIProperty(
                document,
                propertyName,
                value);
        }
    }
}