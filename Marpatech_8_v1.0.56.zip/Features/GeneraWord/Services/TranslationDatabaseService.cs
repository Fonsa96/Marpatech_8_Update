﻿using System;
using System.IO;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class TranslationDatabaseService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string TranslationFile
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "ManualTranslations.json");
            }
        }

        public static string TranslationFilePath
        {
            get
            {
                return TranslationFile;
            }
        }

        public static TranslationDatabase Load()
        {
            try
            {
                ManualFileService.EnsureDirectory(SettingsFolder);

                if (!ManualFileService.FileExists(TranslationFile))
                {
                    TranslationDatabase newDatabase =
                        new TranslationDatabase();

                    Save(newDatabase);

                    return newDatabase;
                }

                TranslationDatabase? database =
                    ManualJsonService.LoadFromFile<TranslationDatabase>(
                        TranslationFile);

                return database ??
                       new TranslationDatabase();
            }
            catch
            {
                return new TranslationDatabase();
            }
        }

        public static void Save(
            TranslationDatabase database)
        {
            ManualFileService.EnsureDirectory(SettingsFolder);

            ManualJsonService.SaveToFile(
                TranslationFile,
                database);
        }

        public static void ImportFromFile(
            string sourceFile)
        {
            if (!ManualFileService.FileExists(sourceFile))
            {
                throw new FileNotFoundException(
                    "File traduzioni non trovato.",
                    sourceFile);
            }

            ManualFileService.EnsureDirectory(SettingsFolder);

            ManualFileService.CopyFileSafe(
                sourceFile,
                TranslationFile,
                true);
        }
    }
}