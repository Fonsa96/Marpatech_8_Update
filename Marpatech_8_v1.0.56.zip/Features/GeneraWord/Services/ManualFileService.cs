﻿using Marpatech_8.Features.Core.Compatibility;
using System.Collections.Generic;
using System.IO;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualFileService
    {
        public static bool FileExists(string path)
        {
            return FileSystemCompatibilityService.FileExists(path);
        }

        public static bool DirectoryExists(string path)
        {
            return FileSystemCompatibilityService.DirectoryExists(path);
        }

        public static void EnsureDirectory(string path)
        {
            FileSystemCompatibilityService.EnsureDirectory(path);
        }

        public static string ReadAllText(string path)
        {
            return FileSystemCompatibilityService.ReadAllTextSafe(path);
        }

        public static void WriteAllText(string path, string content)
        {
            FileSystemCompatibilityService.WriteAllTextSafe(path, content);
        }

        public static IEnumerable<string> GetFiles(
            string folder,
            string searchPattern,
            SearchOption searchOption)
        {
            return FileSystemCompatibilityService.GetFilesSafe(
                folder,
                searchPattern,
                searchOption);
        }

        public static void DeleteFileSafe(string path)
        {
            FileSystemCompatibilityService.DeleteFileSafe(path);
        }
        public static void CopyFileSafe(
            string sourceFile,
            string destinationFile,
            bool overwrite = true)
        {
            FileSystemCompatibilityService.CopyFileSafe(
                sourceFile,
                destinationFile,
                overwrite);
        }
        public static IEnumerable<string> GetDirectories(
    string folder,
    string searchPattern,
    SearchOption searchOption)
        {
            return FileSystemCompatibilityService.GetDirectoriesSafe(
                folder,
                searchPattern,
                searchOption);
        }

        public static void DeleteFile(string path)
        {
            FileSystemCompatibilityService.DeleteFileSafe(path);
        }
        public static void MoveFileSafe(
    string sourceFile,
    string destinationFile,
    bool overwrite = true)
        {
            FileSystemCompatibilityService.MoveFileSafe(
                sourceFile,
                destinationFile,
                overwrite);
        }

        public static void AppendAllText(
            string path,
            string content)
        {
            FileSystemCompatibilityService.AppendAllTextSafe(
                path,
                content);
        }

        public static long GetFileLength(string path)
        {
            return FileSystemCompatibilityService.GetFileLengthSafe(path);
        }
    }
}
