﻿using System.IO;
using Marpatech_8.Features.Core.Compatibility;
using Marpatech_8.Features.GeneraWord.Config;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualConfigurationPackageService
    {
        public static void ExportToFile(string destinationFile)
        {
            ManualConfigurationPackage package = new ManualConfigurationPackage
            {
                Settings = ManualSettingsService.Load(),
                Translations = TranslationDatabaseService.Load(),
                WordPlaceholders = WordPlaceholderSettingsService.Load()
            };

            JsonCompatibilityService.SaveToFile(
                destinationFile,
                package);
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!FileSystemCompatibilityService.FileExists(sourceFile))
            {
                throw new FileNotFoundException(
                    "File pacchetto configurazione manuali non trovato.",
                    sourceFile);
            }

            ManualConfigurationPackage? package =
                JsonCompatibilityService.LoadFromFile<ManualConfigurationPackage>(
                    sourceFile);

            if (package == null)
            {
                throw new InvalidDataException(
                    "File configurazione manuali non valido.");
            }

            ManualSettingsService.Save(package.Settings);
            TranslationDatabaseService.Save(package.Translations);
            WordPlaceholderSettingsService.Save(package.WordPlaceholders);
        }
    }
}