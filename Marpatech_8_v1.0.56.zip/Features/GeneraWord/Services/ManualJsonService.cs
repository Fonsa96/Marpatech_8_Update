﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualJsonService
    {
        public static T? Deserialize<T>(string json)
        {
            return JsonCompatibilityService.Deserialize<T>(json);
        }

        public static string Serialize<T>(T value)
        {
            return JsonCompatibilityService.Serialize(value);
        }

        public static T? LoadFromFile<T>(string path)
        {
            return JsonCompatibilityService.LoadFromFile<T>(path);
        }

        public static void SaveToFile<T>(string path, T value)
        {
            JsonCompatibilityService.SaveToFile(path, value);
        }
    }
}