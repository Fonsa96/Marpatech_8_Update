﻿using System.Windows.Forms;
using Marpatech_8.Features.Core.Windows;

namespace Marpatech_8.Features.GeneraWord.Services
{
    public static class ManualDialogService
    {
        public static string SelectFolder(
            string title,
            string initialPath,
            IWin32Window? owner = null)
        {
            return DialogCompatibilityService.SelectFolder(
                title,
                initialPath,
                owner);
        }

        public static string SelectOpenFile(
            string title,
            string filter,
            IWin32Window? owner = null)
        {
            return DialogCompatibilityService.SelectOpenFile(
                title,
                filter,
                owner);
        }

        public static string SelectSaveFile(
            string title,
            string filter,
            string defaultFileName,
            IWin32Window? owner = null)
        {
            return DialogCompatibilityService.SelectSaveFile(
                title,
                filter,
                defaultFileName,
                owner);
        }

        public static void Info(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Info(message, title, owner);
        }

        public static void Warning(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Warning(message, title, owner);
        }

        public static void Error(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Error(message, title, owner);
        }

        public static bool Confirm(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            return DialogCompatibilityService.Confirm(
                message,
                title,
                owner);
        }
    }
}