﻿using System;
using System.IO;
using Marpatech_8.Features.GeneraWord.Translation.Models;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public static class TranslationDatabaseService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData =
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings");
            }
        }

        private static string DatabasePath
        {
            get
            {
                return Path.Combine(
                    SettingsFolder,
                    "ManualTranslationDatabase.json");
            }
        }

        public static TranslationDatabase Load()
        {
            try
            {
                FileSystemCompatibilityService.EnsureDirectory(
                    SettingsFolder);

                TranslationDatabase? database =
                    JsonCompatibilityService
                        .LoadFromFile<TranslationDatabase>(
                            DatabasePath);

                if (database == null)
                {
                    database = new TranslationDatabase();

                    Save(database);
                }

                return database;
            }
            catch
            {
                return new TranslationDatabase();
            }
        }

        public static void Save(
            TranslationDatabase database)
        {
            FileSystemCompatibilityService.EnsureDirectory(
                SettingsFolder);

            JsonCompatibilityService.SaveToFile(
                DatabasePath,
                database);
        }
    }
}