﻿using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public class MyMemoryTranslationClient
    {
        private static readonly HttpClient _httpClient = new HttpClient();

        public async Task<string?> TranslateAsync(
            string italianText,
            string targetLanguageCode)
        {
            if (string.IsNullOrWhiteSpace(italianText))
                return null;

            if (string.IsNullOrWhiteSpace(targetLanguageCode))
                return null;

            string lang = NormalizeLanguageCode(targetLanguageCode);

            string url =
                "https://api.mymemory.translated.net/get?q=" +
                Uri.EscapeDataString(italianText) +
                "&langpair=it|" +
                Uri.EscapeDataString(lang);

            string json =
                await TranslationHttpService.GetStringAsync(
                    _httpClient,
                    url);

            using JsonDocument document =
                JsonDocument.Parse(json);

            if (!document.RootElement.TryGetProperty("responseData", out JsonElement responseData))
                return null;

            if (!responseData.TryGetProperty("translatedText", out JsonElement translatedText))
                return null;

            string? result = translatedText.GetString();

            if (string.IsNullOrWhiteSpace(result))
                return null;

            return result.Trim();
        }

        private string NormalizeLanguageCode(string languageCode)
        {
            string code = languageCode.Trim();

            if (code.Equals("ZH-CN", StringComparison.OrdinalIgnoreCase))
                return "zh-CN";

            if (code.Equals("ZH-TW", StringComparison.OrdinalIgnoreCase))
                return "zh-TW";

            return code.ToLowerInvariant();
        }
    }
}