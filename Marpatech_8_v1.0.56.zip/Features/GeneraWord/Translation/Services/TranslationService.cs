﻿using System;
using System.Collections.Generic;
using System.Linq;
using Marpatech_8.Features.GeneraWord.Translation.Models;
using System.Threading.Tasks;


namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public class TranslationService
    {
        private readonly TranslationDatabase _database;
        private readonly MyMemoryTranslationClient _client;

        public TranslationService()
        {
            _database = TranslationDatabaseService.Load();
            _client = new MyMemoryTranslationClient();
        }

        public async Task<string> TranslateOrOriginalAsync(
            string italianText,
            string languageCode,
            bool includeInTranslation,
            List<string>? warnings = null)
        {
            if (!includeInTranslation)
                return italianText;

            if (ShouldSkipTranslation(
                italianText,
                languageCode))
            {
                return italianText;
            }

            string normalizedItalian =
                NormalizeKey(italianText);

            string normalizedLanguage =
                NormalizeLanguageCode(languageCode);

            TranslationEntry? entry =
                _database.Entries.FirstOrDefault(
                    x => string.Equals(
                        NormalizeKey(x.ItalianText),
                        normalizedItalian,
                        StringComparison.OrdinalIgnoreCase));

            if (entry != null && entry.Translations == null)
                entry.Translations = new Dictionary<string, string>();

            if (entry != null &&
                entry.Translations.ContainsKey(normalizedLanguage))
            {
                return entry.Translations[normalizedLanguage];
            }

            string? translated = null;

            try
            {
                translated = await _client.TranslateAsync(
                    italianText,
                    normalizedLanguage);
            }
            catch (Exception ex)
            {
                warnings?.Add(
                    "Traduzione non riuscita:" +
                    "\nTesto: " + italianText +
                    "\nLingua: " + normalizedLanguage +
                    "\nErrore: " + ex.Message);

                return italianText;
            }

            if (string.IsNullOrWhiteSpace(translated))
            {
                warnings?.Add(
                    "Traduzione non riuscita:" +
                    "\nTesto: " + italianText +
                    "\nLingua: " + normalizedLanguage);

                return italianText;
            }

            if (entry == null)
            {
                entry = new TranslationEntry
                {
                    ItalianText = italianText.Trim()
                };

                _database.Entries.Add(entry);
            }

            entry.Translations[normalizedLanguage] =
                translated!;

            TranslationDatabaseService.Save(
                _database);

            return translated!;
        }

        private bool ShouldSkipTranslation(
            string text,
            string languageCode)
        {
            if (string.IsNullOrWhiteSpace(text))
                return true;

            if (string.Equals(languageCode, "IT", StringComparison.OrdinalIgnoreCase))
                return true;

            string value = text.Trim();

            if (IsDateLike(value))
                return true;

            if (IsTechnicalValue(value))
                return true;

            return false;
        }

        private bool IsTechnicalValue(string value)
        {
            string upper = value.ToUpperInvariant();

            if (upper.Contains("IP"))
                return true;

            if (upper.Contains("KW"))
                return true;

            if (upper.Contains("HZ"))
                return true;

            if (upper.EndsWith(" V"))
                return true;

            if (upper.EndsWith("V") && upper.Any(char.IsDigit))
                return true;

            if (value.Any(char.IsDigit) &&
                !upper.Contains("MULTITENSIONE"))
                return true;

            return false;
        }

        private bool IsDateLike(string value)
        {
            return DateTime.TryParse(value, out _);
        }

        private string NormalizeKey(string text)
        {
            return text.Trim().ToUpperInvariant();
        }

        private string NormalizeLanguageCode(string languageCode)
        {
            return languageCode.Trim().ToUpperInvariant();
        }
    }
}