﻿using System.Net.Http;
using System.Threading.Tasks;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public static class TranslationHttpService
    {
        public static Task<string> GetStringAsync(
            HttpClient client,
            string url)
        {
            return HttpCompatibilityService.GetStringAsync(
                client,
                url);
        }
    }
}