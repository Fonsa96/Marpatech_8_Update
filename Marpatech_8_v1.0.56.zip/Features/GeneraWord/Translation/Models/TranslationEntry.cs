﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Translation.Models
{
    public class TranslationEntry
    {
        public string ItalianText { get; set; } = "";

        public Dictionary<string, string> Translations { get; set; }
            = new Dictionary<string, string>();
    }
}