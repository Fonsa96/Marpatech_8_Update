﻿using System.Collections.Generic;

namespace Marpatech_8.Features.GeneraWord.Translation.Models
{
    public class TranslationDatabase
    {
        public List<TranslationEntry> Entries { get; set; }
            = new List<TranslationEntry>();
    }
}