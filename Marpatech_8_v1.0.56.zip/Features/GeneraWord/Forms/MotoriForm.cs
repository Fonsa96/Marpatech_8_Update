﻿using Inventor;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using System;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class MotoriForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly ManualMotorsWindowSettings _windowSettings;
        private CheckBox? chkLockGridResize;

        private DataGridView? grid;

        public bool Saved { get; private set; } = false;
        public DrawingSize MaximusSize { get; private set; }

        public MotoriForm(Inventor.Application inventorApp, bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings =
                ManualMotorsWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();

            LoadMotorsFromInventor();
            ApplyGridSettings();
            ApplyGridResizeLock();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Gestione Motori";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(800, 420);
            MinimumSize = new DrawingSize(800, 470);
            MaximumSize = new DrawingSize(800, 470);

            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            BackColor = backgroundColor;

            FormClosing += MotoriForm_FormClosing;

            Label title = new Label();
            title.Text = "Gestione Motori";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Panel panel = new Panel();
            panel.Location = new DrawingPoint(35, 95);
            panel.Size = new DrawingSize(
                ClientSize.Width - 100,
                ClientSize.Height - 205);

            panel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            panel.BackColor = cardColor;
            panel.Padding = new Padding(18);

            grid = CreateGrid();

            panel.Controls.Add(grid);

            chkLockGridResize = new CheckBox();
            chkLockGridResize.Text = "Blocca ridimensionamento righe motori";
            chkLockGridResize.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            chkLockGridResize.ForeColor = titleColor;
            chkLockGridResize.AutoSize = true;
            chkLockGridResize.Location = new DrawingPoint(35, 332);
            chkLockGridResize.Checked = _windowSettings.LockGridResize;
            chkLockGridResize.CheckedChanged += (s, e) =>
            {
                ApplyGridResizeLock();
            };

            Button btnClose = CreateButton(
                "Chiudi",
                DrawingColor.FromArgb(100, 116, 139),
                150,
                45);

            btnClose.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnClose.Location = new DrawingPoint(
                ClientSize.Width - 750,
                ClientSize.Height - 70);

            btnClose.Click += (s, e) => Close();

            Button btnSave = CreateButton(
                "Salva",
                DrawingColor.FromArgb(22, 163, 74),
                150,
                45);

            btnSave.Anchor =
                AnchorStyles.Bottom |
                AnchorStyles.Right;

            btnSave.Location = new DrawingPoint(
                ClientSize.Width - 575,
                ClientSize.Height - 70);

            btnSave.Click += BtnSave_Click;

            Controls.Add(title);
            Controls.Add(panel);
            Controls.Add(chkLockGridResize);
            Controls.Add(btnClose);
            Controls.Add(btnSave);
        }

        private DataGridView CreateGrid()
        {
            DataGridView g = new DataGridView();

            g.Dock = DockStyle.Fill;

            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;

            g.RowHeadersVisible = false;

            g.BackgroundColor =
                _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            g.GridColor = DrawingColor.FromArgb(70, 75, 85);

            g.EnableHeadersVisualStyles = false;

            g.ColumnHeadersDefaultCellStyle.BackColor =
                _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.FromArgb(226, 232, 240);

            g.ColumnHeadersDefaultCellStyle.ForeColor =
                _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.Black;

            g.Columns.Add("Motore", "Motore");
            g.Columns.Add("Potenza", "Potenza");
            g.Columns.Add("IP", "IP");
            g.Columns.Add("Tensione", "Tensione");
            g.Columns.Add("Frequenza", "Frequenza");
            DataGridViewComboBoxColumn lubColumn = new DataGridViewComboBoxColumn();
            lubColumn.Name = "Lub";
            lubColumn.HeaderText = "Lub";
            lubColumn.Items.Add("SI");
            lubColumn.Items.Add("NO");
            g.Columns.Add(lubColumn);

            for (int i = 0; i < 6; i++)
            {
                g.Rows.Add(
                    i.ToString(),
                    "",
                    "",
                    "",
                    "",
                    "");
            }

            g.CellEndEdit += Grid_CellEndEdit;

            g.KeyDown += Grid_KeyDown;

            return g;
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();

            button.Text = text;
            button.Size = new DrawingSize(width, height);

            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;

            button.BackColor = color;
            button.ForeColor = DrawingColor.White;

            button.Font =
                new DrawingFont(
                    "Segoe UI",
                    10,
                    DrawingFontStyle.Bold);

            return button;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (grid == null)
                return;

            Inventor.Document? document =
                ManualInventorService.GetActiveDocument(_inventorApp);

            if (document == null)
            {
                ManualDialogService.Warning(
                "Nessun documento Inventor aperto.",
                "Gestione Motori",
                this);

                return;
            }

            for (int i = 0; i < 6; i++)
            {
                string potenza = grid.Rows[i].Cells["Potenza"].Value?.ToString() ?? "";
                string ip = grid.Rows[i].Cells["IP"].Value?.ToString() ?? "";
                string tensione = grid.Rows[i].Cells["Tensione"].Value?.ToString() ?? "";
                string frequenza = grid.Rows[i].Cells["Frequenza"].Value?.ToString() ?? "";
                string lub = grid.Rows[i].Cells["Lub"].Value?.ToString() ?? "";

                WriteMotorPropertyIfNotEmpty(document, "Potenza Motore " + i, potenza);
                WriteMotorPropertyIfNotEmpty(document, "IP " + i, ip);
                WriteMotorPropertyIfNotEmpty(document, "Tensione " + i, tensione);
                WriteMotorPropertyIfNotEmpty(document, "Frequenza " + i, frequenza);
                WriteMotorPropertyIfNotEmpty(document, "Lub " + i, lub);
            }

            Saved = true;
            Close();
        }

        private void ApplyWindowSettings()
        {
            Width = _windowSettings.Width;
            Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 &&
                _windowSettings.Top >= 0)
            {
                StartPosition = FormStartPosition.Manual;
                Left = _windowSettings.Left;
                Top = _windowSettings.Top;
            }

            if (_windowSettings.IsMaximized)
                WindowState = FormWindowState.Maximized;
        }

        private void MotoriForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = Width;
                _windowSettings.Height = Height;
                _windowSettings.Left = Left;
                _windowSettings.Top = Top;
            }

            _windowSettings.IsMaximized =
                WindowState == FormWindowState.Maximized;

            if (chkLockGridResize != null)
                _windowSettings.LockGridResize = chkLockGridResize.Checked; 

            SaveGridSettings();

            ManualMotorsWindowSettingsService.Save(
                _windowSettings);
        }
        private void LoadMotorsFromInventor()
        {
            if (grid == null)
                return;

            Inventor.Document? document =
                ManualInventorService.GetActiveDocument(_inventorApp);

            if (document == null)
                return;

            for (int i = 0; i < 6; i++)
            {
                grid.Rows[i].Cells["Potenza"].Value =
                    ManualInventorService.ReadIProperty(document, "Potenza Motore " + i);

                grid.Rows[i].Cells["IP"].Value =
                    ManualInventorService.ReadIProperty(document, "IP " + i);

                grid.Rows[i].Cells["Tensione"].Value =
                    ManualInventorService.ReadIProperty(document, "Tensione " + i);

                grid.Rows[i].Cells["Frequenza"].Value =
                    ManualInventorService.ReadIProperty(document, "Frequenza " + i);

                grid.Rows[i].Cells["Lub"].Value =
                    ManualInventorService.ReadIProperty(document, "Lub " + i);
            }
        }
        private void ApplyGridSettings()
        {
            if (grid == null)
                return;

            if (_windowSettings.ColumnWidths != null &&
                _windowSettings.ColumnWidths.Length == grid.Columns.Count)
            {
                for (int i = 0; i < grid.Columns.Count; i++)
                {
                    if (_windowSettings.ColumnWidths[i] > 20)
                        grid.Columns[i].Width = _windowSettings.ColumnWidths[i];
                }
            }

            if (_windowSettings.RowHeights != null &&
                _windowSettings.RowHeights.Length == grid.Rows.Count)
            {
                for (int i = 0; i < grid.Rows.Count; i++)
                {
                    if (_windowSettings.RowHeights[i] > 10)
                        grid.Rows[i].Height = _windowSettings.RowHeights[i];
                }
            }
        }

        private void SaveGridSettings()
        {
            if (grid == null)
                return;

            int[] columnWidths = new int[grid.Columns.Count];

            for (int i = 0; i < grid.Columns.Count; i++)
                columnWidths[i] = grid.Columns[i].Width;

            int[] rowHeights = new int[grid.Rows.Count];

            for (int i = 0; i < grid.Rows.Count; i++)
                rowHeights[i] = grid.Rows[i].Height;

            _windowSettings.ColumnWidths = columnWidths;
            _windowSettings.RowHeights = rowHeights;
        }
        private void ApplyGridResizeLock()
        {
            if (grid == null || chkLockGridResize == null)
                return;

            bool locked = chkLockGridResize.Checked;

            grid.AllowUserToResizeColumns = !locked;
            grid.AllowUserToResizeRows = !locked;
        }

        private void Grid_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            if (grid == null)
                return;

            if (e.RowIndex < 0 || e.ColumnIndex < 0)
                return;

            string columnName = grid.Columns[e.ColumnIndex].Name;
            object? value = grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;

            string text = value?.ToString()?.Trim() ?? "";

            if (string.IsNullOrWhiteSpace(text))
            {
                grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "";
                return;
            }

            switch (columnName)
            {
                case "Potenza":
                    grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value =
                        NormalizeSuffix(text, "Kw");
                    break;

                case "IP":
                    grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value =
                        NormalizePrefix(text, "IP");
                    break;

                case "Tensione":
                    grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value =
                        NormalizeTensione(text);
                    break;

                case "Frequenza":
                    grid.Rows[e.RowIndex].Cells[e.ColumnIndex].Value =
                        NormalizeSuffix(text, "Hz");
                    break;
            }
        }
        private string NormalizeSuffix(string text, string suffix)
        {
            text = text.Trim();

            if (text.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
                text = text.Substring(0, text.Length - suffix.Length).Trim();

            return text + " " + suffix;
        }

        private string NormalizePrefix(string text, string prefix)
        {
            text = text.Trim();

            if (text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                text = text.Substring(prefix.Length).Trim();

            return prefix + text;
        }

        private string NormalizeTensione(string text)
        {
            text = text.Trim();

            if (string.Equals(text, "MULTITENSIONE", StringComparison.OrdinalIgnoreCase))
                return "MULTITENSIONE";

            if (text.EndsWith("V", StringComparison.OrdinalIgnoreCase))
                text = text.Substring(0, text.Length - 1).Trim();

            return text + " V";
        }
        private void Grid_KeyDown(object? sender, KeyEventArgs e)
        {
            if (grid == null)
                return;

            if (e.KeyCode == Keys.Delete)
            {
                foreach (DataGridViewCell cell in grid.SelectedCells)
                {
                    if (cell.ColumnIndex == grid.Columns["Motore"].Index)
                        continue; // non cancella la colonna indice

                    cell.Value = "";
                }

                e.Handled = true;
            }
        }
        private void WriteMotorPropertyIfNotEmpty(
    Inventor.Document document,
    string propertyName,
    string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return;

            ManualInventorService.WriteIProperty(
                document,
                propertyName,
                value.Trim());
        }
    }
}