﻿using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings = Marpatech_8.Features.Core.Settings.WindowSettings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class WordPlaceholderForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly ManualSettings _manualSettings;
        private readonly CoreWindowSettings _windowSettings;

        private WordPlaceholderSettings _placeholderSettings;

        private ComboBox? cmbManualFolderProperty;
        private CheckBox? chkLockEditing;
        private DataGridView? grid;

        public bool Saved { get; private set; } = false;

        public WordPlaceholderForm(bool isDarkTheme, ManualSettings manualSettings)
        {
            _isDarkTheme = isDarkTheme;
            _manualSettings = manualSettings;
            _placeholderSettings = WordPlaceholderSettingsService.Load();
            _windowSettings = WindowSettingsService.Load(
                "WordPlaceholder",
                920,
                560);

            InitializeComponent();
            WindowSettingsService.Apply(
                this,
                _windowSettings);
            LoadData();
            ApplyLockState();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Gestisci Sostituzioni Word";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(950, 650);
            MinimumSize = new DrawingSize(900, 580);
            BackColor = backgroundColor;
            FormClosing += WordPlaceholderForm_FormClosing;

            Label title = new Label();
            title.Text = "Gestisci Sostituzioni Word";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Panel panel = new Panel();
            panel.Location = new DrawingPoint(35, 95);
            panel.Size = new DrawingSize(ClientSize.Width - 70, ClientSize.Height - 175);
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel.BackColor = cardColor;
            panel.Padding = new Padding(18);

            Label lblFolder = CreateLabel("Proprietà Cartella Manuale", titleColor);
            lblFolder.Location = new DrawingPoint(25, 25);

            cmbManualFolderProperty = new ComboBox();
            cmbManualFolderProperty.Location = new DrawingPoint(25, 55);
            cmbManualFolderProperty.Size = new DrawingSize(360, 32);
            cmbManualFolderProperty.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbManualFolderProperty.Font = new DrawingFont("Segoe UI", 10);

            chkLockEditing = new CheckBox();
            chkLockEditing.Text = "Blocca Modifica Placeholder";
            chkLockEditing.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            chkLockEditing.ForeColor = titleColor;
            chkLockEditing.AutoSize = true;
            chkLockEditing.Location = new DrawingPoint(430, 58);
            chkLockEditing.CheckedChanged += (s, e) => ApplyLockState();

            grid = new DataGridView();
            grid.Location = new DrawingPoint(25, 115);
            grid.Size = new DrawingSize(panel.Width - 50, panel.Height - 145);
            grid.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.BackgroundColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            grid.GridColor = DrawingColor.FromArgb(70, 75, 85);
            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Font = new DrawingFont("Segoe UI", 10);
            grid.EnableHeadersVisualStyles = false;

            grid.ColumnHeadersDefaultCellStyle.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.BackColor = _isDarkTheme ? DrawingColor.FromArgb(32, 34, 40) : DrawingColor.FromArgb(226, 232, 240);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = titleColor;
            grid.DefaultCellStyle.BackColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            grid.DefaultCellStyle.ForeColor = titleColor;

            DataGridViewTextBoxColumn placeholderColumn = new DataGridViewTextBoxColumn();
            placeholderColumn.Name = "Placeholder";
            placeholderColumn.HeaderText = "Placeholder";
            placeholderColumn.Width = 220;
            grid.Columns.Add(placeholderColumn);

            DataGridViewComboBoxColumn sourceColumn = new DataGridViewComboBoxColumn();
            sourceColumn.Name = "Source";
            sourceColumn.HeaderText = "Valore da usare";
            sourceColumn.Width = 420;
            grid.Columns.Add(sourceColumn);

            DataGridViewCheckBoxColumn translateColumn = new DataGridViewCheckBoxColumn();
            translateColumn.Name = "IncludeInTranslation";
            translateColumn.HeaderText = "Includi valore nelle traduzioni";
            translateColumn.Width = 220;
            grid.Columns.Add(translateColumn);

            panel.Controls.Add(lblFolder);
            panel.Controls.Add(cmbManualFolderProperty);
            panel.Controls.Add(chkLockEditing);
            panel.Controls.Add(grid);

            Button btnAdd = CreateButton("Aggiungi", DrawingColor.FromArgb(37, 99, 235), 150, 45);
            btnAdd.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnAdd.Location = new DrawingPoint(35, ClientSize.Height - 70);
            btnAdd.Click += BtnAdd_Click;

            Button btnDelete = CreateButton("Elimina", DrawingColor.FromArgb(220, 38, 38), 150, 45);
            btnDelete.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnDelete.Location = new DrawingPoint(200, ClientSize.Height - 70);
            btnDelete.Click += BtnDelete_Click;

            Button btnCancel = CreateButton("Annulla", DrawingColor.FromArgb(100, 116, 139), 150, 45);
            btnCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnCancel.Location = new DrawingPoint(ClientSize.Width - 370, ClientSize.Height - 70);
            btnCancel.Click += (s, e) => Close();

            Button btnSave = CreateButton("Salva", DrawingColor.FromArgb(22, 163, 74), 150, 45);
            btnSave.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSave.Location = new DrawingPoint(ClientSize.Width - 205, ClientSize.Height - 70);
            btnSave.Click += BtnSave_Click;

            Controls.Add(title);
            Controls.Add(panel);
            Controls.Add(btnAdd);
            Controls.Add(btnDelete);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
        }

        private Label CreateLabel(string text, DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;
            return label;
        }

        private Button CreateButton(string text, DrawingColor color, int width, int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private void LoadData()
        {
            if (grid == null || cmbManualFolderProperty == null)
                return;

            List<string> sources = GetAvailableSources();

            cmbManualFolderProperty.Items.Clear();

            foreach (string source in sources)
            {
                if (IsSpecialSource(source))
                    continue;

                cmbManualFolderProperty.Items.Add(source);
            }

            if (!string.IsNullOrWhiteSpace(_placeholderSettings.ManualFolderProperty))
                cmbManualFolderProperty.Text = _placeholderSettings.ManualFolderProperty;

            if (chkLockEditing != null)
                chkLockEditing.Checked = _placeholderSettings.LockEditing;

            DataGridViewComboBoxColumn sourceColumn =
                (DataGridViewComboBoxColumn)grid.Columns["Source"];

            sourceColumn.Items.Clear();

            foreach (string source in sources)
                sourceColumn.Items.Add(source);

            grid.Rows.Clear();

            foreach (WordPlaceholderConfig item in _placeholderSettings.Placeholders)
            {
                grid.Rows.Add(
                    item.Placeholder,
                    item.Source,
                    item.IncludeInTranslation);
            }
        }

        private List<string> GetAvailableSources()
        {
            List<string> sources = new List<string>
            {
                "SPAZIO VUOTO",
                "DATA",
                "EDIZIONE",
                "ANNO DI PRODUZIONE"
            };

            foreach (ManualPropertyConfig property in _manualSettings.Properties.OrderBy(x => x.Tag))
            {
                if (!string.IsNullOrWhiteSpace(property.Tag))
                    sources.Add(property.Tag);
            }

            for (int i = 0; i <= 5; i++)
            {
                sources.Add("Potenza Motore " + i);
                sources.Add("IP " + i);
                sources.Add("Tensione " + i);
                sources.Add("Frequenza " + i);
                sources.Add("Lub " + i);
            }

            return sources;
        }

        private bool IsSpecialSource(string source)
        {
            return source == "SPAZIO VUOTO" ||
                   source == "DATA" ||
                   source == "EDIZIONE" ||
                   source == "ANNO DI PRODUZIONE";
        }

        private void ApplyLockState()
        {
            if (chkLockEditing == null || grid == null || cmbManualFolderProperty == null)
                return;

            bool locked = chkLockEditing.Checked;

            cmbManualFolderProperty.Enabled = !locked;
            grid.ReadOnly = locked;

            grid.AllowUserToResizeColumns = !locked;
            grid.AllowUserToResizeRows = !locked;

            foreach (Control control in Controls)
            {
                if (control is Button button)
                {
                    if (button.Text == "Aggiungi" || button.Text == "Elimina")
                        button.Enabled = !locked;
                }
            }
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (grid == null || chkLockEditing?.Checked == true)
                return;

            int rowIndex = grid.Rows.Add("", "SPAZIO VUOTO", false);
            grid.ClearSelection();
            grid.Rows[rowIndex].Selected = true;
            grid.CurrentCell = grid.Rows[rowIndex].Cells["Placeholder"];
            grid.BeginEdit(true);
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (grid == null || chkLockEditing?.Checked == true)
                return;

            if (grid.CurrentRow == null)
                return;

            bool confirmDelete = ManualDialogService.Confirm(
                "Vuoi eliminare la sostituzione selezionata?",
                "Elimina sostituzione",
                this);

            if (!confirmDelete)
                return;

            grid.Rows.Remove(grid.CurrentRow);
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (grid == null || cmbManualFolderProperty == null || chkLockEditing == null)
                return;

            WordPlaceholderSettings newSettings = new WordPlaceholderSettings();

            newSettings.LockEditing = chkLockEditing.Checked;
            newSettings.ManualFolderProperty = cmbManualFolderProperty.Text.Trim();

            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                string placeholder = row.Cells["Placeholder"].Value?.ToString()?.Trim() ?? "";
                string source = row.Cells["Source"].Value?.ToString()?.Trim() ?? "";

                bool includeInTranslation =
                     Convert.ToBoolean(row.Cells["IncludeInTranslation"].Value ?? false);

                if (string.IsNullOrWhiteSpace(placeholder) &&
                    string.IsNullOrWhiteSpace(source))
                    continue;

                if (string.IsNullOrWhiteSpace(placeholder))
                {
                    ManualDialogService.Warning(
                        "Il campo Placeholder non può essere vuoto.",
                        "Gestisci Sostituzioni Word",
                        this);

                    return;
                }

                if (string.IsNullOrWhiteSpace(source))
                    source = "SPAZIO VUOTO";

                newSettings.Placeholders.Add(new WordPlaceholderConfig
                {
                    Placeholder = placeholder,
                    Source = source,
                    IncludeInTranslation = includeInTranslation
                });
            }

            WordPlaceholderSettingsService.Save(newSettings);

            _placeholderSettings = newSettings;
            Saved = true;

            Close();
        }
        private void WordPlaceholderForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "WordPlaceholder");
        }
    }
}