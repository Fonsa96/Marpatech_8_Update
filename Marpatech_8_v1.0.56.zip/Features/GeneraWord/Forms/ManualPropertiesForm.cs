﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.GeneraWord.Services;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings = Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class ManualPropertiesForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly ManualSettings _settings;
        private readonly CoreWindowSettings _windowSettings;

        private DataGridView? grid;

        public ManualPropertiesForm(bool isDarkTheme, ManualSettings settings)
        {
            _isDarkTheme = isDarkTheme;
            _settings = settings;
            _windowSettings = WindowSettingsService.Load(
               "ManualProperties",
               920,
               560);

            InitializeComponent();
            WindowSettingsService.Apply(
                this,
                _windowSettings);
            LoadRows();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            this.Text = "Gestione Proprietà Manuali";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(850, 620);
            this.MinimumSize = new DrawingSize(780, 540);
            this.BackColor = backgroundColor;
            this.FormClosing += ManualPropertiesForm_FormClosing;

            Label title = new Label();
            title.Text = "Gestione Proprietà Manuali";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Panel panel = new Panel();
            panel.Location = new DrawingPoint(35, 95);
            panel.Size = new DrawingSize(this.ClientSize.Width - 70, this.ClientSize.Height - 190);
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel.BackColor = cardColor;
            panel.Padding = new Padding(18);

            grid = new DataGridView();
            grid.Dock = DockStyle.Fill;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.BackgroundColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            grid.GridColor = DrawingColor.FromArgb(70, 75, 85);
            grid.BorderStyle = BorderStyle.FixedSingle;
            grid.Font = new DrawingFont("Segoe UI", 10);
            grid.EnableHeadersVisualStyles = false;
            grid.ColumnHeadersDefaultCellStyle.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.BackColor = _isDarkTheme ? DrawingColor.FromArgb(32, 34, 40) : DrawingColor.FromArgb(226, 232, 240);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = titleColor;
            grid.DefaultCellStyle.BackColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            grid.DefaultCellStyle.ForeColor = titleColor;

            grid.Columns.Add("Tag", "Tag");
            grid.Columns.Add("IPropertyName", "Proprietà Inventor");

            DataGridViewCheckBoxColumn requiredColumn = new DataGridViewCheckBoxColumn();
            requiredColumn.Name = "Required";
            requiredColumn.HeaderText = "Obbligatoria";
            grid.Columns.Add(requiredColumn);

            grid.Columns["Tag"]!.Width = 220;
            grid.Columns["IPropertyName"]!.Width = 360;
            grid.Columns["Required"]!.Width = 120;

            Button btnSave = CreateButton("Salva", DrawingColor.FromArgb(22, 163, 74), 150, 45);
            btnSave.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnSave.Location = new DrawingPoint(this.ClientSize.Width - 205, this.ClientSize.Height - 75);
            btnSave.Click += BtnSave_Click;

            Button btnClose = CreateButton("Chiudi", DrawingColor.FromArgb(100, 116, 139), 150, 45);
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Location = new DrawingPoint(this.ClientSize.Width - 370, this.ClientSize.Height - 75);
            btnClose.Click += (s, e) => this.Close();

            Button btnAdd = CreateButton("Aggiungi", DrawingColor.FromArgb(37, 99, 235), 150, 45);
            btnAdd.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnAdd.Location = new DrawingPoint(35, this.ClientSize.Height - 75);
            btnAdd.Click += BtnAdd_Click;

            Button btnDelete = CreateButton("Elimina", DrawingColor.FromArgb(220, 38, 38), 150, 45);
            btnDelete.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnDelete.Location = new DrawingPoint(200, this.ClientSize.Height - 75);
            btnDelete.Click += BtnDelete_Click;

            panel.Controls.Add(grid);

            this.Controls.Add(title);
            this.Controls.Add(panel);
            this.Controls.Add(btnClose);
            this.Controls.Add(btnSave);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnDelete);
        }

        private Button CreateButton(string text, DrawingColor color, int width, int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private void LoadRows()
        {
            if (grid == null)
                return;

            grid.Rows.Clear();

            foreach (ManualPropertyConfig property in _settings.Properties)
            {
                grid.Rows.Add(
                    property.Tag,
                    property.IPropertyName,
                    property.Required);
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (grid == null)
                return;

            _settings.Properties.Clear();

            foreach (DataGridViewRow row in grid.Rows)
            {
                if (row.IsNewRow)
                    continue;

                string tag = row.Cells["Tag"].Value?.ToString()?.Trim() ?? "";
                string iproperty = row.Cells["IPropertyName"].Value?.ToString()?.Trim() ?? "";
                bool required = Convert.ToBoolean(row.Cells["Required"].Value ?? true);

                if (string.IsNullOrWhiteSpace(tag) &&
                    string.IsNullOrWhiteSpace(iproperty))
                {
                    continue;
                }

                if (string.IsNullOrWhiteSpace(tag) ||
                    string.IsNullOrWhiteSpace(iproperty))
                {
                    ManualDialogService.Warning(
                        "Ogni riga deve avere sia Tag che Proprietà Inventor.",
                        "Gestione Proprietà Manuali",
                        this);

                    return;
                }

                _settings.Properties.Add(new ManualPropertyConfig
                {
                    Tag = tag,
                    IPropertyName = iproperty,
                    Required = required
                });
            }

            ManualSettingsService.Save(_settings);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void ManualPropertiesForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "ManualProperties");
        }
        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (grid == null)
                return;

            int rowIndex = grid.Rows.Add("", "", true);
            grid.ClearSelection();
            grid.Rows[rowIndex].Selected = true;
            grid.CurrentCell = grid.Rows[rowIndex].Cells["Tag"];
            grid.BeginEdit(true);
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (grid == null)
                return;

            if (grid.CurrentRow == null)
                return;

            if (grid.CurrentRow.IsNewRow)
                return;

            bool confirmDelete = ManualDialogService.Confirm(
                "Vuoi eliminare la proprietà selezionata?",
                "Elimina proprietà",
                this);

            if (!confirmDelete)
                return;

            grid.Rows.Remove(grid.CurrentRow);
        }
    }
}