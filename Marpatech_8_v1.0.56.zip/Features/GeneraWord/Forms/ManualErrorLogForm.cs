﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.GeneraWord.Config;
using Marpatech_8.Features.Core.Windows;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.GeneraWord.Forms
{
    public class ManualErrorLogForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly List<ManualGenerationError> _errors;

        public ManualErrorLogForm(
            bool isDarkTheme,
            List<ManualGenerationError> errors)
        {
            _isDarkTheme = isDarkTheme;
            _errors = errors;

            InitializeComponent();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            Text = "Log Errori Generazione";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new DrawingSize(900, 560);
            MinimumSize = new DrawingSize(800, 480);
            BackColor = backgroundColor;

            Label title = new Label();
            title.Text = "Log Errori Generazione";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Panel panel = new Panel();
            panel.Location = new DrawingPoint(35, 95);
            panel.Size = new DrawingSize(ClientSize.Width - 70, ClientSize.Height - 165);
            panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel.BackColor = cardColor;
            panel.Padding = new Padding(18);

            TextBox txtLog = new TextBox();
            txtLog.Multiline = true;
            txtLog.ScrollBars = ScrollBars.Vertical;
            txtLog.ReadOnly = true;
            txtLog.Dock = DockStyle.Fill;
            txtLog.Font = new DrawingFont("Consolas", 10);
            txtLog.BackColor = _isDarkTheme ? DrawingColor.FromArgb(43, 46, 55) : DrawingColor.White;
            txtLog.ForeColor = titleColor;
            txtLog.BorderStyle = BorderStyle.FixedSingle;
            txtLog.Text = BuildLogText();

            Button btnCopy = CreateButton("Copia", DrawingColor.FromArgb(37, 99, 235), 150, 45);
            btnCopy.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btnCopy.Location = new DrawingPoint(35, ClientSize.Height - 65);
            btnCopy.Click += (s, e) =>
            {
                ClipboardCompatibilityService.SetText(
                    txtLog.Text);
            };

            Button btnClose = CreateButton("Chiudi", DrawingColor.FromArgb(100, 116, 139), 150, 45);
            btnClose.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnClose.Location = new DrawingPoint(ClientSize.Width - 205, ClientSize.Height - 65);
            btnClose.Click += (s, e) => Close();

            panel.Controls.Add(txtLog);

            Controls.Add(title);
            Controls.Add(panel);
            Controls.Add(btnCopy);
            Controls.Add(btnClose);
        }

        private string BuildLogText()
        {
            if (_errors.Count == 0)
                return "Nessun errore.";

            return string.Join(
                System.Environment.NewLine + System.Environment.NewLine,
                _errors.Select(error =>
                    "File: " + error.FileName +
                    System.Environment.NewLine +
                    "Errore: " + error.ErrorMessage));
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }
    }
}