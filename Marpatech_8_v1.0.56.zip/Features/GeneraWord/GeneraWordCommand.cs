﻿using Inventor;
using Marpatech_8.Features.Core.Forms;
using Marpatech_8.Features.Core.Inventor;
using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.GeneraWord.Forms;
using Marpatech_8.Features.Mail;
using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.GeneraWord
{
    public static class GeneraWordCommand
    {
        public static void Execute(
            Inventor.Application inventorApp,
            FeatureOpenContext context)
        {
            /*
             * ==========================================
             * APERTURA DALLA MAIN DASHBOARD
             * ==========================================
             *
             * Se esiste una Main Dashboard utilizziamo
             * il Core Navigation comune:
             *
             * - nasconde la Dashboard;
             * - apre Genera Word;
             * - alla chiusura ripristina la Dashboard.
             */
            if (context.MainDashboard != null &&
                !context.MainDashboard.IsDisposed)
            {
                FeatureNavigationService.OpenFeature(
                    context,
                    "GeneraWord",
                    () => new GeneraWordDashboardForm(
                        inventorApp,
                        context.IsDarkTheme));

                return;
            }

            /*
             * ==========================================
             * APERTURA DIRETTA DA INVENTOR / RIBBON
             * ==========================================
             *
             * Manteniamo integralmente la logica
             * precedente:
             *
             * recuperiamo l'handle nativo di Inventor
             * e lo utilizziamo come owner.
             */
            IntPtr inventorHandle =
                InventorService.GetMainFrameHandle(
                    inventorApp);

            InventorWindowWrapper owner =
                new InventorWindowWrapper(
                    inventorHandle);

            SingleFormService.ShowSingle(
                "GeneraWord",
                () => new GeneraWordDashboardForm(
                    inventorApp,
                    context.IsDarkTheme),
                owner);
        }

        /*
         * ==========================================
         * COMPATIBILITÀ
         * ==========================================
         *
         * Manteniamo anche la vecchia firma,
         * così eventuali altre chiamate già presenti
         * nel progetto non vengono rotte.
         */
        public static void Execute(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            Execute(
                inventorApp,
                FeatureOpenContext.FromInventor(
                    isDarkTheme));
        }
    }
}