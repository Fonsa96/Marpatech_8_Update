﻿using System.IO.Compression;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class ZipCompatibilityService
    {
        public static bool ExtractToDirectory(
            string zipPath,
            string destinationFolder)
        {
            try
            {
                ZipFile.ExtractToDirectory(
                    zipPath,
                    destinationFolder);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}