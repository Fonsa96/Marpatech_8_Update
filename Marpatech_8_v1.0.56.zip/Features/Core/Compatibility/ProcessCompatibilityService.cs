﻿using System.Diagnostics;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class ProcessCompatibilityService
    {
        public static bool StartFile(string path)
        {
            return Start(
                new ProcessStartInfo
                {
                    FileName = path,
                    UseShellExecute = true
                });
        }

        public static bool StartHiddenCommand(
            string fileName,
            string arguments)
        {
            return Start(
                fileName,
                arguments,
                useShellExecute: false,
                createNoWindow: true,
                windowStyle: ProcessWindowStyle.Hidden);
        }

        public static void KillProcessSafe(string processName)
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName(processName))
                {
                    try
                    {
                        process.Kill();
                        process.WaitForExit(3000);
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }
        }
        public static bool Start(
    ProcessStartInfo processStartInfo)
        {
            try
            {
                Process.Start(processStartInfo);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool Start(
            string fileName,
            string arguments,
            bool useShellExecute = false,
            bool createNoWindow = false,
            ProcessWindowStyle windowStyle = ProcessWindowStyle.Normal)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    UseShellExecute = useShellExecute,
                    CreateNoWindow = createNoWindow,
                    WindowStyle = windowStyle
                };

                Process.Start(psi);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}