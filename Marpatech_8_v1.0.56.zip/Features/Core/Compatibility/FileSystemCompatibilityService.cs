﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class FileSystemCompatibilityService
    {
        public static bool FileExists(string path)
        {
            return File.Exists(path);
        }

        public static bool DirectoryExists(string path)
        {
            return Directory.Exists(path);
        }

        public static void EnsureDirectory(string path)
        {
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
        }

        public static void DeleteFileSafe(string path)
        {
            try
            {
                if (File.Exists(path))
                    File.Delete(path);
            }
            catch
            {
            }
        }

        public static void DeleteDirectorySafe(
            string path,
            bool recursive = true)
        {
            try
            {
                if (Directory.Exists(path))
                    Directory.Delete(path, recursive);
            }
            catch
            {
            }
        }

        public static IEnumerable<string> GetFilesSafe(
            string folder,
            string searchPattern,
            SearchOption searchOption)
        {
            try
            {
                if (!Directory.Exists(folder))
                    return Enumerable.Empty<string>();

                return Directory.GetFiles(
                    folder,
                    searchPattern,
                    searchOption);
            }
            catch
            {
                return Enumerable.Empty<string>();
            }
        }

        public static string ReadAllTextSafe(string path)
        {
            try
            {
                if (!File.Exists(path))
                    return "";

                return File.ReadAllText(path);
            }
            catch
            {
                return "";
            }
        }

        public static void WriteAllTextSafe(
            string path,
            string content)
        {
            try
            {
                string? folder = Path.GetDirectoryName(path);

                if (!string.IsNullOrWhiteSpace(folder))
                    Directory.CreateDirectory(folder);

                File.WriteAllText(path, content);
            }
            catch
            {
            }
        }
        public static void CopyFileSafe(
    string sourceFile,
    string destinationFile,
    bool overwrite = true)
        {
            try
            {
                if (!File.Exists(sourceFile))
                    return;

                string? destinationFolder =
                    Path.GetDirectoryName(destinationFile);

                if (!string.IsNullOrWhiteSpace(destinationFolder))
                    Directory.CreateDirectory(destinationFolder);

                File.Copy(
                    sourceFile,
                    destinationFile,
                    overwrite);
            }
            catch
            {
            }
        }
        public static IEnumerable<string> GetDirectoriesSafe(
    string folder,
    string searchPattern,
    SearchOption searchOption)
        {
            try
            {
                if (!Directory.Exists(folder))
                    return Enumerable.Empty<string>();

                return Directory.GetDirectories(
                    folder,
                    searchPattern,
                    searchOption);
            }
            catch
            {
                return Enumerable.Empty<string>();
            }
        }
        public static void MoveFileSafe(
            string sourceFile,
            string destinationFile,
            bool overwrite = true)
        {
            try
            {
                if (!File.Exists(sourceFile))
                    return;

                string? destinationFolder =
                    Path.GetDirectoryName(destinationFile);

                if (!string.IsNullOrWhiteSpace(destinationFolder))
                    Directory.CreateDirectory(destinationFolder);

                if (overwrite && File.Exists(destinationFile))
                    File.Delete(destinationFile);

                File.Move(
                    sourceFile,
                    destinationFile);
            }
            catch
            {
            }
        }
        public static void AppendAllTextSafe(
    string path,
    string content)
        {
            try
            {
                string? folder =
                    Path.GetDirectoryName(path);

                if (!string.IsNullOrWhiteSpace(folder))
                    Directory.CreateDirectory(folder);

                File.AppendAllText(
                    path,
                    content);
            }
            catch
            {
            }
        }
        public static long GetFileLengthSafe(
    string path)
        {
            try
            {
                if (!File.Exists(path))
                    return 0;

                return new FileInfo(path).Length;
            }
            catch
            {
                return 0;
            }
        }
        public static async Task<string> ReadAllTextAsyncSafe(string path)
        {
            try
            {
                if (!File.Exists(path))
                    return "";

                return await File.ReadAllTextAsync(path);
            }
            catch
            {
                return "";
            }
        }

        public static async Task WriteAllBytesAsyncSafe(
            string path,
            byte[] data)
        {
            try
            {
                string? folder = Path.GetDirectoryName(path);

                if (!string.IsNullOrWhiteSpace(folder))
                    Directory.CreateDirectory(folder);

                await File.WriteAllBytesAsync(path, data);
            }
            catch
            {
            }
        }
    }
}