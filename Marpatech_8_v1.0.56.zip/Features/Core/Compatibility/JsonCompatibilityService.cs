﻿using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class JsonCompatibilityService
    {
        private static readonly JsonSerializerOptions Options =
            new JsonSerializerOptions
            {
                WriteIndented = true,
                PropertyNameCaseInsensitive = true
            };

        public static T? Deserialize<T>(string json)
        {
            return DeserializeSafe<T>(json);
        }

        public static string Serialize<T>(T value)
        {
            return SerializeSafe(value);
        }

        public static T? LoadFromFile<T>(string path)
        {
            string json =
                FileSystemCompatibilityService.ReadAllTextSafe(path);

            if (string.IsNullOrWhiteSpace(json))
                return default;

            return DeserializeSafe<T>(json);
        }

        public static void SaveToFile<T>(
            string path,
            T value)
        {
            FileSystemCompatibilityService.WriteAllTextSafe(
                path,
                SerializeSafe(value));
        }
        public static T? DeserializeSafe<T>(string json)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(json))
                    return default;

                return JsonSerializer.Deserialize<T>(
                    json,
                    Options);
            }
            catch
            {
                return default;
            }
        }

        public static string SerializeSafe<T>(T value)
        {
            try
            {
                return JsonSerializer.Serialize(
                    value,
                    Options);
            }
            catch
            {
                return "";
            }
        }
    }
}