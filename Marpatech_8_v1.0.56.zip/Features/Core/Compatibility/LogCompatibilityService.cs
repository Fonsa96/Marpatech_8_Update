﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class LogCompatibilityService
    {
        public static void AppendLine(
            string logPath,
            string message)
        {
            try
            {
                string? folder =
                    Path.GetDirectoryName(logPath);

                if (!string.IsNullOrWhiteSpace(folder))
                    Directory.CreateDirectory(folder);

                File.AppendAllText(
                    logPath,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") +
                    " - " +
                    message +
                    Environment.NewLine);
            }
            catch
            {
            }
        }

        public static string JoinErrors(
            IEnumerable<string> errors)
        {
            return string.Join(
                Environment.NewLine +
                Environment.NewLine,
                errors.Where(x => !string.IsNullOrWhiteSpace(x)));
        }

        public static void AddError(
            List<string> errors,
            string message)
        {
            if (errors == null)
                return;

            if (string.IsNullOrWhiteSpace(message))
                return;

            errors.Add(message);
        }

        public static void AddException(
            List<string> errors,
            string title,
            Exception ex)
        {
            if (errors == null || ex == null)
                return;

            errors.Add(
                title +
                Environment.NewLine +
                ex.ToString());
        }
    }
}