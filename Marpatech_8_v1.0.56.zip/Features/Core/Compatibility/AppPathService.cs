﻿using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class AppPathService
    {
        public static string StartupPath
        {
            get
            {
                return Application.StartupPath;
            }
        }

        public static string Combine(params string[] paths)
        {
            return Path.Combine(paths);
        }

        public static string GetAppFolder(params string[] relativeParts)
        {
            string path = StartupPath;

            foreach (string part in relativeParts)
            {
                path = Path.Combine(path, part);
            }

            return path;
        }
    }
}