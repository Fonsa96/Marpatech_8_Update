﻿using System.Net.Http;
using System.Threading.Tasks;

namespace Marpatech_8.Features.Core.Compatibility
{
    public static class HttpCompatibilityService
    {
        public static async Task<string> GetStringAsync(
            string url)
        {
            using HttpClient client = new HttpClient();

            return await client.GetStringAsync(url);
        }

        public static async Task<byte[]> GetByteArrayAsync(
            string url)
        {
            using HttpClient client = new HttpClient();

            return await client.GetByteArrayAsync(url);
        }
    public static async Task<string> GetStringAsync(
    HttpClient client,
    string url)
        {
            return await client.GetStringAsync(url);
        }
    }
}