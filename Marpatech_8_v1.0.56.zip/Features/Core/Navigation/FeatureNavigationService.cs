﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public static class FeatureNavigationService
    {
        public static void OpenFeature(
            Form mainDashboard,
            string key,
            Func<Form> createFeatureForm,
            IWin32Window? owner = null)
        {
            if (mainDashboard == null || mainDashboard.IsDisposed)
                return;

            mainDashboard.Hide();

            SingleFormService.ShowSingle(
                key,
                () =>
                {
                    Form featureForm = createFeatureForm();

                    featureForm.FormClosed += (s, e) =>
                    {
                        if (!mainDashboard.IsDisposed)
                        {
                            mainDashboard.Show();

                            if (mainDashboard.WindowState == FormWindowState.Minimized)
                                mainDashboard.WindowState = FormWindowState.Normal;

                            mainDashboard.TopMost = true;
                            mainDashboard.TopMost = false;

                            mainDashboard.Activate();
                            mainDashboard.BringToFront();
                            mainDashboard.Focus();
                        }
                    };

                    return featureForm;
                },
                owner);
        }
        public static void OpenFeature(
    FeatureOpenContext context,
    string key,
    Func<Form> createFeatureForm)
        {
            if (context == null)
                return;

            Form? mainDashboard =
                context.MainDashboard;

            /*
             * ==========================================
             * APERTURA DALLA MAIN DASHBOARD
             * ==========================================
             *
             * Se esiste una Dashboard:
             * - la nascondiamo;
             * - alla chiusura della Feature la ripristiniamo.
             */
            if (mainDashboard != null &&
                !mainDashboard.IsDisposed)
            {
                mainDashboard.Hide();
            }

            /*
             * Manteniamo SingleFormService.
             *
             * Quindi anche aprendo la stessa funzione
             * dalla Ribbon non verranno create più
             * istanze contemporanee.
             */
            SingleFormService.ShowSingle(
                key,
                () =>
                {
                    Form featureForm =
                        createFeatureForm();

                    /*
                     * Questa parte serve solamente
                     * se la funzione è stata aperta
                     * dalla Main Dashboard.
                     *
                     * Se arriva dalla Ribbon,
                     * mainDashboard sarà null e
                     * non succederà nulla.
                     */
                    if (mainDashboard != null)
                    {
                        featureForm.FormClosed +=
                            (s, e) =>
                            {
                                if (mainDashboard.IsDisposed)
                                    return;

                                mainDashboard.Show();

                                if (mainDashboard.WindowState ==
                                    FormWindowState.Minimized)
                                {
                                    mainDashboard.WindowState =
                                        FormWindowState.Normal;
                                }

                                /*
                                 * Manteniamo lo stesso identico
                                 * comportamento già utilizzato
                                 * dal metodo originale.
                                 */
                                mainDashboard.TopMost =
                                    true;

                                mainDashboard.TopMost =
                                    false;

                                mainDashboard.Activate();

                                mainDashboard.BringToFront();

                                mainDashboard.Focus();
                            };
                    }

                    return featureForm;
                },
                mainDashboard);
        }
    }
}