﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public class FeatureOpenContext
    {
        public Form? MainDashboard
        {
            get;
            init;
        }

        /*
         * Owner della finestra quando la Feature
         * viene aperta direttamente da Inventor.
         *
         * Normalmente sarà InventorWindowWrapper.
         */
        public IWin32Window? WindowOwner
        {
            get;
            init;
        }

        public bool IsDarkTheme
        {
            get;
            init;
        }

        public bool HasMainDashboard =>
            MainDashboard != null;

        public static FeatureOpenContext FromDashboard(
            Form dashboard,
            bool isDarkTheme)
        {
            return new FeatureOpenContext
            {
                MainDashboard =
                    dashboard,

                WindowOwner =
                    dashboard,

                IsDarkTheme =
                    isDarkTheme
            };
        }

        /*
         * Manteniamo la vecchia firma
         * per non rompere eventuali chiamate esistenti.
         */
        public static FeatureOpenContext FromInventor(
            bool isDarkTheme)
        {
            return new FeatureOpenContext
            {
                MainDashboard =
                    null,

                WindowOwner =
                    null,

                IsDarkTheme =
                    isDarkTheme
            };
        }

        /*
         * Nuova firma:
         * permette di utilizzare Inventor
         * come vero owner della finestra modeless.
         */
        public static FeatureOpenContext FromInventor(
            bool isDarkTheme,
            IWin32Window inventorOwner)
        {
            return new FeatureOpenContext
            {
                MainDashboard =
                    null,

                WindowOwner =
                    inventorOwner,

                IsDarkTheme =
                    isDarkTheme
            };
        }
    }
}