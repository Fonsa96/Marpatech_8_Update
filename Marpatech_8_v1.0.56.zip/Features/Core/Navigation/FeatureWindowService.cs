﻿using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Navigation
{
    public static class FeatureWindowService
    {
        public static void Open(
            Form featureForm,
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                dashboard.Hide();
            }

            featureForm.FormClosed +=
                (_, _) =>
                {
                    RestoreDashboardDeferred(
                        context);
                };

            if (dashboard != null &&
                !dashboard.IsDisposed)
            {
                /*
                 * Apertura dalla Main Dashboard.
                 */
                featureForm.Show(
                    dashboard);
            }
            else if (context.WindowOwner != null)
            {
                /*
                 * Apertura diretta dalla Ribbon Inventor.
                 *
                 * Inventor diventa il vero owner Win32
                 * della finestra modeless.
                 */
                featureForm.Show(
                    context.WindowOwner);
            }
            else
            {
                /*
                 * Fallback di compatibilità.
                 */
                featureForm.Show();
            }

            featureForm.BringToFront();

            featureForm.Activate();

            featureForm.Focus();
        }


        /*
         * ==========================================
         * RIPRISTINO DASHBOARD DIFFERITO
         * ==========================================
         *
         * FormClosed può arrivare mentre WinForms
         * sta ancora completando la chiusura della
         * Feature.
         *
         * Rimandiamo quindi il ripristino al ciclo
         * successivo del message loop UI.
         */
        private static void RestoreDashboardDeferred(
            FeatureOpenContext context)
        {
            Form? dashboard =
                context.MainDashboard;

            if (dashboard == null ||
                dashboard.IsDisposed)
            {
                return;
            }

            try
            {
                if (dashboard.InvokeRequired)
                {
                    dashboard.BeginInvoke(
                        new Action(
                            () =>
                            {
                                RestoreDashboard(
                                    dashboard);
                            }));

                    return;
                }

                dashboard.BeginInvoke(
                    new Action(
                        () =>
                        {
                            RestoreDashboard(
                                dashboard);
                        }));
            }
            catch
            {
                /*
                 * Se la Dashboard viene chiusa
                 * mentre la Feature sta terminando,
                 * non dobbiamo generare errori.
                 */
            }
        }


        /*
         * ==========================================
         * RIPRISTINO E RIDISEGNO DASHBOARD
         * ==========================================
         */
        private static void RestoreDashboard(
            Form dashboard)
        {
            if (dashboard.IsDisposed ||
                dashboard.Disposing)
            {
                return;
            }

            try
            {
                /*
                 * Riportiamo prima la finestra
                 * in uno stato valido.
                 */
                if (dashboard.WindowState ==
                    FormWindowState.Minimized)
                {
                    dashboard.WindowState =
                        FormWindowState.Normal;
                }


                /*
                 * Mostriamo la Dashboard.
                 */
                if (!dashboard.Visible)
                {
                    dashboard.Show();
                }


                /*
                 * Forziamo un nuovo calcolo
                 * completo del layout.
                 */
                dashboard.PerformLayout();


                /*
                 * Invalidiamo anche tutti i controlli
                 * figli, non solamente il Form.
                 */
                dashboard.Invalidate(
                    true);


                /*
                 * Update forza l'elaborazione
                 * immediata del repaint pendente.
                 */
                dashboard.Update();


                /*
                 * Ripristino focus/z-order.
                 */
                dashboard.BringToFront();

                dashboard.Activate();

                dashboard.Focus();


                /*
                 * Secondo refresh dopo l'attivazione.
                 *
                 * Utile soprattutto quando Inventor
                 * sta contemporaneamente riprendendo
                 * il focus della propria finestra.
                 */
                dashboard.Refresh();
            }
            catch
            {
                /*
                 * Il ripristino grafico non deve
                 * mai bloccare l'Addin.
                 */
            }
        }
    }
}