﻿using System;

using InventorApplication =
    global::Inventor.Application;

using InventorButtonDefinition =
    global::Inventor.ButtonDefinition;

using InventorCommandTypesEnum =
    global::Inventor.CommandTypesEnum;

using InventorNameValueMap =
    global::Inventor.NameValueMap;


namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Servizio comune per registrare una Feature
    /// come comando Inventor.
    ///
    /// Responsabilità:
    /// - crea o recupera il ButtonDefinition;
    /// - collega l'evento OnExecute;
    /// - applica le eventuali posizioni Ribbon.
    ///
    /// NON contiene logica specifica delle Feature.
    /// </summary>
    public static class RibbonFeatureService
    {
        private const string AddInClientId =
            "{A2F7D8B1-3C44-4A1F-9C8E-112233445566}";


        /// <summary>
        /// Registra una Feature come comando Inventor.
        ///
        /// Restituisce il ButtonDefinition creato
        /// o recuperato.
        ///
        /// Se Placements è vuoto, il comando viene
        /// comunque registrato ma non viene inserito
        /// automaticamente in nessun pannello Ribbon.
        /// </summary>
        public static InventorButtonDefinition?
            RegisterFeature(
                InventorApplication inventorApp,
                RibbonFeatureDefinition feature,
                Action<InventorNameValueMap> executeAction)
        {
            if (inventorApp == null)
                return null;

            if (feature == null)
                return null;

            if (executeAction == null)
                return null;

            if (string.IsNullOrWhiteSpace(
                    feature.DisplayName))
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(
                    feature.InternalName))
            {
                return null;
            }

            InventorButtonDefinition?
                buttonDefinition =
                    GetOrCreateButtonDefinition(
                        inventorApp,
                        feature);

            if (buttonDefinition == null)
                return null;

                        /*
             * Garantiamo automaticamente che ogni Feature
             * registrata esista anche nel RibbonLayout.json.
             *
             * Se esiste già:
             * - NON tocchiamo i Placements;
             * - aggiorniamo solo l'eventuale DisplayName.
             *
             * Se non esiste:
             * - la aggiungiamo con Placements vuoto.
             */
                        RibbonLayoutService.EnsureFeatureExists(
                            feature.InternalName,
                            feature.DisplayName);

            /*
             * Colleghiamo il comportamento della Feature.
             *
             * L'Action viene convertita nell'evento
             * richiesto da Inventor.
             */
            buttonDefinition.OnExecute +=
                executeAction.Invoke;

            /*
             * Se la Feature ha delle posizioni definite,
             * la aggiungiamo automaticamente.
             *
             * Se Placements è vuoto non succede nulla:
             * il comando resta comunque registrato.
             */
            foreach (RibbonPlacementDefinition placement
                     in feature.Placements)
            {
                RibbonPlacementService.AddButton(
                    inventorApp,
                    buttonDefinition,
                    placement);
            }

            return buttonDefinition;
        }

        /// <summary>
        /// Scollega l'evento di una Feature.
        ///
        /// Da utilizzare in Deactivate().
        /// </summary>
        public static void UnregisterFeature(
            InventorButtonDefinition? buttonDefinition,
            Action<InventorNameValueMap> executeAction)
        {
            if (buttonDefinition == null)
                return;

            if (executeAction == null)
                return;

            try
            {
                buttonDefinition.OnExecute -=
                    executeAction.Invoke;
            }
            catch
            {
                /*
                 * Non impediamo la disattivazione
                 * dell'Addin per un problema UI.
                 */
            }
        }

        private static InventorButtonDefinition?
            GetOrCreateButtonDefinition(
                InventorApplication inventorApp,
                RibbonFeatureDefinition feature)
        {
            try
            {
                /*
                 * Prima proviamo a recuperare
                 * una definizione già registrata.
                 */
                try
                {
                    return inventorApp
                        .CommandManager
                        .ControlDefinitions[
                            feature.InternalName]
                        as InventorButtonDefinition;
                }
                catch
                {
                    /*
                     * Non esiste ancora:
                     * continuiamo con la creazione.
                     */
                }

                string description =
                    string.IsNullOrWhiteSpace(
                        feature.Description)
                        ? feature.DisplayName
                        : feature.Description;

                string toolTip =
                    string.IsNullOrWhiteSpace(
                        feature.ToolTip)
                        ? description
                        : feature.ToolTip;

                object? standardIcon =
                    RibbonIconService.LoadPictureDisp(
                        feature.IconPath);

                object? largeIcon =
                    RibbonIconService.LoadPictureDisp(
                        feature.IconPath);

                return inventorApp
                    .CommandManager
                    .ControlDefinitions
                    .AddButtonDefinition(
                        feature.DisplayName,
                        feature.InternalName,
                        InventorCommandTypesEnum
                            .kNonShapeEditCmdType,
                        AddInClientId,
                        description,
                        toolTip,
                        standardIcon,
                        largeIcon);
            }
            catch
            {
                return null;
            }
        }
    }
}