﻿using Marpatech_8.Features.Core.Compatibility;
using System;
using System.IO;
using System.Linq;

namespace Marpatech_8.Features.Core.Ribbon
{
    public static class RibbonLayoutService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData =
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings",
                    "Ribbon");
            }
        }

        private static string SettingsPath =>
            Path.Combine(
                SettingsFolder,
                "RibbonLayout.json");

        public static RibbonLayoutSettings Load()
        {
            try
            {
                RibbonLayoutSettings? settings =
                    JsonCompatibilityService
                        .LoadFromFile<RibbonLayoutSettings>(
                            SettingsPath);

                if (settings != null)
                    return settings;
            }
            catch
            {
            }

            RibbonLayoutSettings defaultSettings =
                CreateDefaultSettings();

            Save(
                defaultSettings);

            return defaultSettings;
        }

        public static void Save(
            RibbonLayoutSettings settings)
        {
            try
            {
                JsonCompatibilityService.SaveToFile(
                    SettingsPath,
                    settings);
            }
            catch
            {
            }
        }

        /*
         * ==========================================
         * REGISTRAZIONE AUTOMATICA FEATURE
         * ==========================================
         *
         * Questo metodo viene richiamato quando
         * una Feature viene registrata nel Core Ribbon.
         *
         * Se la Feature:
         *
         * - ESISTE GIÀ:
         *   non modifica MAI i Placements esistenti.
         *
         * - ESISTE ma manca DisplayName:
         *   aggiorna solamente DisplayName.
         *
         * - NON ESISTE:
         *   la aggiunge automaticamente al JSON
         *   con Placements vuoto.
         *
         * In questo modo una nuova funzione comparirà
         * automaticamente nelle Impostazioni Ribbon,
         * ma NON verrà inserita a caso in una scheda.
         */
        public static void EnsureFeatureExists(
            string internalName,
            string displayName)
        {
            if (string.IsNullOrWhiteSpace(
                    internalName))
            {
                return;
            }

            RibbonLayoutSettings settings =
                Load();

            RibbonFeatureLayout? existingFeature =
                settings.Features
                    .FirstOrDefault(
                        x =>
                            string.Equals(
                                x.InternalName,
                                internalName,
                                StringComparison.OrdinalIgnoreCase));

            bool mustSave =
                false;

            /*
             * ==========================================
             * FEATURE NUOVA
             * ==========================================
             */
            if (existingFeature == null)
            {
                settings.Features.Add(
                    new RibbonFeatureLayout
                    {
                        InternalName =
                            internalName,

                        DisplayName =
                            displayName ?? string.Empty,
                       IncludeInRibbon =
                          false
                    });

                /*
                 * Placements rimane volutamente vuoto.
                 *
                 * Sarà l'utente a scegliere:
                 *
                 * - Parte / Assieme / Disegno / ...
                 * - nome della scheda
                 *
                 * dal Form Impostazioni.
                 */
                mustSave =
                    true;
            }
            else
            {
                /*
                 * ==========================================
                 * FEATURE GIÀ ESISTENTE
                 * ==========================================
                 *
                 * Non tocchiamo assolutamente:
                 *
                 * RibbonName
                 * TabInternalName
                 * TabDisplayName
                 * PanelDisplayName
                 * PanelInternalName
                 * UseLargeButton
                 *
                 * Quindi le personalizzazioni dell'utente
                 * restano sempre intatte.
                 */

                if (!string.IsNullOrWhiteSpace(
                        displayName) &&
                    !string.Equals(
                        existingFeature.DisplayName,
                        displayName,
                        StringComparison.Ordinal))
                {
                    existingFeature.DisplayName =
                        displayName;

                    mustSave =
                        true;
                }
            }

            /*
             * Scriviamo fisicamente il JSON
             * solo se è davvero cambiato qualcosa.
             */
            if (mustSave)
            {
                Save(
                    settings);
            }
        }

        public static RibbonPlacementDefinition[]
            GetPlacements(
                string featureInternalName)
        {
            if (string.IsNullOrWhiteSpace(
                    featureInternalName))
            {
                return Array.Empty<RibbonPlacementDefinition>();
            }

            RibbonLayoutSettings settings =
                Load();

            RibbonFeatureLayout? feature =
                settings.Features
                    .FirstOrDefault(
                        x =>
                            string.Equals(
                                x.InternalName,
                                featureInternalName,
                                StringComparison.OrdinalIgnoreCase));

            if (feature == null)
            {
                return Array.Empty<RibbonPlacementDefinition>();
            }

            if (!feature.IncludeInRibbon)
            {
                return Array.Empty<RibbonPlacementDefinition>();
            }

            return feature
                .Placements
                .ToArray();
        }

        private static RibbonLayoutSettings
            CreateDefaultSettings()
        {
            return new RibbonLayoutSettings
            {
                Features =
                {
                    new RibbonFeatureLayout
                    {
                        InternalName =
                            "Marpatech8_RegoleProgettazione",

                        DisplayName =
                            "Regole di progettazione",

                            IncludeInRibbon =
                             true,

                        Placements =
                        {
                            new RibbonPlacementDefinition
                            {
                                RibbonName =
                                    "Assembly",

                                TabDisplayName =
                                    "Assembla",

                                PanelDisplayName =
                                    "Marpatech",

                                PanelInternalName =
                                    "Marpatech8_Assembly_Features",

                                UseLargeButton =
                                    true

                            }
                        }
                    }
                }
            };
        }
    }
}