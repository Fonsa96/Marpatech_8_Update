﻿using System.Collections.Generic;

namespace Marpatech_8.Features.Core.Ribbon
{
    public sealed class RibbonLayoutSettings
    {
        public List<RibbonFeatureLayout>
            Features
        { get; set; } =
            new List<RibbonFeatureLayout>();
    }

    public sealed class RibbonFeatureLayout
    {
        public string InternalName
        {
            get;
            set;
        } = string.Empty;

        public string DisplayName
        {
            get;
            set;
        } = string.Empty;

        public bool IncludeInRibbon
        {
            get;
            set;
        } = false;

        public List<RibbonPlacementDefinition>
            Placements
        { get; set; } =
            new List<RibbonPlacementDefinition>();
    }
}