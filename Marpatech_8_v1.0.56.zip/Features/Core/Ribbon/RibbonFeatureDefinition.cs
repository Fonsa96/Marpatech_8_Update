﻿using System.Collections.Generic;

namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Descrive un comando Feature dell'Addin
    /// che può essere registrato in Inventor
    /// e successivamente posizionato nella Ribbon.
    ///
    /// Questa classe contiene solo dati:
    /// non crea pulsanti e non esegue logica.
    /// </summary>
    public sealed class RibbonFeatureDefinition
    {
        /// <summary>
        /// Testo mostrato da Inventor.
        ///
        /// Esempio:
        /// "Regole di progettazione"
        /// </summary>
        public string DisplayName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// InternalName univoco e stabile
        /// del comando Inventor.
        ///
        /// Esempio:
        /// "Marpatech8_RegoleProgettazione"
        /// </summary>
        public string InternalName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Testo breve mostrato come descrizione.
        /// </summary>
        public string Description
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Tooltip esteso del comando.
        /// </summary>
        public string ToolTip
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Percorso dell'icona utilizzata dal comando Ribbon.
        ///
        /// Se vuoto, il comando continua a funzionare
        /// senza icona personalizzata.
        /// </summary>
        public string IconPath
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Se true, il Core può inserire un separatore
        /// prima del comando quando viene aggiunto
        /// a un pannello Ribbon.
        ///
        /// Serve a distinguere meglio più Feature
        /// presenti nello stesso pannello.
        /// </summary>
        public bool SeparatorBefore
        {
            get;
            init;
        } = true;

        /// <summary>
        /// Elenco delle posizioni in cui il comando
        /// deve essere inserito automaticamente.
        ///
        /// Se la lista è vuota:
        /// il comando può comunque essere registrato
        /// come ButtonDefinition, ma non viene inserito
        /// automaticamente in nessun pannello Ribbon.
        /// </summary>
        public List<RibbonPlacementDefinition>
            Placements
        { get; init; } =
            new List<RibbonPlacementDefinition>();
    }
}