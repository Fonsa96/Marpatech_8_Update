﻿using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Servizio comune per convertire immagini .NET
    /// nel formato COM utilizzato dalla Ribbon Inventor.
    /// </summary>
    public static class RibbonIconService
    {
        private sealed class PictureDispConverter :
            AxHost
        {
            private PictureDispConverter()
                : base(string.Empty)
            {
            }

            public static object? Convert(
                Image image)
            {
                if (image == null)
                    return null;

                return GetIPictureDispFromPicture(
                    image);
            }
        }

        public static object? LoadPictureDisp(
            string iconPath)
        {
            if (string.IsNullOrWhiteSpace(
                    iconPath))
            {
                return null;
            }

            if (!File.Exists(
                    iconPath))
            {
                return null;
            }

            try
            {
                using Image image =
                    Image.FromFile(
                        iconPath);

                using Bitmap bitmap =
                    new Bitmap(
                        image);

                return PictureDispConverter.Convert(
                    bitmap);
            }
            catch
            {
                return null;
            }
        }
    }
}