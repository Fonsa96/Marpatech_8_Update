﻿namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Descrive una posizione nella Ribbon di Inventor
    /// in cui può essere inserito un comando dell'Addin.
    ///
    /// Questa classe contiene solamente configurazione.
    /// Non crea pulsanti e non contiene logica Feature.
    /// </summary>
    public sealed class RibbonPlacementDefinition
    {
        /// <summary>
        /// Nome della Ribbon Inventor.
        ///
        /// Esempi:
        /// ZeroDoc
        /// Part
        /// Assembly
        /// Drawing
        /// Presentation
        /// </summary>
        public string RibbonName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// InternalName della scheda Ribbon.
        ///
        /// Se conosciuto, ha la precedenza assoluta.
        ///
        /// Se vuoto, RibbonPlacementService proverà
        /// a cercare la scheda tramite TabDisplayName.
        /// </summary>
        public string TabInternalName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Nome visualizzato della scheda.
        ///
        /// Esempio in Inventor italiano:
        /// "Assembla"
        ///
        /// Serve soprattutto quando non conosciamo
        /// ancora l'InternalName Autodesk.
        ///
        /// In futuro potremo sostituirlo nel JSON
        /// con l'InternalName senza modificare codice.
        /// </summary>
        public string TabDisplayName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// Nome visualizzato del pannello
        /// che conterrà il comando.
        /// </summary>
        public string PanelDisplayName
        {
            get;
            init;
        } = "Marpatech";

        /// <summary>
        /// InternalName univoco e stabile
        /// del pannello creato dall'Addin.
        /// </summary>
        public string PanelInternalName
        {
            get;
            init;
        } = string.Empty;

        /// <summary>
        /// true  = pulsante grande.
        /// false = pulsante piccolo.
        /// </summary>
        public bool UseLargeButton
        {
            get;
            init;
        } = true;
    }
}