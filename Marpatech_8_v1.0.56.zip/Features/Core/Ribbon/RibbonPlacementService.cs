﻿using System;

using InventorApplication =
    global::Inventor.Application;

using InventorButtonDefinition =
    global::Inventor.ButtonDefinition;

using InventorRibbon =
    global::Inventor.Ribbon;

using InventorRibbonTab =
    global::Inventor.RibbonTab;

using InventorRibbonPanel =
    global::Inventor.RibbonPanel;

namespace Marpatech_8.Features.Core.Ribbon
{
    /// <summary>
    /// Servizio comune per posizionare un comando
    /// già esistente all'interno della Ribbon di Inventor.
    ///
    /// Questo servizio:
    /// - NON crea il ButtonDefinition;
    /// - NON contiene logica delle Feature;
    /// - NON gestisce eventi OnExecute;
    /// - decide solamente dove mostrare il comando.
    /// </summary>
    public static class RibbonPlacementService
    {
        public static void AddButton(
            InventorApplication inventorApp,
            InventorButtonDefinition buttonDefinition,
            RibbonPlacementDefinition placement)
        {
            if (inventorApp == null)
                return;

            if (buttonDefinition == null)
                return;

            if (placement == null)
                return;

            if (string.IsNullOrWhiteSpace(
                    placement.RibbonName))
            {
                return;
            }

            try
            {
                InventorRibbon ribbon =
                    inventorApp
                        .UserInterfaceManager
                        .Ribbons[
                            placement.RibbonName];

                InventorRibbonTab? ribbonTab =
                    GetRibbonTab(
                        ribbon,
                        placement);

                /*
                 * Se l'utente ha indicato esplicitamente
                 * una scheda e questa non esiste,
                 * NON spostiamo il comando in Strumenti.
                 */
                if (ribbonTab == null)
                {
                    return;
                }

                InventorRibbonPanel ribbonPanel =
                    GetOrCreatePanel(
                        ribbonTab,
                        placement);

                AddButtonToPanel(
                    ribbonPanel,
                    buttonDefinition,
                    placement.UseLargeButton);
            }
            catch
            {
                /*
                 * Un problema nella Ribbon
                 * non deve impedire il caricamento
                 * dell'Addin.
                 */
            }
        }

        private static InventorRibbonTab? GetRibbonTab(
            InventorRibbon ribbon,
            RibbonPlacementDefinition placement)
        {
            /*
             * ==========================================
             * 1. INTERNAL NAME ESPLICITO
             * ==========================================
             */
            if (!string.IsNullOrWhiteSpace(
                    placement.TabInternalName))
            {
                string requestedInternalName =
                    placement.TabInternalName.Trim();

                /*
                 * Prima proviamo l'accesso diretto.
                 */
                try
                {
                    return ribbon
                        .RibbonTabs[
                            requestedInternalName];
                }
                catch
                {
                }

                /*
                 * Poi facciamo anche una ricerca manuale,
                 * case-insensitive.
                 */
                foreach (InventorRibbonTab tab
                         in ribbon.RibbonTabs)
                {
                    try
                    {
                        string tabInternalName =
                            tab.InternalName?
                                .Trim()
                            ?? string.Empty;

                        if (string.Equals(
                                tabInternalName,
                                requestedInternalName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return tab;
                        }
                    }
                    catch
                    {
                    }
                }
            }

            /*
             * ==========================================
             * 2. NOME VISUALIZZATO
             * ==========================================
             *
             * Questo è il caso utilizzato dalle nostre
             * Impostazioni.
             *
             * Esempio:
             * MARPATECH
             */
            if (!string.IsNullOrWhiteSpace(
                    placement.TabDisplayName))
            {
                string requestedDisplayName =
                    placement.TabDisplayName.Trim();

                foreach (InventorRibbonTab tab
                         in ribbon.RibbonTabs)
                {
                    try
                    {
                        string tabDisplayName =
                            tab.DisplayName?
                                .Trim()
                            ?? string.Empty;

                        /*
                         * Ricerca per nome visualizzato.
                         */
                        if (string.Equals(
                                tabDisplayName,
                                requestedDisplayName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return tab;
                        }

                        /*
                         * Per maggiore robustezza controlliamo
                         * anche l'InternalName.
                         *
                         * Alcune schede personalizzate possono
                         * avere un InternalName molto simile
                         * al nome che l'utente vede.
                         */
                        string tabInternalName =
                            tab.InternalName?
                                .Trim()
                            ?? string.Empty;

                        if (string.Equals(
                                tabInternalName,
                                requestedDisplayName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return tab;
                        }
                    }
                    catch
                    {
                        /*
                         * Una singola scheda non leggibile
                         * non interrompe la ricerca.
                         */
                    }
                }

                /*
                 * IMPORTANTISSIMO:
                 *
                 * l'utente ha specificato una scheda precisa
                 * ma non è stata trovata.
                 *
                 * NON facciamo fallback su Strumenti.
                 */
                return null;
            }

            /*
             * ==========================================
             * 3. FALLBACK SOLO SE NON È STATA
             *    CONFIGURATA NESSUNA SCHEDA
             * ==========================================
             *
             * Questo mantiene compatibilità con eventuali
             * configurazioni vecchie.
             */
            try
            {
                return ribbon
                    .RibbonTabs[
                        "id_TabTools"];
            }
            catch
            {
            }

            try
            {
                return ribbon.RibbonTabs[1];
            }
            catch
            {
                return null;
            }
        }
        private static InventorRibbonPanel GetOrCreatePanel(
            InventorRibbonTab ribbonTab,
            RibbonPlacementDefinition placement)
        {
            string panelInternalName =
                placement.PanelInternalName;

            if (string.IsNullOrWhiteSpace(
                    panelInternalName))
            {
                panelInternalName =
                    BuildDefaultPanelInternalName(
                        placement);
            }

            try
            {
                return ribbonTab
                    .RibbonPanels[
                        panelInternalName];
            }
            catch
            {
                string displayName =
                    string.IsNullOrWhiteSpace(
                        placement.PanelDisplayName)
                        ? "Marpatech"
                        : placement.PanelDisplayName;

                return ribbonTab
                    .RibbonPanels
                    .Add(
                        displayName,
                        panelInternalName,
                        "{A2F7D8B1-3C44-4A1F-9C8E-112233445566}");
            }
        }

        private static void AddButtonToPanel(
            InventorRibbonPanel ribbonPanel,
            InventorButtonDefinition buttonDefinition,
            bool useLargeButton)
        {
            /*
             * ==========================================
             * 1. VERIFICA SE IL COMANDO ESISTE GIÀ
             * ==========================================
             *
             * Il posizionamento può essere richiamato
             * più volte, ad esempio da OnActivateDocument.
             *
             * Prima di aggiungere qualsiasi cosa
             * verifichiamo quindi se questo comando
             * è già presente nel pannello.
             */
            try
            {
                foreach (global::Inventor.CommandControl control
                         in ribbonPanel.CommandControls)
                {
                    try
                    {
                        if (control.ControlDefinition == null)
                            continue;

                        if (string.Equals(
                                control.ControlDefinition.InternalName,
                                buttonDefinition.InternalName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            /*
                             * Il pulsante è già presente.
                             *
                             * Non aggiungiamo né un altro
                             * separatore né un altro pulsante.
                             */
                            return;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
                /*
                 * Se Inventor non permette la lettura
                 * della collection, continuiamo comunque
                 * con il normale tentativo di inserimento.
                 */
            }

            /*
             * ==========================================
             * 2. SEPARATORE
             * ==========================================
             */
            try
            {
                ribbonPanel
                    .CommandControls
                    .AddSeparator();
            }
            catch
            {
                /*
                 * Un problema con il separatore
                 * non deve impedire l'aggiunta
                 * della Feature.
                 */
            }

            /*
             * ==========================================
             * 3. PULSANTE
             * ==========================================
             */
            try
            {
                ribbonPanel
                    .CommandControls
                    .AddButton(
                        buttonDefinition,
                        useLargeButton);
            }
            catch
            {
                /*
                 * Un problema UI non deve impedire
                 * il caricamento dell'Addin.
                 */
            }
        }

        private static string BuildDefaultPanelInternalName(
            RibbonPlacementDefinition placement)
        {
            string ribbonName =
                CleanInternalName(
                    placement.RibbonName);

            string panelName =
                CleanInternalName(
                    placement.PanelDisplayName);

            return
                "Marpatech8_" +
                ribbonName +
                "_" +
                panelName;
        }

        private static string CleanInternalName(
            string value)
        {
            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return "Panel";
            }

            return value
                .Replace(
                    " ",
                    string.Empty)
                .Replace(
                    ".",
                    string.Empty)
                .Replace(
                    "-",
                    string.Empty)
                .Trim();
        }
    }
}