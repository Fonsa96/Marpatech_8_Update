﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Core.Temporary
{
    public static class TempFileService
    {
        public static string GetTempFolder(string featureName)
        {
            string featureFolder =
                AppPathService.GetAppFolder(
                    "Features",
                    "MainDashboard",
                    "Temp",
                    featureName);

            FileSystemCompatibilityService.EnsureDirectory(
                featureFolder);

            return featureFolder;
        }

        public static void ClearTempFolder(string featureName)
        {
            try
            {
                string folder =
                    GetTempFolder(featureName);

                FileSystemCompatibilityService.DeleteDirectorySafe(
                    folder,
                    true);
            }
            catch
            {
            }
        }
    }
}