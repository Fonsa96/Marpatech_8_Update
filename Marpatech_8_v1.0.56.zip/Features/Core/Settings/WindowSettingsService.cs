﻿using System;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Core.Settings
{
    public static class WindowSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(
                    Environment.SpecialFolder.ApplicationData);

                return Path.Combine(
                    appData,
                    "Marpatech",
                    "Settings",
                    "Windows");
            }
        }

        public static WindowSettings Load(
            string windowKey,
            int defaultWidth,
            int defaultHeight)
        {
            try
            {
                string path = GetSettingsPath(windowKey);

                WindowSettings? settings =
                    JsonCompatibilityService.LoadFromFile<WindowSettings>(path);

                if (settings == null)
                {
                    return new WindowSettings
                    {
                        Width = defaultWidth,
                        Height = defaultHeight
                    };
                }

                if (settings.Width <= 0)
                    settings.Width = defaultWidth;

                if (settings.Height <= 0)
                    settings.Height = defaultHeight;

                return settings;
            }
            catch
            {
                return new WindowSettings
                {
                    Width = defaultWidth,
                    Height = defaultHeight
                };
            }
        }

        public static void Apply(
            Form form,
            WindowSettings settings)
        {
            if (form == null || settings == null)
                return;

            form.Width = settings.Width;
            form.Height = settings.Height;

            if (settings.Left >= 0 && settings.Top >= 0)
            {
                form.StartPosition = FormStartPosition.Manual;
                form.Left = settings.Left;
                form.Top = settings.Top;
            }

            if (settings.IsMaximized)
                form.WindowState = FormWindowState.Maximized;
        }

        public static void Save(
            Form form,
            string windowKey)
        {
            if (form == null)
                return;

            WindowSettings settings = new WindowSettings();

            if (form.WindowState == FormWindowState.Normal)
            {
                settings.Width = form.Width;
                settings.Height = form.Height;
                settings.Left = form.Left;
                settings.Top = form.Top;
                settings.IsMaximized = false;
            }
            else if (form.WindowState == FormWindowState.Maximized)
            {
                settings.IsMaximized = true;

                settings.Width = form.RestoreBounds.Width;
                settings.Height = form.RestoreBounds.Height;
                settings.Left = form.RestoreBounds.Left;
                settings.Top = form.RestoreBounds.Top;
            }

            Save(windowKey, settings);
        }

        public static void Save(
            string windowKey,
            WindowSettings settings)
        {
            try
            {
                string path = GetSettingsPath(windowKey);

                JsonCompatibilityService.SaveToFile(
                    path,
                    settings);
            }
            catch
            {
            }
        }

        private static string GetSettingsPath(string windowKey)
        {
            string safeKey = CleanFileName(windowKey);

            return Path.Combine(
                SettingsFolder,
                safeKey + ".json");
        }

        private static string CleanFileName(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return "Window";

            foreach (char invalidChar in Path.GetInvalidFileNameChars())
            {
                value = value.Replace(invalidChar.ToString(), "");
            }

            return value.Trim();
        }
    }
}