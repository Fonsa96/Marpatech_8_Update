﻿namespace Marpatech_8.Features.Core.Settings
{
    public class WindowSettings
    {
        public int Width { get; set; } = 900;
        public int Height { get; set; } = 600;
        public int Left { get; set; } = -1;
        public int Top { get; set; } = -1;
        public bool IsMaximized { get; set; }
    }
}