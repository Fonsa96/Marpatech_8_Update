﻿using System;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace Marpatech_8.Features.Core.Office
{
    public static class ExcelAutomationService
    {
        public static Excel.Application? CreateApplication(
            bool visible,
            bool displayAlerts)
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = visible;
                excelApp.DisplayAlerts = displayAlerts;
                return excelApp;
            }
            catch
            {
                return null;
            }
        }

        public static Excel.Workbook? OpenWorkbook(
            Excel.Application excelApp,
            string filePath,
            bool readOnly = true)
        {
            try
            {
                return excelApp.Workbooks.Open(
                    filePath,
                    ReadOnly: readOnly);
            }
            catch
            {
                return null;
            }
        }

        public static bool PrintWorkbook(
            Excel.Workbook workbook)
        {
            try
            {
                workbook.PrintOut(
                    Copies: 1,
                    Collate: true);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void CloseWorkbook(
            Excel.Workbook? workbook,
            bool saveChanges)
        {
            try
            {
                if (workbook == null)
                    return;

                workbook.Close(
                    SaveChanges: saveChanges);
            }
            catch
            {
            }
        }

        public static void QuitApplication(
            Excel.Application? excelApp)
        {
            try
            {
                if (excelApp == null)
                    return;

                excelApp.Quit();
            }
            catch
            {
            }
        }
        public static bool SaveWorkbook(
            Excel.Workbook? workbook)
        {
            try
            {
                if (workbook == null)
                    return false;

                workbook.Save();

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool SaveWorkbookAs(
            Excel.Workbook? workbook,
            string filePath)
        {
            try
            {
                if (workbook == null)
                    return false;

                if (string.IsNullOrWhiteSpace(filePath))
                    return false;

                workbook.SaveAs(filePath);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void ReleaseWorkbook(
            ref Excel.Workbook? workbook,
            bool saveChanges)
        {
            try
            {
                if (workbook == null)
                    return;

                CloseWorkbook(
                    workbook,
                    saveChanges);
            }
            finally
            {
                try
                {
                    if (workbook != null &&
                        Marshal.IsComObject(workbook))
                    {
                        Marshal.ReleaseComObject(workbook);
                    }
                }
                catch
                {
                }

                workbook = null;
            }
        }

        public static void ReleaseApplication(
            ref Excel.Application? excelApp)
        {
            try
            {
                if (excelApp == null)
                    return;

                QuitApplication(excelApp);
            }
            finally
            {
                try
                {
                    if (excelApp != null &&
                        Marshal.IsComObject(excelApp))
                    {
                        Marshal.ReleaseComObject(excelApp);
                    }
                }
                catch
                {
                }

                excelApp = null;
            }
        }
    }
}