﻿using System;
using Word = Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace Marpatech_8.Features.Core.Office
{
    public static class WordAutomationService
    {
        public static Word.Application? CreateApplication(
            bool visible,
            bool displayAlerts)
        {
            try
            {
                Word.Application wordApp = new Word.Application();
                wordApp.Visible = visible;
                wordApp.DisplayAlerts = displayAlerts
                    ? Word.WdAlertLevel.wdAlertsAll
                    : Word.WdAlertLevel.wdAlertsNone;

                return wordApp;
            }
            catch
            {
                return null;
            }
        }

        public static Word.Document? OpenDocument(
            Word.Application wordApp,
            string filePath,
            bool readOnly = false,
            bool visible = false)
        {
            try
            {
                return wordApp.Documents.Open(
                    FileName: filePath,
                    ReadOnly: readOnly,
                    AddToRecentFiles: false,
                    Visible: visible);
            }
            catch
            {
                return null;
            }
        }

        public static void ReplaceText(
            Word.Document document,
            string findText,
            string replaceText)
        {
            try
            {
                Word.Find find = document.Content.Find;

                find.ClearFormatting();
                find.Replacement.ClearFormatting();

                find.Text = findText;
                find.Replacement.Text = replaceText ?? "";
                find.Forward = true;
                find.Wrap = Word.WdFindWrap.wdFindContinue;
                find.Format = false;
                find.MatchCase = false;
                find.MatchWholeWord = false;
                find.MatchWildcards = false;

                find.Execute(
                    Replace: Word.WdReplace.wdReplaceAll);
            }
            catch
            {
            }
        }

        public static bool PrintDocument(
            Word.Document document)
        {
            try
            {
                document.PrintOut(
                    Background: false);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void CloseDocument(
            Word.Document? document,
            bool saveChanges)
        {
            try
            {
                if (document == null)
                    return;

                object save =
                    saveChanges
                        ? Word.WdSaveOptions.wdSaveChanges
                        : Word.WdSaveOptions.wdDoNotSaveChanges;

                document.Close(
                    SaveChanges: ref save);
            }
            catch
            {
            }
        }

        public static void QuitApplication(
            Word.Application? wordApp)
        {
            try
            {
                if (wordApp == null)
                    return;

                wordApp.Quit(false);
            }
            catch
            {
            }
        }

        public static bool SaveDocumentAs(
    Word.Document? document,
    string filePath)
        {
            try
            {
                if (document == null)
                    return false;

                if (string.IsNullOrWhiteSpace(filePath))
                    return false;

                document.SaveAs2(
                    FileName: filePath,
                    FileFormat: Word.WdSaveFormat.wdFormatDocumentDefault,
                    AddToRecentFiles: false);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool ExportToPdf(
            Word.Document? document,
            string pdfPath)
        {
            try
            {
                if (document == null)
                    return false;

                if (string.IsNullOrWhiteSpace(pdfPath))
                    return false;

                document.ExportAsFixedFormat(
                    OutputFileName: pdfPath,
                    ExportFormat:
                        Word.WdExportFormat.wdExportFormatPDF,
                    OpenAfterExport: false,
                    OptimizeFor:
                        Word.WdExportOptimizeFor.wdExportOptimizeForPrint,
                    Range:
                        Word.WdExportRange.wdExportAllDocument,
                    Item:
                        Word.WdExportItem.wdExportDocumentContent,
                    IncludeDocProps: true,
                    KeepIRM: true,
                    CreateBookmarks:
                        Word.WdExportCreateBookmarks
                            .wdExportCreateWordBookmarks,
                    DocStructureTags: true,
                    BitmapMissingFonts: true,
                    UseISO19005_1: false);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void ReplaceTexts(
            Word.Document? document,
            IDictionary<string, string> replacements)
        {
            if (document == null)
                return;

            if (replacements == null)
                return;

            foreach (KeyValuePair<string, string> replacement in replacements)
            {
                if (string.IsNullOrWhiteSpace(replacement.Key))
                    continue;

                ReplaceText(
                    document,
                    replacement.Key,
                    replacement.Value ?? "");
            }
        }

        public static void ReleaseDocument(
    ref Word.Document? document,
    bool saveChanges)
        {
            try
            {
                if (document == null)
                    return;

                CloseDocument(
                    document,
                    saveChanges);
            }
            finally
            {
                try
                {
                    if (document != null &&
                        Marshal.IsComObject(document))
                    {
                        Marshal.ReleaseComObject(document);
                    }
                }
                catch
                {
                }

                document = null;
            }
        }

        public static void ReleaseApplication(
            ref Word.Application? wordApp)
        {
            try
            {
                if (wordApp == null)
                    return;

                QuitApplication(wordApp);
            }
            finally
            {
                try
                {
                    if (wordApp != null &&
                        Marshal.IsComObject(wordApp))
                    {
                        Marshal.ReleaseComObject(wordApp);
                    }
                }
                catch
                {
                }

                wordApp = null;
            }
        }
        public static bool SaveDocument(
    Word.Document? document)
        {
            try
            {
                if (document == null)
                    return false;

                document.Save();

                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}