﻿using System;

namespace Marpatech_8.Features.Core.Office
{
    public static class OutlookAutomationService
    {
        public static bool CreateMail(
            string to,
            string cc,
            string subject,
            string body,
            string linkPath,
            string attachmentPath,
            out string errorMessage)
        {
            errorMessage = "";

            try
            {
                Type? outlookType =
                    Type.GetTypeFromProgID("Outlook.Application");

                if (outlookType == null)
                {
                    errorMessage = "Outlook non trovato su questo PC.";
                    return false;
                }

                dynamic outlookApp =
                    Activator.CreateInstance(outlookType)!;

                dynamic mail =
                    outlookApp.CreateItem(0);

                mail.To = to;
                mail.CC = cc;
                mail.Subject = subject;

                if (!string.IsNullOrWhiteSpace(attachmentPath))
                    mail.Attachments.Add(attachmentPath);

                mail.Display(false);

                string signatureHtml =
                    mail.HTMLBody;

                string htmlBody =
                    ConvertTextToHtml(
                        body,
                        linkPath);

                mail.HTMLBody =
                    htmlBody + signatureHtml;

                mail.GetInspector.Activate();

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = ex.ToString();
                return false;
            }
        }

        private static string ConvertTextToHtml(
            string body,
            string linkPath)
        {
            string html =
                System.Net.WebUtility.HtmlEncode(body)
                    .Replace("\r\n", "<br>")
                    .Replace("\n", "<br>");

            if (!string.IsNullOrWhiteSpace(linkPath))
            {
                string encodedLink =
                    System.Net.WebUtility.HtmlEncode(linkPath);

                html = html.Replace(
                    "{LINK}",
                    "<a href=\"" + encodedLink + "\">" +
                    encodedLink +
                    "</a>");
            }
            else
            {
                html = html.Replace("{LINK}", "");
            }

            return
                "<div style=\"font-family:Calibri; font-size:11pt;\">" +
                html +
                "</div><br>";
        }
    }
}