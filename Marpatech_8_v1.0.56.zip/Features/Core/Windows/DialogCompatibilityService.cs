﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Windows
{
    public static class DialogCompatibilityService
    {
        public static string SelectFolder(
            string title,
            string initialPath,
            IWin32Window? owner = null)
        {
            using FolderBrowserDialog dialog =
                new FolderBrowserDialog();

            dialog.Description = title;
            dialog.SelectedPath = initialPath;

            DialogResult result = owner == null
                ? dialog.ShowDialog()
                : dialog.ShowDialog(owner);

            if (result == DialogResult.OK)
                return dialog.SelectedPath;

            return "";
        }

        public static void Info(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            MessageBox.Show(
                owner,
                message,
                title,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        public static void Warning(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            MessageBox.Show(
                owner,
                message,
                title,
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }

        public static void Error(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            MessageBox.Show(
                owner,
                message,
                title,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }

        public static bool Confirm(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogResult result =
                MessageBox.Show(
                    owner,
                    message,
                    title,
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

            return result == DialogResult.Yes;
        }
        public static string SelectOpenFile(
    string title,
    string filter,
    IWin32Window? owner = null)
        {
            using OpenFileDialog dialog =
                new OpenFileDialog();

            dialog.Title = title;
            dialog.Filter = filter;

            DialogResult result = owner == null
                ? dialog.ShowDialog()
                : dialog.ShowDialog(owner);

            if (result == DialogResult.OK)
                return dialog.FileName;

            return "";
        }

        public static string SelectSaveFile(
            string title,
            string filter,
            string defaultFileName,
            IWin32Window? owner = null)
        {
            using SaveFileDialog dialog =
                new SaveFileDialog();

            dialog.Title = title;
            dialog.Filter = filter;
            dialog.FileName = defaultFileName;

            DialogResult result = owner == null
                ? dialog.ShowDialog()
                : dialog.ShowDialog(owner);

            if (result == DialogResult.OK)
                return dialog.FileName;

            return "";
        }
    }
}