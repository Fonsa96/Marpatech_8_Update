﻿using System.Threading.Tasks;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Windows
{
    public static class UiCompatibilityService
    {
        public static void DoEventsSafe()
        {
            try
            {
                Application.DoEvents();
            }
            catch
            {
            }
        }

        public static async Task DelayAsync(int milliseconds)
        {
            try
            {
                await Task.Delay(milliseconds);
            }
            catch
            {
            }
        }

        public static void Sleep(int milliseconds)
        {
            try
            {
                System.Threading.Thread.Sleep(milliseconds);
            }
            catch
            {
            }
        }
    }
}