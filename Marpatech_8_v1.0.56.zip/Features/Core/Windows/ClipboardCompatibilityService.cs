﻿using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.Core.Windows
{
    public static class ClipboardCompatibilityService
    {
        public static bool SetImage(Image image)
        {
            try
            {
                if (image == null)
                    return false;

                Clipboard.SetImage(image);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void ClearSafe()
        {
            try
            {
                Clipboard.Clear();
            }
            catch
            {
            }
        }
        public static void SetText(string text)
        {
            try
            {
                Clipboard.SetText(text ?? "");
            }
            catch
            {
            }
        }
    }
}