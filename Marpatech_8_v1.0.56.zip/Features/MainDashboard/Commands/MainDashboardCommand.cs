﻿using Inventor;
using Marpatech_8.Features.Core.Forms;

namespace Marpatech_8.Features.MainDashboard
{
    public static class MainDashboardCommand
    {
        public static void Execute(Inventor.Application inventorApp)
        {
            bool isDarkTheme = IsInventorDarkTheme(inventorApp);

            SingleFormService.ShowSingle(
                "MainDashboard",
                () => new MainDashboardForm(
                    inventorApp,
                    isDarkTheme));
        }

        public static bool IsInventorDarkTheme(Inventor.Application inventorApp)
        {
            try
            {
                string themeName = inventorApp.ThemeManager.ActiveTheme.Name.ToLower();

                return themeName.Contains("dark") ||
                       themeName.Contains("scuro") ||
                       themeName.Contains("nero");
            }
            catch
            {
                return false;
            }
        }
    }
}