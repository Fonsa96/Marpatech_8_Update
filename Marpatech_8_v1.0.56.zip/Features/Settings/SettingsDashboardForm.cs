﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Marpatech_8.Features.Updater;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using Marpatech_8.Features.Settings.Services;
using Marpatech_8.Features.Core.Settings;
using System.Collections.Generic;
using Marpatech_8.Features.Core.Ribbon;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

namespace Marpatech_8.Features.Settings
{
    public class SettingsDashboardForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly Inventor.Application
    _inventorApp;
        private Button? btnUpdate;
        private readonly CoreWindowSettings _windowSettings;

        private FlowLayoutPanel? settingsPanel;
        private Panel? mainPanel;

        private Label? lblCurrentVersion;


        /*
 * ==========================================
 * CONFIGURAZIONE RIBBON
 * ==========================================
 */

        private ComboBox? cmbRibbonFeature;
        private ComboBox? cmbRibbonEnvironment;
        private TextBox? txtRibbonTabName;
        private Button? btnSaveRibbon;
        private Label? lblRibbonStatus;

        private CheckBox?
    chkIncludeInRibbon;

        private ListView?
            lstRibbonPlacements;

        private Button?
            btnAddRibbonPlacement;

        private Button?
            btnRemoveRibbonPlacement;

        private RibbonLayoutSettings?
            _ribbonLayoutSettings;

        private bool
            _isLoadingRibbonSettings;

        public SettingsDashboardForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp =
                   inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "SettingsDashboard",
                680,
                430);

            InitializeComponent();

            ShowInTaskbar =
               false;

            KeyPreview =
                false;

            WindowSettingsService.Apply(
               this,
               _windowSettings);

            LoadRibbonSettings();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor buttonColor = DrawingColor.FromArgb(37, 99, 235);

            this.Text = "Impostazioni";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(680, 430);
            this.MinimumSize = new DrawingSize(580, 380);
            this.BackColor = backgroundColor;
            this.FormClosing += SettingsDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Impostazioni";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);

            lblCurrentVersion = new Label();
            lblCurrentVersion.Text = "Versione corrente: " + GetCurrentVersion();
            lblCurrentVersion.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            lblCurrentVersion.ForeColor = titleColor;
            lblCurrentVersion.AutoSize = true;
            lblCurrentVersion.Location = new DrawingPoint(34, 70);

            mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(25, 110);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 50,
                this.ClientSize.Height - 145);

            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(12);

            settingsPanel = new FlowLayoutPanel();
            settingsPanel.Dock = DockStyle.Fill;
            settingsPanel.AutoScroll = true;
            settingsPanel.WrapContents = true;
            settingsPanel.Padding = new Padding(8);
            settingsPanel.BackColor = cardColor;

            btnUpdate = new Button();
            btnUpdate.Text = "Aggiorna versione";
            btnUpdate.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            btnUpdate.Size = new DrawingSize(210, 48);
            btnUpdate.Location = new DrawingPoint(25, 25);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.FlatAppearance.BorderSize = 0;
            btnUpdate.BackColor = buttonColor;
            btnUpdate.ForeColor = DrawingColor.White;
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.Click += BtnUpdate_Click;

            settingsPanel.Controls.Add(btnUpdate);
            /*
 * La sezione Ribbon deve iniziare
 * sotto al pulsante Aggiorna versione,
 * non di fianco.
 */
            settingsPanel.SetFlowBreak(
                btnUpdate,
                true);

            Panel separatorPanel =
    new Panel();

            separatorPanel.Height =
                1;

            separatorPanel.Width =
                585;

            separatorPanel.Margin =
                new Padding(
                    0,
                    14,
                    0,
                    14);

            separatorPanel.BackColor =
                _isDarkTheme
                    ? DrawingColor.FromArgb(
                        70,
                        75,
                        88)
                    : DrawingColor.FromArgb(
                        200,
                        205,
                        215);

            settingsPanel.Controls.Add(
                separatorPanel);

            settingsPanel.SetFlowBreak(
                separatorPanel,
                true);

            /*
             * ==========================================
             * SEZIONE POSIZIONE RIBBON
             * ==========================================
             */

            Panel ribbonSettingsPanel =
                new Panel();

            ribbonSettingsPanel.Size =
                new DrawingSize(
                    585,
                    455);

            ribbonSettingsPanel.Margin =
                new Padding(
                    0,
                    18,
                    0,
                    10);

            ribbonSettingsPanel.BackColor =
                cardColor;

            Label ribbonTitle =
                new Label();

            ribbonTitle.Text =
                "Posizione funzioni nella Ribbon";

            ribbonTitle.Font =
                new DrawingFont(
                    "Segoe UI",
                    13,
                    DrawingFontStyle.Bold);

            ribbonTitle.ForeColor =
                titleColor;

            ribbonTitle.AutoSize =
                true;

            ribbonTitle.Location =
                new DrawingPoint(
                    8,
                    5);

            Label ribbonDescription =
                new Label();

            ribbonDescription.Text =
                "Scegli l'ambiente Inventor e il nome della scheda in cui visualizzare la funzione.\r\n" +
                "Le modifiche saranno applicate al prossimo riavvio di Inventor.";

            ribbonDescription.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            ribbonDescription.ForeColor =
                titleColor;

            ribbonDescription.Location =
                new DrawingPoint(
                    8,
                    38);

            ribbonDescription.Size =
                new DrawingSize(
                    555,
                    42);

            /*
             * FEATURE
             */
            Label featureLabel =
                new Label();

            featureLabel.Text =
                "Funzione";

            featureLabel.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            featureLabel.ForeColor =
                titleColor;

            featureLabel.AutoSize =
                true;

            featureLabel.Location =
                new DrawingPoint(
                    8,
                    91);

            cmbRibbonFeature =
                new ComboBox();

            cmbRibbonFeature.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cmbRibbonFeature.Location =
                new DrawingPoint(
                    8,
                    114);

            cmbRibbonFeature.Size =
                new DrawingSize(
                    250,
                    30);

            cmbRibbonFeature.SelectedIndexChanged +=
                CmbRibbonFeature_SelectedIndexChanged;

            chkIncludeInRibbon =
                new CheckBox();

            chkIncludeInRibbon.Text =
                "Includi nelle ribbon selezionate";

            chkIncludeInRibbon.AutoSize =
                true;

            chkIncludeInRibbon.Location =
                new DrawingPoint(
                    8,
                    154);

            chkIncludeInRibbon.ForeColor =
                titleColor;

            chkIncludeInRibbon.BackColor =
                cardColor;

            chkIncludeInRibbon.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            chkIncludeInRibbon.CheckedChanged +=
                (_, _) =>
                {
                    UpdateRibbonPlacementControls();
                };

            /*
             * AMBIENTE INVENTOR
             */
            Label environmentLabel =
                new Label();

            environmentLabel.Text =
                "Ambiente Inventor";

            environmentLabel.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            environmentLabel.ForeColor =
                titleColor;

            environmentLabel.AutoSize =
                true;

            environmentLabel.Location =
                new DrawingPoint(
                    8,
                    190);

            cmbRibbonEnvironment =
                new ComboBox();

            cmbRibbonEnvironment.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cmbRibbonEnvironment.Location =
                new DrawingPoint(
                    8,
                    213);

            cmbRibbonEnvironment.Size =
                new DrawingSize(
                    180,
                    30);

            cmbRibbonEnvironment.Items.AddRange(
                new object[]
                {
        "Parte",
        "Assieme",
        "Disegno",
        "Presentazione",
        "Nessun documento"
                });

            /*
             * NOME SCHEDA
             */
            Label tabLabel =
                new Label();

            tabLabel.Text =
                "Nome scheda";

            tabLabel.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            tabLabel.ForeColor =
                titleColor;

            tabLabel.AutoSize =
                true;

            tabLabel.Location =
                new DrawingPoint(
                    205,
                    190);

            txtRibbonTabName =
                new TextBox();


            txtRibbonTabName.Location =
                new DrawingPoint(
                   205,
                    213);

            txtRibbonTabName.Size =
                new DrawingSize(
                    245,
                    30);

            txtRibbonTabName.BackColor =
                _isDarkTheme
                    ? DrawingColor.FromArgb(26, 28, 34)
                    : DrawingColor.White;

            txtRibbonTabName.ForeColor =
                titleColor;

            btnAddRibbonPlacement =
    new Button();

            btnAddRibbonPlacement.Text =
                "+ Posizione";

            btnAddRibbonPlacement.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            btnAddRibbonPlacement.Location =
                new DrawingPoint(
                    462,
                    211);

            btnAddRibbonPlacement.Size =
                new DrawingSize(
                    105,
                    34);

            btnAddRibbonPlacement.FlatStyle =
                FlatStyle.Flat;

            btnAddRibbonPlacement.FlatAppearance.BorderSize =
                0;

            btnAddRibbonPlacement.BackColor =
                DrawingColor.FromArgb(
                    124,
                    58,
                    237);

            btnAddRibbonPlacement.ForeColor =
                DrawingColor.White;

            btnAddRibbonPlacement.UseVisualStyleBackColor =
                false;

            btnAddRibbonPlacement.Cursor =
                Cursors.Hand;

            btnAddRibbonPlacement.Click +=
                BtnAddRibbonPlacement_Click;

            Label positionsLabel =
    new Label();

            positionsLabel.Text =
                "Ribbon selezionate";

            positionsLabel.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            positionsLabel.ForeColor =
                titleColor;

            positionsLabel.AutoSize =
                true;

            positionsLabel.Location =
                new DrawingPoint(
                    8,
                    260);

            lstRibbonPlacements =
                new ListView();

            lstRibbonPlacements.Location =
                new DrawingPoint(
                    8,
                    283);

            lstRibbonPlacements.Size =
                new DrawingSize(
                    442,
                    90);

            lstRibbonPlacements.View =
                View.Details;

            lstRibbonPlacements.FullRowSelect =
                true;

            lstRibbonPlacements.MultiSelect =
                false;

            lstRibbonPlacements.HideSelection =
                false;

            lstRibbonPlacements.Columns.Add(
                "Ambiente",
                155);

            lstRibbonPlacements.Columns.Add(
                "Scheda",
                255);

            lstRibbonPlacements.BackColor =
                _isDarkTheme
                    ? DrawingColor.FromArgb(26, 28, 34)
                    : DrawingColor.White;

            lstRibbonPlacements.ForeColor =
                titleColor;


            btnRemoveRibbonPlacement =
    new Button();

            btnRemoveRibbonPlacement.Text =
                "- Rimuovi";

            btnRemoveRibbonPlacement.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            btnRemoveRibbonPlacement.Location =
                new DrawingPoint(
                    462,
                    283);

            btnRemoveRibbonPlacement.Size =
                new DrawingSize(
                    105,
                    34);

            btnRemoveRibbonPlacement.FlatStyle =
                FlatStyle.Flat;

            btnRemoveRibbonPlacement.FlatAppearance.BorderSize =
                0;

            btnRemoveRibbonPlacement.BackColor =
                DrawingColor.FromArgb(
                    220,
                    38,
                    38);

            btnRemoveRibbonPlacement.ForeColor =
                DrawingColor.White;

            btnRemoveRibbonPlacement.UseVisualStyleBackColor =
                false;

            btnRemoveRibbonPlacement.Cursor =
                Cursors.Hand;

            btnRemoveRibbonPlacement.Click +=
                BtnRemoveRibbonPlacement_Click;

            /*
             * SALVA CONFIGURAZIONE
             */
            btnSaveRibbon =
                new Button();

            btnSaveRibbon.Text =
                "Salva configurazione";

            btnSaveRibbon.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            btnSaveRibbon.Location =
                new DrawingPoint(
                    397,
                    389);

            btnSaveRibbon.Size =
                new DrawingSize(
                    170,
                    34);

            btnSaveRibbon.FlatStyle =
                FlatStyle.Flat;

            btnSaveRibbon.FlatAppearance.BorderSize =
                0;

            btnSaveRibbon.BackColor =
                DrawingColor.FromArgb(
                    22,
                    163,
                    74);

            btnSaveRibbon.ForeColor =
                DrawingColor.White;

            btnSaveRibbon.UseVisualStyleBackColor =
                false;

            btnSaveRibbon.Cursor =
                Cursors.Hand;

            btnSaveRibbon.Click +=
                BtnSaveRibbon_Click;

            /*
             * STATO
             */
            lblRibbonStatus =
                new Label();

            lblRibbonStatus.Text =
                string.Empty;

            lblRibbonStatus.Font =
                new DrawingFont(
                    "Segoe UI",
                    8,
                    DrawingFontStyle.Regular);

            lblRibbonStatus.ForeColor =
                titleColor;

            lblRibbonStatus.Location =
                new DrawingPoint(
                    8,
                    427);

            lblRibbonStatus.Size =
                new DrawingSize(
                    555,
                    22);

            ribbonSettingsPanel.Controls.Add(
                ribbonTitle);

            ribbonSettingsPanel.Controls.Add(
                ribbonDescription);

            ribbonSettingsPanel.Controls.Add(
                featureLabel);

            ribbonSettingsPanel.Controls.Add(
                cmbRibbonFeature);

            ribbonSettingsPanel.Controls.Add(
                environmentLabel);

            ribbonSettingsPanel.Controls.Add(
                cmbRibbonEnvironment);

            ribbonSettingsPanel.Controls.Add(
                tabLabel);

            ribbonSettingsPanel.Controls.Add(
                txtRibbonTabName);

            ribbonSettingsPanel.Controls.Add(
                btnSaveRibbon);

            ribbonSettingsPanel.Controls.Add(
                lblRibbonStatus);

            ribbonSettingsPanel.Controls.Add(
                chkIncludeInRibbon);

            ribbonSettingsPanel.Controls.Add(
                btnAddRibbonPlacement);

            ribbonSettingsPanel.Controls.Add(
                positionsLabel);

            ribbonSettingsPanel.Controls.Add(
                lstRibbonPlacements);

            ribbonSettingsPanel.Controls.Add(
                btnRemoveRibbonPlacement);

            settingsPanel.Controls.Add(
                ribbonSettingsPanel);

            settingsPanel.SetFlowBreak(
                ribbonSettingsPanel,
                true);
            mainPanel.Controls.Add(settingsPanel);

            this.Controls.Add(title);
            this.Controls.Add(lblCurrentVersion);
            this.Controls.Add(mainPanel);
        }

        private async void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (btnUpdate == null)
                return;

            btnUpdate.Enabled = false;
            btnUpdate.Text = "Controllo aggiornamenti...";

            await UpdateCommand.ExecuteAsync();

            btnUpdate.Text = "Aggiorna versione";
            btnUpdate.Enabled = true;
        }

        private void SettingsDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "SettingsDashboard");
        }
        private string GetCurrentVersion()
        {
            try
            {
                UpdateSettings settings = new UpdateSettings();

                if (!SettingsFileService.FileExists(
                    settings.LocalVersionFile))
                {
                    return "non trovata";
                }

                LocalVersionInfo? versionInfo =
                    SettingsJsonService.LoadFromFile<LocalVersionInfo>(
                        settings.LocalVersionFile);

                return versionInfo?.Version ?? "non trovata";
            }
            catch
            {
                return "non trovata";
            }
        }
        private void LoadRibbonSettings()
        {
            if (cmbRibbonFeature == null)
                return;

            _isLoadingRibbonSettings =
                true;

            try
            {
                _ribbonLayoutSettings =
                    RibbonLayoutService.Load();

                cmbRibbonFeature.Items.Clear();

                foreach (RibbonFeatureLayout feature
                         in _ribbonLayoutSettings.Features)
                {
                    string displayName =
                        !string.IsNullOrWhiteSpace(
                            feature.DisplayName)
                            ? feature.DisplayName
                            : feature.InternalName;

                    cmbRibbonFeature.Items.Add(
                        new RibbonFeatureComboItem(
                            feature.InternalName,
                            displayName));
                }

                if (cmbRibbonFeature.Items.Count > 0)
                {
                    cmbRibbonFeature.SelectedIndex =
                        0;
                }
                else
                {
                    ClearRibbonEditor();
                }
            }
            finally
            {
                _isLoadingRibbonSettings =
                    false;

                /*
                 * SelectedIndexChanged è stato ignorato
                 * durante il caricamento, quindi carichiamo
                 * esplicitamente la prima Feature.
                 */
                LoadSelectedRibbonFeature();
            }
        }
        private sealed class RibbonFeatureComboItem
        {
            public string InternalName
            {
                get;
            }

            public string DisplayName
            {
                get;
            }

            public RibbonFeatureComboItem(
                string internalName,
                string displayName)
            {
                InternalName =
                    internalName;

                DisplayName =
                    displayName;
            }

            public override string ToString()
            {
                return DisplayName;
            }
        }

        private void CmbRibbonFeature_SelectedIndexChanged(
    object? sender,
    EventArgs e)
        {
            if (_isLoadingRibbonSettings)
                return;

            LoadSelectedRibbonFeature();
        }
        private void LoadSelectedRibbonFeature()
        {
            if (_ribbonLayoutSettings == null ||
                cmbRibbonFeature?.SelectedItem
                    is not RibbonFeatureComboItem selectedItem ||
                cmbRibbonEnvironment == null ||
                txtRibbonTabName == null ||
                chkIncludeInRibbon == null ||
                lstRibbonPlacements == null)
            {
                ClearRibbonEditor();
                return;
            }

            RibbonFeatureLayout? feature =
                FindRibbonFeature(
                    selectedItem.InternalName);

            if (feature == null)
            {
                ClearRibbonEditor();
                return;
            }

            chkIncludeInRibbon.Checked =
                feature.IncludeInRibbon;

            cmbRibbonEnvironment.SelectedIndex =
                -1;

            txtRibbonTabName.Text =
                string.Empty;

            lstRibbonPlacements.Items.Clear();

            foreach (RibbonPlacementDefinition placement
                     in feature.Placements)
            {
                AddPlacementToList(
                    placement);
            }

            UpdateRibbonPlacementControls();
        }
        private static string GetEnvironmentDisplayName(
    string ribbonName)
        {
            return ribbonName switch
            {
                "Part" =>
                    "Parte",

                "Assembly" =>
                    "Assieme",

                "Drawing" =>
                    "Disegno",

                "Presentation" =>
                    "Presentazione",

                "ZeroDoc" =>
                    "Nessun documento",

                _ =>
                    ribbonName
            };
        }
        private static string GetRibbonName(
    string environmentDisplayName)
        {
            return environmentDisplayName switch
            {
                "Parte" =>
                    "Part",

                "Assieme" =>
                    "Assembly",

                "Disegno" =>
                    "Drawing",

                "Presentazione" =>
                    "Presentation",

                "Nessun documento" =>
                    "ZeroDoc",

                _ =>
                    string.Empty
            };
        }
        private RibbonFeatureLayout?
    FindRibbonFeature(
        string internalName)
        {
            if (_ribbonLayoutSettings == null)
                return null;

            foreach (RibbonFeatureLayout feature
                     in _ribbonLayoutSettings.Features)
            {
                if (string.Equals(
                        feature.InternalName,
                        internalName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return feature;
                }
            }

            return null;
        }
        private void BtnSaveRibbon_Click(
            object? sender,
            EventArgs e)
        {
            if (_ribbonLayoutSettings == null ||
                cmbRibbonFeature?.SelectedItem
                    is not RibbonFeatureComboItem selectedItem ||
                chkIncludeInRibbon == null ||
                lstRibbonPlacements == null)
            {
                return;
            }

            RibbonFeatureLayout? feature =
                FindRibbonFeature(
                    selectedItem.InternalName);

            if (feature == null)
                return;

            /*
             * Se deve essere mostrata nella Ribbon,
             * deve esserci almeno una posizione.
             */
            if (chkIncludeInRibbon.Checked &&
                lstRibbonPlacements.Items.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "La funzione è impostata per essere inclusa nella Ribbon,\r\n" +
                    "ma non è stata aggiunta nessuna posizione.",
                    "Impostazioni Ribbon",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            feature.IncludeInRibbon =
                chkIncludeInRibbon.Checked;

            var placements =
                new List<RibbonPlacementDefinition>();

            foreach (ListViewItem item
                     in lstRibbonPlacements.Items)
            {
                if (item.Tag
                    is RibbonPlacementDefinition placement)
                {
                    placements.Add(
                        placement);
                }
            }

            feature.Placements =
                placements;

            RibbonLayoutService.Save(
                _ribbonLayoutSettings);

            if (lblRibbonStatus != null)
            {
                lblRibbonStatus.Text =
                    "Configurazione salvata. Riavvia Inventor per applicare le modifiche.";
            }

            MessageBox.Show(
                this,
                feature.IncludeInRibbon
                    ? "Configurazione Ribbon salvata correttamente.\r\n\r\n" +
                      "La modifica sarà applicata al prossimo riavvio di Inventor."
                    : "La funzione è stata esclusa dalla Ribbon.\r\n\r\n" +
                      "Rimarrà comunque accessibile dalla Main Dashboard.\r\n" +
                      "La modifica sarà applicata al prossimo riavvio di Inventor.",
                "Impostazioni Ribbon",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        private void ClearRibbonEditor()
        {
            if (cmbRibbonEnvironment != null)
            {
                cmbRibbonEnvironment.SelectedIndex =
                    -1;
            }

            if (txtRibbonTabName != null)
            {
                txtRibbonTabName.Text =
                    string.Empty;
            }

            if (lblRibbonStatus != null)
            {
                lblRibbonStatus.Text =
                    string.Empty;
            }
            if (chkIncludeInRibbon != null)
            {
                chkIncludeInRibbon.Checked =
                    false;
            }

            if (lstRibbonPlacements != null)
            {
                lstRibbonPlacements.Items.Clear();
            }
        }
        private void AddPlacementToList(
    RibbonPlacementDefinition placement)
        {
            if (lstRibbonPlacements == null)
                return;

            string environmentName =
                GetEnvironmentDisplayName(
                    placement.RibbonName);

            ListViewItem item =
                new ListViewItem(
                    environmentName);

            item.SubItems.Add(
                placement.TabDisplayName);

            item.Tag =
                placement;

            lstRibbonPlacements.Items.Add(
                item);
        }
        private void BtnAddRibbonPlacement_Click(
    object? sender,
    EventArgs e)
        {
            if (cmbRibbonEnvironment == null ||
                txtRibbonTabName == null ||
                lstRibbonPlacements == null)
            {
                return;
            }

            if (cmbRibbonEnvironment.SelectedItem == null)
            {
                MessageBox.Show(
                    this,
                    "Seleziona l'ambiente Inventor.",
                    "Impostazioni Ribbon",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string tabDisplayName =
                txtRibbonTabName
                    .Text
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                    tabDisplayName))
            {
                MessageBox.Show(
                    this,
                    "Inserisci il nome della scheda.",
                    "Impostazioni Ribbon",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string environmentDisplayName =
                cmbRibbonEnvironment
                    .SelectedItem
                    .ToString() ??
                string.Empty;

            string ribbonName =
                GetRibbonName(
                    environmentDisplayName);

            if (string.IsNullOrWhiteSpace(
                    ribbonName))
            {
                return;
            }

            /*
             * Non permettiamo duplicati identici.
             */
            foreach (ListViewItem existingItem
                     in lstRibbonPlacements.Items)
            {
                if (existingItem.Tag
                    is not RibbonPlacementDefinition existingPlacement)
                {
                    continue;
                }

                if (string.Equals(
                        existingPlacement.RibbonName,
                        ribbonName,
                        StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(
                        existingPlacement.TabDisplayName,
                        tabDisplayName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show(
                        this,
                        "Questa posizione è già presente.",
                        "Impostazioni Ribbon",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    return;
                }
            }

            string tabInternalName =
    ResolveRibbonTabInternalName(
        ribbonName,
        tabDisplayName);

            if (string.IsNullOrWhiteSpace(
                    tabInternalName))
            {
                MessageBox.Show(
                    this,
                    "La scheda \"" +
                    tabDisplayName +
                    "\" non è stata trovata nell'ambiente \"" +
                    environmentDisplayName +
                    "\".\r\n\r\n" +
                    "Controlla che il nome della scheda sia scritto esattamente come appare in Inventor.",
                    "Impostazioni Ribbon",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            string safeTabName =
                CleanRibbonInternalName(
                    tabDisplayName);

            var placement =
                new RibbonPlacementDefinition
                {
                    RibbonName =
                        ribbonName,

                    TabInternalName =
                         tabInternalName,

                    TabDisplayName =
                        tabDisplayName,

                    PanelDisplayName =
                        "Marpatech",

                    /*
                     * Deve essere univoco anche se la stessa
                     * Feature compare in più schede.
                     */
                    PanelInternalName =
                        "Marpatech8_" +
                        ribbonName +
                        "_" +
                        safeTabName +
                        "_Features",

                    UseLargeButton =
                        true
                };

            AddPlacementToList(
                placement);

            txtRibbonTabName.Text =
                string.Empty;

            txtRibbonTabName.Focus();
        }
        private static string CleanRibbonInternalName(
    string value)
        {
            if (string.IsNullOrWhiteSpace(
                    value))
            {
                return "Tab";
            }

            return value
                .Replace(" ", string.Empty)
                .Replace(".", string.Empty)
                .Replace("-", string.Empty)
                .Replace("/", string.Empty)
                .Replace("\\", string.Empty)
                .Trim();
        }
        private void BtnRemoveRibbonPlacement_Click(
            object? sender,
            EventArgs e)
        {
            if (lstRibbonPlacements == null)
                return;

            if (lstRibbonPlacements.SelectedItems.Count == 0)
            {
                MessageBox.Show(
                    this,
                    "Seleziona prima una posizione da rimuovere.",
                    "Impostazioni Ribbon",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                return;
            }

            lstRibbonPlacements.Items.Remove(
                lstRibbonPlacements
                    .SelectedItems[0]);
        }
        private void UpdateRibbonPlacementControls()
        {
            bool enabled =
                chkIncludeInRibbon?.Checked ==
                true;

            if (cmbRibbonEnvironment != null)
                cmbRibbonEnvironment.Enabled = enabled;

            if (txtRibbonTabName != null)
                txtRibbonTabName.Enabled = enabled;

            if (btnAddRibbonPlacement != null)
                btnAddRibbonPlacement.Enabled = enabled;

            if (btnRemoveRibbonPlacement != null)
                btnRemoveRibbonPlacement.Enabled = enabled;

            if (lstRibbonPlacements != null)
                lstRibbonPlacements.Enabled = enabled;
        }
        private string ResolveRibbonTabInternalName(
    string ribbonName,
    string tabDisplayName)
        {
            if (string.IsNullOrWhiteSpace(
                    ribbonName) ||
                string.IsNullOrWhiteSpace(
                    tabDisplayName))
            {
                return string.Empty;
            }

            try
            {
                Inventor.Ribbon ribbon =
                    _inventorApp
                        .UserInterfaceManager
                        .Ribbons[
                            ribbonName];

                string requestedName =
                    tabDisplayName.Trim();

                foreach (Inventor.RibbonTab tab
                         in ribbon.RibbonTabs)
                {
                    try
                    {
                        string displayName =
                            tab.DisplayName?
                                .Trim()
                            ?? string.Empty;

                        if (string.Equals(
                                displayName,
                                requestedName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return
                                tab.InternalName?
                                    .Trim()
                                ?? string.Empty;
                        }

                        string internalName =
                            tab.InternalName?
                                .Trim()
                            ?? string.Empty;

                        if (string.Equals(
                                internalName,
                                requestedName,
                                StringComparison.OrdinalIgnoreCase))
                        {
                            return internalName;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
            }

            return string.Empty;
        }
    }
}