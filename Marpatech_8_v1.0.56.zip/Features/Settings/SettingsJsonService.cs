﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Settings.Services
{
    public static class SettingsJsonService
    {
        public static T? LoadFromFile<T>(string path)
        {
            return JsonCompatibilityService.LoadFromFile<T>(path);
        }
    }
}