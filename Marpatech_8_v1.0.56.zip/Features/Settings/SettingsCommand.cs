﻿using System.Windows.Forms;

namespace Marpatech_8.Features.Settings
{
    public static class SettingsCommand
    {
        public static void Execute(
            Form owner,
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            SettingsDashboardForm form =
                new SettingsDashboardForm(
                    inventorApp,
                    isDarkTheme);

            form.Show(
                owner);

            form.BringToFront();

            form.Activate();

            form.Focus();
        }
    }
}