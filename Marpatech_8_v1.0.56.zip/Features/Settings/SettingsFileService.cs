﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Settings.Services
{
    public static class SettingsFileService
    {
        public static bool FileExists(string path)
        {
            return FileSystemCompatibilityService.FileExists(path);
        }
    }
}