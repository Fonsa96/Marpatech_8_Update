﻿using System.Threading.Tasks;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Updater.Services
{
    public static class UpdateFileService
    {
        public static bool FileExists(string path)
        {
            return FileSystemCompatibilityService.FileExists(path);
        }

        public static bool DirectoryExists(string path)
        {
            return FileSystemCompatibilityService.DirectoryExists(path);
        }

        public static void EnsureDirectory(string path)
        {
            FileSystemCompatibilityService.EnsureDirectory(path);
        }

        public static void DeleteDirectorySafe(
            string path,
            bool recursive = true)
        {
            FileSystemCompatibilityService.DeleteDirectorySafe(
                path,
                recursive);
        }

        public static void CopyFileSafe(
            string sourceFile,
            string destinationFile,
            bool overwrite = true)
        {
            FileSystemCompatibilityService.CopyFileSafe(
                sourceFile,
                destinationFile,
                overwrite);
        }

        public static string ReadAllText(string path)
        {
            return FileSystemCompatibilityService.ReadAllTextSafe(path);
        }

        public static Task<string> ReadAllTextAsync(string path)
        {
            return FileSystemCompatibilityService.ReadAllTextAsyncSafe(path);
        }

        public static void WriteAllText(
            string path,
            string content)
        {
            FileSystemCompatibilityService.WriteAllTextSafe(
                path,
                content);
        }

        public static Task WriteAllBytesAsync(
            string path,
            byte[] data)
        {
            return FileSystemCompatibilityService.WriteAllBytesAsyncSafe(
                path,
                data);
        }
    }
}