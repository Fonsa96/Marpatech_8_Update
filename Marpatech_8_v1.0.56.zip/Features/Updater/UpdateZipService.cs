﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Updater.Services
{
    public static class UpdateZipService
    {
        public static bool ExtractToDirectory(
            string zipPath,
            string destinationFolder)
        {
            return ZipCompatibilityService.ExtractToDirectory(
                zipPath,
                destinationFolder);
        }
    }
}