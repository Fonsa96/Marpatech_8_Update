﻿namespace Marpatech_8.Features.Updater
{
    public class UpdateInfo
    {
        public string Version { get; set; } = "";

        public string DownloadUrl { get; set; } = "";

        public string ZipFileName { get; set; } = "";

        public bool Mandatory { get; set; } = false;

        public string ReleaseNotes { get; set; } = "";
    }
}