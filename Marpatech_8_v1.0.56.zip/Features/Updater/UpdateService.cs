﻿using System;
using System.IO;
using System.Threading.Tasks;
using Marpatech_8.Features.Updater.Services;

namespace Marpatech_8.Features.Updater
{
    public class UpdateService
    {
        private readonly UpdateSettings _settings;

        public UpdateService(UpdateSettings settings)
        {
            _settings = settings;
        }

        public async Task<UpdateInfo?> CheckForUpdateAsync()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_settings.UpdateManifestUrl))
                    return null;

                string json;

                if (_settings.UpdateManifestUrl.StartsWith("file:///"))
                {
                    string localPath =
                        _settings.UpdateManifestUrl
                            .Replace("file:///", "")
                            .Replace("/", "\\");

                    json =
                        await UpdateFileService.ReadAllTextAsync(
                            localPath);
                }
                else
                {
                    json =
                        await UpdateHttpService.GetStringAsync(
                            _settings.UpdateManifestUrl);
                }

                UpdateInfo? updateInfo =
                    UpdateJsonService.Deserialize<UpdateInfo>(
                        json);

                if (updateInfo == null)
                    return null;

                string currentVersion = GetCurrentVersion();

                if (IsNewerVersion(
                    updateInfo.Version,
                    currentVersion))
                {
                    return updateInfo;
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> DownloadUpdateAsync(
            UpdateInfo updateInfo)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(updateInfo.DownloadUrl))
                    return false;

                PreparePendingFolder();

                string zipPath = Path.Combine(
                    _settings.PendingUpdateFolder,
                    updateInfo.ZipFileName);

                if (updateInfo.DownloadUrl.StartsWith("file:///"))
                {
                    string localZipPath =
                        updateInfo.DownloadUrl
                            .Replace("file:///", "")
                            .Replace("/", "\\");

                    UpdateFileService.CopyFileSafe(
                        localZipPath,
                        zipPath,
                        true);
                }
                else
                {
                    byte[] data =
                        await UpdateHttpService.GetByteArrayAsync(
                            updateInfo.DownloadUrl);

                    await UpdateFileService.WriteAllBytesAsync(
                        zipPath,
                        data);
                }

                string extractFolder = Path.Combine(
                    _settings.PendingUpdateFolder,
                    "Extracted");

                if (UpdateFileService.DirectoryExists(extractFolder))
                {
                    UpdateFileService.DeleteDirectorySafe(
                        extractFolder,
                        true);
                }

                UpdateFileService.EnsureDirectory(extractFolder);

                bool extracted =
                    UpdateZipService.ExtractToDirectory(
                        zipPath,
                        extractFolder);

                if (!extracted)
                    return false;

                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool MarkUpdateAsPending()
        {
            try
            {
                UpdateFileService.EnsureDirectory(
                    _settings.PendingUpdateFolder);

                string markerFile = Path.Combine(
                    _settings.PendingUpdateFolder,
                    "update_pending.flag");

                UpdateFileService.WriteAllText(
                    markerFile,
                    DateTime.Now.ToString(
                        "yyyy-MM-dd HH:mm:ss"));

                return true;
            }
            catch
            {
                return false;
            }
        }

        private void PreparePendingFolder()
        {
            if (UpdateFileService.DirectoryExists(
                _settings.PendingUpdateFolder))
            {
                UpdateFileService.DeleteDirectorySafe(
                    _settings.PendingUpdateFolder,
                    true);
            }

            UpdateFileService.EnsureDirectory(
                _settings.PendingUpdateFolder);
        }

        private bool IsNewerVersion(
            string onlineVersion,
            string currentVersion)
        {
            if (!Version.TryParse(
                onlineVersion,
                out Version? online))
            {
                return false;
            }

            if (!Version.TryParse(
                currentVersion,
                out Version? current))
            {
                return false;
            }

            return online > current;
        }

        private string GetCurrentVersion()
        {
            try
            {
                if (!UpdateFileService.FileExists(
                    _settings.LocalVersionFile))
                {
                    return "0.0.0";
                }

                LocalVersionInfo? versionInfo =
                    UpdateJsonService.LoadFromFile<LocalVersionInfo>(
                        _settings.LocalVersionFile);

                return versionInfo?.Version ?? "0.0.0";
            }
            catch
            {
                return "0.0.0";
            }
        }
    }
}