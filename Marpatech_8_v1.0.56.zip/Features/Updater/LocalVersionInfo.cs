﻿namespace Marpatech_8.Features.Updater
{
    public class LocalVersionInfo
    {
        public string Version { get; set; } = "1.0.0";
    }
}