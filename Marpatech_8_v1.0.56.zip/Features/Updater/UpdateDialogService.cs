﻿using System.Windows.Forms;
using Marpatech_8.Features.Core.Windows;

namespace Marpatech_8.Features.Updater
{
    public static class UpdateDialogService
    {
        public static void Info(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Info(
                message,
                title,
                owner);
        }

        public static void Warning(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Warning(
                message,
                title,
                owner);
        }

        public static void Error(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            DialogCompatibilityService.Error(
                message,
                title,
                owner);
        }

        public static bool Confirm(
            string message,
            string title,
            IWin32Window? owner = null)
        {
            return DialogCompatibilityService.Confirm(
                message,
                title,
                owner);
        }
    }
}