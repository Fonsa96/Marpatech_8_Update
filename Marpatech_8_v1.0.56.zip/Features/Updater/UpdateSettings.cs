﻿using System;
using System.IO;

namespace Marpatech_8.Features.Updater
{
    public class UpdateSettings
    {
        public string UpdateManifestUrl { get; set; } =
            "https://raw.githubusercontent.com/Fonsa96/Marpatech_8_Update/main/update.json";

        public string RootFolder { get; set; }

        public string LocalAppFolder { get; set; }

        public string LocalVersionFile { get; set; }

        public string LocalUpdaterFile { get; set; }

        public string PendingUpdateFolder { get; set; }

        public bool SilentMode { get; set; } = true;

        public UpdateSettings()
        {
            string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

            string inventorAddinsFolder = Path.Combine(
                appData,
                "Autodesk",
                "Inventor 2025",
                "Addins");

            RootFolder = Path.Combine(
                inventorAddinsFolder,
                "Marpatech_8");

            LocalAppFolder = Path.Combine(
                RootFolder,
                "App");

            LocalVersionFile = Path.Combine(
                LocalAppFolder,
                "version.json");

            LocalUpdaterFile = Path.Combine(
                RootFolder,
                "Updater",
                "MarpatechUpdater_8.exe");

            PendingUpdateFolder = Path.Combine(
                RootFolder,
                "PendingUpdate_8");
        }
    }
}