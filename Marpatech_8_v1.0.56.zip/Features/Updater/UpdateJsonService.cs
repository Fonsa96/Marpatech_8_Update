﻿using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Updater.Services
{
    public static class UpdateJsonService
    {
        public static T? Deserialize<T>(string json)
        {
            return JsonCompatibilityService.Deserialize<T>(json);
        }

        public static T? LoadFromFile<T>(string path)
        {
            return JsonCompatibilityService.LoadFromFile<T>(path);
        }
    }
}