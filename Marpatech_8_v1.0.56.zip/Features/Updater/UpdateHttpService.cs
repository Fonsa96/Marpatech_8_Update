﻿using System.Threading.Tasks;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.Updater.Services
{
    public static class UpdateHttpService
    {
        public static Task<string> GetStringAsync(
            string url)
        {
            return HttpCompatibilityService.GetStringAsync(url);
        }

        public static Task<byte[]> GetByteArrayAsync(
            string url)
        {
            return HttpCompatibilityService.GetByteArrayAsync(url);
        }
    }
}