﻿using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.UI
{
    /// <summary>
    /// Stili standard dei pulsanti della funzione
    /// Regole di progettazione.
    ///
    /// Questo helper NON modifica i pulsanti
    /// delle altre funzioni dell'Addin.
    /// </summary>
    public static class RuleButtonStyle
    {
        /*
         * ==========================================
         * COLORI
         * ==========================================
         */

        private static readonly Color SaveColor =
            Color.FromArgb(
                22,
                163,
                74);

        private static readonly Color SaveHoverColor =
            Color.FromArgb(
                34,
                197,
                94);

        private static readonly Color DeleteColor =
            Color.FromArgb(
                220,
                38,
                38);

        private static readonly Color DeleteHoverColor =
            Color.FromArgb(
                239,
                68,
                68);

        private static readonly Color PrimaryColor =
            Color.FromArgb(
                124,
                58,
                237);

        private static readonly Color PrimaryHoverColor =
            Color.FromArgb(
                139,
                92,
                246);

        private static readonly Color SecondaryColor =
            Color.FromArgb(
                71,
                85,
                105);

        private static readonly Color SecondaryHoverColor =
            Color.FromArgb(
                100,
                116,
                139);

        /*
         * ==========================================
         * SALVA
         * ==========================================
         */

        public static void ApplySave(
            Button button)
        {
            ApplyStyle(
                button,
                SaveColor,
                SaveHoverColor);
        }

        /*
         * ==========================================
         * ELIMINA
         * ==========================================
         */

        public static void ApplyDelete(
            Button button)
        {
            ApplyStyle(
                button,
                DeleteColor,
                DeleteHoverColor);
        }

        /*
         * ==========================================
         * AZIONE PRINCIPALE
         *
         * Viola.
         * Esempio:
         * - Aggiungi
         * - Sfoglia
         * - azioni importanti
         * ==========================================
         */

        public static void ApplyPrimary(
            Button button)
        {
            ApplyStyle(
                button,
                PrimaryColor,
                PrimaryHoverColor);
        }

        /*
         * ==========================================
         * AZIONE SECONDARIA
         *
         * Grigio/blu.
         * Esempio:
         * - Annulla
         * - Sposta
         * - azioni secondarie
         * ==========================================
         */

        public static void ApplySecondary(
            Button button)
        {
            ApplyStyle(
                button,
                SecondaryColor,
                SecondaryHoverColor);
        }

        /*
         * ==========================================
         * IMPLEMENTAZIONE COMUNE
         * ==========================================
         */

        private static void ApplyStyle(
            Button button,
            Color normalColor,
            Color hoverColor)
        {
            button.FlatStyle =
                FlatStyle.Flat;

            button.FlatAppearance.BorderSize =
                0;

            button.BackColor =
                normalColor;

            button.ForeColor =
                Color.White;

            button.UseVisualStyleBackColor =
                false;

            button.Cursor =
                Cursors.Hand;

            /*
             * Rimuoviamo l'effetto standard
             * del pulsante WinForms.
             */
            button.FlatAppearance.MouseOverBackColor =
                hoverColor;

            button.FlatAppearance.MouseDownBackColor =
                ControlPaint.Dark(
                    normalColor);

            /*
             * Importante:
             * non utilizziamo MouseEnter/MouseLeave.
             *
             * FlatAppearance gestisce direttamente
             * hover e pressione mantenendo il colore
             * base quando il mouse esce.
             */
        }
    }
}