﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Input;
using Marpatech_8.Features.RegoleProgettazione.Commands;
using Marpatech_8.Features.RegoleProgettazione.Models;
using Marpatech_8.Features.RegoleProgettazione.Services;

namespace Marpatech_8.Features.RegoleProgettazione.ViewModels
{
    public class RegoleProgettazioneViewModel :
        INotifyPropertyChanged
    {
        private readonly RuleFileSystemService
            _fileSystemService;

        private readonly RuleTreeEditorService
            _treeEditorService;

        private RuleNode? _selectedNode;

        private bool _isReadOnly;

        private bool _hasUnsavedChanges;

        private bool _isLoading;

        private string _rootPath =
            string.Empty;

        /*
         * Contiene gli elementi esistenti sul filesystem
         * che l'utente ha deciso di eliminare.
         *
         * Non vengono cancellati fino a Salva Modifiche.
         */
        private readonly List<RuleNode>
            _pendingDeletedNodes = new();

        private readonly RuleSaveService
    _saveService;

        public RegoleProgettazioneViewModel(
            RuleFileSystemService fileSystemService,
            RuleTreeEditorService treeEditorService,
            RuleSaveService saveService)
        {
            _fileSystemService =
                fileSystemService;

            _treeEditorService =
                treeEditorService;

            _saveService =
                saveService;

            AddParagraphCommand =
                new RelayCommand(
                    AddParagraph,
                    CanEdit);

            DeleteParagraphCommand =
                new RelayCommand(
                    RequestDeleteParagraph,
                    CanDeleteParagraph);

            AddTextCommand =
                new RelayCommand(
                    AddText,
                    CanEdit);

            DeleteTextCommand =
                new RelayCommand(
                    RequestDeleteText,
                    CanDeleteText);

            MoveUpCommand =
                new RelayCommand(
                    MoveUp,
                    CanMoveSelectedNode);

            MoveDownCommand =
                new RelayCommand(
                    MoveDown,
                    CanMoveSelectedNode);

            SaveChangesCommand =
                new RelayCommand(
                    RequestSaveChanges,
                    CanSaveChanges);
        }

        public ObservableCollection<RuleNode>
            RootNodes
        { get; } =
            new ObservableCollection<RuleNode>();

        public RuleNode? SelectedNode
        {
            get => _selectedNode;

            set
            {
                if (_selectedNode == value)
                    return;

                _selectedNode = value;

                OnPropertyChanged();

                RefreshCommands();
            }
        }

        public string RootPath
        {
            get => _rootPath;

            private set
            {
                if (_rootPath == value)
                    return;

                _rootPath = value;

                OnPropertyChanged();
            }
        }

        public bool IsReadOnly
        {
            get => _isReadOnly;

            set
            {
                if (_isReadOnly == value)
                    return;

                _isReadOnly = value;

                OnPropertyChanged();

                /*
                 * Questo verrà usato nello XAML:
                 *
                 * false = toolbar VISIBILE
                 * true  = toolbar completamente NASCOSTA
                 */
                OnPropertyChanged(
                    nameof(IsEditingVisible));

                RefreshCommands();
            }
        }

        /// <summary>
        /// Da usare nello XAML con un converter bool -> Visibility.
        ///
        /// In modalità Sola Lettura la toolbar di modifica
        /// deve sparire completamente.
        /// </summary>
        public bool IsEditingVisible =>
            !IsReadOnly;

        public bool HasUnsavedChanges
        {
            get => _hasUnsavedChanges;

            private set
            {
                if (_hasUnsavedChanges == value)
                    return;

                _hasUnsavedChanges = value;

                OnPropertyChanged();

                RefreshCommands();
            }
        }

        public bool IsLoading
        {
            get => _isLoading;

            private set
            {
                if (_isLoading == value)
                    return;

                _isLoading = value;

                OnPropertyChanged();

                RefreshCommands();
            }
        }

        public IReadOnlyList<RuleNode>
            PendingDeletedNodes =>
            _pendingDeletedNodes.AsReadOnly();

        public ICommand AddParagraphCommand
        {
            get;
        }

        public ICommand DeleteParagraphCommand
        {
            get;
        }

        public ICommand AddTextCommand
        {
            get;
        }

        public ICommand DeleteTextCommand
        {
            get;
        }

        public ICommand MoveUpCommand
        {
            get;
        }

        public ICommand MoveDownCommand
        {
            get;
        }

        public ICommand SaveChangesCommand
        {
            get;
        }

        /*
         * Evento che la Window intercetterà
         * per mostrare la finestra di conferma.
         */
        public event EventHandler<DeleteRuleRequest>?
            DeleteRequested;

        /*
         * Per ora Salva Modifiche viene richiesto
         * alla Window.
         *
         * Nel prossimo blocco collegheremo direttamente
         * il nuovo RuleSaveService.
         */
        public event EventHandler?
            SaveRequested;

        public async Task LoadAsync(
            string rootPath,
            bool isReadOnly)
        {
            IsLoading = true;

            try
            {
                RootPath = rootPath;

                IsReadOnly = isReadOnly;

                RootNodes.Clear();

                _pendingDeletedNodes.Clear();

                List<RuleNode> nodes =
                    await _fileSystemService.LoadAsync(
                        rootPath);

                foreach (RuleNode node in nodes)
                {
                    RootNodes.Add(node);

                    SubscribeNodeRecursive(node);
                }

                SelectedNode = null;

                HasUnsavedChanges = false;
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void AddParagraph()
        {
            if (IsReadOnly)
                return;

            RuleNode newNode =
                _treeEditorService.AddParagraph(
                    RootNodes,
                    SelectedNode);

            SubscribeNodeRecursive(newNode);

            SelectedNode = newNode;

            MarkUnsaved();
        }

        private void AddText()
        {
            if (IsReadOnly)
                return;

            RuleNode newNode =
                _treeEditorService.AddText(
                    RootNodes,
                    SelectedNode);

            SubscribeNodeRecursive(newNode);

            SelectedNode = newNode;

            MarkUnsaved();
        }

        private void RequestDeleteParagraph()
        {
            if (IsReadOnly ||
                SelectedNode == null ||
                !SelectedNode.IsParagraph)
            {
                return;
            }

            DeleteRequested?.Invoke(
                this,
                new DeleteRuleRequest(
                    SelectedNode));
        }

        private void RequestDeleteText()
        {
            if (IsReadOnly ||
                SelectedNode == null ||
                !SelectedNode.IsText)
            {
                return;
            }

            DeleteRequested?.Invoke(
                this,
                new DeleteRuleRequest(
                    SelectedNode));
        }

        /// <summary>
        /// Questa funzione deve essere chiamata dalla Window
        /// SOLO dopo che l'utente ha completato la doppia
        /// conferma di sicurezza.
        /// </summary>
        public void ConfirmDelete(
            RuleNode node)
        {
            if (IsReadOnly)
                return;

            if (!ContainsNode(node))
                return;

            /*
             * Se esiste già nel filesystem,
             * conserviamo il nodo completo per cancellarlo
             * solamente al momento di Salva Modifiche.
             */
            bool mustDeleteFromDisk =
                _treeEditorService.RemoveNode(
                    RootNodes,
                    node);

            if (mustDeleteFromDisk)
            {
                MarkDeletedRecursive(node);

                _pendingDeletedNodes.Add(node);
            }

            /*
             * Se invece era un nodo Added,
             * semplicemente scompare dalla memoria:
             * non è mai esistito sul filesystem,
             * quindi non dovremo cancellare nulla.
             */

            SelectedNode = null;

            MarkUnsaved();
        }

        private void MoveUp()
        {
            if (IsReadOnly ||
                SelectedNode == null)
            {
                return;
            }

            bool moved =
                _treeEditorService.MoveUp(
                    RootNodes,
                    SelectedNode);

            if (moved)
                MarkUnsaved();
        }

        private void MoveDown()
        {
            if (IsReadOnly ||
                SelectedNode == null)
            {
                return;
            }

            bool moved =
                _treeEditorService.MoveDown(
                    RootNodes,
                    SelectedNode);

            if (moved)
                MarkUnsaved();
        }

        private void RequestSaveChanges()
        {
            if (!CanSaveChanges())
                return;

            SaveRequested?.Invoke(
                this,
                EventArgs.Empty);
        }

        private bool CanEdit()
        {
            return !IsReadOnly &&
                   !IsLoading;
        }

        private bool CanDeleteParagraph()
        {
            return CanEdit() &&
                   SelectedNode != null &&
                   SelectedNode.IsParagraph;
        }

        private bool CanDeleteText()
        {
            return CanEdit() &&
                   SelectedNode != null &&
                   SelectedNode.IsText;
        }

        private bool CanMoveSelectedNode()
        {
            return CanEdit() &&
                   SelectedNode != null;
        }

        private bool CanSaveChanges()
        {
            return CanEdit() &&
                   HasUnsavedChanges;
        }

        private void MarkUnsaved()
        {
            HasUnsavedChanges = true;
        }

        /// <summary>
        /// Segnala al ViewModel una modifica effettuata
        /// da componenti esterni all'albero principale,
        /// ad esempio aggiunta o rimozione di allegati.
        /// </summary>
        public void NotifyExternalChange()
        {
            if (IsReadOnly ||
                IsLoading)
            {
                return;
            }

            MarkUnsaved();
        }

        /// <summary>
        /// Da chiamare dopo un Salva Modifiche
        /// completato correttamente.
        /// </summary>
        public void MarkChangesAsSaved()
        {
            HasUnsavedChanges = false;

            _pendingDeletedNodes.Clear();

            RefreshCommands();
        }

        private void SubscribeNodeRecursive(
            RuleNode node)
        {
            node.PropertyChanged -=
                Node_PropertyChanged;

            node.PropertyChanged +=
                Node_PropertyChanged;

            foreach (RuleNode child in node.Children)
            {
                SubscribeNodeRecursive(child);
            }
        }

        private void Node_PropertyChanged(
            object? sender,
            PropertyChangedEventArgs e)
        {
            if (IsLoading)
                return;

            /*
             * Apertura/chiusura dei paragrafi NON è una
             * modifica del contenuto aziendale.
             *
             * Non deve quindi attivare Salva Modifiche.
             */
            if (e.PropertyName ==
                    nameof(RuleNode.IsExpanded) ||
                e.PropertyName ==
                    nameof(RuleNode.IsSelected))
            {
                return;
            }

            /*
             * Tutte le altre modifiche:
             *
             * titolo
             * testo
             * ordine
             * stato
             *
             * rendono la sessione modificata.
             */
            MarkUnsaved();
        }

        private bool ContainsNode(
            RuleNode node)
        {
            foreach (RuleNode root in RootNodes)
            {
                if (ReferenceEquals(
                        root,
                        node))
                {
                    return true;
                }

                if (ContainsNodeRecursive(
                        root,
                        node))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool ContainsNodeRecursive(
            RuleNode parent,
            RuleNode target)
        {
            foreach (RuleNode child in parent.Children)
            {
                if (ReferenceEquals(
                        child,
                        target))
                {
                    return true;
                }

                if (ContainsNodeRecursive(
                        child,
                        target))
                {
                    return true;
                }
            }

            return false;
        }

        private static void MarkDeletedRecursive(
            RuleNode node)
        {
            node.State =
                RuleNodeState.Deleted;

            foreach (RuleNode child in node.Children)
            {
                MarkDeletedRecursive(child);
            }

            foreach (RuleAttachment attachment
                     in node.Attachments)
            {
                attachment.State =
                    RuleNodeState.Deleted;
            }
        }

        private void RefreshCommands()
        {
            RaiseCanExecuteChanged(
                AddParagraphCommand);

            RaiseCanExecuteChanged(
                DeleteParagraphCommand);

            RaiseCanExecuteChanged(
                AddTextCommand);

            RaiseCanExecuteChanged(
                DeleteTextCommand);

            RaiseCanExecuteChanged(
                MoveUpCommand);

            RaiseCanExecuteChanged(
                MoveDownCommand);

            RaiseCanExecuteChanged(
                SaveChangesCommand);
        }

        private static void RaiseCanExecuteChanged(
            ICommand command)
        {
            if (command is RelayCommand relayCommand)
            {
                relayCommand.RaiseCanExecuteChanged();
            }
        }

        public event PropertyChangedEventHandler?
            PropertyChanged;

        protected virtual void OnPropertyChanged(
            [CallerMemberName]
            string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(
                    propertyName));
        }
        public async Task<RuleSaveResult> SaveAsync()
        {
            if (IsReadOnly)
            {
                return new RuleSaveResult
                {
                    Success = false
                };
            }

            if (!HasUnsavedChanges)
            {
                return new RuleSaveResult
                {
                    Success = true
                };
            }

            IsLoading = true;

            try
            {
                RuleSaveResult result =
                    await _saveService.SaveAsync(
                        RootPath,
                        RootNodes,
                        PendingDeletedNodes);

                if (!result.Success)
                    return result;

                /*
                 * IMPORTANTISSIMO:
                 *
                 * Dopo un salvataggio riuscito rileggiamo realmente
                 * il filesystem.
                 *
                 * Non ci fidiamo solamente della struttura in memoria.
                 */
                List<RuleNode> refreshedNodes =
                    await _fileSystemService.LoadAsync(
                        RootPath);

                RootNodes.Clear();

                foreach (RuleNode node
                         in refreshedNodes)
                {
                    RootNodes.Add(node);

                    SubscribeNodeRecursive(node);
                }

                _pendingDeletedNodes.Clear();

                SelectedNode = null;

                HasUnsavedChanges = false;

                return result;
            }
            finally
            {
                IsLoading = false;
            }
        }
    }
}