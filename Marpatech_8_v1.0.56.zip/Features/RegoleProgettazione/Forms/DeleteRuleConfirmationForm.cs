﻿using Marpatech_8.Features.RegoleProgettazione.Models;
using Marpatech_8.Features.RegoleProgettazione.UI;
using System;
using System.Drawing;
using System.Windows.Forms;
using Marpatech_8.Features.Core.Settings;

using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

namespace Marpatech_8.Features.RegoleProgettazione.Forms
{
    public class DeleteRuleConfirmationForm : Form
    {
        private readonly bool _isDarkTheme;

        private CheckBox
            safetyCheckBox = null!;

        private Button
            deleteButton = null!;

        public bool DeleteConfirmed
        {
            get;
            private set;
        }

        public DeleteRuleConfirmationForm(
            RuleNode node,
            bool isDarkTheme)
        {
            _isDarkTheme =
                isDarkTheme;

            InitializeComponent(
                node);

        }

        private void InitializeComponent(
            RuleNode node)
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Color secondaryColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            Color borderColor =
                _isDarkTheme
                    ? Color.FromArgb(70, 75, 88)
                    : Color.FromArgb(190, 200, 215);

            Text =
                "Conferma eliminazione";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    560,
                    350);

            BackColor =
                backgroundColor;

            Font =
                new Font(
                    "Segoe UI",
                    9F);

            Label titleLabel =
                new Label
                {
                    Text =
                        "Conferma eliminazione",

                    Font =
                        new Font(
                            "Segoe UI",
                            18F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            24,
                            20)
                };

            string elementType =
                node.IsParagraph
                    ? "paragrafo"
                    : "testo";

            Label warningLabel =
                new Label
                {
                    Text =
                        $"Stai per eliminare il {elementType}:\r\n\r\n" +
                        $"\"{node.Title}\"",

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Regular),

                    ForeColor =
                        textColor,

                    AutoSize =
                        false,

                    Location =
                        new Point(
                            26,
                            72),

                    Size =
                        new Size(
                            500,
                            65)
                };

            string details =
                BuildDetails(
                    node);

            Label detailsLabel =
                new Label
                {
                    Text =
                        details,

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            26,
                            140),

                    Size =
                        new Size(
                            500,
                            72)
                };

            Panel safetyPanel =
                new Panel
                {
                    Location =
                        new Point(
                            24,
                            218),

                    Size =
                        new Size(
                            512,
                            58),

                    BackColor =
                        panelColor
                };

            safetyPanel.Paint +=
                (_, e) =>
                {
                    using Pen pen =
                        new Pen(
                            borderColor);

                    e.Graphics.DrawRectangle(
                        pen,
                        0,
                        0,
                        safetyPanel.Width - 1,
                        safetyPanel.Height - 1);
                };

            safetyCheckBox =
                new CheckBox
                {
                    Text =
                        "Sono consapevole che l'elemento e tutto il suo contenuto verranno eliminati.",

                    ForeColor =
                        textColor,

                    BackColor =
                        panelColor,

                    AutoSize =
                        false,

                    Size =
                        new Size(
                            480,
                            38),

                    Location =
                        new Point(
                            14,
                            10)
                };

            safetyCheckBox.CheckedChanged +=
                (_, _) =>
                {
                    deleteButton.Enabled =
                        safetyCheckBox.Checked;
                };

            safetyPanel.Controls.Add(
                safetyCheckBox);

            Button cancelButton =
                new Button
                {
                    Text =
                        "Annulla",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            326,
                            294),

                    DialogResult =
                        DialogResult.Cancel
                };

            RuleButtonStyle.ApplySecondary(
             cancelButton);

            deleteButton =
                new Button
                {
                    Text =
                        "Elimina",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            436,
                            294),

                    Enabled =
                        false
                };

            RuleButtonStyle.ApplyDelete(
               deleteButton);

            deleteButton.Click +=
                (_, _) =>
                {
                    if (!safetyCheckBox.Checked)
                        return;

                    DeleteConfirmed =
                        true;

                    DialogResult =
                        DialogResult.OK;

                    Close();
                };

            Controls.Add(
                titleLabel);

            Controls.Add(
                warningLabel);

            Controls.Add(
                detailsLabel);

            Controls.Add(
                safetyPanel);

            Controls.Add(
                cancelButton);

            Controls.Add(
                deleteButton);

            AcceptButton =
                deleteButton;

            CancelButton =
                cancelButton;
        }

        private static string BuildDetails(
            RuleNode node)
        {
            if (node.IsText)
            {
                int attachments =
                    node.Attachments.Count;

                return attachments == 0
                    ? "Il testo non contiene allegati."
                    : attachments == 1
                        ? "Verrà eliminato anche 1 allegato."
                        : $"Verranno eliminati anche {attachments} allegati.";
            }

            int paragraphCount =
                CountParagraphs(
                    node);

            int textCount =
                CountTexts(
                    node);

            int attachmentCount =
                CountAttachments(
                    node);

            return
                "Verrà eliminato anche tutto il contenuto interno.\r\n" +
                $"Paragrafi: {paragraphCount}   " +
                $"Testi: {textCount}   " +
                $"Allegati: {attachmentCount}";
        }

        private static int CountParagraphs(
            RuleNode node)
        {
            int count = 0;

            foreach (RuleNode child
                     in node.Children)
            {
                if (child.IsParagraph)
                    count++;

                count +=
                    CountParagraphs(
                        child);
            }

            return count;
        }

        private static int CountTexts(
            RuleNode node)
        {
            int count = 0;

            foreach (RuleNode child
                     in node.Children)
            {
                if (child.IsText)
                    count++;

                count +=
                    CountTexts(
                        child);
            }

            return count;
        }

        private static int CountAttachments(
            RuleNode node)
        {
            int count =
                node.Attachments.Count;

            foreach (RuleNode child
                     in node.Children)
            {
                count +=
                    CountAttachments(
                        child);
            }

            return count;
        }
    }
}