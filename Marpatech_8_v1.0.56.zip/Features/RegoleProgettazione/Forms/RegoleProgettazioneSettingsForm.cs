﻿using Marpatech_8.Features.RegoleProgettazione.Models;
using Marpatech_8.Features.RegoleProgettazione.Services;
using Marpatech_8.Features.RegoleProgettazione.UI;
using Marpatech_8.Features.Core.Settings;

using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;

using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.Forms
{
    public class RegoleProgettazioneSettingsForm : Form
    {
        private readonly RuleSettingsService
            _settingsService;

        private readonly RuleSettings
            _settings;

        private readonly bool
            _isDarkTheme;

        private readonly bool
            _forcePathEditing;

        private TextBox
            rootPathTextBox = null!;

        private Button
            browseButton = null!;

        private CheckBox
            readOnlyCheckBox = null!;

        public bool SettingsChanged
        {
            get;
            private set;
        }

        public RegoleProgettazioneSettingsForm(
            RuleSettingsService settingsService,
            bool isDarkTheme,
            bool forcePathEditing = false)
        {
            _settingsService =
                settingsService;

            _settings =
                _settingsService.Load();

            _isDarkTheme =
                isDarkTheme;

            _forcePathEditing =
                forcePathEditing;

            InitializeComponent();

            LoadSettings();

        }

        private void InitializeComponent()
        {
            Color backgroundColor =
                _isDarkTheme
                    ? Color.FromArgb(18, 18, 22)
                    : Color.FromArgb(245, 247, 250);

            Color panelColor =
                _isDarkTheme
                    ? Color.FromArgb(32, 34, 40)
                    : Color.White;

            Color textColor =
                _isDarkTheme
                    ? Color.White
                    : Color.FromArgb(30, 41, 59);

            Color secondaryColor =
                _isDarkTheme
                    ? Color.FromArgb(170, 178, 190)
                    : Color.FromArgb(100, 116, 139);

            Text =
                "Impostazioni - Regole di progettazione";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    650,
                    300);

            BackColor =
                backgroundColor;

            Font =
                new Font(
                    "Segoe UI",
                    9F);

            Label titleLabel =
                new Label
                {
                    Text =
                        "Impostazioni",

                    Font =
                        new Font(
                            "Segoe UI",
                            18F,
                            FontStyle.Bold),

                    ForeColor =
                        textColor,

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            24,
                            20)
                };

            Label pathLabel =
                new Label
                {
                    Text =
                        "Cartella Regole di progettazione",

                    ForeColor =
                        textColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            9F,
                            FontStyle.Bold),

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            26,
                            72)
                };

            rootPathTextBox =
                new TextBox
                {
                    Location =
                        new Point(
                            26,
                            98),

                    Size =
                        new Size(
                            535,
                            30),

                    BackColor =
                        panelColor,

                    ForeColor =
                        textColor
                };

            browseButton =
                new Button
                {
                    Text =
                        "...",

                    Location =
                        new Point(
                            570,
                            97),

                    Size =
                        new Size(
                            48,
                            30)
                };

            RuleButtonStyle.ApplyPrimary(
             browseButton);

            browseButton.Click +=
                BrowseButton_Click;

            Label noteLabel =
                new Label
                {
                    Text =
                        "Può essere una cartella locale, di rete o su server.",

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            28,
                            134),

                    AutoSize =
                        true
                };

            readOnlyCheckBox =
                new CheckBox
                {
                    Text =
                        "Sola Lettura",

                    ForeColor =
                        textColor,

                    BackColor =
                        backgroundColor,

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Bold),

                    AutoSize =
                        true,

                    Location =
                        new Point(
                            28,
                            178)
                };

            readOnlyCheckBox.CheckedChanged +=
                (_, _) =>
                {
                    UpdateReadOnlyState();
                };

            Label readOnlyDescription =
                new Label
                {
                    Text =
                        "Nasconde tutte le funzioni di modifica nell'addin. " +
                        "La cartella Windows rimane comunque modificabile secondo i normali permessi del sistema.",

                    ForeColor =
                        secondaryColor,

                    Location =
                        new Point(
                            48,
                            207),

                    Size =
                        new Size(
                            550,
                            40)
                };

            Button cancelButton =
                new Button
                {
                    Text =
                        "Annulla",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            408,
                            252),

                    DialogResult =
                        DialogResult.Cancel
                };

            RuleButtonStyle.ApplySecondary(
                cancelButton);

            Button saveButton =
                new Button
                {
                    Text =
                        "Salva",

                    Size =
                        new Size(
                            100,
                            34),

                    Location =
                        new Point(
                            518,
                            252)
                };

            RuleButtonStyle.ApplySave(
               saveButton);

            saveButton.Click +=
                SaveButton_Click;

            Controls.Add(
                titleLabel);

            Controls.Add(
                pathLabel);

            Controls.Add(
                rootPathTextBox);

            Controls.Add(
                browseButton);

            Controls.Add(
                noteLabel);

            Controls.Add(
                readOnlyCheckBox);

            Controls.Add(
                readOnlyDescription);

            Controls.Add(
                cancelButton);

            Controls.Add(
                saveButton);

            AcceptButton =
                saveButton;

            CancelButton =
                cancelButton;
        }

        private void LoadSettings()
        {
            rootPathTextBox.Text =
                _settings.RootPath;

            readOnlyCheckBox.Checked =
                _settings.IsReadOnly;

            UpdateReadOnlyState();
        }

        private void UpdateReadOnlyState()
        {
            bool lockPath =
                readOnlyCheckBox.Checked &&
                !_forcePathEditing;

            rootPathTextBox.ReadOnly =
                lockPath;

            browseButton.Enabled =
                !lockPath;
        }

        private void BrowseButton_Click(
            object? sender,
            EventArgs e)
        {
            if (rootPathTextBox.ReadOnly)
                return;

            using FolderBrowserDialog dialog =
                new FolderBrowserDialog
                {
                    Description =
                        "Seleziona la cartella principale delle Regole di progettazione",

                    UseDescriptionForTitle =
                        true
                };

            if (!string.IsNullOrWhiteSpace(
                    rootPathTextBox.Text) &&
                Directory.Exists(
                    rootPathTextBox.Text))
            {
                dialog.SelectedPath =
                    rootPathTextBox.Text;
            }

            if (dialog.ShowDialog(
                    this) !=
                DialogResult.OK)
            {
                return;
            }

            rootPathTextBox.Text =
                dialog.SelectedPath;
        }

        private void SaveButton_Click(
            object? sender,
            EventArgs e)
        {
            string rootPath =
                rootPathTextBox
                    .Text
                    .Trim();

            if (string.IsNullOrWhiteSpace(
                    rootPath))
            {
                MessageBox.Show(
                    this,
                    "Imposta la cartella principale delle Regole di progettazione.",
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            /*
             * IMPORTANTE:
             * cartella VUOTA è perfettamente valida.
             *
             * Deve semplicemente esistere.
             */
            if (!Directory.Exists(
                    rootPath))
            {
                MessageBox.Show(
                    this,
                    "La cartella indicata non esiste:\r\n\r\n" +
                    rootPath,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            try
            {
                _settings.RootPath =
                    rootPath;

                _settings.IsReadOnly =
                    readOnlyCheckBox.Checked;

                _settingsService.Save(
                    _settings);

                if (!_settings.IsReadOnly)
                {
                    RuleExternalChangesService.EnsureRequestFile(
                        rootPath);
                }

                SettingsChanged =
                    true;

                DialogResult =
                    DialogResult.OK;

                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    this,
                    ex.Message,
                    "Errore salvataggio impostazioni",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}