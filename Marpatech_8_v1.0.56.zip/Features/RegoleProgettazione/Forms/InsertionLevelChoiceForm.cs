﻿using System.Drawing;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.Forms
{
    public sealed class InsertionLevelChoiceForm : Form
    {
        public bool SameLevelSelected
        {
            get;
            private set;
        }

        public InsertionLevelChoiceForm(
            string elementType)
        {
            Text =
                "Regole di progettazione";

            StartPosition =
                FormStartPosition.CenterParent;

            FormBorderStyle =
                FormBorderStyle.FixedDialog;

            MaximizeBox =
                false;

            MinimizeBox =
                false;

            ShowInTaskbar =
                false;

            ClientSize =
                new Size(
                    430,
                    150);

            Label questionLabel =
                new Label
                {
                    Text =
                        $"Dove vuoi inserire questo {elementType}?",

                    AutoSize =
                        false,

                    Location =
                        new Point(
                            25,
                            25),

                    Size =
                        new Size(
                            380,
                            45),

                    Font =
                        new Font(
                            "Segoe UI",
                            10F,
                            FontStyle.Regular),

                    TextAlign =
                        ContentAlignment.MiddleLeft
                };

            Button sameLevelButton =
                new Button
                {
                    Text =
                        "Stesso Livello",

                    Size =
                        new Size(
                            130,
                            34),

                    Location =
                        new Point(
                            145,
                            95)
                };

            Button lowerLevelButton =
                new Button
                {
                    Text =
                        "Livello Inferiore",

                    Size =
                        new Size(
                            130,
                            34),

                    Location =
                        new Point(
                            285,
                            95)
                };

            /*
             * STESSO LIVELLO
             */
            sameLevelButton.Click +=
                (_, _) =>
                {
                    SameLevelSelected =
                        true;

                    DialogResult =
                        DialogResult.OK;

                    Close();
                };

            /*
             * LIVELLO INFERIORE
             */
            lowerLevelButton.Click +=
                (_, _) =>
                {
                    SameLevelSelected =
                        false;

                    DialogResult =
                        DialogResult.Yes;

                    Close();
                };

            /*
             * Invio = Stesso Livello.
             */
            AcceptButton =
                sameLevelButton;

            /*
             * NON associamo Livello Inferiore
             * al CancelButton.
             *
             * X oppure ESC devono significare
             * ANNULLA e non Livello Inferiore.
             */
            CancelButton =
                null;

            /*
             * Se la finestra viene chiusa con X
             * senza aver premuto uno dei due pulsanti,
             * il risultato è ANNULLA.
             */
            FormClosing +=
                (_, _) =>
                {
                    if (DialogResult ==
                        DialogResult.None)
                    {
                        DialogResult =
                            DialogResult.Cancel;
                    }
                };

            Controls.Add(
                questionLabel);

            Controls.Add(
                sameLevelButton);

            Controls.Add(
                lowerLevelButton);
        }
    }
}