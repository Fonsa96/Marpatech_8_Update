﻿namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public enum RuleNodeState
    {
        Unchanged,
        Added,
        Modified,
        Deleted,
        Moved
    }
}