﻿namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public enum RuleNodeType
    {
        Paragraph,
        Text
    }
}