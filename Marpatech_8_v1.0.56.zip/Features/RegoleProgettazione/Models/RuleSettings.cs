﻿namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class RuleSettings
    {
        public string RootPath { get; set; } =
            string.Empty;

        public bool IsReadOnly { get; set; }
    }
}