﻿using System;

namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class RuleAttachment
    {
        public Guid Id { get; set; } =
            Guid.NewGuid();

        public string FileName { get; set; } =
            string.Empty;

        public string OriginalPath { get; set; } =
            string.Empty;

        public string PendingSourcePath { get; set; } =
            string.Empty;

        public RuleNodeState State { get; set; } =
            RuleNodeState.Unchanged;

        public bool IsPending =>
            State == RuleNodeState.Added;

        public bool IsDeleted =>
            State == RuleNodeState.Deleted;

        public string DisplayPath
        {
            get
            {
                if (State == RuleNodeState.Added &&
                    !string.IsNullOrWhiteSpace(
                        PendingSourcePath))
                {
                    return PendingSourcePath;
                }

                return OriginalPath;
            }
        }
    }
}