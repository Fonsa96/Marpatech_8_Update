﻿namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class DeleteRuleRequest
    {
        public RuleNode Node { get; }

        public DeleteRuleRequest(
            RuleNode node)
        {
            Node = node;
        }
    }
}