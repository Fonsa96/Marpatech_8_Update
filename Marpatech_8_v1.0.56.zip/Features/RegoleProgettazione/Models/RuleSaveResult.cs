﻿using System.Collections.Generic;

namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class RuleSaveResult
    {
        public bool Success { get; set; }

        public bool HasConflicts =>
            Conflicts.Count > 0;

        public int CreatedItems { get; set; }

        public int ModifiedItems { get; set; }

        public int DeletedItems { get; set; }

        public int MovedItems { get; set; }

        public int AddedAttachments { get; set; }

        public int DeletedAttachments { get; set; }

        public List<string> Conflicts { get; } =
            new List<string>();

        public List<string> Errors { get; } =
            new List<string>();
    }
}