﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Marpatech_8.Features.RegoleProgettazione.Models
{
    public class RuleNode : INotifyPropertyChanged
    {
        private string _title = string.Empty;
        private bool _isExpanded = true;
        private bool _isSelected;
        private string _htmlContent = string.Empty;
        private RuleNodeState _state = RuleNodeState.Unchanged;

        public Guid Id { get; set; } = Guid.NewGuid();

        public RuleNodeType NodeType { get; set; }

        /// <summary>
        /// Nome visualizzato nell'Addin.
        ///
        /// Esempio:
        /// filesystem = "001 - P - Trasmissioni"
        /// Title      = "Trasmissioni"
        /// </summary>
        public string Title
        {
            get => _title;
            set
            {
                if (_title == value)
                    return;

                _title = value;
                OnPropertyChanged();

                MarkModified();
            }
        }

        /// <summary>
        /// Ordine dell'elemento all'interno del proprio paragrafo.
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// Percorso originale letto dal filesystem.
        /// Non viene modificato fino a Salva Modifiche.
        /// </summary>
        public string OriginalPath { get; set; } = string.Empty;

        /// <summary>
        /// Nome originale della cartella.
        /// Es:
        /// "001 - P - Trasmissioni"
        /// </summary>
        public string OriginalFolderName { get; set; } =
            string.Empty;

        /// <summary>
        /// Nodo padre.
        /// Null per gli elementi alla radice.
        /// </summary>
        /// 

        /// <summary>
        /// Contenuto del testo così com'era al momento
        /// dell'apertura della funzione.
        /// Serve per rilevare modifiche esterne prima del salvataggio.
        /// </summary>
        public string OriginalHtmlContent { get; set; } =
            string.Empty;

        /// <summary>
        /// Data di ultima modifica originale di contenuto.html.
        /// </summary>
        public DateTime? OriginalContentLastWriteTimeUtc
        {
            get;
            set;
        }

        public RuleNode? Parent { get; set; }

        /// <summary>
        /// Figli del paragrafo.
        ///
        /// I nodi Text normalmente non devono contenere figli.
        /// </summary>
        public ObservableCollection<RuleNode> Children { get; } =
            new ObservableCollection<RuleNode>();

        /// <summary>
        /// Allegati del nodo Text.
        /// </summary>
        public ObservableCollection<RuleAttachment> Attachments { get; } =
            new ObservableCollection<RuleAttachment>();

        public ObservableCollection<RuleAttachment>
            PendingDeletedAttachments
        { get; } =
            new ObservableCollection<RuleAttachment>();

        /// <summary>
        /// Contenuto HTML.
        /// Utilizzato solamente per NodeType == Text.
        /// </summary>
        public string HtmlContent
        {
            get => _htmlContent;
            set
            {
                if (_htmlContent == value)
                    return;

                _htmlContent = value;
                OnPropertyChanged();

                MarkModified();
            }
        }

        /// <summary>
        /// Ogni paragrafo può sempre essere aperto/chiuso.
        /// </summary>
        public bool IsExpanded
        {
            get => _isExpanded;
            set
            {
                if (_isExpanded == value)
                    return;

                _isExpanded = value;
                OnPropertyChanged();
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                if (_isSelected == value)
                    return;

                _isSelected = value;
                OnPropertyChanged();
            }
        }

        public RuleNodeState State
        {
            get => _state;
            set
            {
                if (_state == value)
                    return;

                _state = value;
                OnPropertyChanged();

                OnPropertyChanged(nameof(IsDeleted));
                OnPropertyChanged(nameof(IsNew));
            }
        }

        public bool IsParagraph =>
            NodeType == RuleNodeType.Paragraph;

        public bool IsText =>
            NodeType == RuleNodeType.Text;

        public bool IsDeleted =>
            State == RuleNodeState.Deleted;

        public bool IsNew =>
            State == RuleNodeState.Added;

        private void MarkModified()
        {
            /*
             * Se è appena stato aggiunto deve rimanere Added.
             *
             * Un elemento Added non deve diventare Modified,
             * perché al salvataggio dovremo comunque crearlo
             * integralmente.
             */
            if (State == RuleNodeState.Unchanged)
                State = RuleNodeState.Modified;
        }

        public void MarkMoved()
        {
            if (State == RuleNodeState.Unchanged)
                State = RuleNodeState.Moved;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(
            [CallerMemberName] string? propertyName = null)
        {
            PropertyChanged?.Invoke(
                this,
                new PropertyChangedEventArgs(propertyName));
        }
    }
}
