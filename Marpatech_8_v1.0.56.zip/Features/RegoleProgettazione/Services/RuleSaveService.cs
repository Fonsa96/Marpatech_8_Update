﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Marpatech_8.Features.RegoleProgettazione.Models;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public class RuleSaveService
    {
        public async Task<RuleSaveResult> SaveAsync(
            string rootPath,
            ObservableCollection<RuleNode> rootNodes,
            IReadOnlyList<RuleNode> pendingDeletedNodes,
            CancellationToken cancellationToken = default)
        {
            var result =
                new RuleSaveResult();

            if (string.IsNullOrWhiteSpace(rootPath))
            {
                result.Errors.Add(
                    "Il percorso delle Regole di progettazione non è impostato.");

                return result;
            }

            if (!Directory.Exists(rootPath))
            {
                result.Errors.Add(
                    $"La cartella principale non esiste: {rootPath}");

                return result;
            }

            try
            {
                /*
                 * Prima di toccare qualsiasi file eseguiamo
                 * tutti i controlli possibili.
                 */
                ValidateBeforeSave(
                    rootNodes,
                    pendingDeletedNodes,
                    result);

                if (result.HasConflicts ||
                    result.Errors.Count > 0)
                {
                    return result;
                }

                await Task.Run(
                    () =>
                    {
                        /*
                         * 1.
                         * Eliminiamo gli elementi esistenti che
                         * l'utente ha esplicitamente eliminato.
                         *
                         * Questo libera anche eventuali nomi/ordini.
                         */
                        DeletePendingNodes(
                            pendingDeletedNodes,
                            result,
                            cancellationToken);

                        /*
                         * 2.
                         * Salviamo ricorsivamente la struttura.
                         */
                        SaveLevel(
                            rootPath,
                            rootNodes,
                            result,
                            cancellationToken);

                        result.Success = true;
                    },
                    cancellationToken);

                return result;
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                result.Errors.Add(
                    ex.Message);

                result.Success = false;

                return result;
            }
        }

        private static void ValidateBeforeSave(
            IEnumerable<RuleNode> rootNodes,
            IReadOnlyList<RuleNode> pendingDeletedNodes,
            RuleSaveResult result)
        {
            /*
             * Verifichiamo innanzitutto che gli elementi che
             * esistevano all'apertura esistano ancora.
             */
            foreach (RuleNode node in
                     EnumerateAllNodes(rootNodes))
            {
                ValidateNode(
                    node,
                    result);
            }

            foreach (RuleNode deletedNode
                     in pendingDeletedNodes)
            {
                /*
                 * Se qualcun altro l'ha già cancellato da Windows
                 * non consideriamolo un errore bloccante.
                 *
                 * Al salvataggio è già nello stato finale desiderato.
                 */
                if (string.IsNullOrWhiteSpace(
                        deletedNode.OriginalPath))
                {
                    continue;
                }
            }
        }

        private static void ValidateNode(
            RuleNode node,
            RuleSaveResult result)
        {
            if (node.State ==
                RuleNodeState.Added)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(
                    node.OriginalPath))
            {
                return;
            }

            if (!Directory.Exists(
                    node.OriginalPath))
            {
                result.Conflicts.Add(
                    $"'{node.Title}' non esiste più nella cartella aziendale.");

                return;
            }

            /*
             * Il controllo più importante riguarda il contenuto
             * dei testi.
             *
             * Se NOI stiamo modificando un testo, verifichiamo
             * che nel frattempo qualcun altro non abbia modificato
             * lo stesso contenuto.html.
             */
            if (node.IsText &&
                node.State ==
                    RuleNodeState.Modified)
            {
                ValidateTextConflict(
                    node,
                    result);
            }

            foreach (RuleNode child
                     in node.Children)
            {
                ValidateNode(
                    child,
                    result);
            }
        }

        private static void ValidateTextConflict(
            RuleNode node,
            RuleSaveResult result)
        {
            string contentPath =
                Path.Combine(
                    node.OriginalPath,
                    RuleFileSystemService.ContentFileName);

            string currentDiskContent =
                File.Exists(contentPath)
                    ? File.ReadAllText(contentPath)
                    : string.Empty;

            /*
             * Se ciò che si trova ora su disco non è uguale
             * a ciò che avevamo letto all'apertura,
             * qualcuno lo ha modificato esternamente.
             */
            if (!string.Equals(
                    currentDiskContent,
                    node.OriginalHtmlContent,
                    StringComparison.Ordinal))
            {
                result.Conflicts.Add(
                    $"Il testo '{node.Title}' è stato modificato esternamente dopo l'apertura della funzione.");
            }
        }

        private static void DeletePendingNodes(
            IReadOnlyList<RuleNode> pendingDeletedNodes,
            RuleSaveResult result,
            CancellationToken cancellationToken)
        {
            /*
             * Ordiniamo dai livelli più profondi.
             *
             * In realtà Directory.Delete(..., true) elimina già
             * tutto ricorsivamente, ma questa ordinazione rende
             * il comportamento più prevedibile in caso di più
             * eliminazioni indipendenti.
             */
            foreach (RuleNode node
                     in pendingDeletedNodes
                         .OrderByDescending(
                             GetDepth))
            {
                cancellationToken
                    .ThrowIfCancellationRequested();

                if (string.IsNullOrWhiteSpace(
                        node.OriginalPath))
                {
                    continue;
                }

                if (!Directory.Exists(
                        node.OriginalPath))
                {
                    continue;
                }

                Directory.Delete(
                    node.OriginalPath,
                    recursive: true);

                result.DeletedItems++;
            }
        }

        private static void SaveLevel(
            string parentPath,
            IEnumerable<RuleNode> nodes,
            RuleSaveResult result,
            CancellationToken cancellationToken)
        {
            List<RuleNode> orderedNodes =
                nodes
                    .OrderBy(x => x.Order)
                    .ToList();

            /*
             * Prima prepariamo le eventuali rinomine.
             *
             * Usiamo un nome temporaneo per evitare problemi
             * del tipo:
             *
             * 001 -> 002
             * 002 -> 001
             *
             * dove i nomi si scontrerebbero.
             */
            PrepareExistingNodeRenames(
                parentPath,
                orderedNodes,
                result,
                cancellationToken);

            /*
             * Adesso assegniamo i nomi finali.
             */
            foreach (RuleNode node
                     in orderedNodes)
            {
                cancellationToken
                    .ThrowIfCancellationRequested();

                string finalFolderName =
                    RuleFolderNameService.BuildFolderName(
                        node.Order,
                        node.NodeType,
                        node.Title);

                string finalPath =
                    Path.Combine(
                        parentPath,
                        finalFolderName);

                if (node.State ==
                    RuleNodeState.Added)
                {
                    if (Directory.Exists(finalPath))
                    {
                        throw new IOException(
                            $"Esiste già una cartella chiamata '{finalFolderName}'.");
                    }

                    Directory.CreateDirectory(
                        finalPath);

                    node.OriginalPath =
                        finalPath;

                    node.OriginalFolderName =
                        finalFolderName;

                    result.CreatedItems++;
                }
                else
                {
                    /*
                     * Dopo PrepareExistingNodeRenames,
                     * OriginalPath può indicare il nome temporaneo.
                     */
                    if (!PathsEqual(
                            node.OriginalPath,
                            finalPath))
                    {
                        if (Directory.Exists(finalPath))
                        {
                            throw new IOException(
                                $"Impossibile rinominare '{node.Title}': '{finalFolderName}' esiste già.");
                        }

                        Directory.Move(
                            node.OriginalPath,
                            finalPath);

                        node.OriginalPath =
                            finalPath;

                        node.OriginalFolderName =
                            finalFolderName;

                        result.MovedItems++;
                    }
                }

                if (node.IsText)
                {
                    SaveTextNode(
                        node,
                        result,
                        cancellationToken);
                }
                else
                {
                    SaveLevel(
                        node.OriginalPath,
                        node.Children,
                        result,
                        cancellationToken);
                }

                /*
                 * Il nodo ora rappresenta esattamente
                 * ciò che esiste sul filesystem.
                 */
                node.State =
                    RuleNodeState.Unchanged;
            }
        }

        private static void PrepareExistingNodeRenames(
            string parentPath,
            IEnumerable<RuleNode> nodes,
            RuleSaveResult result,
            CancellationToken cancellationToken)
        {
            foreach (RuleNode node
                     in nodes)
            {
                cancellationToken
                    .ThrowIfCancellationRequested();

                if (node.State ==
                    RuleNodeState.Added)
                {
                    continue;
                }

                if (string.IsNullOrWhiteSpace(
                        node.OriginalPath))
                {
                    continue;
                }

                string finalFolderName =
                    RuleFolderNameService.BuildFolderName(
                        node.Order,
                        node.NodeType,
                        node.Title);

                string finalPath =
                    Path.Combine(
                        parentPath,
                        finalFolderName);

                if (PathsEqual(
                        node.OriginalPath,
                        finalPath))
                {
                    continue;
                }

                if (!Directory.Exists(
                        node.OriginalPath))
                {
                    throw new DirectoryNotFoundException(
                        $"La cartella '{node.OriginalPath}' non esiste più.");
                }

                string temporaryPath =
                    Path.Combine(
                        parentPath,
                        $".rp_tmp_{Guid.NewGuid():N}");

                Directory.Move(
                    node.OriginalPath,
                    temporaryPath);

                node.OriginalPath =
                    temporaryPath;
            }
        }

        private static void SaveTextNode(
            RuleNode node,
            RuleSaveResult result,
            CancellationToken cancellationToken)
        {
            cancellationToken
                .ThrowIfCancellationRequested();

            string contentPath =
                Path.Combine(
                    node.OriginalPath,
                    RuleFileSystemService.ContentFileName);

            bool mustWriteContent =
                node.State ==
                    RuleNodeState.Added ||
                node.State ==
                    RuleNodeState.Modified ||
                !File.Exists(contentPath);

            if (mustWriteContent)
            {
                File.WriteAllText(
                    contentPath,
                    node.HtmlContent ?? string.Empty);

                node.OriginalHtmlContent =
                    node.HtmlContent ?? string.Empty;

                node.OriginalContentLastWriteTimeUtc =
                    File.GetLastWriteTimeUtc(
                        contentPath);

                if (node.State !=
                    RuleNodeState.Added)
                {
                    result.ModifiedItems++;
                }
            }

            SaveAttachments(
                node,
                result,
                cancellationToken);
        }

        private static void SaveAttachments(
            RuleNode node,
            RuleSaveResult result,
            CancellationToken cancellationToken)
        {
            /*
             * ============================================
             * 1. NUOVI ALLEGATI
             * ============================================
             *
             * Gli allegati Added esistono solamente
             * in memoria fino a Salva Modifiche.
             *
             * Solo qui vengono realmente copiati
             * nella cartella aziendale del testo.
             */
            foreach (RuleAttachment attachment
                     in node.Attachments.ToList())
            {
                cancellationToken
                    .ThrowIfCancellationRequested();

                if (attachment.State !=
                    RuleNodeState.Added)
                {
                    continue;
                }

                if (string.IsNullOrWhiteSpace(
                        attachment.PendingSourcePath))
                {
                    throw new IOException(
                        $"Percorso sorgente mancante per l'allegato '{attachment.FileName}'.");
                }

                if (!File.Exists(
                        attachment.PendingSourcePath))
                {
                    throw new FileNotFoundException(
                        $"L'allegato '{attachment.FileName}' non esiste più nella posizione sorgente.",
                        attachment.PendingSourcePath);
                }

                string destinationPath =
                    Path.Combine(
                        node.OriginalPath,
                        attachment.FileName);

                if (File.Exists(
                        destinationPath))
                {
                    throw new IOException(
                        $"Esiste già un allegato chiamato '{attachment.FileName}' nel testo '{node.Title}'.");
                }

                File.Copy(
                    attachment.PendingSourcePath,
                    destinationPath,
                    overwrite: false);

                attachment.OriginalPath =
                    destinationPath;

                attachment.PendingSourcePath =
                    string.Empty;

                attachment.State =
                    RuleNodeState.Unchanged;

                result.AddedAttachments++;
            }

            /*
             * ============================================
             * 2. ALLEGATI DA ELIMINARE
             * ============================================
             *
             * Quando l'utente preme Rimuovi,
             * il file NON viene cancellato immediatamente.
             *
             * Viene tolto dalla lista visibile e inserito
             * in PendingDeletedAttachments.
             *
             * La cancellazione fisica avviene solamente
             * quando viene premuto Salva Modifiche.
             */
            foreach (RuleAttachment attachment
                     in node.PendingDeletedAttachments.ToList())
            {
                cancellationToken
                    .ThrowIfCancellationRequested();

                if (!string.IsNullOrWhiteSpace(
                        attachment.OriginalPath) &&
                    File.Exists(
                        attachment.OriginalPath))
                {
                    File.Delete(
                        attachment.OriginalPath);
                }

                node.PendingDeletedAttachments.Remove(
                    attachment);

                result.DeletedAttachments++;
            }
        }

        private static IEnumerable<RuleNode>
            EnumerateAllNodes(
                IEnumerable<RuleNode> nodes)
        {
            foreach (RuleNode node
                     in nodes)
            {
                yield return node;

                foreach (RuleNode child
                         in EnumerateAllNodes(
                             node.Children))
                {
                    yield return child;
                }
            }
        }

        private static int GetDepth(
            RuleNode node)
        {
            int depth = 0;

            RuleNode? current =
                node.Parent;

            while (current != null)
            {
                depth++;
                current = current.Parent;
            }

            return depth;
        }

        private static bool PathsEqual(
            string path1,
            string path2)
        {
            string fullPath1 =
                Path.GetFullPath(path1)
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar);

            string fullPath2 =
                Path.GetFullPath(path2)
                    .TrimEnd(
                        Path.DirectorySeparatorChar,
                        Path.AltDirectorySeparatorChar);

            return string.Equals(
                fullPath1,
                fullPath2,
                StringComparison.OrdinalIgnoreCase);
        }
    }
}