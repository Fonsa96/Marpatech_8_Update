﻿using System;
using System.Text.RegularExpressions;
using Marpatech_8.Features.RegoleProgettazione.Models;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class RuleFolderNameService
    {
        /*
         * Formato:
         *
         * 001 - P - Trasmissioni
         * 002 - T - Regole generali
         */
        private static readonly Regex FolderRegex =
            new Regex(
                @"^(?<order>\d+)\s*-\s*(?<type>[PT])\s*-\s*(?<title>.+)$",
                RegexOptions.Compiled |
                RegexOptions.IgnoreCase);

        public static bool TryParse(
            string folderName,
            out int order,
            out RuleNodeType nodeType,
            out string title)
        {
            order = 0;
            nodeType = RuleNodeType.Paragraph;
            title = string.Empty;

            if (string.IsNullOrWhiteSpace(folderName))
                return false;

            Match match = FolderRegex.Match(folderName);

            if (!match.Success)
                return false;

            if (!int.TryParse(
                    match.Groups["order"].Value,
                    out order))
            {
                return false;
            }

            string type =
                match.Groups["type"].Value.ToUpperInvariant();

            nodeType = type == "P"
                ? RuleNodeType.Paragraph
                : RuleNodeType.Text;

            title =
                match.Groups["title"].Value.Trim();

            return !string.IsNullOrWhiteSpace(title);
        }

        public static string BuildFolderName(
            int order,
            RuleNodeType nodeType,
            string title)
        {
            string typeCode =
                nodeType == RuleNodeType.Paragraph
                    ? "P"
                    : "T";

            string cleanTitle =
                SanitizeTitle(title);

            return
                $"{order:000} - {typeCode} - {cleanTitle}";
        }

        private static string SanitizeTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return "Senza titolo";

            string result = title.Trim();

            char[] invalidChars =
                System.IO.Path.GetInvalidFileNameChars();

            foreach (char invalidChar in invalidChars)
            {
                result =
                    result.Replace(
                        invalidChar,
                        '_');
            }

            return result;
        }
    }
}
