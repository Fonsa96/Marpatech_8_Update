﻿using Marpatech_8.Features.Core.Navigation;
using Marpatech_8.Features.RegoleProgettazione.Forms;
using Marpatech_8.Features.RegoleProgettazione.Models;
using System;
using System.IO;
using System.Windows.Forms;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class RegoleProgettazioneLauncher
    {
        private static RegoleProgettazioneForm?
            _currentForm;

        private static RuleExternalChangesService?
            _externalChangesService;

        public static void Open(
            FeatureOpenContext context)
        {
            /*
             * Il contesto ci dice da dove arriva
             * l'apertura della funzione.
             *
             * Dashboard:
             * MainDashboard contiene il Form.
             *
             * Ribbon Inventor:
             * MainDashboard è null.
             */
            Form? owner =
                context.MainDashboard;

            bool isDarkTheme =
                context.IsDarkTheme;

            /*
             * ==========================================
             * 1. FUNZIONE GIÀ APERTA
             * ==========================================
             *
             * Non permettiamo più istanze contemporanee
             * della funzione sullo stesso PC.
             */
            if (_currentForm != null &&
                !_currentForm.IsDisposed)
            {
                if (_currentForm.WindowState ==
                    FormWindowState.Minimized)
                {
                    _currentForm.WindowState =
                        FormWindowState.Normal;
                }

                _currentForm.Show();

                _currentForm.BringToFront();

                _currentForm.Activate();

                _currentForm.Focus();

                return;
            }

            var settingsService =
                new RuleSettingsService();

            RuleSettings settings =
                settingsService.Load();

            /*
             * ==========================================
             * 2. PRIMO AVVIO
             * ==========================================
             *
             * Nessun percorso impostato:
             * apriamo automaticamente Impostazioni.
             */
            if (string.IsNullOrWhiteSpace(
                    settings.RootPath))
            {
                bool configured =
                    ShowSettings(
                        owner,
                        settingsService,
                        isDarkTheme,
                        forcePathEditing: true);

                if (!configured)
                    return;

                settings =
                    settingsService.Load();
            }

            /*
             * ==========================================
             * 3. PERCORSO NON DISPONIBILE
             * ==========================================
             *
             * Una cartella vuota è valida.
             *
             * Qui controlliamo soltanto che
             * la cartella esista e sia raggiungibile.
             */
            if (!Directory.Exists(
                    settings.RootPath))
            {
                DialogResult result =
                    ShowMessage(
                        owner,
                        "La cartella configurata per le Regole di progettazione non è disponibile:\r\n\r\n" +
                        settings.RootPath +
                        "\r\n\r\nVuoi aprire le Impostazioni per selezionare un altro percorso?",
                        "Regole di progettazione",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                if (result !=
                    DialogResult.Yes)
                {
                    return;
                }

                bool configured =
                    ShowSettings(
                        owner,
                        settingsService,
                        isDarkTheme,
                        forcePathEditing: true);

                if (!configured)
                    return;

                settings =
                    settingsService.Load();

                if (string.IsNullOrWhiteSpace(
                        settings.RootPath) ||
                    !Directory.Exists(
                        settings.RootPath))
                {
                    return;
                }
            }

            /*
             * ==========================================
             * 4. FILE PER AGGIUNTA MODIFICHE
             * ==========================================
             *
             * Tutto questo sistema viene bypassato
             * completamente in Sola Lettura.
             */
            bool externalChangesClaimed =
                false;

            _externalChangesService =
                null;

            if (!settings.IsReadOnly)
            {
                RuleExternalChangesService
                    .EnsureRequestFile(
                        settings.RootPath);

                bool hasExternalChanges =
                    RuleExternalChangesService
                        .HasPendingChanges(
                            settings.RootPath);

                if (hasExternalChanges)
                {
                    _externalChangesService =
                        new RuleExternalChangesService();

                    externalChangesClaimed =
                        _externalChangesService
                            .TryClaim(
                                settings.RootPath);

                    if (!externalChangesClaimed)
                    {
                        _externalChangesService
                            .Dispose();

                        _externalChangesService =
                            null;

                        ShowMessage(
                            owner,
                            "File già aperto in un altro PC.\r\n\r\n" +
                            "La modifica è già stata presa in carico.",
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        ShowMessage(
                            owner,
                            "ATTENZIONE\r\n\r\n" +
                            "Qualcuno ha modificato il file di aggiunta regole.\r\n\r\n" +
                            "Il file sarà aperto per permettere l'aggiunta dei dati alla funzione.",
                            "Regole di progettazione",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);
                    }
                }
            }

            /*
             * ==========================================
             * 5. APERTURA FORM PRINCIPALE
             * ==========================================
             */
            try
            {
                var form =
                    new RegoleProgettazioneForm(
                        settings.RootPath,
                        settings.IsReadOnly,
                        isDarkTheme,
                        _externalChangesService);

                _currentForm =
                    form;

                /*
                 * Questo evento serve ormai solamente
                 * a pulire i riferimenti statici
                 * quando il Form viene chiuso.
                 *
                 * NON gestisce più la Main Dashboard.
                 */
                form.FormClosed +=
                    CurrentForm_FormClosed;

                /*
                 * Il Core decide automaticamente:
                 *
                 * APERTURA DA DASHBOARD
                 * → nasconde Dashboard
                 * → apre Feature
                 * → alla chiusura ripristina Dashboard
                 *
                 * APERTURA DA RIBBON
                 * → nessuna Dashboard da nascondere
                 * → apre direttamente la Feature
                 */
                FeatureWindowService.Open(
                    form,
                    context);

                /*
                 * Se questo PC ha preso in carico
                 * il file TXT, lo apriamo solamente
                 * dopo che il Form principale
                 * è stato mostrato.
                 */
                if (externalChangesClaimed &&
                    _externalChangesService != null)
                {
                    _externalChangesService
                        .OpenRequestFile();
                }
            }
            catch (Exception ex)
            {
                _currentForm =
                    null;

                /*
                 * Se avevamo preso in carico il TXT
                 * ma il Form non è riuscito ad aprirsi,
                 * liberiamo il claim senza cancellare
                 * il contenuto.
                 */
                if (_externalChangesService != null)
                {
                    _externalChangesService
                        .CancelRequestHandling();

                    _externalChangesService =
                        null;
                }

                ShowMessage(
                    owner,
                    "Non è stato possibile aprire Regole di progettazione.\r\n\r\n" +
                    ex.Message,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        /*
         * ==========================================
         * IMPOSTAZIONI
         * ==========================================
         *
         * owner può essere:
         *
         * - MainDashboardForm quando arriviamo
         *   dalla Dashboard;
         *
         * - null quando arriviamo direttamente
         *   dalla Ribbon di Inventor.
         */
        private static bool ShowSettings(
            Form? owner,
            RuleSettingsService settingsService,
            bool isDarkTheme,
            bool forcePathEditing)
        {
            try
            {
                using var settingsForm =
                    new RegoleProgettazioneSettingsForm(
                        settingsService,
                        isDarkTheme,
                        forcePathEditing);

                DialogResult result;

                if (owner != null &&
                    !owner.IsDisposed)
                {
                    result =
                        settingsForm.ShowDialog(
                            owner);
                }
                else
                {
                    result =
                        settingsForm.ShowDialog();
                }

                return
                    result ==
                        DialogResult.OK &&
                    settingsForm.SettingsChanged;
            }
            catch (Exception ex)
            {
                ShowMessage(
                    owner,
                    "Non è stato possibile aprire le Impostazioni di Regole di progettazione.\r\n\r\n" +
                    ex.Message,
                    "Regole di progettazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return false;
            }
        }

        /*
         * ==========================================
         * MESSAGE BOX CON OWNER OPZIONALE
         * ==========================================
         *
         * Ci permette di usare lo stesso Launcher
         * sia dalla Dashboard sia dalla Ribbon.
         */
        private static DialogResult ShowMessage(
            Form? owner,
            string message,
            string title,
            MessageBoxButtons buttons,
            MessageBoxIcon icon)
        {
            if (owner != null &&
                !owner.IsDisposed)
            {
                return MessageBox.Show(
                    owner,
                    message,
                    title,
                    buttons,
                    icon);
            }

            return MessageBox.Show(
                message,
                title,
                buttons,
                icon);
        }

        /*
         * ==========================================
         * CHIUSURA FEATURE
         * ==========================================
         */
        private static void CurrentForm_FormClosed(
            object? sender,
            FormClosedEventArgs e)
        {
            if (_currentForm != null)
            {
                _currentForm.FormClosed -=
                    CurrentForm_FormClosed;
            }

            _currentForm =
                null;

            /*
             * RegoleProgettazioneForm si occupa già
             * della corretta chiusura/liberazione
             * dell'eventuale richiesta TXT.
             *
             * Qui togliamo soltanto il riferimento.
             */
            _externalChangesService =
                null;
        }
    }
}