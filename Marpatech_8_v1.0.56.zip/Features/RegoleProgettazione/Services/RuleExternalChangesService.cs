﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public sealed class RuleExternalChangesService :
        IDisposable
    {
        public const string RequestFileName =
            "File per aggiunta modifiche.txt";

        public const string ClaimFileName =
            ".regole_progettazione_external_changes.lock";

        private FileStream?
            _claimStream;

        private Process?
            _openedNotepadProcess;

        public string RequestFilePath
        {
            get;
            private set;
        } = string.Empty;

        public bool HasClaim =>
            _claimStream != null;

        public static string EnsureRequestFile(
            string rootPath)
        {
            if (string.IsNullOrWhiteSpace(rootPath))
            {
                throw new ArgumentException(
                    "Il percorso delle Regole di progettazione non è valido.",
                    nameof(rootPath));
            }

            if (!Directory.Exists(rootPath))
            {
                throw new DirectoryNotFoundException(
                    $"La cartella non esiste: {rootPath}");
            }

            string requestPath =
                Path.Combine(
                    rootPath,
                    RequestFileName);

            /*
             * IMPORTANTISSIMO:
             *
             * se esiste già NON viene sovrascritto,
             * troncato o modificato.
             */
            if (!File.Exists(requestPath))
            {
                using FileStream stream =
                    new FileStream(
                        requestPath,
                        FileMode.CreateNew,
                        FileAccess.Write,
                        FileShare.ReadWrite);

                stream.Flush(
                    flushToDisk: true);
            }

            return requestPath;
        }

        public static bool HasPendingChanges(
            string rootPath)
        {
            string requestPath =
                EnsureRequestFile(
                    rootPath);

            try
            {
                string content =
                    File.ReadAllText(
                        requestPath);

                /*
                 * Un file appena creato e vuoto
                 * NON genera nessun avviso.
                 */
                return
                    !string.IsNullOrWhiteSpace(
                        content);
            }
            catch
            {
                /*
                 * Se temporaneamente non riusciamo a leggerlo,
                 * non lo consideriamo automaticamente vuoto.
                 *
                 * Il Launcher potrà mostrare l'errore
                 * normalmente se necessario.
                 */
                return false;
            }
        }

        public bool TryClaim(
            string rootPath)
        {
            if (HasClaim)
                return true;

            RequestFilePath =
                EnsureRequestFile(
                    rootPath);

            string claimPath =
                Path.Combine(
                    rootPath,
                    ClaimFileName);

            try
            {
                /*
                 * FileShare.None è la vera protezione
                 * multi-PC.
                 *
                 * Il primo Addin che arriva mantiene
                 * questo stream aperto fino a quando
                 * la richiesta viene completata.
                 */
                _claimStream =
                    new FileStream(
                        claimPath,
                        FileMode.OpenOrCreate,
                        FileAccess.ReadWrite,
                        FileShare.None);

                _claimStream.SetLength(
                    0);

                string information =
                    "Computer: " +
                    Environment.MachineName +
                    Environment.NewLine +
                    "Utente: " +
                    Environment.UserName +
                    Environment.NewLine +
                    "Presa in carico: " +
                    DateTime.Now.ToString(
                        "yyyy-MM-dd HH:mm:ss");

                byte[] bytes =
                    Encoding.UTF8.GetBytes(
                        information);

                _claimStream.Write(
                    bytes,
                    0,
                    bytes.Length);

                _claimStream.Flush(
                    flushToDisk: true);

                return true;
            }
            catch (IOException)
            {
                ReleaseClaim();

                return false;
            }
            catch
            {
                ReleaseClaim();

                return false;
            }
        }

        public void OpenRequestFile()
        {
            if (!HasClaim)
                return;

            if (string.IsNullOrWhiteSpace(
                    RequestFilePath) ||
                !File.Exists(
                    RequestFilePath))
            {
                return;
            }

            /*
             * Usiamo esplicitamente Blocco note.
             *
             * Il file rimane modificabile normalmente
             * anche fuori dall'Addin.
             */
            var startInfo =
                new ProcessStartInfo
                {
                    FileName =
                        "notepad.exe",

                    Arguments =
                        "\"" +
                        RequestFilePath +
                        "\"",

                    UseShellExecute =
                        true
                };

            try
            {
                _openedNotepadProcess =
                    Process.Start(
                        startInfo);
            }
            catch
            {
                _openedNotepadProcess =
                    null;

                /*
                 * Fallback:
                 * Windows apre il TXT con l'app associata.
                 */
                Process.Start(
                    new ProcessStartInfo
                    {
                        FileName =
                            RequestFilePath,

                        UseShellExecute =
                            true
                    });
            }
        }

        public void CompleteRequest()
        {
            if (!HasClaim)
                return;

            /*
             * 1. Proviamo a chiudere il Blocco note
             * aperto da questa sessione.
             */
            CloseOpenedEditor();

            /*
             * 2. Eliminiamo il vecchio TXT.
             */
            if (!string.IsNullOrWhiteSpace(
                    RequestFilePath) &&
                File.Exists(
                    RequestFilePath))
            {
                File.Delete(
                    RequestFilePath);
            }

            /*
             * 3. Ricreiamo immediatamente un TXT
             * completamente vuoto con lo stesso nome.
             */
            if (!string.IsNullOrWhiteSpace(
                    RequestFilePath))
            {
                using FileStream stream =
                    new FileStream(
                        RequestFilePath,
                        FileMode.CreateNew,
                        FileAccess.Write,
                        FileShare.ReadWrite);

                stream.Flush(
                    flushToDisk: true);
            }

            /*
             * 4. Solo alla fine liberiamo la presa
             * in carico per gli altri PC.
             */
            ReleaseClaim();
        }

        public void CancelRequestHandling()
        {
            /*
             * Se l'utente chiude Regole di progettazione
             * SENZA completare il salvataggio:
             *
             * - NON cancelliamo il TXT;
             * - NON svuotiamo il TXT;
             * - chiudiamo soltanto l'editor eventualmente
             *   aperto da questa sessione;
             * - liberiamo il claim.
             *
             * Al prossimo avvio un altro PC potrà
             * prenderlo nuovamente in carico.
             */
            CloseOpenedEditor();

            ReleaseClaim();
        }

        private void CloseOpenedEditor()
        {
            if (_openedNotepadProcess == null)
                return;

            try
            {
                if (!_openedNotepadProcess.HasExited)
                {
                    _openedNotepadProcess.CloseMainWindow();

                    _openedNotepadProcess.WaitForExit(
                        1500);
                }
            }
            catch
            {
            }
            finally
            {
                try
                {
                    _openedNotepadProcess.Dispose();
                }
                catch
                {
                }

                _openedNotepadProcess =
                    null;
            }
        }

        private void ReleaseClaim()
        {
            string claimPath =
                string.Empty;

            if (!string.IsNullOrWhiteSpace(
                    RequestFilePath))
            {
                string? directory =
                    Path.GetDirectoryName(
                        RequestFilePath);

                if (!string.IsNullOrWhiteSpace(
                        directory))
                {
                    claimPath =
                        Path.Combine(
                            directory,
                            ClaimFileName);
                }
            }

            try
            {
                _claimStream?.Dispose();
            }
            catch
            {
            }

            _claimStream =
                null;

            /*
             * Il vero lock era lo stream FileShare.None.
             * Il file fisico può essere eliminato.
             */
            if (!string.IsNullOrWhiteSpace(
                    claimPath))
            {
                try
                {
                    if (File.Exists(
                            claimPath))
                    {
                        File.Delete(
                            claimPath);
                    }
                }
                catch
                {
                }
            }
        }

        public void Dispose()
        {
            CancelRequestHandling();
        }
    }
}