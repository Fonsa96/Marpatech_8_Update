﻿using System;
using System.IO;
using System.Text;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public sealed class RuleSaveLockService :
        IDisposable
    {
        private const string LockFileName =
            ".regole_progettazione_save.lock";

        private FileStream?
            _lockStream;

        private string
            _lockFilePath = string.Empty;

        public bool IsLocked =>
            _lockStream != null;

        public bool TryAcquire(
            string rootPath,
            out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (string.IsNullOrWhiteSpace(
                    rootPath))
            {
                errorMessage =
                    "Il percorso delle Regole di progettazione non è impostato.";

                return false;
            }

            if (!Directory.Exists(
                    rootPath))
            {
                errorMessage =
                    "La cartella delle Regole di progettazione non è disponibile.";

                return false;
            }

            _lockFilePath =
                Path.Combine(
                    rootPath,
                    LockFileName);

            try
            {
                /*
                 * FileShare.None è il vero lock.
                 *
                 * Anche se due PC tentano il salvataggio
                 * nello stesso istante, solamente uno
                 * riuscirà ad aprire questo file.
                 */
                _lockStream =
                    new FileStream(
                        _lockFilePath,
                        FileMode.OpenOrCreate,
                        FileAccess.ReadWrite,
                        FileShare.None);

                _lockStream.SetLength(
                    0);

                string information =
                    "Computer: " +
                    Environment.MachineName +
                    Environment.NewLine +
                    "Utente: " +
                    Environment.UserName +
                    Environment.NewLine +
                    "Data: " +
                    DateTime.Now.ToString(
                        "yyyy-MM-dd HH:mm:ss");

                byte[] bytes =
                    Encoding.UTF8.GetBytes(
                        information);

                _lockStream.Write(
                    bytes,
                    0,
                    bytes.Length);

                _lockStream.Flush(
                    flushToDisk: true);

                return true;
            }
            catch (IOException)
            {
                errorMessage =
                    "È già in corso un salvataggio delle Regole di progettazione da parte di un altro utente.\r\n\r\n" +
                    "Attendi qualche secondo e riprova.";

                Release();

                return false;
            }
            catch (UnauthorizedAccessException)
            {
                errorMessage =
                    "Non è possibile creare il lock di salvataggio nella cartella aziendale.\r\n\r\n" +
                    "Verifica i permessi di scrittura.";

                Release();

                return false;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Non è stato possibile iniziare il salvataggio.\r\n\r\n" +
                    ex.Message;

                Release();

                return false;
            }
        }

        public void Dispose()
        {
            Release();
        }

        private void Release()
        {
            try
            {
                _lockStream?.Dispose();
            }
            catch
            {
            }

            _lockStream =
                null;

            /*
             * La sicurezza non dipende dall'esistenza
             * del file, ma dal FileShare.None.
             *
             * Proviamo comunque a rimuoverlo quando
             * il salvataggio termina.
             */
            if (string.IsNullOrWhiteSpace(
                    _lockFilePath))
            {
                return;
            }

            try
            {
                if (File.Exists(
                        _lockFilePath))
                {
                    File.Delete(
                        _lockFilePath);
                }
            }
            catch
            {
                /*
                 * Non è un problema grave:
                 * se il file rimane ma nessuno lo tiene
                 * aperto, un altro PC potrà comunque
                 * acquisire normalmente il lock.
                 */
            }
        }
    }
}