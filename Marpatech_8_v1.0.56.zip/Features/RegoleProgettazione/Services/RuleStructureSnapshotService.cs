﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public static class RuleStructureSnapshotService
    {
        private const string LockFileName =
            ".regole_progettazione_save.lock";

        public static string CreateSnapshot(
            string rootPath)
        {
            if (string.IsNullOrWhiteSpace(
                    rootPath) ||
                !Directory.Exists(
                    rootPath))
            {
                return string.Empty;
            }

            var entries =
                new List<string>();

            BuildSnapshotRecursive(
                rootPath,
                rootPath,
                entries);

            entries.Sort(
                StringComparer.OrdinalIgnoreCase);

            string joined =
                string.Join(
                    "\n",
                    entries);

            using SHA256 sha256 =
                SHA256.Create();

            byte[] bytes =
                Encoding.UTF8.GetBytes(
                    joined);

            byte[] hash =
                sha256.ComputeHash(
                    bytes);

            return Convert.ToHexString(
                hash);
        }

        private static void BuildSnapshotRecursive(
            string rootPath,
            string currentPath,
            List<string> entries)
        {
            foreach (string directory
                     in Directory
                         .EnumerateDirectories(
                             currentPath)
                         .OrderBy(
                             x => x,
                             StringComparer.OrdinalIgnoreCase))
            {
                string name =
                    Path.GetFileName(
                        directory);

                /*
                 * Eventuali elementi tecnici
                 * non fanno parte delle regole.
                 */
                if (name.StartsWith(
                        ".rp_tmp_",
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                string relativePath =
                    Path.GetRelativePath(
                        rootPath,
                        directory);

                entries.Add(
                    "D|" +
                    relativePath);

                BuildSnapshotRecursive(
                    rootPath,
                    directory,
                    entries);
            }

            foreach (string file
                     in Directory
                         .EnumerateFiles(
                             currentPath)
                         .OrderBy(
                             x => x,
                             StringComparer.OrdinalIgnoreCase))
            {
                string fileName =
                    Path.GetFileName(
                        file);
                /*
                 * File tecnici che NON fanno parte
                 * della struttura delle Regole.
                 */
                if (string.Equals(
                        fileName,
                        LockFileName,
                        StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(
                        fileName,
                        RuleExternalChangesService.RequestFileName,
                        StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(
                        fileName,
                        RuleExternalChangesService.ClaimFileName,
                        StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(
                        fileName,
                        RuleEditReservationService.ReservationFileName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                string relativePath =
                    Path.GetRelativePath(
                        rootPath,
                        file);

                FileInfo info =
                    new FileInfo(
                        file);

                entries.Add(
                    "F|" +
                    relativePath +
                    "|" +
                    info.Length +
                    "|" +
                    info.LastWriteTimeUtc.Ticks);
            }
        }
    }
}