﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Marpatech_8.Features.RegoleProgettazione.Models;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public class RuleFileSystemService
    {
        public const string ContentFileName =
            "contenuto.html";

        public async Task<List<RuleNode>> LoadAsync(
            string rootPath,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(rootPath))
            {
                throw new ArgumentException(
                    "Il percorso delle Regole di progettazione non è impostato.",
                    nameof(rootPath));
            }

            if (!Directory.Exists(rootPath))
            {
                throw new DirectoryNotFoundException(
                    $"La cartella delle Regole di progettazione non esiste:\n{rootPath}");
            }

            return await Task.Run(
                () => LoadLevel(
                    rootPath,
                    parent: null,
                    cancellationToken),
                cancellationToken);
        }

        private List<RuleNode> LoadLevel(
            string directoryPath,
            RuleNode? parent,
            CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var nodes =
                new List<RuleNode>();

            IEnumerable<string> directories;

            try
            {
                directories =
                    Directory.EnumerateDirectories(
                        directoryPath);
            }
            catch (UnauthorizedAccessException)
            {
                return nodes;
            }

            foreach (string directory in directories)
            {
                cancellationToken.ThrowIfCancellationRequested();

                string folderName =
                    Path.GetFileName(directory);

                if (!RuleFolderNameService.TryParse(
                        folderName,
                        out int order,
                        out RuleNodeType nodeType,
                        out string title))
                {
                    /*
                     * Una normale cartella non riconosciuta
                     * non viene visualizzata come regola.
                     */
                    continue;
                }

                var node = new RuleNode
                {
                    NodeType = nodeType,
                    Title = title,
                    Order = order,
                    OriginalPath = directory,
                    OriginalFolderName = folderName,
                    Parent = parent,
                    State = RuleNodeState.Unchanged,
                    IsExpanded = true
                };

                /*
                 * Importante:
                 * l'assegnazione Title durante la costruzione
                 * potrebbe chiamare MarkModified().
                 *
                 * Reimpostiamo quindi esplicitamente lo stato
                 * a Unchanged dopo aver caricato il nodo.
                 */
                node.State =
                    RuleNodeState.Unchanged;

                if (node.IsParagraph)
                {
                    List<RuleNode> children =
                        LoadLevel(
                            directory,
                            node,
                            cancellationToken);

                    foreach (RuleNode child in
                             children.OrderBy(x => x.Order))
                    {
                        node.Children.Add(child);
                    }
                }
                else
                {
                    LoadTextNode(
                        node,
                        directory,
                        cancellationToken);
                }

                nodes.Add(node);
            }

            return nodes
                .OrderBy(x => x.Order)
                .ToList();
        }

        private void LoadTextNode(
            RuleNode node,
            string directoryPath,
            CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            string contentPath =
                Path.Combine(
                    directoryPath,
                    ContentFileName);

            if (File.Exists(contentPath))
            {
                string content =
                    File.ReadAllText(contentPath);

                node.HtmlContent =
                    content;

                node.OriginalHtmlContent =
                    content;

                node.OriginalContentLastWriteTimeUtc =
                    File.GetLastWriteTimeUtc(
                        contentPath);

                node.State =
                    RuleNodeState.Unchanged;
            }
            else
            {
                node.HtmlContent =
                    string.Empty;

                node.OriginalHtmlContent =
                    string.Empty;

                node.OriginalContentLastWriteTimeUtc =
                    null;

                node.State =
                    RuleNodeState.Unchanged;
            }

            IEnumerable<string> files =
                Directory.EnumerateFiles(
                    directoryPath);

            foreach (string file in files)
            {
                cancellationToken.ThrowIfCancellationRequested();

                string fileName =
                    Path.GetFileName(file);

                if (string.Equals(
                        fileName,
                        ContentFileName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                node.Attachments.Add(
                    new RuleAttachment
                    {
                        FileName = fileName,
                        OriginalPath = file,
                        State = RuleNodeState.Unchanged
                    });
            }
        }
    }
}