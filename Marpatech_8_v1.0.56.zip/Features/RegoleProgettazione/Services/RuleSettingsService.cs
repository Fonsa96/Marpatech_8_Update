﻿using Marpatech_8.Features.RegoleProgettazione.Models;
using System;
using System.IO;
using System.Text.Json;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public class RuleSettingsService
    {
        private const string SettingsFolderName =
            "RegoleProgettazione";

        private const string SettingsFileName =
            "settings.json";

        public string SettingsFilePath
        {
            get
            {
                string basePath =
                    Environment.GetFolderPath(
                        Environment.SpecialFolder.LocalApplicationData);

                return Path.Combine(
                    basePath,
                    "Marpatech_8",
                    SettingsFolderName,
                    SettingsFileName);
            }
        }

        public RuleSettings Load()
        {
            try
            {
                if (!File.Exists(SettingsFilePath))
                {
                    return new RuleSettings();
                }

                string json =
                    File.ReadAllText(
                        SettingsFilePath);

                RuleSettings? settings =
                    JsonSerializer.Deserialize<RuleSettings>(
                        json);

                return settings ??
                       new RuleSettings();
            }
            catch
            {
                /*
                 * Se il file configurazione fosse corrotto,
                 * non blocchiamo l'intero Addin.
                 */
                return new RuleSettings();
            }
        }

        public void Save(
            RuleSettings settings)
        {
            if (settings == null)
            {
                throw new ArgumentNullException(
                    nameof(settings));
            }

            string? directory =
                Path.GetDirectoryName(
                    SettingsFilePath);

            if (string.IsNullOrWhiteSpace(directory))
            {
                throw new InvalidOperationException(
                    "Impossibile determinare la cartella delle impostazioni.");
            }

            Directory.CreateDirectory(
                directory);

            var options =
                new JsonSerializerOptions
                {
                    WriteIndented = true
                };

            string json =
                JsonSerializer.Serialize(
                    settings,
                    options);

            File.WriteAllText(
                SettingsFilePath,
                json);
        }
    }
}