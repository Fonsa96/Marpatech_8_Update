﻿using System;
using System.IO;
using System.Text;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public sealed class RuleEditReservationService :
        IDisposable
    {
        public const string ReservationFileName =
            ".regole_progettazione_edit.lock";

        private FileStream?
            _reservationStream;

        private string
            _reservationFilePath =
                string.Empty;

        public bool HasReservation =>
            _reservationStream != null;

        public bool TryAcquire(
            string rootPath,
            out string errorMessage)
        {
            errorMessage =
                string.Empty;

            if (string.IsNullOrWhiteSpace(
                    rootPath))
            {
                errorMessage =
                    "Il percorso delle Regole di progettazione non è impostato.";

                return false;
            }

            if (!Directory.Exists(
                    rootPath))
            {
                errorMessage =
                    "La cartella delle Regole di progettazione non è disponibile.";

                return false;
            }

            _reservationFilePath =
                Path.Combine(
                    rootPath,
                    ReservationFileName);

            try
            {
                /*
                 * La riserva rimane fisicamente
                 * aperta fino alla chiusura della funzione.
                 *
                 * FileShare.Read permette eventualmente
                 * di leggere il contenuto diagnostico,
                 * ma impedisce ad un altro PC di aprire
                 * lo stesso file in ReadWrite.
                 */
                _reservationStream =
                    new FileStream(
                        _reservationFilePath,
                        FileMode.OpenOrCreate,
                        FileAccess.ReadWrite,
                        FileShare.Read);

                _reservationStream.SetLength(
                    0);

                string information =
                    "RISERVA REGOLE DI PROGETTAZIONE" +
                    Environment.NewLine +
                    Environment.NewLine +
                    "Computer: " +
                    Environment.MachineName +
                    Environment.NewLine +
                    "Utente: " +
                    Environment.UserName +
                    Environment.NewLine +
                    "Data: " +
                    DateTime.Now.ToString(
                        "yyyy-MM-dd HH:mm:ss");

                byte[] bytes =
                    Encoding.UTF8.GetBytes(
                        information);

                _reservationStream.Write(
                    bytes,
                    0,
                    bytes.Length);

                _reservationStream.Flush(
                    flushToDisk: true);

                return true;
            }
            catch (IOException)
            {
                errorMessage =
                    "Le Regole di progettazione sono già riservate da un altro utente.";

                Release();

                return false;
            }
            catch (UnauthorizedAccessException)
            {
                errorMessage =
                    "Non è possibile creare la riserva delle Regole di progettazione.\r\n\r\n" +
                    "Verifica i permessi di scrittura.";

                Release();

                return false;
            }
            catch (Exception ex)
            {
                errorMessage =
                    "Non è stato possibile riservare le Regole di progettazione.\r\n\r\n" +
                    ex.Message;

                Release();

                return false;
            }
        }

        public void Dispose()
        {
            Release();
        }

        private void Release()
        {
            try
            {
                _reservationStream?.Dispose();
            }
            catch
            {
            }

            _reservationStream =
                null;

            if (string.IsNullOrWhiteSpace(
                    _reservationFilePath))
            {
                return;
            }

            try
            {
                if (File.Exists(
                        _reservationFilePath))
                {
                    File.Delete(
                        _reservationFilePath);
                }
            }
            catch
            {
                /*
                 * Un file rimasto fisicamente sul disco
                 * NON significa che esista ancora la riserva.
                 *
                 * La vera riserva è il FileStream aperto.
                 */
            }
        }
    }
}