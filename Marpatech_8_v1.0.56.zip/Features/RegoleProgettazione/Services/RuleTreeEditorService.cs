﻿using System.Collections.ObjectModel;
using System.Linq;
using Marpatech_8.Features.RegoleProgettazione.Models;

namespace Marpatech_8.Features.RegoleProgettazione.Services
{
    public class RuleTreeEditorService
    {
        public RuleNode AddParagraph(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode? selectedNode)
        {
            var newParagraph = new RuleNode
            {
                NodeType = RuleNodeType.Paragraph,
                Title = "Nuovo paragrafo",
                IsExpanded = true,
                State = RuleNodeState.Added
            };

            /*
             * Nessuna selezione:
             * nuovo paragrafo alla radice come ultimo elemento.
             */
            if (selectedNode == null)
            {
                newParagraph.Parent = null;
                newParagraph.Order = GetNextOrder(rootNodes);

                rootNodes.Add(newParagraph);

                return newParagraph;
            }

            /*
             * PARAGRAFO SELEZIONATO:
             *
             * nuovo paragrafo DENTRO il paragrafo
             * selezionato, sempre come ULTIMO elemento.
             */
            if (selectedNode.IsParagraph)
            {
                newParagraph.Parent = selectedNode;

                newParagraph.Order =
                    GetNextOrder(selectedNode.Children);

                selectedNode.Children.Add(newParagraph);

                /*
                 * Lo apriamo automaticamente così
                 * il nuovo elemento è subito visibile.
                 */
                selectedNode.IsExpanded = true;

                return newParagraph;
            }

            /*
             * TESTO SELEZIONATO:
             *
             * nuovo paragrafo nello stesso contenitore
             * del testo, ma SEMPRE come ultimo elemento.
             */
            RuleNode? parent = selectedNode.Parent;

            if (parent != null)
            {
                newParagraph.Parent = parent;

                newParagraph.Order =
                    GetNextOrder(parent.Children);

                parent.Children.Add(newParagraph);

                parent.IsExpanded = true;

                return newParagraph;
            }

            /*
             * Eventuale testo alla radice.
             */
            newParagraph.Parent = null;
            newParagraph.Order = GetNextOrder(rootNodes);

            rootNodes.Add(newParagraph);

            return newParagraph;
        }

        public RuleNode AddText(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode? selectedNode)
        {
            var newText = new RuleNode
            {
                NodeType = RuleNodeType.Text,
                Title = "Nuovo testo",
                HtmlContent = string.Empty,
                State = RuleNodeState.Added
            };

            /*
             * Nessuna selezione:
             * testo alla radice.
             */
            if (selectedNode == null)
            {
                newText.Parent = null;
                newText.Order = GetNextOrder(rootNodes);

                rootNodes.Add(newText);

                return newText;
            }

            /*
             * PARAGRAFO SELEZIONATO:
             *
             * nuovo testo dentro il paragrafo
             * come ultimo elemento.
             */
            if (selectedNode.IsParagraph)
            {
                newText.Parent = selectedNode;

                newText.Order =
                    GetNextOrder(selectedNode.Children);

                selectedNode.Children.Add(newText);

                selectedNode.IsExpanded = true;

                return newText;
            }

            /*
             * TESTO SELEZIONATO:
             *
             * nuovo testo IMMEDIATAMENTE SOTTO
             * il testo selezionato.
             */
            RuleNode? parent = selectedNode.Parent;

            if (parent != null)
            {
                int selectedIndex =
                    parent.Children.IndexOf(selectedNode);

                int insertIndex =
                    selectedIndex + 1;

                newText.Parent = parent;

                parent.Children.Insert(
                    insertIndex,
                    newText);

                RecalculateOrder(parent.Children);

                parent.IsExpanded = true;

                return newText;
            }

            /*
             * Testo alla radice:
             * inserimento immediatamente sotto.
             */
            int rootIndex =
                rootNodes.IndexOf(selectedNode);

            rootNodes.Insert(
                rootIndex + 1,
                newText);

            RecalculateOrder(rootNodes);

            return newText;
        }

        public bool MoveUp(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode selectedNode)
        {
            ObservableCollection<RuleNode> collection =
                GetCollection(rootNodes, selectedNode);

            int currentIndex =
                collection.IndexOf(selectedNode);

            if (currentIndex <= 0)
                return false;

            collection.Move(
                currentIndex,
                currentIndex - 1);

            RecalculateOrder(collection);

            return true;
        }

        public bool MoveDown(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode selectedNode)
        {
            ObservableCollection<RuleNode> collection =
                GetCollection(rootNodes, selectedNode);

            int currentIndex =
                collection.IndexOf(selectedNode);

            if (currentIndex < 0 ||
                currentIndex >= collection.Count - 1)
            {
                return false;
            }

            collection.Move(
                currentIndex,
                currentIndex + 1);

            RecalculateOrder(collection);

            return true;
        }

        /// <summary>
        /// Rimuove il nodo solamente dalla struttura visualizzata.
        ///
        /// NON cancella nulla dal filesystem.
        ///
        /// Restituisce true se l'elemento deve essere conservato
        /// tra gli elementi da cancellare al prossimo salvataggio.
        /// </summary>
        public bool RemoveNode(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode selectedNode)
        {
            ObservableCollection<RuleNode> collection =
                GetCollection(rootNodes, selectedNode);

            /*
             * Se il nodo esisteva già quando abbiamo aperto
             * la funzione, dovremo cancellarlo realmente
             * solo con Salva Modifiche.
             */
            bool mustDeleteFromDisk =
                selectedNode.State != RuleNodeState.Added;

            collection.Remove(selectedNode);

            RecalculateOrder(collection);

            return mustDeleteFromDisk;
        }

        private static ObservableCollection<RuleNode> GetCollection(
            ObservableCollection<RuleNode> rootNodes,
            RuleNode node)
        {
            if (node.Parent == null)
                return rootNodes;

            return node.Parent.Children;
        }

        private static int GetNextOrder(
            ObservableCollection<RuleNode> nodes)
        {
            if (nodes.Count == 0)
                return 1;

            return nodes.Max(x => x.Order) + 1;
        }

        private static void RecalculateOrder(
            ObservableCollection<RuleNode> nodes)
        {
            for (int index = 0;
                 index < nodes.Count;
                 index++)
            {
                RuleNode node = nodes[index];

                int newOrder = index + 1;

                if (node.Order == newOrder)
                    continue;

                node.Order = newOrder;

                node.MarkMoved();
            }
        }
    }
}