﻿using System.Collections.Generic;
using Marpatech_8.Features.Mail.Config;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailTemplateService
    {
        public static string ApplyVariables(
            string template,
            MailSettings settings,
            Dictionary<string, string> values)
        {
            if (string.IsNullOrEmpty(template))
                return "";

            string result = template;

            foreach (MailVariableConfig variable in settings.Variables)
            {
                string tag = "{" + variable.Name + "}";

                string value = "";

                if (values.ContainsKey(variable.Name))
                    value = values[variable.Name];

                result = result.Replace(tag, value);
            }

            return result;
        }

        public static string RemoveLinkTag(string text)
        {
            if (string.IsNullOrEmpty(text))
                return "";

            return text.Replace("{LINK}", "").Trim();
        }
    }
}
