﻿using System.Collections.Generic;
using Inventor;
using Marpatech_8.Features.Mail.Config;
using InventorApplication = Inventor.Application;
using Marpatech_8.Features.Core.Inventor;


namespace Marpatech_8.Features.Mail.Services
{
    public static class MailInventorService
    {
        public static Document? GetActiveDocument(InventorApplication inventorApp)
        {
            return InventorService.GetActiveDocument(inventorApp);
        }

        public static Dictionary<string, string> ReadVariableValues(
            Document document,
            MailSettings settings)
        {
            Dictionary<string, string> values = new Dictionary<string, string>();

            foreach (MailVariableConfig variable in settings.Variables)
            {
                string value = ReadIProperty(document, variable.IPropertyName);
                values[variable.Name] = value;
            }

            return values;
        }

        public static string ReadIProperty(Document document, string propertyName)
        {
            return InventorService.ReadIProperty(document, propertyName);
        }

        public static bool RunMultiReleaseCommand(
    Inventor.Application inventorApp)
        {
            try
            {
                ControlDefinition? control =
                    inventorApp.CommandManager.ControlDefinitions[
                        "DEDNETINV_RIL_MULTI"] as ControlDefinition;

                if (control == null)
                {
                    MailDialogService.Warning(
                        "Comando DEDNETINV_RIL_MULTI non trovato.",
                        "Invio Mail");

                    return false;
                }

                control.Execute();

                return true;
            }
            catch (Exception ex)
            {
                MailDialogService.Error(
                    "Errore durante il rilascio multiplo.\n\n" +
                    ex.Message,
                    "Invio Mail");

                return false;
            }
        }
    }
}