﻿using Marpatech_8.Features.Core.Office;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailOutlookService
    {
        public static void CreateMail(
            string to,
            string cc,
            string subject,
            string body,
            string linkPath,
            string attachmentPath)
        {
            bool ok = OutlookAutomationService.CreateMail(
                to,
                cc,
                subject,
                body,
                linkPath,
                attachmentPath,
                out string errorMessage);

            if (!ok)
            {
                MailDialogService.Error(
                    errorMessage,
                    "Invio Mail");
            }
        }
    }
}