﻿using System;
using System.IO;
using Marpatech_8.Features.Mail.Config;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailPathService
    {
        public static string BuildMailLinkPath(
     MailTypeConfig mailType,
     string searchValue)
        {
            if (string.IsNullOrWhiteSpace(mailType.BasePath))
                return "";

            if (string.IsNullOrWhiteSpace(searchValue))
                return "";

            string baseSearchPath = ResolveBaseSearchPath(
                mailType,
                searchValue);

            if (string.IsNullOrWhiteSpace(baseSearchPath))
                return "";

            if (!MailFileService.DirectoryExists(baseSearchPath))
                return "";

            string foundFolder = FindFolder(
                baseSearchPath,
                searchValue,
                mailType.FolderSearchMode);

            if (string.IsNullOrWhiteSpace(foundFolder))
                return "";

            string fullPath = CombinePath(foundFolder, mailType.FinalPath);

            if (MailFileService.DirectoryExists(fullPath))
                return fullPath;

            bool useFoundFolder = MailDialogService.Confirm(
                "Percorso precompilato completo non trovato.\n\n" +
                "Vuoi inserire il percorso trovato?\n\n" +
                foundFolder,
                "Percorso non trovato",
                null);

            if (useFoundFolder)
                return foundFolder;

            return "";
        }

        public static string BuildExcelSearchPath(
            MailTypeConfig mailType,
            string searchValue)
        {
            if (string.IsNullOrWhiteSpace(mailType.BasePath))
                return "";

            if (string.IsNullOrWhiteSpace(searchValue))
                return "";

            if (!MailFileService.DirectoryExists(mailType.BasePath))
                return "";

            string foundFolder = FindFolder(
                mailType.BasePath,
                searchValue,
                mailType.FolderSearchMode);

            if (string.IsNullOrWhiteSpace(foundFolder))
                return "";

            string excelPath = CombinePath(
                foundFolder,
                mailType.ExcelFinalPath);

            if (MailFileService.DirectoryExists(excelPath))
                return excelPath;

            return foundFolder;
        }

        private static string FindFolder(
            string basePath,
            string searchValue,
            string searchMode)
        {
            try
            {
                foreach (string directory in MailFileService.GetDirectories(
                    basePath,
                    "*",
                    SearchOption.TopDirectoryOnly))
                {
                    string folderName = Path.GetFileName(directory);

                    if (IsMatch(folderName, searchValue, searchMode))
                        return directory;
                }
            }
            catch
            {
            }

            return "";
        }

        private static bool IsMatch(
            string folderName,
            string searchValue,
            string searchMode)
        {
            if (string.Equals(searchMode, "Contiene", StringComparison.OrdinalIgnoreCase))
            {
                return folderName.Contains(
                    searchValue,
                    StringComparison.OrdinalIgnoreCase);
            }

            if (string.Equals(searchMode, "Uguale a", StringComparison.OrdinalIgnoreCase))
            {
                return string.Equals(
                    folderName,
                    searchValue,
                    StringComparison.OrdinalIgnoreCase);
            }

            return folderName.StartsWith(
                searchValue,
                StringComparison.OrdinalIgnoreCase);
        }

        private static string CombinePath(string basePath, string finalPath)
        {
            if (string.IsNullOrWhiteSpace(finalPath))
                return basePath;

            string cleanedFinalPath = finalPath.TrimStart('\\', '/');

            return Path.Combine(basePath, cleanedFinalPath);
        }
        private static string ResolveBaseSearchPath(
    MailTypeConfig mailType,
    string searchValue)
        {
            string basePath = mailType.BasePath;

            if (!mailType.UseYearSubFolder)
                return basePath;

            string year = ExtractYearFromCommessa(searchValue);

            if (string.IsNullOrWhiteSpace(year))
                return basePath;

            return Path.Combine(basePath, year);
        }

        private static string ExtractYearFromCommessa(string commessa)
        {
            if (string.IsNullOrWhiteSpace(commessa))
                return "";

            if (commessa.Length < 5)
                return "";

            string yearDigits = commessa.Substring(3, 2);

            if (!int.TryParse(yearDigits, out _))
                return "";

            return "20" + yearDigits;
        }
    }
}