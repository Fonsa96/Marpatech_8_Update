﻿using System;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.Mail.Config;
using Marpatech_8.Features.Mail.Services;
using Marpatech_8.Features.Core.Settings;
using CoreWindowSettings = Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.Mail.Forms
{
    public class MailVariablesForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly MailSettings _settings;
        private readonly CoreWindowSettings _windowSettings;


        private ListBox? lstVariables;
        private TextBox? txtName;
        private TextBox? txtIPropertyName;
        private TextBox? txtSearch;

        public MailVariablesForm(bool isDarkTheme, MailSettings settings)
        {
            _isDarkTheme = isDarkTheme;
            _settings = settings;
            _windowSettings = WindowSettingsService.Load(
                "MailVariables",
                760,
                520);

            InitializeComponent();
            WindowSettingsService.Apply(
                this,
                _windowSettings);
            ReloadVariables();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor inputBackColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            DrawingColor inputForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            this.Text = "Variabili disponibili";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(760, 520);
            this.MinimumSize = new DrawingSize(800, 520);
            this.BackColor = backgroundColor;
            this.FormClosing += MailVariablesForm_FormClosing;

            Label title = new Label();
            title.Text = "Variabili disponibili";
            title.Font = new DrawingFont("Segoe UI", 24, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);
            txtSearch = CreateTextBox(inputBackColor, inputForeColor);
            txtSearch.Location = new DrawingPoint(35, 118);
            txtSearch.Width = 310;
            txtSearch.PlaceholderText = "Cerca variabile...";
            txtSearch.TextChanged += (s, e) => ReloadVariables();

            Panel card = new Panel();
            card.Location = new DrawingPoint(30, 165);
            card.Size = new DrawingSize(this.ClientSize.Width - 60, this.ClientSize.Height - 205);
            card.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            card.BackColor = cardColor;
            card.Padding = new Padding(18);

            lstVariables = new ListBox();
            lstVariables.Location = new DrawingPoint(18, 18);
            lstVariables.Size = new DrawingSize(310, card.Height - 36);
            lstVariables.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstVariables.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            lstVariables.BackColor = inputBackColor;
            lstVariables.ForeColor = inputForeColor;
            lstVariables.SelectedIndexChanged += LstVariables_SelectedIndexChanged;
            lstVariables.DoubleClick += LstVariables_SelectedIndexChanged;

            Label lblName = CreateLabel("Nome Tag", titleColor);
            lblName.Location = new DrawingPoint(355, 20);

            txtName = CreateTextBox(inputBackColor, inputForeColor);
            txtName.Location = new DrawingPoint(355, 48);

            Label lblIProp = CreateLabel("Nome iProperty Inventor", titleColor);
            lblIProp.Location = new DrawingPoint(355, 95);

            txtIPropertyName = CreateTextBox(inputBackColor, inputForeColor);
            txtIPropertyName.Location = new DrawingPoint(355, 123);

            Button btnAdd = CreateButton("Aggiungi", DrawingColor.FromArgb(37, 99, 235));
            btnAdd.Location = new DrawingPoint(355, 180);
            btnAdd.Click += BtnAdd_Click;

            Button btnUpdate = CreateButton("Modifica", DrawingColor.FromArgb(245, 158, 11));
            btnUpdate.Location = new DrawingPoint(475, 180);
            btnUpdate.Click += BtnUpdate_Click;

            Button btnDelete = CreateButton("Elimina", DrawingColor.FromArgb(220, 38, 38));
            btnDelete.Location = new DrawingPoint(595, 180);
            btnDelete.Click += BtnDelete_Click;

            Button btnClose = CreateButton("Chiudi", DrawingColor.FromArgb(100, 116, 139));
            btnClose.Location = new DrawingPoint(595, card.Height - 52);
            btnClose.Anchor = AnchorStyles.Right | AnchorStyles.Bottom;
            btnClose.Click += (s, e) => this.Close();

            card.Controls.Add(lstVariables);
            card.Controls.Add(lblName);
            card.Controls.Add(txtName);
            card.Controls.Add(lblIProp);
            card.Controls.Add(txtIPropertyName);
            card.Controls.Add(btnAdd);
            card.Controls.Add(btnUpdate);
            card.Controls.Add(btnDelete);
            card.Controls.Add(btnClose);

            this.Controls.Add(title);
            this.Controls.Add(card);
            this.Controls.Add(txtSearch);
        }

        private Label CreateLabel(string text, DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;
            return label;
        }

        private TextBox CreateTextBox(DrawingColor backColor, DrawingColor foreColor)
        {
            TextBox textBox = new TextBox();
            textBox.Size = new DrawingSize(350, 32);
            textBox.Font = new DrawingFont("Segoe UI", 10);
            textBox.BackColor = backColor;
            textBox.ForeColor = foreColor;
            textBox.BorderStyle = BorderStyle.FixedSingle;
            return textBox;
        }

        private Button CreateButton(string text, DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(105, 38);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;
            return button;
        }

        private void ReloadVariables()
        {
            if (lstVariables == null)
                return;

            string filter = txtSearch?.Text.Trim() ?? "";

            lstVariables.Items.Clear();

            foreach (MailVariableConfig variable in _settings.Variables
                .Where(v =>
                    string.IsNullOrWhiteSpace(filter) ||
                    v.Name.Contains(filter, StringComparison.OrdinalIgnoreCase) ||
                    v.IPropertyName.Contains(filter, StringComparison.OrdinalIgnoreCase))
                .OrderBy(v => v.Name))
            {
                lstVariables.Items.Add(variable.Name + "  →  " + variable.IPropertyName);
            }
        }
        private void LstVariables_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (lstVariables == null || txtName == null || txtIPropertyName == null)
                return;

            int index = lstVariables.SelectedIndex;

            if (index < 0)
                return;

            MailVariableConfig variable =
                _settings.Variables.OrderBy(v => v.Name).ElementAt(index);

            txtName.Text = variable.Name;
            txtIPropertyName.Text = variable.IPropertyName;
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (txtName == null || txtIPropertyName == null)
                return;

            string name = txtName.Text.Trim();
            string iPropertyName = txtIPropertyName.Text.Trim();

            if (name == "" || iPropertyName == "")
            {
                MailDialogService.Warning(
                    "Inserire Nome Tag e Nome iProperty.",
                    "Variabili",
                    this);
                return;
            }

            if (_settings.Variables.Any(v => string.Equals(v.Name, name, StringComparison.OrdinalIgnoreCase)))
            {
                MailDialogService.Warning(
                    "Esiste già una variabile con questo nome.",
                    "Variabili",
                    this);
                return;
            }

            _settings.Variables.Add(new MailVariableConfig
            {
                Name = name,
                IPropertyName = iPropertyName
            });

            MailSettingsService.Save(_settings);
            ReloadVariables();
            ClearFields();
        }

        private void BtnUpdate_Click(object? sender, EventArgs e)
        {
            if (lstVariables == null || txtName == null || txtIPropertyName == null)
                return;

            int index = lstVariables.SelectedIndex;

            if (index < 0)
                return;

            MailVariableConfig variable =
                _settings.Variables.OrderBy(v => v.Name).ElementAt(index);

            variable.Name = txtName.Text.Trim();
            variable.IPropertyName = txtIPropertyName.Text.Trim();

            MailSettingsService.Save(_settings);
            ReloadVariables();
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            if (lstVariables == null)
                return;

            int index = lstVariables.SelectedIndex;

            if (index < 0)
                return;

            MailVariableConfig variable =
                _settings.Variables.OrderBy(v => v.Name).ElementAt(index);

            bool confirmDelete = MailDialogService.Confirm(
                "Sei sicuro di voler eliminare questa variabile?",
                "Elimina variabile",
                this);

            if (!confirmDelete)
                return;

            _settings.Variables.Remove(variable);
            MailSettingsService.Save(_settings);
            ReloadVariables();
            ClearFields();
        }

        private void ClearFields()
        {
            if (txtName != null)
                txtName.Text = "";

            if (txtIPropertyName != null)
                txtIPropertyName.Text = "";
        }

        private void MailVariablesForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "MailVariables");
        }
    }
}