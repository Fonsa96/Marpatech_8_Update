﻿using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.Mail
{
    public class InventorWindowWrapper : IWin32Window
    {
        public IntPtr Handle { get; }

        public InventorWindowWrapper(IntPtr handle)
        {
            Handle = handle;
        }
    }
}