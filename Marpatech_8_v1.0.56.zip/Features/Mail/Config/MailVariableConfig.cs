﻿namespace Marpatech_8.Features.Mail.Config
{
    public class MailVariableConfig
    {
        public string Name { get; set; } = "";

        public string IPropertyName { get; set; } = "";
    }
}