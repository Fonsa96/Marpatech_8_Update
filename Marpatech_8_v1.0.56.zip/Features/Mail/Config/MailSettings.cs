﻿using System.Collections.Generic;

namespace Marpatech_8.Features.Mail.Config
{
    public class MailSettings
    {
        public List<MailTypeConfig> MailTypes { get; set; } = new List<MailTypeConfig>();

        public List<MailVariableConfig> Variables { get; set; } = new List<MailVariableConfig>();
    }
}