﻿using System;
using System.IO;
using Marpatech_8.Features.Mail.Services;

namespace Marpatech_8.Features.Mail.Config
{
    public static class MailSettingsService
    {
        private static string SettingsFolder
        {
            get
            {
                string appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                return Path.Combine(appData, "Marpatech", "Settings");
            }
        }

        private static string SettingsFile
        {
            get
            {
                return Path.Combine(SettingsFolder, "MailSettings.json");
            }
        }

        public static string SettingsFilePath
        {
            get
            {
                return SettingsFile;
            }
        }

        public static MailSettings Load()
        {
            try
            {
                MailFileService.EnsureDirectory(SettingsFolder);

                if (!MailFileService.FileExists(SettingsFile))
                {
                    MailSettings defaultSettings = CreateDefaultSettings();
                    Save(defaultSettings);
                    return defaultSettings;
                }

                MailSettings? settings =
                    MailJsonService.LoadFromFile<MailSettings>(
                        SettingsFile);

                return settings ?? CreateDefaultSettings();
            }
            catch
            {
                return CreateDefaultSettings();
            }
        }

        public static void Save(MailSettings settings)
        {
            try
            {
                MailFileService.EnsureDirectory(SettingsFolder);

                MailJsonService.SaveToFile(
                    SettingsFile,
                    settings);
            }
            catch
            {
                // Non blocchiamo Inventor se il salvataggio configurazione fallisce.
            }
        }

        public static string GetSettingsFilePath()
        {
            return SettingsFile;
        }

        public static void ImportFromFile(string sourceFile)
        {
            if (!MailFileService.FileExists(sourceFile))
                return;

            MailFileService.EnsureDirectory(SettingsFolder);

            MailFileService.CopyFileSafe(sourceFile, SettingsFile, true);
        }

        public static void ExportToFile(string destinationFile)
        {
            if (!MailFileService.FileExists(SettingsFile))
            {
                MailSettings defaultSettings = CreateDefaultSettings();
                Save(defaultSettings);
            }

            MailFileService.CopyFileSafe(SettingsFile, destinationFile, true);
        }

        private static MailSettings CreateDefaultSettings()
        {
            MailSettings settings = new MailSettings();

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "COMMESSA",
                IPropertyName = "COMMESSA"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CLIENTE",
                IPropertyName = "NOME CLIENTE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "DESCRIZIONE",
                IPropertyName = "DESCRIZIONE COMMESSA"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CODICE CLIENTE",
                IPropertyName = "CODICE CLIENTE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "ID",
                IPropertyName = "ID"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "CODICE",
                IPropertyName = "CODICE"
            });

            settings.Variables.Add(new MailVariableConfig
            {
                Name = "REV",
                IPropertyName = "REV"
            });

            settings.MailTypes.Add(new MailTypeConfig
            {
                Description = "Esportazione L",
                SearchPropertyName = "COMMESSA",
                FolderSearchMode = "Inizia con",
                ExcelFinalPath = "",
                FinalPath = "",
                IncludeLink = true,
                IncludeExcelAttachment = false,
                SubjectTemplate = "ESPORTAZIONE: {COMMESSA}",
                BodyTemplate = "Ciao,\r\n\r\nho esportato la commessa {COMMESSA}.\r\n\r\n{LINK}"
            });

            return settings;
        }
    }
}                                                                                                                                                                                                                   