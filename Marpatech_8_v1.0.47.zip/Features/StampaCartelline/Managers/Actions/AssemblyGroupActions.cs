﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    internal class AssemblyGroupActions
    {
    }
}
