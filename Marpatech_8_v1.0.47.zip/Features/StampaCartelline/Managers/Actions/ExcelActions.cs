﻿using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers.Actions
{
    public class ExcelActions
    {
        private readonly EditorContext _context;
        private readonly ConfigurationEditorModel _model;

        private bool _isLoading;

        private PathBasedPrintConfiguration Configuration
        {
            get
            {
                return _model.CurrentConfiguration
                    .ExcelDrawings;
            }
        }

        public ExcelActions(
            EditorContext context,
            ConfigurationEditorModel model)
        {
            _context = context;
            _model = model;
        }

        public void Load()
        {
            _isLoading = true;

            try
            {
                _context.ExcelStartPath.Text =
                    Configuration.InitialPath;

                _context.ExcelFinalPath.Text =
                    Configuration.FinalPath;

                _context.ExcelIncludeInPrint.Checked =
                    Configuration.IncludeInPrintProcess;

                ComboBoxHelper.SelectItem(
                    _context.ExcelDeterminingAttribute,
                    Configuration.DeterminingAttributeTag);
            }
            finally
            {
                _isLoading = false;
            }
        }

        public void Save()
        {
            if (_isLoading)
                return;

            Configuration.InitialPath =
                _context.ExcelStartPath.Text.Trim();

            Configuration.FinalPath =
                _context.ExcelFinalPath.Text.Trim();

            Configuration.DeterminingAttributeTag =
                _context.ExcelDeterminingAttribute
                    .SelectedItem?
                    .ToString()
                ?? string.Empty;

            Configuration.IncludeInPrintProcess =
                _context.ExcelIncludeInPrint.Checked;
        }
    }
}