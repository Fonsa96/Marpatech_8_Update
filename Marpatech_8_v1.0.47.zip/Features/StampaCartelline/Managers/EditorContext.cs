﻿using System.Collections.Generic;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class EditorContext
    {
        private readonly Dictionary<EditorAction, Button> _buttons =
            new Dictionary<EditorAction, Button>();

        public Form EditorForm { get; }

        public ListView PropertiesList { get; } =
            new ListView();

        public TextBox PropertyDisplayName { get; } =
            new TextBox();

        public TextBox PropertyInternalName { get; } =
            new TextBox();

        public CheckBox PropertyEditable { get; } =
            new CheckBox();

        public ListBox WordTemplatesList { get; } =
            new ListBox();

        public TextBox WordTemplateName { get; } =
            new TextBox();

        public TextBox WordTemplatePath { get; } =
            new TextBox();

        public DataGridView WordMappingsGrid { get; } =
            new DataGridView();

        public TextBox ExcelStartPath { get; } =
            new TextBox();

        public ComboBox ExcelDeterminingAttribute { get; } =
            new ComboBox();

        public TextBox ExcelFinalPath { get; } =
            new TextBox();

        public CheckBox ExcelIncludeInPrint { get; } =
            new CheckBox();

        public TextBox PdfStartPath { get; } =
            new TextBox();

        public ComboBox PdfDeterminingAttribute { get; } =
            new ComboBox();

        public TextBox PdfFinalPath { get; } =
            new TextBox();

        public CheckBox PdfIncludeInPrint { get; } =
            new CheckBox();

        public EditorContext(
            Form editorForm)
        {
            EditorForm = editorForm;
        }

        public void RegisterButton(
            EditorAction action,
            Button button)
        {
            _buttons[action] = button;
        }

        public IEnumerable<KeyValuePair<EditorAction, Button>>
            GetRegisteredButtons()
        {
            return _buttons;
        }

        public void RefreshDeterminingAttributes(
            IEnumerable<InventorPropertyDefinition> properties)
        {
            RefreshDeterminingAttribute(
                ExcelDeterminingAttribute,
                properties);

            RefreshDeterminingAttribute(
                PdfDeterminingAttribute,
                properties);
        }

        private void RefreshDeterminingAttribute(
            ComboBox comboBox,
            IEnumerable<InventorPropertyDefinition> properties)
        {
            string selectedValue =
                comboBox.SelectedItem?.ToString()
                ?? string.Empty;

            comboBox.BeginUpdate();

            try
            {
                comboBox.Items.Clear();

                foreach (
                    InventorPropertyDefinition property
                    in properties)
                {
                    string tag =
                        property.Tag?.Trim()
                        ?? string.Empty;

                    if (string.IsNullOrWhiteSpace(tag))
                        continue;

                    if (!comboBox.Items.Contains(tag))
                    {
                        comboBox.Items.Add(tag);
                    }
                }

                if (!string.IsNullOrWhiteSpace(selectedValue) &&
                    comboBox.Items.Contains(selectedValue))
                {
                    comboBox.SelectedItem =
                        selectedValue;
                }
                else if (comboBox.Items.Count > 0)
                {
                    comboBox.SelectedIndex = 0;
                }
                else
                {
                    comboBox.SelectedIndex = -1;
                }
            }
            finally
            {
                comboBox.EndUpdate();
            }
        }
    }
}