﻿using Marpatech_8.Features.StampaCartelline.Managers.Actions;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;
using System;
using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Managers
{
    public class ConfigurationEditorManager
    {
        private readonly EditorContext _context;

        private readonly PropertyActions _propertyActions;
        private readonly WordActions _wordActions;
        private readonly ExcelActions _excelActions;
        private readonly PdfActions _pdfActions;

        private readonly Dictionary<EditorAction, Action>
            _commands;

        private readonly ConfigurationEditorModel
    _model;

        public ConfigurationEditorManager(
            EditorContext context)
        {
            _context = context ??
                throw new ArgumentNullException(
                    nameof(context));

            _model =
                new ConfigurationEditorModel();

            _propertyActions =
                new PropertyActions(
                    context,
                    _model);

            _wordActions =
                new WordActions(
                    context,
                    _model);

            _excelActions =
                new ExcelActions(
                    context,
                    _model);

            _pdfActions =
                new PdfActions(
                    context,
                    _model);

            _commands =
                new Dictionary<EditorAction, Action>
                {
                    {
                        EditorAction.AddProperty,
                        _propertyActions.Add
                    },
                    {
                        EditorAction.DuplicateProperty,
                        _propertyActions.Duplicate
                    },
                    {
                        EditorAction.DeleteProperty,
                        _propertyActions.Delete
                    },
                    {
                        EditorAction.MovePropertyUp,
                        _propertyActions.MoveUp
                    },
                    {
                        EditorAction.MovePropertyDown,
                        _propertyActions.MoveDown
                    },

                    {
                        EditorAction.AddWordTemplate,
                        _wordActions.AddTemplate
                    },
                    {
                        EditorAction.DuplicateWordTemplate,
                        _wordActions.DuplicateTemplate
                    },
                    {
                        EditorAction.DeleteWordTemplate,
                        _wordActions.DeleteTemplate
                    },
                    {
                        EditorAction.MoveWordTemplateUp,
                        _wordActions.MoveTemplateUp
                    },
                    {
                        EditorAction.MoveWordTemplateDown,
                        _wordActions.MoveTemplateDown
                    },
                    {
                        EditorAction.AddWordTag,
                        _wordActions.AddTag
                    },
                    {
                        EditorAction.DeleteWordTag,
                        _wordActions.DeleteTag
                    },
                    {
                        EditorAction.BrowseWordTemplate,
                        _wordActions.BrowseTemplate
                    },
                };
        }

        public void BindRegisteredButtons()
        {
            foreach (
                KeyValuePair<EditorAction, System.Windows.Forms.Button>
                registration
                in _context.GetRegisteredButtons())
            {
                EditorAction action =
                    registration.Key;

                registration.Value.Click +=
                    (_, _) => Execute(action);
            }

            BindPropertyEvents();
            BindWordEvents();
            BindExcelEvents();
            BindPdfEvents();
        }

        private void BindPropertyEvents()
        {
            _context.PropertiesList.SelectedIndexChanged +=
                (_, _) =>
                    _propertyActions.SelectProperty();

        }

        public void Execute(EditorAction action)
        {
            if (!_commands.TryGetValue(
                    action,
                    out Action? command))
            {
                throw new InvalidOperationException(
                    "Azione non registrata: " +
                    action);
            }

        command();
        }
        private void BindWordEvents()
        {
            _context.WordTemplatesList.SelectedIndexChanged +=
                (_, _) =>
                    _wordActions.SelectTemplate();
        }
        private void BindExcelEvents()
        {
            _context.ExcelStartPath.TextChanged +=
                (_, _) => _excelActions.Save();

            _context.ExcelFinalPath.TextChanged +=
                (_, _) => _excelActions.Save();

            _context.ExcelDeterminingAttribute.SelectedIndexChanged +=
                (_, _) => _excelActions.Save();

            _context.ExcelIncludeInPrint.CheckedChanged +=
                (_, _) => _excelActions.Save();
        }
        private void BindPdfEvents()
        {
            _context.PdfStartPath.TextChanged +=
                (_, _) => _pdfActions.Save();

            _context.PdfFinalPath.TextChanged +=
                (_, _) => _pdfActions.Save();

            _context.PdfDeterminingAttribute.SelectedIndexChanged +=
                (_, _) => _pdfActions.Save();

            _context.PdfIncludeInPrint.CheckedChanged +=
                (_, _) => _pdfActions.Save();
        }


        public void LoadConfiguration(
            PrintFolderConfiguration configuration)
        {
            _model.SetConfiguration(
                configuration);

            _propertyActions.Load();
            _wordActions.Load();
            _excelActions.Load();
            _pdfActions.Load();
        }

        public PrintFolderConfiguration GetConfiguration()
        {
            CommitPendingChanges();

            return _model.CurrentConfiguration;
        }

        private void CommitPendingChanges()
        {
            _propertyActions.Commit();
            _wordActions.Commit();
            _excelActions.Save();
            _pdfActions.Save();
        }
    }
}