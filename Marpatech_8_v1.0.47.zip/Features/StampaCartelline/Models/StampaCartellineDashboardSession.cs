﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class StampaCartellineDashboardSession
    {
        public string ConfigurationName { get; set; } =
            string.Empty;

        public string ConfigurationDescription { get; set; } =
            string.Empty;

        public List<DashboardPropertySession>
            InventorProperties
        { get; set; } =
                new List<DashboardPropertySession>();
        public DashboardPropertySession?
    GetProperty(string inventorPropertyName)
        {
            return InventorProperties.Find(
                property =>
                    property.InventorPropertyName ==
                    inventorPropertyName);
        }
    }
}