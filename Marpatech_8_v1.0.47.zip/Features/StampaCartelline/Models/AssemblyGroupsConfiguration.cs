﻿using System.Collections.Generic;

namespace Marpatech_8.Features.StampaCartelline.Models
{
    public class AssemblyGroupsConfiguration
    {
        public List<AssemblyGroupDefinition>
            Groups
        { get; set; } =
                new List<AssemblyGroupDefinition>();
    }

    public class AssemblyGroupDefinition
    {
        public string Name { get; set; } =
            string.Empty;
    }
}
