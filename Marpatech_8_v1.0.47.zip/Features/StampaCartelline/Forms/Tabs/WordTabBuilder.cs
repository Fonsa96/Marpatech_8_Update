﻿using System;
using System.Windows.Forms;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Forms.Styling;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class WordTabBuilder
    {
        public static TabPage Build(
            bool isDarkTheme,
            EditorContext context)
        {
            DrawingColor backgroundColor = isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor panelColor = isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor titleColor = isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = isDarkTheme
                ? DrawingColor.FromArgb(55, 58, 68)
                : DrawingColor.White;

            TabPage page = new TabPage
            {
                Text = "Template Word",
                BackColor = backgroundColor,
                Padding = new Padding(18)
            };

            SplitContainer split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                FixedPanel = FixedPanel.Panel1,
                BackColor = backgroundColor
            };

            split.Panel1.BackColor = panelColor;
            split.Panel2.BackColor = backgroundColor;

            split.SizeChanged += (_, _) =>
            {
                int availableWidth =
                    split.ClientSize.Width -
                    split.SplitterWidth;

                if (availableWidth < 500)
                    return;

                int desiredDistance = 250;
                int maximumDistance =
                    availableWidth - 350;

                if (desiredDistance > maximumDistance)
                    desiredDistance = maximumDistance;

                if (desiredDistance < 190)
                    desiredDistance = 190;

                split.SplitterDistance =
                    desiredDistance;
            };

            BuildLeftPanel(
                split.Panel1,
                context,
                titleColor,
                subtitleColor);

            BuildRightPanel(
                split.Panel2,
                context,
                titleColor,
                subtitleColor,
                inputColor,
                isDarkTheme);

            page.Controls.Add(split);

            return page;
        }

        private static void BuildLeftPanel(
            SplitterPanel panel,
            EditorContext context,
            DrawingColor titleColor,
            DrawingColor subtitleColor)
        {
            TableLayoutPanel layout =
                new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    Padding = new Padding(15),
                    ColumnCount = 1,
                    RowCount = 4,
                    BackColor = panel.BackColor
                };

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    36));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    30));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    88));

            Label title = new Label
            {
                Text = "Template",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold),
                ForeColor = titleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label description = new Label
            {
                Text = "Ordine di elaborazione dei template.",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9),
                ForeColor = subtitleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            ListBox templateList =
                context.WordTemplatesList;

            templateList.Dock =
                DockStyle.Fill;

            templateList.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            FlowLayoutPanel templateActions =
                new FlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    FlowDirection =
                        FlowDirection.LeftToRight,
                    WrapContents = true,
                    Padding =
                        new Padding(
                            0,
                            8,
                            0,
                            0),
                    BackColor =
                        panel.BackColor
                };

            Button btnAddTemplate =
                CreateSmallButton("Agg.");

            Button btnDuplicateTemplate =
                CreateSmallButton("Dup.");

            Button btnDeleteTemplate =
                CreateSmallButton("Elim.");

            Button btnTemplateUp =
                CreateSmallButton("↑");

            Button btnTemplateDown =
                CreateSmallButton("↓");

            context.RegisterButton(
                EditorAction.AddWordTemplate,
                btnAddTemplate);

            context.RegisterButton(
                EditorAction.DuplicateWordTemplate,
                btnDuplicateTemplate);

            context.RegisterButton(
                EditorAction.DeleteWordTemplate,
                btnDeleteTemplate);

            context.RegisterButton(
                EditorAction.MoveWordTemplateUp,
                btnTemplateUp);

            context.RegisterButton(
                EditorAction.MoveWordTemplateDown,
                btnTemplateDown);

            templateActions.Controls.Add(
                btnAddTemplate);

            templateActions.Controls.Add(
                btnDuplicateTemplate);

            templateActions.Controls.Add(
                btnDeleteTemplate);

            templateActions.Controls.Add(
                btnTemplateUp);

            templateActions.Controls.Add(
                btnTemplateDown);

            layout.Controls.Add(
                title,
                0,
                0);

            layout.Controls.Add(
                description,
                0,
                1);

            layout.Controls.Add(
                templateList,
                0,
                2);

            layout.Controls.Add(
                templateActions,
                0,
                3);

            panel.Controls.Add(layout);
        }

        private static void BuildRightPanel(
            SplitterPanel panel,
            EditorContext context,
            DrawingColor titleColor,
            DrawingColor subtitleColor,
            DrawingColor inputColor,
            bool isDarkTheme)
        {
            TableLayoutPanel layout =
                new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    Padding = new Padding(20),
                    ColumnCount = 1,
                    RowCount = 10,
                    BackColor = panel.BackColor
                };

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    32));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    27));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    38));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    27));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    40));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    42));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Percent,
                    100));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    52));

            layout.RowStyles.Add(
                new RowStyle(
                    SizeType.Absolute,
                    1));

            Label title = new Label
            {
                Text = "Configurazione template",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold),
                ForeColor = titleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label description = new Label
            {
                Text =
                    "Definisci il file Word e le associazioni con i placeholder.",
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9),
                ForeColor = subtitleColor,
                TextAlign =
                    System.Drawing.ContentAlignment.MiddleLeft
            };

            Label lblName =
                CreateLabel(
                    "Nome Template",
                    titleColor);

            TextBox txtName =
                context.WordTemplateName;

            ConfigureTextBox(
                txtName,
                inputColor,
                titleColor);

            Label lblPath =
                CreateLabel(
                    "Percorso Template",
                    titleColor);

            TableLayoutPanel pathLayout =
                new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    ColumnCount = 2,
                    RowCount = 1,
                    Margin = new Padding(0)
                };

            pathLayout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Percent,
                    100));

            pathLayout.ColumnStyles.Add(
                new ColumnStyle(
                    SizeType.Absolute,
                    100));

            TextBox txtPath =
                context.WordTemplatePath;

            ConfigureTextBox(
                txtPath,
                inputColor,
                titleColor);

            txtPath.Margin =
                new Padding(
                    0,
                    0,
                    8,
                    0);

            Button btnBrowse =
                CreateButton(
                    "Sfoglia",
                    92);

            btnBrowse.Dock =
                DockStyle.Fill;

            btnBrowse.Margin =
                new Padding(0);

            context.RegisterButton(
                EditorAction.BrowseWordTemplate,
                btnBrowse);

            pathLayout.Controls.Add(
                txtPath,
                0,
                0);

            pathLayout.Controls.Add(
                btnBrowse,
                1,
                0);

            Label mappingsTitle =
                CreateLabel(
                    "Testi e Placeholder",
                    titleColor);

            mappingsTitle.TextAlign =
                System.Drawing.ContentAlignment.BottomLeft;

            DataGridView mappingsGrid =
                context.WordMappingsGrid;

            ConfigureMappingsGrid(
                mappingsGrid,
                isDarkTheme);

            ConfigureTagContextMenu(
                mappingsGrid,
                context);

            FlowLayoutPanel mappingActions =
                new FlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    FlowDirection =
                        FlowDirection.LeftToRight,
                    WrapContents = false,
                    Padding =
                        new Padding(
                            0,
                            8,
                            0,
                            0),
                    BackColor =
                        panel.BackColor
                };

            Button btnAddRow =
                CreateButton(
                    "Aggiungi Riga",
                    125);

            Button btnDeleteRow =
                CreateButton(
                    "Elimina Riga",
                    125);

            context.RegisterButton(
                EditorAction.AddWordTag,
                btnAddRow);

            context.RegisterButton(
                EditorAction.DeleteWordTag,
                btnDeleteRow);

            mappingActions.Controls.Add(
                btnAddRow);

            mappingActions.Controls.Add(
                btnDeleteRow);

            layout.Controls.Add(
                title,
                0,
                0);

            layout.Controls.Add(
                description,
                0,
                1);

            layout.Controls.Add(
                lblName,
                0,
                2);

            layout.Controls.Add(
                txtName,
                0,
                3);

            layout.Controls.Add(
                lblPath,
                0,
                4);

            layout.Controls.Add(
                pathLayout,
                0,
                5);

            layout.Controls.Add(
                mappingsTitle,
                0,
                6);

            layout.Controls.Add(
                mappingsGrid,
                0,
                7);

            layout.Controls.Add(
                mappingActions,
                0,
                8);

            panel.Controls.Add(layout);
        }

        private static void ConfigureMappingsGrid(
            DataGridView grid,
            bool isDarkTheme)
        {
            EditorThemeStyler.ApplyDataGridViewTheme(
                grid,
                isDarkTheme);

            grid.Dock =
                DockStyle.Fill;

            grid.AllowUserToAddRows =
                false;

            grid.AllowUserToDeleteRows =
                false;

            grid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            grid.RowHeadersVisible =
                false;

            grid.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            grid.MultiSelect =
                false;

            grid.EditMode =
                DataGridViewEditMode.EditOnEnter;

            grid.Columns.Clear();

            DataGridViewTextBoxColumn textColumn =
                new DataGridViewTextBoxColumn
                {
                    Name = "WordText",
                    HeaderText =
                        "Testo da scrivere in Word",
                    FillWeight = 60
                };

            DataGridViewTextBoxColumn placeholderColumn =
                new DataGridViewTextBoxColumn
                {
                    Name = "Placeholder",
                    HeaderText = "Placeholder",
                    FillWeight = 40
                };

            grid.Columns.Add(
                textColumn);

            grid.Columns.Add(
                placeholderColumn);
        }

        private static void ConfigureTagContextMenu(
            DataGridView grid,
            EditorContext context)
        {
            ContextMenuStrip menu =
                new ContextMenuStrip();

            menu.Opening += (_, e) =>
            {
                menu.Items.Clear();

                if (grid.CurrentCell == null ||
                    grid.CurrentCell.ColumnIndex != 0)
                {
                    e.Cancel = true;
                    return;
                }

                if (context.PropertiesList.Items.Count == 0)
                {
                    ToolStripMenuItem emptyItem =
                        new ToolStripMenuItem(
                            "Nessun Tag disponibile");

                    emptyItem.Enabled = false;

                    menu.Items.Add(
                        emptyItem);

                    return;
                }

                foreach (ListViewItem propertyItem
                    in context.PropertiesList.Items)
                {
                    string tag =
                        propertyItem.Text?.Trim()
                        ?? string.Empty;

                    if (string.IsNullOrWhiteSpace(tag))
                        continue;

                    ToolStripMenuItem tagItem =
                        new ToolStripMenuItem(tag);

                    tagItem.Click += (_, _) =>
                    {
                        if (grid.CurrentCell != null)
                        {
                            grid.CurrentCell.Value =
                                tag;
                        }
                    };

                    menu.Items.Add(
                        tagItem);
                }

                if (menu.Items.Count == 0)
                {
                    ToolStripMenuItem emptyItem =
                        new ToolStripMenuItem(
                            "Nessun Tag disponibile");

                    emptyItem.Enabled = false;

                    menu.Items.Add(
                        emptyItem);
                }
            };

            grid.CellMouseDown += (_, e) =>
            {
                if (e.Button != MouseButtons.Right)
                    return;

                if (e.RowIndex < 0 ||
                    e.ColumnIndex != 0)
                {
                    return;
                }

                grid.CurrentCell =
                    grid.Rows[e.RowIndex]
                        .Cells[e.ColumnIndex];
            };

            grid.ContextMenuStrip =
                menu;
        }

        private static void ConfigureTextBox(
            TextBox textBox,
            DrawingColor backgroundColor,
            DrawingColor foregroundColor)
        {
            textBox.Dock =
                DockStyle.Fill;

            textBox.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            textBox.BackColor =
                backgroundColor;

            textBox.ForeColor =
                foregroundColor;

            textBox.BorderStyle =
                BorderStyle.FixedSingle;

            textBox.Margin =
                new Padding(0);
        }

        private static Label CreateLabel(
            string text,
            DrawingColor color)
        {
            return new Label
            {
                Text = text,
                Dock = DockStyle.Fill,
                Font = new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold),
                ForeColor = color,
                TextAlign =
                    System.Drawing.ContentAlignment.BottomLeft
            };
        }

        private static Button CreateButton(
            string text,
            int width)
        {
            Button button =
                new Button
                {
                    Text = text,
                    Size =
                        new DrawingSize(
                            width,
                            34),
                    Margin =
                        new Padding(
                            0,
                            0,
                            8,
                            0),
                    FlatStyle =
                        FlatStyle.Flat,
                    BackColor =
                        DrawingColor.FromArgb(
                            71,
                            85,
                            105),
                    ForeColor =
                        DrawingColor.White,
                    Cursor =
                        Cursors.Hand
                };

            button.FlatAppearance.BorderSize =
                0;

            return button;
        }

        private static Button CreateSmallButton(
            string text)
        {
            return CreateButton(
                text,
                58);
        }
    }
}