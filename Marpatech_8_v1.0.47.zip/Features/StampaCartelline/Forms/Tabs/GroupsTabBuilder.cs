﻿using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;

namespace Marpatech_8.Features.StampaCartelline.Forms.Tabs
{
    public static class GroupsTabBuilder
    {
        public static TabPage Build(bool isDarkTheme)
        {
            DrawingColor backgroundColor = isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            TabPage page = new TabPage();
            page.Text = "Gruppi di montaggio";
            page.BackColor = backgroundColor;

            Label title = new Label();
            title.Text = "Gruppi di montaggio";
            title.Font = new DrawingFont(
                "Segoe UI",
                16,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Left = 25;
            title.Top = 25;

            Label description = new Label();
            description.Text =
                "La gestione dei gruppi di montaggio verrà progettata al termine della funzione.";
            description.Font = new DrawingFont(
                "Segoe UI",
                10);
            description.ForeColor = subtitleColor;
            description.AutoSize = true;
            description.Left = 27;
            description.Top = 70;

            page.Controls.Add(title);
            page.Controls.Add(description);

            return page;
        }
    }
}