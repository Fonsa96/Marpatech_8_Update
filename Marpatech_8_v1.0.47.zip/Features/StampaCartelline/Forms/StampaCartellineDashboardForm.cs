﻿using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;
using System;
using System.Windows.Forms;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class StampaCartellineDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly CoreWindowSettings _windowSettings;

        private ComboBox? cmbConfigurazione;
        private Label? lblDescrizioneConfigurazione;
        private FlowLayoutPanel? propertiesPanel;
        private Button? btnRefreshProperties;

        private DashboardConfigurationManager?
    _configurationManager;

        private StampaCartellineDashboardSession?
    _currentSession;

        private DashboardInventorPropertyReader?
    _propertyReader;

        public StampaCartellineDashboardForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "StampaCartellineDashboard",
                1100,
                760);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            _propertyReader =
                new DashboardInventorPropertyReader(
                    _inventorApp);

            InitializeConfigurationManager();
        }
        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            this.Text = "Stampa Cartelline";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(1100, 760);
            this.MinimumSize = new DrawingSize(900, 650);
            this.BackColor = backgroundColor;
            this.FormClosing +=
                StampaCartellineDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Stampa Cartelline";
            title.Font = new DrawingFont(
                "Segoe UI",
                26,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 20);

            Label subtitle = new Label();
            subtitle.Text =
                "Gestione e stampa automatica delle cartelline di commessa";
            subtitle.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(38, 68);

            Button btnSettings = CreateButton(
                "⚙",
                DrawingColor.FromArgb(100, 116, 139),
                50,
                42);

            btnSettings.Font = new DrawingFont(
                "Segoe UI",
                18,
                DrawingFontStyle.Regular);

            btnSettings.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            btnSettings.Location = new DrawingPoint(
                this.ClientSize.Width - 85,
                30);

            btnSettings.Click += BtnSettings_Click;

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 105);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 70,
                this.ClientSize.Height - 140);

            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(28);

            FlowLayoutPanel contentPanel =
                new FlowLayoutPanel();

            contentPanel.Dock = DockStyle.Fill;
            contentPanel.FlowDirection =
                FlowDirection.TopDown;
            contentPanel.WrapContents = false;
            contentPanel.AutoScroll = true;
            contentPanel.BackColor = cardColor;

            Panel configurationCard =
                new Panel();

            configurationCard.Size =
                new DrawingSize(930, 165);

            configurationCard.BackColor = cardColor;
            configurationCard.Margin =
                new Padding(0, 0, 0, 15);

            Label configurationTitle =
                CreateSectionTitle(
                    "1) Configurazione",
                    titleColor);

            configurationTitle.Location =
                new DrawingPoint(0, 0);

            Label lblConfigurazione =
                CreateLabel(
                    "Seleziona configurazione",
                    titleColor);

            lblConfigurazione.Location =
                new DrawingPoint(0, 50);

            cmbConfigurazione =
                new ComboBox();

            cmbConfigurazione.Location =
                new DrawingPoint(0, 77);

            cmbConfigurazione.Size =
                new DrawingSize(400, 32);

            cmbConfigurazione.Font =
                new DrawingFont("Segoe UI", 10);

            cmbConfigurazione.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cmbConfigurazione.BackColor =
                inputColor;

            cmbConfigurazione.ForeColor =
                titleColor;

            cmbConfigurazione.SelectedIndexChanged +=
                CmbConfigurazione_SelectedIndexChanged;

            Label lblDescrizioneTitolo =
                CreateLabel(
                    "Descrizione",
                    titleColor);

            lblDescrizioneTitolo.Location =
                new DrawingPoint(440, 50);

            lblDescrizioneConfigurazione =
                new Label();

            lblDescrizioneConfigurazione.Text =
                "Nessuna configurazione selezionata.";

            lblDescrizioneConfigurazione.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            lblDescrizioneConfigurazione.ForeColor =
                subtitleColor;

            lblDescrizioneConfigurazione.Location =
                new DrawingPoint(440, 77);

            lblDescrizioneConfigurazione.Size =
                new DrawingSize(450, 65);

            lblDescrizioneConfigurazione.AutoEllipsis =
                true;

            configurationCard.Controls.Add(
                configurationTitle);

            configurationCard.Controls.Add(
                lblConfigurazione);

            configurationCard.Controls.Add(
                cmbConfigurazione);

            configurationCard.Controls.Add(
                lblDescrizioneTitolo);

            configurationCard.Controls.Add(
                lblDescrizioneConfigurazione);

            contentPanel.Controls.Add(
                configurationCard);

            Panel separator1 = new Panel();
            separator1.Size = new DrawingSize(930, 2);
            separator1.BackColor = _isDarkTheme
                ? DrawingColor.FromArgb(70, 75, 85)
                : DrawingColor.FromArgb(203, 213, 225);
            separator1.Margin = new Padding(0, 5, 0, 20);

            Panel propertiesCard = new Panel();
            propertiesCard.Size = new DrawingSize(930, 260);
            propertiesCard.BackColor = cardColor;
            propertiesCard.Margin = new Padding(0, 0, 0, 15);

            Label propertiesTitle = CreateSectionTitle(
                "2) Proprietà Inventor",
                titleColor);

            propertiesTitle.Location = new DrawingPoint(0, 0);

            Label propertiesSubtitle = new Label();
            propertiesSubtitle.Text =
                "Valori delle proprietà configurate per la cartellina selezionata.";
            propertiesSubtitle.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Regular);
            propertiesSubtitle.ForeColor = subtitleColor;
            propertiesSubtitle.AutoSize = true;
            propertiesSubtitle.Location = new DrawingPoint(0, 38);

            btnRefreshProperties = CreateButton(
                "🔄",
                DrawingColor.FromArgb(37, 99, 235),
                48,
                38);

            btnRefreshProperties.Location = new DrawingPoint(820, 0);
            btnRefreshProperties.Click += BtnRefreshProperties_Click;

            propertiesPanel = new FlowLayoutPanel();
            propertiesPanel.Location = new DrawingPoint(0, 75);
            propertiesPanel.Size = new DrawingSize(890, 170);
            propertiesPanel.FlowDirection = FlowDirection.TopDown;
            propertiesPanel.WrapContents = false;
            propertiesPanel.AutoScroll = true;
            propertiesPanel.BackColor = cardColor;
            propertiesPanel.BorderStyle = BorderStyle.None;

            propertiesCard.Controls.Add(propertiesTitle);
            propertiesCard.Controls.Add(propertiesSubtitle);
            propertiesCard.Controls.Add(btnRefreshProperties);
            propertiesCard.Controls.Add(propertiesPanel);

            contentPanel.Controls.Add(separator1);
            contentPanel.Controls.Add(propertiesCard);

            mainPanel.Controls.Add(
                contentPanel);

            this.Controls.Add(title);
            this.Controls.Add(subtitle);
            this.Controls.Add(btnSettings);
            this.Controls.Add(mainPanel);
        }

        private Label CreateSectionTitle(
            string text,
            DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont(
                "Segoe UI",
                15,
                DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;

            return label;
        }

        private Label CreateLabel(
            string text,
            DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;

            return label;
        }

        private Panel CreatePropertyRow(
            DashboardPropertySession property)
        {
            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            Panel row = new Panel();
            row.Size = new DrawingSize(850, 38);
            row.Margin = new Padding(0, 0, 0, 6);

            Label label = new Label();
            label.Text = property.Tag;
            label.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);

            label.ForeColor = titleColor;
            label.Location = new DrawingPoint(0, 7);
            label.Size = new DrawingSize(260, 24);

            TextBox textBox = new TextBox();
            textBox.Text = property.Value;
            textBox.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Regular);

            textBox.Location = new DrawingPoint(280, 4);
            textBox.Size = new DrawingSize(500, 28);
            textBox.ForeColor = titleColor;
            textBox.BackColor = inputColor;
            textBox.BorderStyle = BorderStyle.FixedSingle;

            textBox.ReadOnly = false;

            textBox.Tag = property;

            textBox.TextChanged +=
                DashboardPropertyTextBox_TextChanged;

            row.Controls.Add(label);
            row.Controls.Add(textBox);

            return row;
        }

        private void LoadSessionProperties()
        {
            if (propertiesPanel == null)
                return;

            propertiesPanel.Controls.Clear();

            if (_currentSession == null)
                return;

            foreach (DashboardPropertySession property
                in _currentSession.InventorProperties)
            {
                propertiesPanel.Controls.Add(
                    CreatePropertyRow(
                        property));
            }
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            button.Size = new DrawingSize(
                width,
                height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void CmbConfigurazione_SelectedIndexChanged(
            object? sender,
            EventArgs e)
        {
            UpdateSelectedConfiguration();
        }

        private void BtnSettings_Click(
            object? sender,
            EventArgs e)
        {
            StampaCartellineSettingsForm form =
                new StampaCartellineSettingsForm(
                    _isDarkTheme);

            form.Show(this);
            form.Activate();
        }

        private void StampaCartellineDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "StampaCartellineDashboard");
        }
        private void BtnRefreshProperties_Click(
            object? sender,
            EventArgs e)
        {
            if (_currentSession == null)
                return;

            _propertyReader?.ReadProperties(
                _currentSession);

            LoadSessionProperties();
        }
        private void InitializeConfigurationManager()
        {
            if (cmbConfigurazione == null)
                return;

            _configurationManager =
                new DashboardConfigurationManager(
                    cmbConfigurazione);

            _configurationManager.Load();

            UpdateSelectedConfiguration();
        }
        private void UpdateSelectedConfiguration()
        {
            if (lblDescrizioneConfigurazione == null)
                return;

            PrintFolderConfiguration? configuration =
                _configurationManager?
                    .SelectedConfiguration;

            if (configuration == null)
            {
                _currentSession = null;

                lblDescrizioneConfigurazione.Text =
                    "Nessuna configurazione disponibile.";

                propertiesPanel?.Controls.Clear();

                return;
            }

            CreateDashboardSession(
                configuration);

            _propertyReader?.ReadProperties(
                  _currentSession!);

            StampaCartellineDashboardSession session =
                _currentSession!;

            lblDescrizioneConfigurazione.Text =
                string.IsNullOrWhiteSpace(
                    session.ConfigurationDescription)
                    ? "Nessuna descrizione."
                    : session.ConfigurationDescription;

            LoadSessionProperties();
        }
        private void CreateDashboardSession(
    PrintFolderConfiguration configuration)
        {
            _currentSession =
                new StampaCartellineDashboardSession
                {
                    ConfigurationName =
                        configuration.Name,

                    ConfigurationDescription =
                        configuration.Description
                };

            foreach (InventorPropertyDefinition property
                in configuration.InventorProperties)
            {
                _currentSession.InventorProperties.Add(
                    new DashboardPropertySession
                    {
                        Tag = property.Tag,

                        InventorPropertyName =
                            property.InventorPropertyName,

                        Editable =
                            property.EditableFromDashboard,

                        Value = string.Empty
                    });
            }
        }
        private void DashboardPropertyTextBox_TextChanged(
    object? sender,
    EventArgs e)
        {
            if (sender is not TextBox textBox)
                return;

            if (textBox.Tag
                is not DashboardPropertySession property)
            {
                return;
            }

            property.Value =
                textBox.Text;
        }
    }
}