﻿using Inventor;
using Marpatech_8.Features.Mail.Forms;

namespace Marpatech_8.Features.Mail
{
    public static class MailCommand
    {
        public static void Execute(Inventor.Application inventorApp, bool isDarkTheme)
        {
            MailDashboardForm form = new MailDashboardForm(inventorApp, isDarkTheme);
            form.ShowDialog();
        }
    }
}