﻿using Marpatech_8.Features.Mail.Config;
using Marpatech_8.Features.Mail.WindowSettings;
using Marpatech_8.Features.Mail.Services ;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;
using System.Collections.Generic;


namespace Marpatech_8.Features.Mail.Forms
{
    public class MailDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;

        private MailSettings _settings = new MailSettings();

        private FlowLayoutPanel? rowsPanel;

        private readonly MailDashboardWindowSettings _windowSettings;

        public MailDashboardForm(Inventor.Application inventorApp, bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _settings = MailSettingsService.Load();
            _windowSettings = MailDashboardWindowSettingsService.Load();

            InitializeComponent();
            ApplyWindowSettings();
            ReloadRows();
        }

        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            this.Text = "Invio Mail";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(920, 560);
            this.MinimumSize = new DrawingSize(1550, 560);
            this.BackColor = backgroundColor;
            this.FormClosing += MailDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Invio Mail";
            title.Font = new DrawingFont("Segoe UI", 26, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(30, 25);

            Button btnAdd = CreateTopButton("Aggiungi Tipo Mail", DrawingColor.FromArgb(37, 99, 235));
            btnAdd.Location = new DrawingPoint(30, 90);
            btnAdd.Click += BtnAdd_Click;

            Button btnImport = CreateTopButton("Carica Configurazione", DrawingColor.FromArgb(245, 158, 11));
            btnImport.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnImport.Location = new DrawingPoint(this.ClientSize.Width - 380, 90);
            btnImport.Click += BtnImport_Click;

            Button btnExport = CreateTopButton("Esporta Configurazione", DrawingColor.FromArgb(124, 58, 237));
            btnExport.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnExport.Location = new DrawingPoint(this.ClientSize.Width - 200, 90);
            btnExport.Click += BtnExport_Click;

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(30, 150);
            mainPanel.Size = new DrawingSize(this.ClientSize.Width - 60, this.ClientSize.Height - 185);
            mainPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(14);

            rowsPanel = new FlowLayoutPanel();
            rowsPanel.SizeChanged += (s, e) => ReloadRows();
            rowsPanel.Dock = DockStyle.Fill;
            rowsPanel.AutoScroll = true;
            rowsPanel.WrapContents = false;
            rowsPanel.FlowDirection = FlowDirection.TopDown;
            rowsPanel.BackColor = cardColor;
            rowsPanel.Padding = new Padding(6);

            mainPanel.Controls.Add(rowsPanel);

            this.Controls.Add(title);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnImport);
            this.Controls.Add(btnExport);
            this.Controls.Add(mainPanel);
        }

        private Button CreateTopButton(string text, DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 9, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(165, 38);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void ReloadRows()
        {
            if (rowsPanel == null)
                return;

            rowsPanel.Controls.Clear();

            foreach (MailTypeConfig mailType in _settings.MailTypes
                  .OrderByDescending(x => x.Enabled)
                  .ThenBy(x => x.Description))
            {
                rowsPanel.Controls.Add(CreateMailTypeRow(mailType));
            }
        }

        private Panel CreateMailTypeRow(MailTypeConfig mailType)
        {
            DrawingColor rowColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.FromArgb(248, 250, 252);

            DrawingColor textColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            int rowWidth = rowsPanel != null
                ? rowsPanel.ClientSize.Width - 28
                : 820;

            Panel row = new Panel();
            row.Size = new DrawingSize(rowWidth, 105);
            row.Margin = new Padding(4, 4, 4, 12);
            row.BackColor = rowColor;

            Label lblDescription = new Label();
            lblDescription.Text = mailType.Description;
            lblDescription.Font = new DrawingFont("Segoe UI", 18, DrawingFontStyle.Bold);
            lblDescription.ForeColor = textColor;
            lblDescription.AutoSize = false;
            lblDescription.Location = new DrawingPoint(24, 14);
            lblDescription.Size = new DrawingSize(430, 36);

            string configured = mailType.IsConfigured ? "✔" : "✖";
            string path = mailType.IncludeLink ? "✔" : "✖";
            string excel = mailType.IncludeExcelAttachment ? "✔" : "✖";
            string enabled = mailType.Enabled ? "✔" : "✖";

            Label lblStatus = new Label();
            string activeStatus = mailType.Enabled ? "ATTIVA" : "DISATTIVATA";

            lblStatus.Text =
                 $"Configurata: {configured}    |    Inserimento Percorso: {path}    |    Inserimento Excel: {excel}    |    Attiva: {enabled}";
            lblStatus.Font = new DrawingFont("Segoe UI", 12, DrawingFontStyle.Bold);
            lblStatus.ForeColor = textColor;
            lblStatus.AutoSize = false;
            lblStatus.Location = new DrawingPoint(24, 56);
            lblStatus.Size = new DrawingSize(800, 28);

            Button btnSend = CreateBigRowButton("✉  Invia Mail", DrawingColor.FromArgb(22, 163, 74));

            bool canSend = mailType.IsConfigured && mailType.Enabled;

            if (!canSend)
            {
                btnSend.Enabled = false;
                btnSend.BackColor = DrawingColor.FromArgb(100, 116, 139);
                btnSend.Cursor = Cursors.No;
            }
            Button btnConfig = CreateBigRowButton("⚙  Configura", DrawingColor.FromArgb(37, 99, 235));
            Button btnDelete = CreateBigRowButton("🗑  Elimina", DrawingColor.FromArgb(220, 38, 38));

            void PositionButtons()
            {
                int marginRight = 24;
                int gap = 14;
                int buttonTop = 24;

                btnDelete.Location = new DrawingPoint(row.Width - marginRight - btnDelete.Width, buttonTop);
                btnConfig.Location = new DrawingPoint(btnDelete.Left - gap - btnConfig.Width, buttonTop);
                btnSend.Location = new DrawingPoint(btnConfig.Left - gap - btnSend.Width, buttonTop);
            }

            btnSend.Click += (s, e) => SendMail(mailType);
            btnConfig.Click += (s, e) => ConfigureMailType(mailType);
            btnDelete.Click += (s, e) => DeleteMailType(mailType);

            row.Controls.Add(lblDescription);
            row.Controls.Add(lblStatus);
            row.Controls.Add(btnSend);
            row.Controls.Add(btnConfig);
            row.Controls.Add(btnDelete);

            row.Resize += (s, e) => PositionButtons();

            PositionButtons();

            return row;
        }

        private Button CreateBigRowButton(string text, DrawingColor color)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 11, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(150, 58);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            MailTypeConfig newType = new MailTypeConfig
            {
                Description = "Nuovo Tipo Mail"
            };

            _settings.MailTypes.Add(newType);
            MailSettingsService.Save(_settings);

            ReloadRows();
        }

        private void DeleteMailType(MailTypeConfig mailType)
        {
            DialogResult result = MessageBox.Show(
                "Sei sicuro di voler eliminare questo tipo mail?",
                "Elimina tipo mail",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (result != DialogResult.Yes)
                return;

            _settings.MailTypes.Remove(mailType);
            MailSettingsService.Save(_settings);

            ReloadRows();
        }

        private void ConfigureMailType(MailTypeConfig mailType)
        {
            MailTypeConfigForm form = new MailTypeConfigForm(
                _isDarkTheme,
                _settings,
                mailType);

            DialogResult result = form.ShowDialog();

            if (result == DialogResult.OK)
            {
                MailSettingsService.Save(_settings);
                ReloadRows();
            }
        }

        private void SendMail(MailTypeConfig mailType)
        {
            if (!mailType.Enabled)
            {
                MessageBox.Show(
                    "Questo tipo mail è disattivato.",
                    "Invia Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            if (!mailType.IsConfigured)
            {
                MessageBox.Show(
                    "Questo tipo mail non risulta ancora configurato.",
                    "Invia Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            try
            {
                Inventor.Document? document =
                    MailInventorService.GetActiveDocument(_inventorApp);

                if (document == null)
                {
                    MessageBox.Show(
                        "Nessun documento aperto in Inventor.",
                        "Invio Mail",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                Dictionary<string, string> values =
                    MailInventorService.ReadVariableValues(document, _settings);
                     MessageBox.Show(
                     "iProperties lette correttamente",
                     "Debug");

                string subject =
                    MailTemplateService.ApplyVariables(
                        mailType.SubjectTemplate,
                        _settings,
                        values);
                MessageBox.Show(
    "Template elaborato",
    "Debug");

                string body =
                    MailTemplateService.ApplyVariables(
                        mailType.BodyTemplate,
                        _settings,
                        values);

                string linkPath = "";
                string attachmentPath = "";

                if (mailType.IncludeLink || mailType.IncludeExcelAttachment)
                {
                    string searchValue = "";

                    if (!string.IsNullOrWhiteSpace(mailType.SearchPropertyName) &&
                        values.ContainsKey(mailType.SearchPropertyName))
                    {
                        searchValue = values[mailType.SearchPropertyName];
                    }

                    if (string.IsNullOrWhiteSpace(searchValue))
                    {
                        MessageBox.Show(
                            "La variabile di ricerca cartella è vuota o non trovata:\n\n" +
                            mailType.SearchPropertyName,
                            "Invio Mail",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning);

                        return;
                    }

                    if (mailType.IncludeLink)
                    {
                        linkPath = MailPathService.BuildMailLinkPath(
                            mailType,
                            searchValue);

                        if (string.IsNullOrWhiteSpace(linkPath))
                            body = MailTemplateService.RemoveLinkTag(body);
                    }
                    else
                    {
                        body = MailTemplateService.RemoveLinkTag(body);
                    }

                    if (mailType.IncludeExcelAttachment)
                    {
                        string excelFolder =
                            MailPathService.BuildExcelSearchPath(
                                mailType,
                                searchValue);

                        attachmentPath =
                            MailExcelAttachmentService.FindExcelAttachment(excelFolder);

                        if (string.IsNullOrWhiteSpace(attachmentPath))
                        {
                            MessageBox.Show(
                                "Nessun file Excel ANTICIPI trovato.\n\n" +
                                "La mail verrà aperta senza allegato.",
                                "Invio Mail",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                        }
                    }
                }
                else
                {
                    body = MailTemplateService.RemoveLinkTag(body);
                }

                MessageBox.Show(
    "Sto aprendo Outlook",
    "Debug");

                MailOutlookService.CreateMail(
                    mailType.To,
                    mailType.Cc,
                    subject,
                    body,
                    linkPath,
                    attachmentPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Errore durante la preparazione della mail.\n\n" + ex.Message,
                    "Invio Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnImport_Click(object? sender, EventArgs e)
        {
            try
            {
                using OpenFileDialog dialog = new OpenFileDialog();

                dialog.Title = "Carica configurazione Mail";
                dialog.Filter = "File JSON (*.json)|*.json";

                if (dialog.ShowDialog() != DialogResult.OK)
                    return;

                DialogResult result = MessageBox.Show(
                    "La configurazione attuale verrà sostituita.\n\nVuoi continuare?",
                    "Carica configurazione",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (result != DialogResult.Yes)
                    return;

                MailSettingsService.ImportFromFile(dialog.FileName);

                _settings = MailSettingsService.Load();

                ReloadRows();

                MessageBox.Show(
                    "Configurazione caricata correttamente.",
                    "Carica configurazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Errore importazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            try
            {
                using SaveFileDialog dialog = new SaveFileDialog();

                dialog.Title = "Esporta configurazione Mail";
                dialog.Filter = "File JSON (*.json)|*.json";
                dialog.FileName = "MailSettings.json";

                if (dialog.ShowDialog() != DialogResult.OK)
                    return;

                string sourceFile = MailSettingsService.SettingsFilePath;

                File.Copy(
                    sourceFile,
                    dialog.FileName,
                    true);

                MessageBox.Show(
                    "Configurazione esportata correttamente.",
                    "Esporta configurazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Errore esportazione",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        private void ApplyWindowSettings()
        {
            this.Width = _windowSettings.Width;
            this.Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = _windowSettings.Left;
                this.Top = _windowSettings.Top;
            }

            if (_windowSettings.IsMaximized)
                this.WindowState = FormWindowState.Maximized;
        }

        private void MailDashboardForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = this.Width;
                _windowSettings.Height = this.Height;
                _windowSettings.Left = this.Left;
                _windowSettings.Top = this.Top;
            }

            _windowSettings.IsMaximized =
                this.WindowState == FormWindowState.Maximized;

            MailDashboardWindowSettingsService.Save(_windowSettings);
        }
    }
}