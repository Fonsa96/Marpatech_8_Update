﻿using System;
using System.Windows.Forms;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailOutlookService
    {
        public static void CreateMail(
            string to,
            string cc,
            string subject,
            string body,
            string linkPath,
            string attachmentPath)
        {
            try
            {
                Type? outlookType = Type.GetTypeFromProgID("Outlook.Application");

                if (outlookType == null)
                {
                    MessageBox.Show(
                        "Outlook non trovato su questo PC.",
                        "Invio Mail",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    return;
                }

                dynamic outlookApp = Activator.CreateInstance(outlookType)!;
                dynamic mail = outlookApp.CreateItem(0);

                mail.To = to;
                mail.CC = cc;
                mail.Subject = subject;

                if (!string.IsNullOrWhiteSpace(attachmentPath))
                {
                    mail.Attachments.Add(attachmentPath);
                }

                 }
                 catch (Exception ex)
                 {
                      MessageBox.Show(
                    "Errore durante la creazione della mail Outlook.\n\n" + ex.Message,
                    "Invio Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                 }
        }
        private static string ConvertTextToHtml(string body, string linkPath)
        {
            string html = System.Net.WebUtility.HtmlEncode(body)
                .Replace("\r\n", "<br>")
                .Replace("\n", "<br>");

            if (!string.IsNullOrWhiteSpace(linkPath))
            {
                string encodedLink = System.Net.WebUtility.HtmlEncode(linkPath);

                html = html.Replace(
                    "{LINK}",
                    "<a href=\"" + encodedLink + "\">" + encodedLink + "</a>");
            }
            else
            {
                html = html.Replace("{LINK}", "");
            }

            return "<div style=\"font-family:Calibri;font-size:11pt;\">" +
                   html +
                   "</div><br>";
        }
    }
}