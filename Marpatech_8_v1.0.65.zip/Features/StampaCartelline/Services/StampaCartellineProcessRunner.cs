﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Inventor;
using Marpatech_8.Features.StampaCartelline.Models;

namespace Marpatech_8.Features.StampaCartelline.Services
{
    public class StampaCartellineProcessRunner
    {
        private readonly Inventor.Application
            _inventorApp;

        private readonly DashboardInventorPropertyWriter
            _propertyWriter;

        private readonly WordTemplateProcessor
            _wordTemplateProcessor;

        private readonly ExcelDrawingsProcessor
            _excelDrawingsProcessor;

        private readonly SheetMetalPdfProcessor
            _sheetMetalPdfProcessor;

        private readonly AssemblyGroupsProcessor
            _assemblyGroupsProcessor;

        private bool
            _cancelEntireProcess;


        public StampaCartellineProcessRunner(
            Inventor.Application inventorApp)
        {
            _inventorApp =
                inventorApp;

            _propertyWriter =
                new DashboardInventorPropertyWriter(
                    inventorApp);

            _wordTemplateProcessor =
                new WordTemplateProcessor();

            _excelDrawingsProcessor =
                new ExcelDrawingsProcessor();

            _sheetMetalPdfProcessor =
                new SheetMetalPdfProcessor();

            _assemblyGroupsProcessor =
                new AssemblyGroupsProcessor(
                    inventorApp);
        }


        public void Run(
            IWin32Window owner,
            PrintFolderConfiguration configuration,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(
                    nameof(configuration));
            }

            if (session == null)
            {
                throw new ArgumentNullException(
                    nameof(session));
            }

            if (progress == null)
            {
                throw new ArgumentNullException(
                    nameof(progress));
            }


            _cancelEntireProcess =
                false;


            /*
             * ==================================================
             * CONFIGURAZIONE BLOCCHI
             * ==================================================
             */

            bool includeInventor =
                session.IncludePrintFolders;


            bool includeWord =
                session.IncludePrintFolders;


            bool includeExcel =
                session.ExcelDrawings != null &&
                session.ExcelDrawings.IncludeInPrintProcess;


            bool includePdf =
                session.SheetMetalPdfs != null &&
                session.SheetMetalPdfs.IncludeInPrintProcess;


            bool includeAssemblyGroups =
                configuration.AssemblyGroups != null &&
                configuration.AssemblyGroups
                    .IncludeInPrintProcess &&
                session.IncludeAssemblyGroups;


            progress.ConfigureSection(
                StampaCartellineProcessSection.Inventor,
                includeInventor);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Word,
                includeWord);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Excel,
                includeExcel);

            progress.ConfigureSection(
                StampaCartellineProcessSection.Pdf,
                includePdf);

            progress.ConfigureSection(
                StampaCartellineProcessSection.AssemblyGroups,
                includeAssemblyGroups);


            /*
             * ==================================================
             * 1 - SCRITTURA IN INVENTOR
             * ==================================================
             */
            if (includeInventor)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Inventor,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Inventor,
                            "Controllo delle proprietà Inventor.");

                        if (!ValidateInventorProperties(
                                owner,
                                session,
                                progress))
                        {
                            return false;
                        }


                        progress.AddInformation(
                            StampaCartellineProcessSection.Inventor,
                            "Verifica delle proprietà modificate.");

                        if (!WriteModifiedInventorProperties(
                                owner,
                                session,
                                progress))
                        {
                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Inventor,
                            "Blocco Scrittura in Inventor completato.");

                        return true;
                    });
            }


            /*
             * Se l'utente ha chiuso con X
             * la finestra Check-Out:
             *
             * - non parte nessun blocco successivo;
             * - tutti i blocchi inclusi vengono marcati
             *   completati;
             * - la barra arriva al 100%.
             */
            if (_cancelEntireProcess)
            {
                CompleteRemainingSectionsAfterCancellation(
                    progress,
                    includeWord,
                    includeExcel,
                    includePdf,
                    includeAssemblyGroups);

                return;
            }


            /*
             * ==================================================
             * 2 - WORD CARTELLINE
             * ==================================================
             */
            if (includeWord)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Word,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Word,
                            "Avvio elaborazione Word Cartelline.");

                        bool result =
                            _wordTemplateProcessor.Process(
                                owner,
                                configuration,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Word,
                                "Il processo Word Cartelline non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Word,
                            "Blocco Word Cartelline completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 3 - EXCEL LAMIERE / DISTINTE
             * ==================================================
             */
            if (includeExcel)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Excel,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Excel,
                            "Avvio elaborazione Excel.");

                        bool result =
                            _excelDrawingsProcessor.Process(
                                owner,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Excel,
                                "Il processo Excel non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Excel,
                            "Blocco Excel completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 4 - PDF LAMIERE
             * ==================================================
             */
            if (includePdf)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.Pdf,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.Pdf,
                            "Avvio elaborazione PDF Lamiere.");

                        bool result =
                            _sheetMetalPdfProcessor.Process(
                                owner,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.Pdf,
                                "Il processo PDF Lamiere non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.Pdf,
                            "Blocco PDF Lamiere completato.");

                        return true;
                    });
            }


            /*
             * ==================================================
             * 5 - GRUPPI DI MONTAGGIO
             * ==================================================
             */
            if (includeAssemblyGroups)
            {
                ExecuteSection(
                    progress,
                    StampaCartellineProcessSection.AssemblyGroups,
                    () =>
                    {
                        progress.AddInformation(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Avvio Stampa Gruppi di montaggio.");

                        bool result =
                            _assemblyGroupsProcessor.Process(
                                owner,
                                configuration,
                                session,
                                progress);

                        if (!result)
                        {
                            progress.AddError(
                                StampaCartellineProcessSection.AssemblyGroups,
                                "Il processo Gruppi di montaggio non è stato completato.");

                            return false;
                        }


                        progress.AddSuccess(
                            StampaCartellineProcessSection.AssemblyGroups,
                            "Blocco Stampa Gruppi di montaggio completato.");

                        return true;
                    });
            }
        }


        /*
         * ==================================================
         * ESECUZIONE SICURA DI UN BLOCCO
         * ==================================================
         */
        private static void ExecuteSection(
            StampaCartellineProcessProgress progress,
            StampaCartellineProcessSection section,
            Func<bool> action)
        {
            try
            {
                action();
            }
            catch (Exception exception)
            {
                progress.AddError(
                    section,
                    "Errore non gestito:" +
                    System.Environment.NewLine +
                    GetRealExceptionMessage(
                        exception));
            }
            finally
            {
                progress.MarkCompleted(
                    section);

                System.Windows.Forms.Application
                    .DoEvents();
            }
        }


        private bool ValidateInventorProperties(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            List<DashboardPropertySession> missingProperties =
                session.InventorProperties
                    .Where(
                        property =>
                            string.IsNullOrWhiteSpace(
                                property.Value))
                    .ToList();


            if (missingProperties.Count == 0)
            {
                progress.AddSuccess(
                    StampaCartellineProcessSection.Inventor,
                    "Tutte le proprietà Inventor richieste sono valorizzate.");

                return true;
            }


            string missingNames =
                string.Join(
                    ", ",
                    missingProperties
                        .Select(
                            property =>
                                property.Tag));


            MessageBox.Show(
                owner,
                "Attenzione proprietà di Inventor mancanti.",
                "Stampa Cartelline",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);


            progress.AddError(
                StampaCartellineProcessSection.Inventor,
                "Proprietà Inventor mancanti: " +
                missingNames);


            return false;
        }


        private bool WriteModifiedInventorProperties(
            IWin32Window owner,
            StampaCartellineDashboardSession session,
            StampaCartellineProcessProgress progress)
        {
            List<DashboardPropertySession> modifiedProperties =
                session.InventorProperties
                    .Where(
                        property =>
                            !string.Equals(
                                property.Value?.Trim(),
                                property.OriginalValue?.Trim(),
                                StringComparison.Ordinal))
                    .ToList();


            if (modifiedProperties.Count == 0)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Inventor,
                    "Nessuna proprietà Inventor modificata da scrivere.");

                return true;
            }


            progress.AddInformation(
                StampaCartellineProcessSection.Inventor,
                "Proprietà Inventor modificate da scrivere: " +
                modifiedProperties.Count);


            /*
             * Popup MODELESS.
             *
             * OK
             * → scrive e continua.
             *
             * Salta scrittura
             * → non scrive ma continua.
             *
             * X
             * → annulla tutto il processo.
             */
            CheckOutConfirmationResult confirmationResult =
                ShowCheckOutConfirmationModeless(
                    owner);


            if (confirmationResult ==
                CheckOutConfirmationResult.SkipWrite)
            {
                progress.AddWarning(
                    StampaCartellineProcessSection.Inventor,
                    "Scrittura proprietà Inventor saltata dall'utente.");

                /*
                 * Non scriviamo nulla,
                 * ma il processo generale continua.
                 */
                return true;
            }


            if (confirmationResult ==
                CheckOutConfirmationResult.CancelProcess)
            {
                progress.AddWarning(
                    StampaCartellineProcessSection.Inventor,
                    "Processo annullato dall'utente prima della scrittura delle proprietà.");

                _cancelEntireProcess =
                    true;

                return false;
            }


            /*
             * CONFIRM:
             * logica di scrittura invariata.
             */
            bool written =
                _propertyWriter.WriteProperties(
                    modifiedProperties);


            if (written)
            {
                foreach (DashboardPropertySession property
                    in modifiedProperties)
                {
                    progress.AddSuccess(
                        StampaCartellineProcessSection.Inventor,
                        "Proprietà scritta: " +
                        property.Tag +
                        " = " +
                        (property.Value ?? string.Empty));
                }

                return true;
            }


            progress.AddError(
                StampaCartellineProcessSection.Inventor,
                "Non è stato possibile scrivere una o più proprietà in Inventor.");


            return false;
        }


        /*
         * ==================================================
         * POPUP CHECK-OUT MODELESS
         * ==================================================
         */
        private static CheckOutConfirmationResult
            ShowCheckOutConfirmationModeless(
                IWin32Window owner)
        {
            using CheckOutConfirmationForm form =
                new CheckOutConfirmationForm();


            if (owner != null)
            {
                form.Show(
                    owner);
            }
            else
            {
                form.Show();
            }


            form.BringToFront();


            /*
             * Il processo attende la scelta,
             * ma Inventor/PDM resta utilizzabile.
             */
            while (!form.SelectionCompleted &&
                   !form.IsDisposed)
            {
                System.Windows.Forms.Application
                    .DoEvents();

                Thread.Sleep(
                    10);
            }


            return form.Result;
        }


        private enum CheckOutConfirmationResult
        {
            Confirm,
            SkipWrite,
            CancelProcess
        }


        private sealed class CheckOutConfirmationForm :
            Form
        {
            public bool SelectionCompleted
            {
                get;
                private set;
            }


            public CheckOutConfirmationResult Result
            {
                get;
                private set;
            } =
                CheckOutConfirmationResult.CancelProcess;


            public CheckOutConfirmationForm()
            {
                InitializeComponent();
            }


            private void InitializeComponent()
            {
                Text =
                    "Stampa Cartelline";

                StartPosition =
                    FormStartPosition.CenterScreen;

                ClientSize =
                    new Size(
                        540,
                        180);

                FormBorderStyle =
                    FormBorderStyle.FixedDialog;

                MaximizeBox =
                    false;

                MinimizeBox =
                    false;

                ShowInTaskbar =
                    false;


                Label messageLabel =
                    new Label
                    {
                        Text =
                            "Stiamo per scrivere le proprietà modificate in Inventor." +
                            System.Environment.NewLine +
                            System.Environment.NewLine +
                            "Assicurati prima di premere OK di avere l'assieme in Check-Out.",

                        AutoSize =
                            false,

                        Location =
                            new System.Drawing.Point(
                                25,
                                25),

                        Size =
                            new Size(
                                490,
                                80),

                        Font =
                            new Font(
                                "Segoe UI",
                                9.5F,
                                FontStyle.Regular)
                    };


                Button okButton =
                    new Button
                    {
                        Text =
                            "OK",

                        Size =
                            new Size(
                                95,
                                34),

                        Location =
                            new System.Drawing.Point(
                                285,
                                125)
                    };


                Button skipButton =
                    new Button
                    {
                        Text =
                            "Salta scrittura",

                        Size =
                            new Size(
                                130,
                                34),

                        Location =
                            new System.Drawing.Point(
                                390,
                                125)
                    };


                /*
                 * OK:
                 * scrittura proprietà.
                 */
                okButton.Click +=
                    delegate
                    {
                        Result =
                            CheckOutConfirmationResult.Confirm;

                        SelectionCompleted =
                            true;

                        Close();
                    };


                /*
                 * SALTA SCRITTURA:
                 *
                 * non scrive le proprietà,
                 * ma il processo continua.
                 */
                skipButton.Click +=
                    delegate
                    {
                        Result =
                            CheckOutConfirmationResult.SkipWrite;

                        SelectionCompleted =
                            true;

                        Close();
                    };


                /*
                 * X:
                 *
                 * se la finestra viene chiusa senza
                 * aver premuto uno dei due pulsanti,
                 * annulliamo l'intero processo.
                 */
                FormClosing +=
                    delegate
                    {
                        if (!SelectionCompleted)
                        {
                            Result =
                                CheckOutConfirmationResult.CancelProcess;

                            SelectionCompleted =
                                true;
                        }
                    };


                Controls.Add(
                    messageLabel);

                Controls.Add(
                    okButton);

                Controls.Add(
                    skipButton);


                AcceptButton =
                    okButton;

                /*
                 * NON assegniamo CancelButton.
                 *
                 * In questo modo ESC non viene
                 * interpretato automaticamente
                 * come "Salta scrittura".
                 *
                 * L'annullamento completo resta
                 * legato alla X della finestra.
                 */
            }
        }


        /*
         * ==================================================
         * ANNULLAMENTO COMPLETO PROCESSO
         * ==================================================
         *
         * Viene chiamato solamente quando l'utente
         * chiude con X il popup Check-Out.
         *
         * I blocchi successivi NON vengono eseguiti,
         * ma vengono marcati completati per portare
         * immediatamente la barra al 100%.
         */
        private static void CompleteRemainingSectionsAfterCancellation(
            StampaCartellineProcessProgress progress,
            bool includeWord,
            bool includeExcel,
            bool includePdf,
            bool includeAssemblyGroups)
        {
            if (includeWord)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Word,
                    "Funzione saltata per annullamento del processo.");

                progress.MarkCompleted(
                    StampaCartellineProcessSection.Word);
            }


            if (includeExcel)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Excel,
                    "Funzione saltata per annullamento del processo.");

                progress.MarkCompleted(
                    StampaCartellineProcessSection.Excel);
            }


            if (includePdf)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.Pdf,
                    "Funzione saltata per annullamento del processo.");

                progress.MarkCompleted(
                    StampaCartellineProcessSection.Pdf);
            }


            if (includeAssemblyGroups)
            {
                progress.AddInformation(
                    StampaCartellineProcessSection.AssemblyGroups,
                    "Funzione saltata per annullamento del processo.");

                progress.MarkCompleted(
                    StampaCartellineProcessSection.AssemblyGroups);
            }


            System.Windows.Forms.Application
                .DoEvents();
        }


        private static string GetRealExceptionMessage(
            Exception exception)
        {
            Exception realException =
                exception;


            while (realException.InnerException != null)
            {
                realException =
                    realException.InnerException;
            }


            return realException.Message;
        }
    }
}