﻿using Marpatech_8.Features.Core.Settings;
using Marpatech_8.Features.StampaCartelline.Managers;
using Marpatech_8.Features.StampaCartelline.Models;
using Marpatech_8.Features.StampaCartelline.Services;
using Marpatech_8.Features.StampaCartelline.Controls;
using System;
using System.Windows.Forms;
using CoreWindowSettings =
    Marpatech_8.Features.Core.Settings.WindowSettings;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.StampaCartelline.Forms
{
    public class StampaCartellineDashboardForm : Form
    {
        private readonly Inventor.Application _inventorApp;
        private readonly bool _isDarkTheme;
        private readonly CoreWindowSettings _windowSettings;

        private ComboBox? cmbConfigurazione;
        private Label? lblDescrizioneConfigurazione;
        private FlowLayoutPanel? propertiesPanel;
        private Button? btnRefreshProperties;
        private CheckBox?
    chkIncludePrintFolders;
        private CheckBox?
            chkPrintingStl;

        private TextBox?
            txtStlDescription;

        private bool
            _isShowingStlPlaceholder;
        private Button?
    btnStart;
        private DashboardPathSection?
            _excelSection;

        private DashboardPathSection?
            _pdfSection;

        private Panel?
    _excelSeparator;

        private Panel?
            _pdfSeparator;

        private Panel?
    _assemblyGroupsCard;

        private DashboardAssemblyGroupsSection?
    _assemblyGroupsSection;

        private Panel?
            _assemblyGroupsSeparator;

        private DashboardConfigurationManager?
    _configurationManager;

        private StampaCartellineDashboardSession?
    _currentSession;

        private DashboardInventorPropertyReader?
    _propertyReader;

        private StampaCartellineProcessRunner?
    _processRunner;


        public StampaCartellineDashboardForm(
            Inventor.Application inventorApp,
            bool isDarkTheme)
        {
            _inventorApp = inventorApp;
            _isDarkTheme = isDarkTheme;

            _windowSettings = WindowSettingsService.Load(
                "StampaCartellineDashboard",
                1100,
                760);

            InitializeComponent();

            WindowSettingsService.Apply(
                this,
                _windowSettings);

            _propertyReader =
                new DashboardInventorPropertyReader(
                    _inventorApp);

            _processRunner =
                new StampaCartellineProcessRunner(
                    _inventorApp);

            InitializeConfigurationManager();
        }
        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor subtitleColor = _isDarkTheme
                ? DrawingColor.FromArgb(170, 178, 190)
                : DrawingColor.FromArgb(100, 116, 139);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            this.Text = "Stampa Cartelline";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(1100, 760);
            this.MinimumSize = new DrawingSize(900, 650);
            this.BackColor = backgroundColor;
            this.FormClosing +=
                StampaCartellineDashboardForm_FormClosing;

            Label title = new Label();
            title.Text = "Stampa Cartelline";
            title.Font = new DrawingFont(
                "Segoe UI",
                26,
                DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 20);

            Label subtitle = new Label();
            subtitle.Text =
                "";
            subtitle.Font = new DrawingFont(
                "Segoe UI",
                10,
                DrawingFontStyle.Regular);
            subtitle.ForeColor = subtitleColor;
            subtitle.AutoSize = true;
            subtitle.Location = new DrawingPoint(38, 68);

            Button btnSettings = CreateButton(
                "⚙",
                DrawingColor.FromArgb(100, 116, 139),
                50,
                42);

            btnSettings.Font = new DrawingFont(
                "Segoe UI",
                18,
                DrawingFontStyle.Regular);

            btnSettings.Anchor =
                AnchorStyles.Top | AnchorStyles.Right;

            btnSettings.Location = new DrawingPoint(
                this.ClientSize.Width - 85,
                30);

            btnSettings.Click += BtnSettings_Click;

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 105);
            mainPanel.Size = new DrawingSize(
                this.ClientSize.Width - 70,
                this.ClientSize.Height - 140);

            mainPanel.Anchor =
                AnchorStyles.Top |
                AnchorStyles.Bottom |
                AnchorStyles.Left |
                AnchorStyles.Right;

            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(28);

            FlowLayoutPanel contentPanel =
                new FlowLayoutPanel();

            contentPanel.Dock = DockStyle.Fill;
            contentPanel.FlowDirection =
                FlowDirection.TopDown;
            contentPanel.WrapContents = false;
            contentPanel.AutoScroll = true;
            contentPanel.BackColor = cardColor;

            Panel configurationCard =
                new Panel();

            configurationCard.Size =
                new DrawingSize(930, 165);

            configurationCard.BackColor = cardColor;
            configurationCard.Margin =
                new Padding(0, 0, 0, 15);

            Label configurationTitle =
                CreateSectionTitle(
                    "1) Configurazione",
                    titleColor);

            configurationTitle.Location =
                new DrawingPoint(0, 0);

            Label lblConfigurazione =
                CreateLabel(
                    "Seleziona configurazione",
                    titleColor);

            lblConfigurazione.Location =
                new DrawingPoint(0, 50);

            cmbConfigurazione =
                new ComboBox();

            cmbConfigurazione.Location =
                new DrawingPoint(0, 77);

            cmbConfigurazione.Size =
                new DrawingSize(400, 32);

            cmbConfigurazione.Font =
                new DrawingFont("Segoe UI", 10);

            cmbConfigurazione.DropDownStyle =
                ComboBoxStyle.DropDownList;

            cmbConfigurazione.BackColor =
                inputColor;

            cmbConfigurazione.ForeColor =
                titleColor;

            cmbConfigurazione.SelectedIndexChanged +=
                CmbConfigurazione_SelectedIndexChanged;

            Label lblDescrizioneTitolo =
                CreateLabel(
                    "Descrizione",
                    titleColor);

            lblDescrizioneTitolo.Location =
                new DrawingPoint(440, 50);

            lblDescrizioneConfigurazione =
                new Label();

            lblDescrizioneConfigurazione.Text =
                "Nessuna configurazione selezionata.";

            lblDescrizioneConfigurazione.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            lblDescrizioneConfigurazione.ForeColor =
                subtitleColor;

            lblDescrizioneConfigurazione.Location =
                new DrawingPoint(440, 77);

            lblDescrizioneConfigurazione.Size =
                new DrawingSize(450, 65);

            lblDescrizioneConfigurazione.AutoEllipsis =
                true;

            configurationCard.Controls.Add(
                configurationTitle);

            configurationCard.Controls.Add(
                lblConfigurazione);

            configurationCard.Controls.Add(
                cmbConfigurazione);

            configurationCard.Controls.Add(
                lblDescrizioneTitolo);

            configurationCard.Controls.Add(
                lblDescrizioneConfigurazione);

            contentPanel.Controls.Add(
                configurationCard);

            Panel separator1 = new Panel();
            separator1.Size = new DrawingSize(930, 2);
            separator1.BackColor = _isDarkTheme
                ? DrawingColor.FromArgb(70, 75, 85)
                : DrawingColor.FromArgb(203, 213, 225);
            separator1.Margin = new Padding(0, 5, 0, 20);

            Panel propertiesCard = new Panel();
            propertiesCard.Size = new DrawingSize(930, 380);
            propertiesCard.BackColor = cardColor;
            propertiesCard.Margin = new Padding(0, 0, 0, 15);

            Label propertiesTitle = CreateSectionTitle(
                "2) Proprietà Inventor",
                titleColor);

            propertiesTitle.Location = new DrawingPoint(0, 0);

            Label propertiesSubtitle = new Label();
            propertiesSubtitle.Text =
                "Valori delle proprietà configurate per la cartellina selezionata.";
            propertiesSubtitle.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Regular);
            propertiesSubtitle.ForeColor = subtitleColor;
            propertiesSubtitle.AutoSize = true;
            propertiesSubtitle.Location = new DrawingPoint(0, 38);

            btnRefreshProperties = CreateButton(
                "🔄",
                DrawingColor.FromArgb(37, 99, 235),
                48,
                38);

            btnRefreshProperties.Location = new DrawingPoint(820, 0);
            btnRefreshProperties.Click += BtnRefreshProperties_Click;

            propertiesPanel = new FlowLayoutPanel();
            propertiesPanel.Location = new DrawingPoint(0, 75);
            propertiesPanel.Size = new DrawingSize(890, 175);
            propertiesPanel.FlowDirection = FlowDirection.TopDown;
            propertiesPanel.WrapContents = false;
            propertiesPanel.AutoScroll = true;
            propertiesPanel.BackColor = cardColor;
            propertiesPanel.BorderStyle = BorderStyle.None;

            chkIncludePrintFolders =
    new CheckBox();

            chkIncludePrintFolders.Text =
                "Includi nella stampa le cartelline";

            chkIncludePrintFolders.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            chkIncludePrintFolders.ForeColor =
                titleColor;

            chkIncludePrintFolders.AutoSize =
                true;

            chkIncludePrintFolders.Location =
                new DrawingPoint(
                    0,
                    260);

            chkIncludePrintFolders.Checked =
                true;

            chkIncludePrintFolders.CheckedChanged +=
                ChkIncludePrintFolders_CheckedChanged;

            chkPrintingStl =
    new CheckBox();

            chkPrintingStl.Text =
                "Stai stampando uno o più STL?";

            chkPrintingStl.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            chkPrintingStl.ForeColor =
                titleColor;

            chkPrintingStl.AutoSize =
                true;

            chkPrintingStl.Location =
                new DrawingPoint(
                    0,
                    295);

            chkPrintingStl.Checked =
                false;

            chkPrintingStl.CheckedChanged +=
                ChkPrintingStl_CheckedChanged;


            txtStlDescription =
                new TextBox();

            txtStlDescription.Location =
                new DrawingPoint(
                    0,
                    330);

            txtStlDescription.Size =
                new DrawingSize(
                    850,
                    28);

            txtStlDescription.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            txtStlDescription.BackColor =
                inputColor;

            txtStlDescription.ForeColor =
                subtitleColor;

            txtStlDescription.BorderStyle =
                BorderStyle.FixedSingle;

            txtStlDescription.Visible =
                false;

            txtStlDescription.Enter +=
                TxtStlDescription_Enter;

            txtStlDescription.Leave +=
                TxtStlDescription_Leave;

            txtStlDescription.TextChanged +=
                TxtStlDescription_TextChanged;

            propertiesCard.Controls.Add(propertiesTitle);
            propertiesCard.Controls.Add(propertiesSubtitle);
            propertiesCard.Controls.Add(btnRefreshProperties);
            propertiesCard.Controls.Add(propertiesPanel);

            propertiesCard.Controls.Add(
                 chkIncludePrintFolders);

            propertiesCard.Controls.Add(
                chkPrintingStl);

            propertiesCard.Controls.Add(
                txtStlDescription);

            contentPanel.Controls.Add(separator1);
            contentPanel.Controls.Add(propertiesCard);


            _excelSeparator =
                CreateSectionSeparator();

            _excelSection =
                CreatePathSection(
                    "Distinte Excel",
                    "Percorsi Excel utilizzati nella sessione corrente.",
                    cardColor,
                    titleColor,
                    subtitleColor,
                    inputColor,
                    3);

            _pdfSeparator =
                CreateSectionSeparator();

            _pdfSection =
                CreatePathSection(
                    "PDF Lamiera",
                    "Percorsi PDF utilizzati nella sessione corrente.",
                    cardColor,
                    titleColor,
                    subtitleColor,
                    inputColor,
                    4);

            contentPanel.Controls.Add(
                _excelSeparator);

            contentPanel.Controls.Add(
                _excelSection.Card);

            contentPanel.Controls.Add(
                _pdfSeparator);

            contentPanel.Controls.Add(
                _pdfSection.Card);

            _assemblyGroupsSeparator =
    CreateSectionSeparator();

            _assemblyGroupsCard =
                new Panel();

            _assemblyGroupsCard.Size =
                new DrawingSize(
                    930,
                    330);

            _assemblyGroupsCard.BackColor =
                cardColor;

            _assemblyGroupsCard.Margin =
                new Padding(
                    0,
                    0,
                    0,
                    15);

            Label assemblyGroupsTitle =
                CreateSectionTitle(
                    "5) Gruppi di montaggio",
                    titleColor);

            assemblyGroupsTitle.Location =
                new DrawingPoint(
                    0,
                    0);

            Label assemblyGroupsSubtitle =
                new Label();

            assemblyGroupsSubtitle.Text =
                "Configura i gruppi di montaggio per la sessione corrente.";

            assemblyGroupsSubtitle.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Regular);

            assemblyGroupsSubtitle.ForeColor =
                subtitleColor;

            assemblyGroupsSubtitle.AutoSize =
                true;

            assemblyGroupsSubtitle.Location =
                new DrawingPoint(
                    0,
                    38);

            _assemblyGroupsCard.Controls.Add(
                assemblyGroupsTitle);

            _assemblyGroupsCard.Controls.Add(
                assemblyGroupsSubtitle);

            _assemblyGroupsSection =
                new DashboardAssemblyGroupsSection(
                    _assemblyGroupsCard,
                    _isDarkTheme);

            _assemblyGroupsSection.ConfigureCodesRequested +=
                AssemblyGroupsSection_ConfigureCodesRequested;

            contentPanel.Controls.Add(
                _assemblyGroupsSeparator);

            contentPanel.Controls.Add(
                _assemblyGroupsCard);

            _assemblyGroupsSeparator.Visible =
                  false;

            _assemblyGroupsCard.Visible =
                false;

            Panel separator4 =
                CreateSectionSeparator();

            Panel startCard =
                new Panel();

            startCard.Size =
                new DrawingSize(
                    930,
                    115);

            startCard.BackColor =
                cardColor;

            startCard.Margin =
                new Padding(
                    0,
                    0,
                    0,
                    20);

            btnStart =
                CreateButton(
                    "AVVIA PROCESSO",
                    DrawingColor.FromArgb(
                        22,
                        163,
                        74),
                    760,
                    60);

            btnStart.Font =
                new DrawingFont(
                    "Segoe UI",
                    14,
                    DrawingFontStyle.Bold);

            btnStart.Location =
                new DrawingPoint(
                    85,
                    25);

            btnStart.Click +=
                BtnStart_Click;

            startCard.Controls.Add(
                btnStart);

            contentPanel.Controls.Add(
                separator4);

            contentPanel.Controls.Add(
                startCard);

            mainPanel.Controls.Add(
                contentPanel);

            this.Controls.Add(title);
            this.Controls.Add(subtitle);
            this.Controls.Add(btnSettings);
            this.Controls.Add(mainPanel);
        }

        private Label CreateSectionTitle(
            string text,
            DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont(
                "Segoe UI",
                15,
                DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;

            return label;
        }

        private Label CreateLabel(
            string text,
            DrawingColor color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            label.ForeColor = color;
            label.AutoSize = true;

            return label;
        }

        private Panel CreatePropertyRow(
            DashboardPropertySession property)
        {
            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor inputColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            Panel row = new Panel();
            row.Size = new DrawingSize(850, 38);
            row.Margin = new Padding(0, 0, 0, 6);

            Label label = new Label();
            label.Text = property.Tag;
            label.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);

            label.ForeColor = titleColor;
            label.Location = new DrawingPoint(0, 7);
            label.Size = new DrawingSize(260, 24);

            TextBox textBox = new TextBox();
            textBox.Text = property.Value;
            textBox.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Regular);

            textBox.Location = new DrawingPoint(280, 4);
            textBox.Size = new DrawingSize(500, 28);
            textBox.ForeColor = titleColor;
            textBox.BackColor = inputColor;
            textBox.BorderStyle = BorderStyle.FixedSingle;

            textBox.ReadOnly = false;

            textBox.Tag = property;

            textBox.TextChanged +=
                DashboardPropertyTextBox_TextChanged;

            row.Controls.Add(label);
            row.Controls.Add(textBox);

            return row;
        }

        private DashboardPathSection
            CreatePathSection(
                string title,
                string subtitle,
                DrawingColor cardColor,
                DrawingColor titleColor,
                DrawingColor subtitleColor,
                DrawingColor inputColor,
                int sectionNumber)
        {
            Panel card =
                new Panel();

            card.Size =
                new DrawingSize(930, 300);

            card.BackColor =
                cardColor;

            card.Margin =
                new Padding(0, 0, 0, 15);

            Label lblTitle =
                CreateSectionTitle(
                    $"{sectionNumber}) {title}",
                    titleColor);

            lblTitle.Location =
                new DrawingPoint(0, 0);

            Label lblSubtitle =
                new Label();

            lblSubtitle.Text =
                subtitle;

            lblSubtitle.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            lblSubtitle.ForeColor =
                subtitleColor;

            lblSubtitle.AutoSize =
                true;

            lblSubtitle.Location =
                new DrawingPoint(0, 38);

            Label lblInitial =
                CreateLabel(
                    "Percorso iniziale",
                    titleColor);

            lblInitial.Location =
                new DrawingPoint(0, 78);

            TextBox txtInitial =
                new TextBox();

            txtInitial.Location =
                new DrawingPoint(0, 103);

            txtInitial.Size =
                new DrawingSize(760, 28);

            txtInitial.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            txtInitial.BackColor =
                inputColor;

            txtInitial.ForeColor =
                titleColor;

            txtInitial.BorderStyle =
                BorderStyle.FixedSingle;

            Button btnInitial =
                CreateButton(
                    "📁",
                    DrawingColor.FromArgb(
                        147,
                        51,
                        234),
                    48,
                    30);

            btnInitial.Location =
                new DrawingPoint(780, 101);

            Label lblFinal =
                CreateLabel(
                    "Percorso finale",
                    titleColor);

            lblFinal.Location =
                new DrawingPoint(0, 145);

            TextBox txtFinal =
                new TextBox();

            txtFinal.Location =
                new DrawingPoint(0, 170);

            txtFinal.Size =
                new DrawingSize(760, 28);

            txtFinal.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            txtFinal.BackColor =
                inputColor;

            txtFinal.ForeColor =
                titleColor;

            txtFinal.BorderStyle =
                BorderStyle.FixedSingle;

            Button btnFinal =
                CreateButton(
                    "📁",
                    DrawingColor.FromArgb(
                        147,
                        51,
                        234),
                    48,
                    30);

            btnFinal.Location =
                new DrawingPoint(780, 168);

            Label lblAttribute =
                CreateLabel(
                    "Attributo determinante",
                    titleColor);

            lblAttribute.Location =
                new DrawingPoint(0, 218);

            Label lblValue =
                new Label();

            lblValue.Location =
                new DrawingPoint(0, 244);

            lblValue.AutoSize =
                true;

            lblValue.ForeColor =
                subtitleColor;

            lblValue.Font =
                new DrawingFont(
                    "Segoe UI",
                    9);

            CheckBox chkInclude =
                new CheckBox();

            chkInclude.Text =
                "Includi nel processo di stampa";

            chkInclude.Location =
                new DrawingPoint(550, 218);

            chkInclude.AutoSize =
                true;

            chkInclude.ForeColor =
                titleColor;

            chkInclude.Font =
                new DrawingFont(
                    "Segoe UI",
                    9,
                    DrawingFontStyle.Bold);

            card.Controls.Add(lblTitle);
            card.Controls.Add(lblSubtitle);
            card.Controls.Add(lblInitial);
            card.Controls.Add(txtInitial);
            card.Controls.Add(btnInitial);
            card.Controls.Add(lblFinal);
            card.Controls.Add(txtFinal);
            card.Controls.Add(btnFinal);
            card.Controls.Add(lblAttribute);
            card.Controls.Add(lblValue);
            card.Controls.Add(chkInclude);

            txtInitial.Tag =
                card;

            txtFinal.Tag =
                card;

            chkInclude.Tag =
                card;

            btnInitial.Tag =
                txtInitial;

            btnFinal.Tag =
                txtFinal;

            txtInitial.TextChanged +=
    PathSectionTextChanged;

            txtFinal.TextChanged +=
                PathSectionTextChanged;

            chkInclude.CheckedChanged +=
                PathSectionCheckedChanged;

            btnInitial.Click +=
                BrowseFolderClick;

            btnFinal.Click +=
                BrowseFolderClick;

            return
                new DashboardPathSection(
                    card,
                    txtInitial,
                    btnInitial,
                    lblAttribute,
                    lblValue,
                    txtFinal,
                    btnFinal,
                    chkInclude);
        }

        private void LoadSessionProperties()
        {
            if (propertiesPanel == null)
                return;

            propertiesPanel.Controls.Clear();

            if (_currentSession == null)
                return;

            foreach (DashboardPropertySession property
                in _currentSession.InventorProperties)
            {
                propertiesPanel.Controls.Add(
                    CreatePropertyRow(
                        property));
            }
        }

        private void LoadPathSection(
            DashboardPathSection section,
            DashboardPathSession session)
        {
            section.Session =
                session;

            section.InitialPathTextBox.Text =
                session.InitialPath;

            section.FinalPathTextBox.Text =
                session.FinalPath;

            section.IncludeInPrintCheckBox.Checked =
                session.IncludeInPrintProcess;

            section.DeterminingAttributeLabel.Text =
                string.IsNullOrWhiteSpace(
                    session.DeterminingAttributeTag)
                    ? "Attributo determinante: -"
                    : "Attributo determinante: " +
                      session.DeterminingAttributeTag;

            DashboardPropertySession? property =
                _currentSession?.GetPropertyByTag(
                    session.DeterminingAttributeTag);

            section.DeterminingValueLabel.Text =
                property == null
                    ? "Valore corrente: -"
                    : "Valore corrente: " +
                      property.Value;
        }
        private void ClearPathSection(
            DashboardPathSection section)
        {
            section.Session =
                null;

            section.InitialPathTextBox.Text =
                string.Empty;

            section.FinalPathTextBox.Text =
                string.Empty;

            section.IncludeInPrintCheckBox.Checked =
                false;

            section.DeterminingAttributeLabel.Text =
                "Attributo determinante: -";

            section.DeterminingValueLabel.Text =
                "Valore corrente: -";
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont(
                "Segoe UI",
                9,
                DrawingFontStyle.Bold);
            button.Size = new DrawingSize(
                width,
                height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void CmbConfigurazione_SelectedIndexChanged(
            object? sender,
            EventArgs e)
        {
            UpdateSelectedConfiguration();
        }

        private void BtnSettings_Click(
            object? sender,
            EventArgs e)
        {
            StampaCartellineSettingsForm form =
                new StampaCartellineSettingsForm(
                    _isDarkTheme);

            form.Show(this);
            form.Activate();
        }

        private void StampaCartellineDashboardForm_FormClosing(
            object? sender,
            FormClosingEventArgs e)
        {
            WindowSettingsService.Save(
                this,
                "StampaCartellineDashboard");
        }
        private void BtnRefreshProperties_Click(
            object? sender,
            EventArgs e)
        {
            if (_currentSession == null)
                return;

            _propertyReader?.ReadProperties(
                _currentSession);

            LoadSessionProperties();
        }
        private void InitializeConfigurationManager()
        {
            if (cmbConfigurazione == null)
                return;

            _configurationManager =
                new DashboardConfigurationManager(
                    cmbConfigurazione);

            _configurationManager.Load();

            UpdateSelectedConfiguration();
        }
        private void UpdateSelectedConfiguration()
        {
            if (lblDescrizioneConfigurazione == null)
                return;

            PrintFolderConfiguration? configuration =
                _configurationManager?
                    .SelectedConfiguration;

            if (configuration == null)
            {
                _currentSession = null;

                lblDescrizioneConfigurazione.Text =
                    "Nessuna configurazione disponibile.";

                propertiesPanel?.Controls.Clear();

                if (_excelSection != null)
                    ClearPathSection(_excelSection);

                if (_pdfSection != null)
                    ClearPathSection(_pdfSection);

                _assemblyGroupsSection?.Clear();

                HideDynamicSections();

                LoadStlSession();

                return;
            }

            UpdateDynamicSectionsVisibility(
                configuration);

            CreateDashboardSession(
                configuration);

            StampaCartellineDashboardSession? session =
                _currentSession;

            if (session == null)
                return;

            _propertyReader?.ReadProperties(
                session);

            lblDescrizioneConfigurazione.Text =
                string.IsNullOrWhiteSpace(
                    session.ConfigurationDescription)
                    ? "Nessuna descrizione."
                    : session.ConfigurationDescription;

            LoadSessionProperties();
            LoadStlSession();

            _assemblyGroupsSection?.LoadSession(
                session);

            if (_excelSection != null)
            {
                LoadPathSection(
                    _excelSection,
                    session.ExcelDrawings);
            }

            if (_pdfSection != null)
            {
                LoadPathSection(
                    _pdfSection,
                    session.SheetMetalPdfs);
            }
        }
        private void CreateDashboardSession(
            PrintFolderConfiguration configuration)
        {
            _currentSession =
                new StampaCartellineDashboardSession
                {
                    ConfigurationName =
                        configuration.Name,

                    ConfigurationDescription =
                        configuration.Description,

                    ExcelDrawings =
                        new DashboardPathSession
                        {
                            InitialPath =
                                configuration.ExcelDrawings
                                    ?.InitialPath
                                ?? string.Empty,

                            DeterminingAttributeTag =
                                configuration.ExcelDrawings
                                    ?.DeterminingAttributeTag
                                ?? string.Empty,

                            FinalPath =
                                configuration.ExcelDrawings
                                    ?.FinalPath
                                ?? string.Empty,

                            IncludeInPrintProcess =
                                configuration.ExcelDrawings
                                    ?.IncludeInPrintProcess
                                ?? false
                        },

                    SheetMetalPdfs =
                        new DashboardPathSession
                        {
                            InitialPath =
                                configuration.SheetMetalPdfs
                                    ?.InitialPath
                                ?? string.Empty,

                            DeterminingAttributeTag =
                                configuration.SheetMetalPdfs
                                    ?.DeterminingAttributeTag
                                ?? string.Empty,

                            FinalPath =
                                configuration.SheetMetalPdfs
                                    ?.FinalPath
                                ?? string.Empty,

                            IncludeInPrintProcess =
                                configuration.SheetMetalPdfs
                                    ?.IncludeInPrintProcess
                                ?? false
                        }
                };

            foreach (InventorPropertyDefinition property
                in configuration.InventorProperties)
            {
                _currentSession.InventorProperties.Add(
                    new DashboardPropertySession
                    {
                        Tag =
                            property.Tag,

                        InventorPropertyName =
                            property.InventorPropertyName,

                        Editable =
                            property.EditableFromDashboard,

                        Value =
                            string.Empty
                    });
            }
        }    

        private Panel CreateSectionSeparator()
        {
            Panel separator =
                new Panel();

            separator.Size =
                new DrawingSize(930, 2);

            separator.BackColor =
                _isDarkTheme
                    ? DrawingColor.FromArgb(
                        70,
                        75,
                        85)
                    : DrawingColor.FromArgb(
                        203,
                        213,
                        225);

            separator.Margin =
                new Padding(
                    0,
                    5,
                    0,
                    20);

            return separator;
        }
        private void DashboardPropertyTextBox_TextChanged(
    object? sender,
    EventArgs e)
        {
            if (sender is not TextBox textBox)
                return;

            if (textBox.Tag is not DashboardPropertySession property)
                return;

            property.Value = textBox.Text;
        }

        private void PathSectionCheckedChanged(
            object? sender,
            EventArgs e)
        {
            if (sender is not CheckBox checkBox)
                return;

            if (checkBox.Parent is not Panel panel)
                return;

            DashboardPathSection? section =
                GetPathSectionFromPanel(
                    panel);

            if (section?.Session == null)
                return;

            section.Session.IncludeInPrintProcess =
                checkBox.Checked;
        }

        private void PathSectionTextChanged(
            object? sender,
            EventArgs e)
        {
            if (sender is not TextBox textBox)
                return;

            if (textBox.Parent is not Panel panel)
                return;

            DashboardPathSection? section =
                GetPathSectionFromPanel(
                    panel);

            if (section?.Session == null)
                return;

            if (ReferenceEquals(
                textBox,
                section.InitialPathTextBox))
            {
                section.Session.InitialPath =
                    textBox.Text;

                return;
            }

            if (ReferenceEquals(
                textBox,
                section.FinalPathTextBox))
            {
                section.Session.FinalPath =
                    textBox.Text;
            }
        }
        private DashboardPathSection?
            GetPathSectionFromPanel(
                Panel panel)
        {
            if (ReferenceEquals(
                panel,
                _excelSection?.Card))
            {
                return _excelSection;
            }

            if (ReferenceEquals(
                panel,
                _pdfSection?.Card))
            {
                return _pdfSection;
            }

            return null;
        }
        private void BrowseFolderClick(
    object? sender,
    EventArgs e)
        {
            if (sender is not Button button)
                return;

            if (button.Tag is not TextBox textBox)
                return;

            using FolderBrowserDialog dialog =
                new FolderBrowserDialog();

            dialog.Description =
                "Seleziona la cartella";

            dialog.UseDescriptionForTitle =
                true;

            string currentPath =
                textBox.Text.Trim();

            if (!string.IsNullOrWhiteSpace(
                    currentPath) &&
                System.IO.Directory.Exists(
                    currentPath))
            {
                dialog.SelectedPath =
                    currentPath;
            }

            DialogResult result =
                dialog.ShowDialog(this);

            if (result != DialogResult.OK)
                return;

            textBox.Text =
                dialog.SelectedPath;
        }
        private void UpdateDynamicSectionsVisibility(
            PrintFolderConfiguration configuration)
        {
            bool showExcel =
                configuration.ExcelDrawings
                    ?.IncludeInPrintProcess
                ?? false;

            bool showPdf =
                configuration.SheetMetalPdfs
                    ?.IncludeInPrintProcess
                ?? false;

            bool showAssemblyGroups =
                configuration.AssemblyGroups
                    ?.IncludeInPrintProcess
                ?? false;

            if (_excelSection != null)
            {
                _excelSection.Card.Visible =
                    showExcel;
            }

            if (_excelSeparator != null)
            {
                _excelSeparator.Visible =
                    showExcel;
            }

            if (_pdfSection != null)
            {
                _pdfSection.Card.Visible =
                    showPdf;
            }

            if (_pdfSeparator != null)
            {
                _pdfSeparator.Visible =
                    showPdf;
            }

            if (_assemblyGroupsCard != null)
            {
                _assemblyGroupsCard.Visible =
                    showAssemblyGroups;
            }

            if (_assemblyGroupsSeparator != null)
            {
                _assemblyGroupsSeparator.Visible =
                    showAssemblyGroups;
            }
        }
        private void HideDynamicSections()
        {
            if (_excelSection != null)
            {
                _excelSection.Card.Visible =
                    false;
            }

            if (_excelSeparator != null)
            {
                _excelSeparator.Visible =
                    false;
            }

            if (_pdfSection != null)
            {
                _pdfSection.Card.Visible =
                    false;
            }

            if (_pdfSeparator != null)
            {
                _pdfSeparator.Visible =
                    false;
            }

            if (_assemblyGroupsCard != null)
            {
                _assemblyGroupsCard.Visible =
                    false;
            }

            if (_assemblyGroupsSeparator != null)
            {
                _assemblyGroupsSeparator.Visible =
                    false;
            }
        }

        private void AssemblyGroupsSection_ConfigureCodesRequested(
    object? sender,
    EventArgs e)
        {
            StampaCartellineDashboardSession? session =
                _currentSession;

            if (session == null)
                return;

            using ConfigureAssemblyCodesForm form =
                new ConfigureAssemblyCodesForm(
                    session.SelectedAssemblyCodes,
                    _isDarkTheme);

            DialogResult result =
                form.ShowDialog(
                    this);

            if (result != DialogResult.OK)
                return;

            session.SelectedAssemblyCodes.Clear();

            foreach (AssemblyCodeSelection item
                in form.Result)
            {
                session.SelectedAssemblyCodes.Add(
                    item.Clone());
            }

            _assemblyGroupsSection?
                .RefreshSelectedCodesCount();
        }
        private void BtnStart_Click(
    object? sender,
    EventArgs e)
        {
            PrintFolderConfiguration? configuration =
                _configurationManager?
                    .SelectedConfiguration;

            if (configuration == null)
            {
                MessageBox.Show(
                    this,
                    "Seleziona una configurazione prima di avviare il processo.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            StampaCartellineDashboardSession? session =
                _currentSession;

            if (session == null)
            {
                MessageBox.Show(
                    this,
                    "La sessione della Dashboard non è disponibile.",
                    "Stampa Cartelline",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                return;
            }

            _processRunner?.Run(
                this,
                configuration,
                session);
        }
        private void ShowStlPlaceholder()
        {
            if (txtStlDescription == null)
                return;

            _isShowingStlPlaceholder =
                true;

            txtStlDescription.Text =
                "inserisci qui gli STL da inserire nella cartellina";

            txtStlDescription.ForeColor =
                _isDarkTheme
                    ? DrawingColor.FromArgb(
                        130,
                        138,
                        150)
                    : DrawingColor.FromArgb(
                        148,
                        163,
                        184);
        }
        private void HideStlPlaceholder()
        {
            if (txtStlDescription == null)
                return;

            if (!_isShowingStlPlaceholder)
                return;

            _isShowingStlPlaceholder =
                false;

            txtStlDescription.Text =
                string.Empty;

            txtStlDescription.ForeColor =
                _isDarkTheme
                    ? DrawingColor.White
                    : DrawingColor.FromArgb(
                        30,
                        41,
                        59);
        }
        private void ChkPrintingStl_CheckedChanged(
    object? sender,
    EventArgs e)
        {
            if (chkPrintingStl == null ||
                txtStlDescription == null)
            {
                return;
            }

            bool isChecked =
                chkPrintingStl.Checked;

            txtStlDescription.Visible =
                isChecked;

            if (_currentSession != null)
            {
                _currentSession.IsPrintingStl =
                    isChecked;
            }

            if (!isChecked)
                return;

            if (_currentSession == null ||
                string.IsNullOrWhiteSpace(
                    _currentSession.StlDescription))
            {
                ShowStlPlaceholder();
                return;
            }

            _isShowingStlPlaceholder =
                false;

            txtStlDescription.Text =
                _currentSession.StlDescription;
        }
        private void TxtStlDescription_Enter(
    object? sender,
    EventArgs e)
        {
            HideStlPlaceholder();
        }
        private void TxtStlDescription_Leave(
    object? sender,
    EventArgs e)
        {
            if (txtStlDescription == null)
                return;

            if (string.IsNullOrWhiteSpace(
                txtStlDescription.Text))
            {
                ShowStlPlaceholder();
            }
        }
        private void TxtStlDescription_TextChanged(
    object? sender,
    EventArgs e)
        {
            if (_currentSession == null ||
                txtStlDescription == null ||
                _isShowingStlPlaceholder)
            {
                return;
            }

            _currentSession.StlDescription =
                txtStlDescription.Text;
        }
        private void LoadStlSession()
        {
            if (chkIncludePrintFolders == null ||
                chkPrintingStl == null ||
                txtStlDescription == null)
            {
                return;
            }

            if (_currentSession == null)
            {
                chkIncludePrintFolders.Checked =
                    true;

                chkPrintingStl.Checked =
                    false;

                txtStlDescription.Visible =
                    false;

                txtStlDescription.Text =
                    string.Empty;

                _isShowingStlPlaceholder =
                    false;

                return;
            }

            chkIncludePrintFolders.Checked =
                _currentSession.IncludePrintFolders;

            chkPrintingStl.Checked =
                _currentSession.IsPrintingStl;

            txtStlDescription.Visible =
                _currentSession.IsPrintingStl;

            if (!_currentSession.IsPrintingStl)
                return;

            if (string.IsNullOrWhiteSpace(
                _currentSession.StlDescription))
            {
                ShowStlPlaceholder();
            }
            else
            {
                _isShowingStlPlaceholder =
                    false;

                txtStlDescription.Text =
                    _currentSession.StlDescription;
            }
        }
        private void ChkIncludePrintFolders_CheckedChanged(
    object? sender,
    EventArgs e)
        {
            if (_currentSession == null ||
                chkIncludePrintFolders == null)
            {
                return;
            }

            _currentSession.IncludePrintFolders =
                chkIncludePrintFolders.Checked;
        }
    }
}