﻿using System;
using System.IO;
using System.Windows.Forms;
using Marpatech_8.Features.Mail.Config;

namespace Marpatech_8.Features.Mail.Services
{
    public static class MailPathService
    {
        public static string BuildMailLinkPath(
            MailTypeConfig mailType,
            string searchValue)
        {
            if (string.IsNullOrWhiteSpace(mailType.BasePath))
                return "";

            if (string.IsNullOrWhiteSpace(searchValue))
                return "";

            if (!Directory.Exists(mailType.BasePath))
                return "";

            string foundFolder = FindFolder(
                mailType.BasePath,
                searchValue,
                mailType.FolderSearchMode);

            if (string.IsNullOrWhiteSpace(foundFolder))
                return "";

            string fullPath = CombinePath(foundFolder, mailType.FinalPath);

            if (Directory.Exists(fullPath))
                return fullPath;

            DialogResult result = MessageBox.Show(
                "Percorso precompilato completo non trovato.\n\n" +
                "Vuoi inserire il percorso trovato?\n\n" +
                foundFolder,
                "Percorso non trovato",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
                return foundFolder;

            return "";
        }

        public static string BuildExcelSearchPath(
            MailTypeConfig mailType,
            string searchValue)
        {
            if (string.IsNullOrWhiteSpace(mailType.BasePath))
                return "";

            if (string.IsNullOrWhiteSpace(searchValue))
                return "";

            if (!Directory.Exists(mailType.BasePath))
                return "";

            string foundFolder = FindFolder(
                mailType.BasePath,
                searchValue,
                mailType.FolderSearchMode);

            if (string.IsNullOrWhiteSpace(foundFolder))
                return "";

            string excelPath = CombinePath(
                foundFolder,
                mailType.ExcelFinalPath);

            if (Directory.Exists(excelPath))
                return excelPath;

            return foundFolder;
        }

        private static string FindFolder(
            string basePath,
            string searchValue,
            string searchMode)
        {
            try
            {
                foreach (string directory in Directory.GetDirectories(basePath))
                {
                    string folderName = Path.GetFileName(directory);

                    if (IsMatch(folderName, searchValue, searchMode))
                        return directory;
                }
            }
            catch
            {
            }

            return "";
        }

        private static bool IsMatch(
            string folderName,
            string searchValue,
            string searchMode)
        {
            if (string.Equals(searchMode, "Contiene", StringComparison.OrdinalIgnoreCase))
            {
                return folderName.Contains(
                    searchValue,
                    StringComparison.OrdinalIgnoreCase);
            }

            if (string.Equals(searchMode, "Uguale a", StringComparison.OrdinalIgnoreCase))
            {
                return string.Equals(
                    folderName,
                    searchValue,
                    StringComparison.OrdinalIgnoreCase);
            }

            return folderName.StartsWith(
                searchValue,
                StringComparison.OrdinalIgnoreCase);
        }

        private static string CombinePath(string basePath, string finalPath)
        {
            if (string.IsNullOrWhiteSpace(finalPath))
                return basePath;

            string cleanedFinalPath = finalPath.TrimStart('\\', '/');

            return Path.Combine(basePath, cleanedFinalPath);
        }
    }
}