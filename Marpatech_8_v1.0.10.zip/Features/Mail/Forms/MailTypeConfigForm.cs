﻿using System;
using System.Linq;
using System.Windows.Forms;
using Marpatech_8.Features.Mail.Config;
using DrawingColor = System.Drawing.Color;
using DrawingFont = System.Drawing.Font;
using DrawingFontStyle = System.Drawing.FontStyle;
using DrawingPoint = System.Drawing.Point;
using DrawingSize = System.Drawing.Size;

namespace Marpatech_8.Features.Mail.Forms
{
    public class MailTypeConfigForm : Form
    {
        private readonly bool _isDarkTheme;
        private readonly MailSettings _settings;
        private readonly MailTypeConfig _mailType;
        private readonly MailTypeConfigWindowSettings _windowSettings;
        private ContextMenuStrip? subjectContextMenu;
        private ContextMenuStrip? bodyContextMenu;

        private TextBox? txtDescription;
        private TextBox? txtTo;
        private TextBox? txtCc;
        private TextBox? txtSubject;
        private TextBox? txtBody;
        private TextBox? txtBasePath;
        private ComboBox? cmbSearchProperty;
        private ComboBox? cmbSearchMode;
        private TextBox? txtFinalPath;
        private TextBox? txtExcelFinalPath;
        private CheckBox? chkIncludeLink;
        private CheckBox? chkIncludeExcel;
        private CheckBox? chkEnabled;
        private CheckBox? chkConfigured;

        public MailTypeConfigForm(
            bool isDarkTheme,
            MailSettings settings,
            MailTypeConfig mailType)
        {
            _isDarkTheme = isDarkTheme;
            _settings = settings;
            _mailType = mailType;

            _windowSettings = MailTypeConfigWindowSettingsService.Load();
            InitializeComponent();
            ApplyWindowSettings();
            LoadValues();
            ResizeInputs();
        }


        private void InitializeComponent()
        {
            DrawingColor backgroundColor = _isDarkTheme
                ? DrawingColor.FromArgb(18, 18, 22)
                : DrawingColor.FromArgb(245, 247, 250);

            DrawingColor cardColor = _isDarkTheme
                ? DrawingColor.FromArgb(32, 34, 40)
                : DrawingColor.White;

            DrawingColor titleColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor labelColor = _isDarkTheme
                ? DrawingColor.FromArgb(220, 225, 235)
                : DrawingColor.FromArgb(30, 41, 59);

            DrawingColor inputBackColor = _isDarkTheme
                ? DrawingColor.FromArgb(43, 46, 55)
                : DrawingColor.White;

            DrawingColor inputForeColor = _isDarkTheme
                ? DrawingColor.White
                : DrawingColor.FromArgb(30, 41, 59);

            this.Text = "Configura Tipo Mail";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new DrawingSize(1100, 760);
            this.MinimumSize = new DrawingSize(1000, 680);
            this.BackColor = backgroundColor;
            this.FormClosing += MailTypeConfigForm_FormClosing;

            Label title = new Label();
            title.Text = "Configura Tipo Mail";
            title.Font = new DrawingFont("Segoe UI", 26, DrawingFontStyle.Bold);
            title.ForeColor = titleColor;
            title.AutoSize = true;
            title.Location = new DrawingPoint(35, 25);

            Button btnSave = CreateButton("Salva", DrawingColor.FromArgb(22, 163, 74), 135, 42);
            btnSave.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSave.Location = new DrawingPoint(this.ClientSize.Width - 315, 35);
            btnSave.Click += BtnSave_Click;

            Button btnCancel = CreateButton("Annulla", DrawingColor.FromArgb(100, 116, 139), 135, 42);
            btnCancel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnCancel.Location = new DrawingPoint(this.ClientSize.Width - 165, 35);
            btnCancel.Click += (s, e) => this.Close();

            this.Controls.Add(btnSave);
            this.Controls.Add(btnCancel);

            Panel mainPanel = new Panel();
            mainPanel.Location = new DrawingPoint(35, 95);
            mainPanel.Size = new DrawingSize(this.ClientSize.Width - 70, this.ClientSize.Height - 150);
            mainPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            mainPanel.BackColor = cardColor;
            mainPanel.Padding = new Padding(22);

            FlowLayoutPanel contentPanel = new FlowLayoutPanel();
            contentPanel.Dock = DockStyle.Fill;
            contentPanel.AutoScroll = true;
            contentPanel.WrapContents = false;
            contentPanel.FlowDirection = FlowDirection.TopDown;
            contentPanel.BackColor = cardColor;

            txtDescription = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtTo = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtCc = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtSubject = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtBody = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtBody.Multiline = true;
            txtBody.Height = 130;
            txtBody.ScrollBars = ScrollBars.Vertical;

            txtBasePath = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtFinalPath = CreateTextBox(inputBackColor, inputForeColor, 720);
            txtExcelFinalPath = CreateTextBox(inputBackColor, inputForeColor, 720);

            cmbSearchProperty = CreateComboBox(inputBackColor, inputForeColor, 360);
            cmbSearchMode = CreateComboBox(inputBackColor, inputForeColor, 260);

            foreach (MailVariableConfig variable in _settings.Variables)
            {
                cmbSearchProperty.Items.Add(variable.Name);
            }

            cmbSearchMode.Items.Add("Inizia con");
            cmbSearchMode.Items.Add("Contiene");
            cmbSearchMode.Items.Add("Uguale a");

            AddField(contentPanel, "Nome Configurazione", txtDescription, labelColor);
            AddField(contentPanel, "Destinatari/o", txtTo, labelColor);
            AddField(contentPanel, "Copia in Conoscenza (CC)", txtCc, labelColor);

            AddField(contentPanel, "Oggetto Mail", txtSubject, labelColor);
            AddField(contentPanel, "Testo Mail", txtBody, labelColor);

            Button btnVariables = CreateButton("Variabili Disponibili", DrawingColor.FromArgb(124, 58, 237), 220, 38);
            btnVariables.Margin = new Padding(0, 6, 0, 18);
            btnVariables.Click += BtnVariables_Click;
            contentPanel.Controls.Add(btnVariables);

            AddField(contentPanel, "Parte iniziale Percorso", txtBasePath, labelColor);
            AddField(contentPanel, "Variabile ricerca Cartella", cmbSearchProperty, labelColor);
            AddField(contentPanel, "Metodo ricerca Cartella", cmbSearchMode, labelColor);
            AddField(contentPanel, "Parte finale percorso Mail", txtFinalPath, labelColor);
            AddField(contentPanel, "Parte finale percorso Excel", txtExcelFinalPath, labelColor);

            chkIncludeLink = CreateCheckBox("Inserisci percorso nella Mail", labelColor);
            chkIncludeExcel = CreateCheckBox("Inserisci Excel nella Mail", labelColor);
            chkEnabled = CreateCheckBox("Tipo Mail Attivo", labelColor);
            chkConfigured = CreateCheckBox("Configurazione Completata", labelColor);

            contentPanel.Controls.Add(chkIncludeLink);
            contentPanel.Controls.Add(chkIncludeExcel);
            contentPanel.Controls.Add(chkEnabled);
            contentPanel.Controls.Add(chkConfigured);


            RefreshVariableContextMenus();

            mainPanel.Controls.Add(contentPanel);

            this.Controls.Add(title);
            this.Controls.Add(mainPanel);

            this.Resize += (s, e) =>
            {
                ResizeInputs();
            };
        }

        private TextBox CreateTextBox(
            DrawingColor backColor,
            DrawingColor foreColor,
            int width)
        {
            TextBox textBox = new TextBox();
            textBox.Width = width;
            textBox.Height = 32;
            textBox.Font = new DrawingFont("Segoe UI", 10);
            textBox.BackColor = backColor;
            textBox.ForeColor = foreColor;
            textBox.BorderStyle = BorderStyle.FixedSingle;

            return textBox;
        }

        private ComboBox CreateComboBox(
            DrawingColor backColor,
            DrawingColor foreColor,
            int width)
        {
            ComboBox comboBox = new ComboBox();
            comboBox.Width = width;
            comboBox.Height = 34;
            comboBox.Font = new DrawingFont("Segoe UI", 10);
            comboBox.BackColor = backColor;
            comboBox.ForeColor = foreColor;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;

            return comboBox;
        }

        private CheckBox CreateCheckBox(string text, DrawingColor foreColor)
        {
            CheckBox checkBox = new CheckBox();
            checkBox.Text = text;
            checkBox.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            checkBox.ForeColor = foreColor;
            checkBox.AutoSize = true;
            checkBox.Margin = new Padding(0, 6, 0, 4);

            return checkBox;
        }

        private Button CreateButton(
            string text,
            DrawingColor color,
            int width,
            int height)
        {
            Button button = new Button();
            button.Text = text;
            button.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            button.Size = new DrawingSize(width, height);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = color;
            button.ForeColor = DrawingColor.White;
            button.Cursor = Cursors.Hand;

            return button;
        }

        private void AddField(
            FlowLayoutPanel panel,
            string labelText,
            Control input,
            DrawingColor labelColor)
        {
            Label label = new Label();
            label.Text = labelText;
            label.Font = new DrawingFont("Segoe UI", 10, DrawingFontStyle.Bold);
            label.ForeColor = labelColor;
            label.AutoSize = true;
            label.Margin = new Padding(0, 8, 0, 4);

            input.Margin = new Padding(0, 0, 0, 8);

            panel.Controls.Add(label);
            panel.Controls.Add(input);
        }

        private void LoadValues()
        {
            if (txtDescription == null ||
                txtTo == null ||
                txtCc == null ||
                txtSubject == null ||
                txtBody == null ||
                txtBasePath == null ||
                txtFinalPath == null ||
                txtExcelFinalPath == null ||
                cmbSearchProperty == null ||
                cmbSearchMode == null ||
                chkIncludeLink == null ||
                chkIncludeExcel == null ||
                chkEnabled == null ||
                chkConfigured == null)
            {
                return;
            }

            txtDescription.Text = _mailType.Description;
            txtTo.Text = _mailType.To;
            txtCc.Text = _mailType.Cc;
            txtSubject.Text = _mailType.SubjectTemplate;
            txtBody.Text = _mailType.BodyTemplate;
            txtBasePath.Text = _mailType.BasePath;
            txtFinalPath.Text = _mailType.FinalPath;
            txtExcelFinalPath.Text = _mailType.ExcelFinalPath;

            cmbSearchProperty.SelectedItem = _mailType.SearchPropertyName;
            cmbSearchMode.SelectedItem = _mailType.FolderSearchMode;

            if (cmbSearchMode.SelectedIndex < 0)
                cmbSearchMode.SelectedIndex = 0;

            chkIncludeLink.Checked = _mailType.IncludeLink;
            chkIncludeExcel.Checked = _mailType.IncludeExcelAttachment;
            chkEnabled.Checked = _mailType.Enabled;
            chkConfigured.Checked = _mailType.IsConfigured;
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            if (txtDescription == null ||
                txtTo == null ||
                txtCc == null ||
                txtSubject == null ||
                txtBody == null ||
                txtBasePath == null ||
                txtFinalPath == null ||
                txtExcelFinalPath == null ||
                cmbSearchProperty == null ||
                cmbSearchMode == null ||
                chkIncludeLink == null ||
                chkIncludeExcel == null ||
                chkEnabled == null ||
                chkConfigured == null)
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show(
                    "Inserire una descrizione per il tipo mail.",
                    "Configura Tipo Mail",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);

                txtDescription.Focus();
                return;
            }

            _mailType.Description = txtDescription.Text.Trim();
            _mailType.To = txtTo.Text.Trim();
            _mailType.Cc = txtCc.Text.Trim();
            _mailType.SubjectTemplate = txtSubject.Text;
            _mailType.BodyTemplate = txtBody.Text;
            _mailType.BasePath = txtBasePath.Text.Trim();
            _mailType.SearchPropertyName = cmbSearchProperty.Text.Trim();
            _mailType.FolderSearchMode = cmbSearchMode.Text.Trim();
            _mailType.FinalPath = txtFinalPath.Text.Trim();
            _mailType.ExcelFinalPath = txtExcelFinalPath.Text.Trim();
            _mailType.IncludeLink = chkIncludeLink.Checked;
            _mailType.IncludeExcelAttachment = chkIncludeExcel.Checked;
            _mailType.Enabled = chkEnabled.Checked;

            if (chkConfigured.Checked)
            {
                _mailType.IsConfigured = true;
            }
            else
            {
                DialogResult result = MessageBox.Show(
                    "Stai salvando una configurazione senza la spunta su \"Configurazione completata\".\n\n" +
                    "Consideri questa configurazione pronta per l'utilizzo?",
                    "Configurazione non completata",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                _mailType.IsConfigured = result == DialogResult.Yes;
            }


            MailSettingsService.Save(_settings);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void BtnVariables_Click(object? sender, EventArgs e)
        {
            MailVariablesForm form = new MailVariablesForm(_isDarkTheme, _settings);
            form.ShowDialog();

            RefreshVariableLists();
            RefreshVariableContextMenus();
        }

        private void RefreshVariableLists()
        {
            if (cmbSearchProperty == null)
                return;

            string selected = cmbSearchProperty.Text;

            cmbSearchProperty.Items.Clear();

            foreach (MailVariableConfig variable in _settings.Variables)
            {
                cmbSearchProperty.Items.Add(variable.Name);
            }

            cmbSearchProperty.SelectedItem = selected;
        }

        private ContextMenuStrip CreateVariableContextMenu(TextBox textBox)
        {
            ContextMenuStrip menu = new ContextMenuStrip();

            ToolStripMenuItem parent = new ToolStripMenuItem("Inserisci variabile");

            foreach (MailVariableConfig variable in _settings.Variables.OrderBy(v => v.Name))
            {
                ToolStripMenuItem item = new ToolStripMenuItem("{" + variable.Name + "}");

                item.Click += (s, e) =>
                {
                    string tag = "{" + variable.Name + "}";
                    int selectionStart = textBox.SelectionStart;

                    textBox.Text = textBox.Text.Insert(selectionStart, tag);
                    textBox.SelectionStart = selectionStart + tag.Length;
                    textBox.Focus();
                };

                parent.DropDownItems.Add(item);
            }

            menu.Items.Add(parent);

            return menu;
        }
        private void ApplyWindowSettings()
        {
            this.Width = _windowSettings.Width;
            this.Height = _windowSettings.Height;

            if (_windowSettings.Left >= 0 && _windowSettings.Top >= 0)
            {
                this.StartPosition = FormStartPosition.Manual;
                this.Left = _windowSettings.Left;
                this.Top = _windowSettings.Top;
            }

            if (_windowSettings.IsMaximized)
                this.WindowState = FormWindowState.Maximized;
        }

        private void MailTypeConfigForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                _windowSettings.Width = this.Width;
                _windowSettings.Height = this.Height;
                _windowSettings.Left = this.Left;
                _windowSettings.Top = this.Top;
            }

            _windowSettings.IsMaximized =
                this.WindowState == FormWindowState.Maximized;

            MailTypeConfigWindowSettingsService.Save(_windowSettings);
        }
        private void RefreshVariableContextMenus()
        {
            if (txtSubject == null || txtBody == null)
                return;

            subjectContextMenu?.Dispose();
            bodyContextMenu?.Dispose();

            subjectContextMenu = CreateVariableContextMenu(txtSubject);
            bodyContextMenu = CreateVariableContextMenu(txtBody);

            txtSubject.ContextMenuStrip = subjectContextMenu;
            txtBody.ContextMenuStrip = bodyContextMenu;
        }

        private void ResizeInputs()
        {
            int newWidth = this.ClientSize.Width - 330;

            if (newWidth < 500)
                newWidth = 500;

            if (txtDescription != null) txtDescription.Width = newWidth;
            if (txtTo != null) txtTo.Width = newWidth;
            if (txtCc != null) txtCc.Width = newWidth;
            if (txtSubject != null) txtSubject.Width = newWidth;
            if (txtBody != null) txtBody.Width = newWidth;
            if (txtBasePath != null) txtBasePath.Width = newWidth;
            if (txtFinalPath != null) txtFinalPath.Width = newWidth;
            if (txtExcelFinalPath != null) txtExcelFinalPath.Width = newWidth;
        }
    }
}