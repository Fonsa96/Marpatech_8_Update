﻿using System;

namespace Marpatech_8.Features.Mail.Config
{
    public class MailTypeConfig
    {
        public Guid Id { get; set; } = Guid.NewGuid();

        public string Description { get; set; } = "Nuovo Tipo Mail";

        public string To { get; set; } = "";

        public string Cc { get; set; } = "";

        public string SubjectTemplate { get; set; } = "";

        public string BodyTemplate { get; set; } = "";

        public string BasePath { get; set; } = "";

        public string SearchPropertyName { get; set; } = "";

        public bool UseYearSubFolder { get; set; } = false;

        public string YearPropertyName { get; set; } = "";

        public string FolderSearchMode { get; set; } = "Inizia con";

        public string FinalPath { get; set; } = "";

        public string ExcelFinalPath { get; set; } = "";

        public bool IncludeLink { get; set; } = true;

        public bool IncludeExcelAttachment { get; set; } = false;

        public bool IsConfigured { get; set; } = false;

        public bool Enabled { get; set; } = true;
    }
}