﻿using System;
using Excel = Microsoft.Office.Interop.Excel;

namespace Marpatech_8.Features.Core.Office
{
    public static class ExcelAutomationService
    {
        public static Excel.Application? CreateApplication(
            bool visible,
            bool displayAlerts)
        {
            try
            {
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = visible;
                excelApp.DisplayAlerts = displayAlerts;
                return excelApp;
            }
            catch
            {
                return null;
            }
        }

        public static Excel.Workbook? OpenWorkbook(
            Excel.Application excelApp,
            string filePath,
            bool readOnly = true)
        {
            try
            {
                return excelApp.Workbooks.Open(
                    filePath,
                    ReadOnly: readOnly);
            }
            catch
            {
                return null;
            }
        }

        public static bool PrintWorkbook(
            Excel.Workbook workbook)
        {
            try
            {
                workbook.PrintOut(
                    Copies: 1,
                    Collate: true);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static void CloseWorkbook(
            Excel.Workbook? workbook,
            bool saveChanges)
        {
            try
            {
                if (workbook == null)
                    return;

                workbook.Close(
                    SaveChanges: saveChanges);
            }
            catch
            {
            }
        }

        public static void QuitApplication(
            Excel.Application? excelApp)
        {
            try
            {
                if (excelApp == null)
                    return;

                excelApp.Quit();
            }
            catch
            {
            }
        }
    }
}