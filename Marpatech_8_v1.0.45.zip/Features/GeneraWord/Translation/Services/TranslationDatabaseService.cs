﻿using System.IO;
using Marpatech_8.Features.GeneraWord.Translation.Models;
using Marpatech_8.Features.Core.Compatibility;

namespace Marpatech_8.Features.GeneraWord.Translation.Services
{
    public static class TranslationDatabaseService
    {
        private static string DatabasePath
        {
            get
            {
                return AppPathService.GetAppFolder(
                    "Features",
                    "GeneraWord",
                    "Translation",
                    "translations.json");
            }
        }

        public static TranslationDatabase Load()
        {
            try
            {
                return JsonCompatibilityService
                    .LoadFromFile<TranslationDatabase>(DatabasePath)
                    ?? new TranslationDatabase();
            }
            catch
            {
                return new TranslationDatabase();
            }
        }

        public static void Save(
            TranslationDatabase database)
        {
            JsonCompatibilityService.SaveToFile(
                DatabasePath,
                database);
        }
    }
}